"""Привязка рабочих столов к виртуальным headless-выводам HyprScreen.

ЕДИНЫЙ источник истины по воркспейсам: номер выбирает пользователь
(по умолчанию **6**), правила ставятся через :func:`hyprctl.set_workspace_rule`
и не накапливаются (``hl.workspace_rule`` заменяет правило).

Как привязка не мешает рабочему столу («странный экран»)
---------------------------------------------------------
Ключевой приём — **закрепление правила ДО создания вывода**
(:func:`pin_rules_planned`): правило «воркспейс N → HEADLESS-K,
default:true» ставится заранее, и headless **рождается** сразу с
телефонным воркспейсом. Тогда :func:`bind` в обычном запуске не делает
НИ ОДНОГО действия над фокусом/видом — переключений стола нет вообще.
Исходный wayvnc-вариант hyprscreen работал так же: ни одной операции с
воркспейсами, только ``output create``.

Запасной путь (предсказание имени не совпало, правило не применилось):
перенос номера, выселение посторонних воркспейсов и активация — каждая
с немедленным возвратом фокуса на физмонитор.

При остановке (:func:`unbind`) ручной эвакуации НЕТ: Hyprland при
``output remove`` сам переносит воркспейсы (с окнами) на оставшийся
монитор — один атомарный шаг без прыжков стола.
"""

from __future__ import annotations

import logging
from typing import Any

import hyprctl
from config import Config

log = logging.getLogger(__name__)


def _ws_id(w: dict[str, Any]) -> str | None:
    """Идентификатор воркспейса из записи ``hyprctl -j workspaces``."""
    wid = w.get("id", w.get("name"))
    if wid is None:
        return None
    return str(wid)


def workspaces_on_monitor(monitor: str) -> list[str]:
    """Список id воркспейсов, живущих на данном мониторе (best-effort)."""
    try:
        data = hyprctl.list_workspaces()
    except hyprctl.HyprctlError as exc:
        log.warning("не удалось получить workspaces: %s", exc)
        return []
    out = []
    for w in data:
        if str(w.get("monitor", "")) == monitor:
            wid = _ws_id(w)
            if wid:
                out.append(wid)
    return out


def _focus_real_monitor() -> None:
    """Вернуть фокус И курсор на физический монитор (headless не должен их отбирать)."""
    real = hyprctl.real_monitors()
    if not real:
        return
    try:
        hyprctl.focus_monitor(real[0])
        hyprctl.move_cursor_to_monitor(real[0])
    except hyprctl.HyprctlError as exc:
        log.debug("focusmonitor %s: %s", real[0], exc)


def _evacuate_stray(monitor: str, keep: set[str]) -> None:
    """Перенести все воркспейсы monitor (кроме keep) на физический монитор."""
    target = hyprctl.real_monitors()[:1]
    if not target:
        return
    for wid in workspaces_on_monitor(monitor):
        if wid in keep:
            continue
        try:
            log.info("эвакуация постороннего воркспейса %s с %s → %s", wid, monitor, target[0])
            hyprctl.move_workspace_to_monitor(wid, target[0])
        except hyprctl.HyprctlError as exc:
            log.warning("эвакуация %s: %s", wid, exc)


def _active_workspace_on(monitor: str) -> str | None:
    """Активный воркспейс монитора (поле ``activeWorkspace``) или None.

    Полностью defensive: любая ошибка — «неизвестно», активация ниже
    просто сработает (она best-effort и не должна ломать bind).
    """
    try:
        mons = hyprctl.monitors()
    except Exception as exc:  # noqa: BLE001 - defensive
        log.warning("не удалось получить monitors: %s", exc)
        return None
    for m in mons:
        if str(m.get("name", "")) != monitor:
            continue
        aw = m.get("activeWorkspace") or {}
        wid = aw.get("id", aw.get("name"))
        return str(wid) if wid is not None else None
    return None


def _activate(monitor: str, ws: int) -> None:
    """Сделать воркспейс ``ws`` активным на headless-мониторе (best-effort).

    Запасной путь привязки: если headless родился без правила, активным
    на нём остаётся пустой авто-воркспейс. Активация открывает нужный
    номер на СВОЁМ мониторе; фокус возвращается физическому монитору
    сразу после неё (см. :func:`bind`). На Hyprland 0.55+ классический
    ``dispatch workspace N`` сломан — используется
    :func:`hyprctl.focus_workspace`.
    """
    if _active_workspace_on(monitor) == str(ws):
        return
    try:
        hyprctl.focus_workspace(ws)
        log.info("воркспейс %d активирован на %s", ws, monitor)
    except hyprctl.HyprctlError as exc:
        log.warning("активация воркспейса %d на %s: %s", ws, monitor, exc)


def predict_headless_names(count: int) -> list[str]:
    """Предсказать имена headless-выводов, которые создаст Hyprland.

    Hyprland называет headless-выводы ``HEADLESS-<N>``; закрепить правило
    нужно ДО ``output create`` (иначе новый вывод рождается без нашего
    воркспейса), поэтому имя предсказывается: первый свободный индекс,
    затем следующий и т.д. Если предсказание не совпадёт — :func:`bind`
    честно проверит активный воркспейс и уйдёт в запасной путь.
    """
    occupied: set[int] = set()
    try:
        for m in hyprctl.monitors():
            name = str(m.get("name", ""))
            if not name.startswith("HEADLESS"):
                continue
            try:
                occupied.add(int(name.split("-", 1)[1]))
            except (ValueError, IndexError):
                continue
    except hyprctl.HyprctlError as exc:
        log.warning("предсказание имён headless: %s", exc)
    names: list[str] = []
    n = 1
    while len(names) < count and n <= 64:
        if n not in occupied:
            names.append(f"HEADLESS-{n}")
            occupied.add(n)
        n += 1
    if len(names) < count:
        raise hyprctl.HyprctlError(
            f"не удалось предсказать {count} имён headless-выводов"
        )
    return names


def pin_rules_planned(cfg: Config, count: int) -> dict[str, int]:
    """Закрепить правила воркспейсов за БУДУЩИМИ headless-выводами.

    Вызывается ДО создания выводов: ``default:true`` заставляет новый
    вывод родиться сразу с телефонным воркспейсом — без переносов,
    активаций и миганий рабочего стола. Возвращает маппинг
    ``{предсказанное_имя: воркспейс}``. Ошибка одного правила не
    фатальна (остальные закрепляются, bind проверит результат).
    """
    planned: dict[str, int] = {}
    try:
        names = predict_headless_names(count)
    except hyprctl.HyprctlError as exc:
        log.warning("закрепление правил до создания не удалось: %s", exc)
        return planned
    for i, name in enumerate(names):
        ws = min(99, cfg.workspace + i)
        try:
            hyprctl.set_workspace_rule(ws, name, default=True)
            planned[name] = ws
        except hyprctl.HyprctlError as exc:
            log.warning("правило воркспейса %d → %s (до создания): %s", ws, name, exc)
    if planned:
        log.info(
            "правила закреплены до создания выводов: %s",
            {k: v for k, v in planned.items()},
        )
    return planned


def bind(
    cfg: Config,
    output_names: list[str],
    planned: dict[str, int] | None = None,
) -> list[dict[str, Any]]:
    """Привязать воркспейсы к headless-выводам. Возвращает список привязок.

    Для экрана i привязывается воркспейс ``cfg.workspace + i`` к выводу
    ``output_names[i]`` (1 экран → ровно один номер).

    ``planned`` — результат :func:`pin_rules_planned` (правила,
    поставленные ДО создания выводов). Если закрепление сработало
    (телефонный номер уже активен на headless), привязка НЕ ВЫПОЛНЯЕТ
    ни одного действия над фокусом/видом рабочего стола. Запасной путь —
    перенос номера, выселение посторонних, активация с немедленным
    возвратом фокуса.
    """
    if not planned:
        # Снять/переуказать накопленные runtime-правила (в т.ч. от
        # прошлых запусков).
        reply = hyprctl.remove_workspace_rules()
        log.info("снятие правил воркспейсов: %s", (reply or "ok").strip()[:80])
    else:
        # planned есть: снимаем только ЧУЖИЕ headless-правила; наши (для
        # только что созданных выводов) защищены через keep_monitors.
        hyprctl.remove_workspace_rules(keep_monitors=set(output_names))

    bindings: list[dict[str, Any]] = []
    for i, output_name in enumerate(output_names):
        ws = min(99, cfg.workspace + i)
        # Правило на ФАКТИЧЕСКОЕ имя (replaceOrAdd): закрывает и случай,
        # когда предсказанное имя не совпало.
        try:
            hyprctl.set_workspace_rule(ws, output_name, default=True)
        except hyprctl.HyprctlError as exc:
            log.error("правило воркспейса %d -> %s: %s", ws, output_name, exc)
        # БЫСТРЫЙ ПУТЬ: закрепление до создания уже сделало номер активным
        # на headless — ноль действий над фокусом, стол не дёргается.
        if _active_workspace_on(output_name) == str(ws):
            bindings.append({"workspace": ws, "monitor": output_name})
            log.info(
                "воркспейс %d уже активен на %s (закреплён до создания)",
                ws, output_name,
            )
            continue
        # ЗАПАСНОЙ ПУТЬ (редкий): номер нужно привести на место. Если он
        # существует НЕ на headless — переносим (окна переезжают с ним).
        try:
            hyprctl.move_workspace_to_monitor_checked(str(ws), output_name)
        except hyprctl.HyprctlError as exc:
            log.debug("workspace %s пока не существует (нормально): %s", ws, exc)
        # Посторонние воркспейсы (авто-созданный при output create без
        # правила) выселяем с телефона — там живёт только выбранный номер.
        _evacuate_stray(output_name, keep={str(ws)})
        # Активация на мгновение переводит вид на headless — сразу
        # возвращаем фокус пользователю.
        _activate(output_name, ws)
        _focus_real_monitor()
        bindings.append({"workspace": ws, "monitor": output_name})
        log.info("воркспейс %d привязан к %s", ws, output_name)

    return bindings


def unbind(output_names: list[str]) -> None:
    """Отвязать воркспейсы перед удалением headless-выводов.

    ЭВАКУАЦИИ НЕТ. Ручной переброс «воркспейс за воркспейсом» на
    физмонитор переключал вид пользователя и был главным источником
    «странного экрана» при ОСТАНОВКЕ сервера. Hyprland при
    ``output remove`` сам переносит воркспейсы удаляемого вывода
    (вместе с окнами) на оставшийся монитор — один атомарный шаг, так
    же работал исходный wayvnc-вариант.

    Здесь мы только: запоминаем рабочий стол пользователя, снимаем
    правила (на 0.55+ переуказываем с headless на физмонитор) и
    возвращаем фокус/исходный воркспейс, если фокус успел уйти на
    телефон (последнее касание было с телефона).
    """
    real = hyprctl.real_monitors()[:1]
    user_ws = _active_workspace_on(real[0]) if real else None

    try:
        hyprctl.remove_workspace_rules()
    except hyprctl.HyprctlError as exc:
        log.warning("снятие правил воркспейсов: %s", exc)
    _focus_real_monitor()

    # Если активный воркспейс физмонитора изменился (фокус был на
    # телефоне) — возвращаем тот, на котором сидел пользователь.
    if real and user_ws is not None:
        now = _active_workspace_on(real[0])
        if now is not None and now != user_ws:
            try:
                hyprctl.focus_workspace(user_ws)
                log.info("воркспейс %s пользователя возвращён на %s", user_ws, real[0])
            except hyprctl.HyprctlError as exc:
                log.warning("возврат воркспейса %s: %s", user_ws, exc)
