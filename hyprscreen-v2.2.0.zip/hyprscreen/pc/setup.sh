#!/usr/bin/env bash
#
# Одноразовая настройка HyprScreen 2.2.0 на CachyOS / Hyprland (Arch-based).
#
# Что делает:
#  - ставит системные пакеты (grim, wtype, tk для GUI; swww для обоев);
#  - проверяет группу input (права на /dev/uinput для evdev);
#  - создаёт Python-venv в ./.venv и ставит зависимости
#    (websockets, evdev, customtkinter);
#  - копирует config.toml.example → config.toml, если ещё нет;
#  - опционально (--install) создаёт симлинк ~/.local/bin/hyprscreen.
#
# Повторный запуск безопасен.
#
# Использование:
#   ./setup.sh                # сделать всё
#   ./setup.sh --install      # + симлинк ~/.local/bin/hyprscreen
#   ./setup.sh --dry-run      # показать, что будет сделано

set -euo pipefail

# Работаем строго из каталога скрипта — раньше при вызове из install.sh
# venv и config.toml создавались в CWD установщика (распакованном архиве),
# и после его удаления run.sh не находил .venv → сервер/GUI мертвы.
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
cd "$SCRIPT_DIR"

# Копия должна быть ПОЛНОЙ до любых установок (pacman/venv). Локальные
# *.py — файлы проекта (их НЕТ в requirements.txt, pip их не ставит); если
# settings_store.py и т. п. не докопировались, всё равно упадёт в рантайме
# с «ModuleNotFoundError». Падаем сразу, с точным списком и лечением.
missing_py=()
for mod in config hyprctl settings_store state_file wallpaper \
           capture logging_setup server virtual_output workspaces \
           discovery input; do
    [[ -f "$mod.py" ]] || missing_py+=("$mod.py")
done
if ((${#missing_py[@]})); then
    echo "❌ В $SCRIPT_DIR нет файлов проекта: ${missing_py[*]}"
    echo "   Это ЛОКАЛЬНЫЕ модули HyprScreen — их нет в requirements.txt, pip их не ставит."
    echo "   Лечение: скопируйте перечисленные файлы из полной поставки 2.2.0 в pc/"
    echo "   ИЛИ заново распакуйте полный архив hyprscreen-v2.2.0.zip и запустите"
    echo "   из него ./install.sh."
    exit 1
fi

DRY_RUN=0
DO_INSTALL=0
for arg in "$@"; do
    case "$arg" in
        --dry-run|-n) DRY_RUN=1 ;;
        --install)    DO_INSTALL=1 ;;
        *) echo "неизвестный аргумент: $arg"; exit 1 ;;
    esac
done

run() {
    if [[ $DRY_RUN -eq 1 ]]; then
        echo "   (dry-run) $*"
    else
        "$@"
    fi
}

echo ">> Системные пакеты (grim, wtype, tk, swww)"
missing=()
pacman -Qi grim >/dev/null 2>&1 || missing+=(grim)
pacman -Qi wtype >/dev/null 2>&1 || missing+=(wtype)
pacman -Qi tk   >/dev/null 2>&1 || missing+=(tk)
pacman -Qi swww >/dev/null 2>&1 || missing+=(swww)
if [[ ${#missing[@]} -gt 0 ]]; then
    if [[ $DRY_RUN -eq 1 ]]; then
        echo "   (dry-run) sudo pacman -S --needed ${missing[*]}"
    else
        sudo pacman -S --needed "${missing[@]}" || \
            echo "   !! не установлены ${missing[*]} — grim/wtype/GUI/обои могут не работать"
    fi
else
    echo "   уже установлены"
fi

echo ">> Права на /dev/uinput (группа input)"
if id -nG "$USER" | grep -qw input; then
    echo "   вы уже в группе input"
else
    echo "   выполните:  sudo usermod -aG input $USER   и перелогиньтесь"
    echo "   (без этого телефонный ввод — касания — работать не будет)"
fi

echo ">> Python-venv и зависимости"
if [[ ! -x .venv/bin/python ]]; then
    run python -m venv .venv
fi
if [[ $DRY_RUN -eq 1 ]]; then
    echo "   (dry-run) .venv/bin/pip install -r requirements.txt"
else
    .venv/bin/pip install --upgrade pip >/dev/null
    .venv/bin/pip install -r requirements.txt
fi

if [[ ! -f config.toml && -f config.toml.example ]]; then
    echo ">> config.toml: создаю из config.toml.example"
    run cp config.toml.example config.toml
else
    echo ">> config.toml: уже существует (или пример отсутствует)"
fi

if [[ $DO_INSTALL -eq 1 ]]; then
    echo ">> Симлинк ~/.local/bin/hyprscreen → $SCRIPT_DIR/run.sh"
    mkdir -p "$HOME/.local/bin"
    run ln -sf "$SCRIPT_DIR/run.sh" "$HOME/.local/bin/hyprscreen"
    echo "   в hyprland.conf:  exec-once = hyprscreen"
fi

echo
echo "Готово. Запуск:  ./run.sh            (GUI)"
echo "                 ./run.sh interactive (консольное меню)"
echo "Диагностика:     ./run.sh diagnose && ./run.sh grimtest"
