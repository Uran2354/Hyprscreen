"""Persistent-настройки HyprScreen (между запусками).

Хранится в ``~/.config/hyprscreen/settings.json``:
  * ``workspace``       — номер воркспейса, живущего на телефоне (дефолт 6);
  * ``fps_mode``        — пресет FPS (auto/eco/balance/smooth/max/custom);
  * ``wallpaper``       — выбранные обои для headless-вывода (путь или нет ключа);
  * ``wallpaper_dir``   — каталог, из которого GUI показывает обои (дефолт ~/Обои);
  * ``settings_version``— версия формата (для одноразовой миграции).

Миграции:
  * v2 (0.12.0): сброс чужого номера воркспейса на дефолт 6.
  * v3 (0.14.0): возврат разрешения в config.toml к альбомному
    ``2340x1080`` — приложение на телефоне зафиксировано в landscape,
    а 0.12.0–0.13.2 переписывали разрешение на портрет ``1080x2340``
    (и рабочий ``1920x1080`` тоже) — из-за этого кадр на телефоне был
    «маленький, не на весь экран».
"""

from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Any

from config import DEFAULT_WORKSPACE
from wallpaper import DEFAULT_DIR as WALLPAPER_DEFAULT_DIR

log = logging.getLogger(__name__)

#: Текущая версия формата settings.json (миграция выполняется один раз).
#: v3 (0.14.0): resolution в config.toml возвращается к альбомному
#: 2340x1080 (регрессия портрета 0.12.0 — «маленький экран»).
SETTINGS_VERSION = 3


def _settings_path() -> Path:
    config_home = os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config"))
    return Path(config_home) / "hyprscreen" / "settings.json"


def load_settings() -> dict[str, Any]:
    path = _settings_path()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except (OSError, json.JSONDecodeError) as exc:
        log.warning("settings: %s", exc)
    return {}


def save_settings(settings: dict[str, Any]) -> None:
    path = _settings_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(settings, indent=2, ensure_ascii=False), encoding="utf-8"
        )
    except OSError as exc:
        log.warning("settings save: %s", exc)


# -- миграция ----------------------------------------------------------------

def migrate(config_toml_path: str | None = None) -> list[str]:
    """Одноразовая миграция настроек (сейчас — формат 0.14.0, v3).

    * v2 (0.12.0): в 0.9–0.11 номер воркспейса выбирался «очередным
      свободным» и мог сохраниться (например 4) — сброс на дефолт 6.
    * v3 (0.14.0): 0.12.0–0.13.2 переписывали разрешение в config.toml
      на портрет ``1080x2340`` (включая рабочий ``1920x1080``), а
      приложение на телефоне зафиксировано в landscape — кадр получался
      «маленький, не на весь экран». Миграция возвращает альбомный
      дефолт ``2340x1080`` (точное соответствие экрану телефона).

    Выполняется один раз (``settings_version = SETTINGS_VERSION``).
    Возвращает список предпринятых действий — main/gui пишут их в лог.
    """
    actions: list[str] = []
    s = load_settings()
    if s.get("settings_version") == SETTINGS_VERSION:
        return actions
    if "workspaces" in s:
        del s["workspaces"]
        actions.append("удалён устаревший ключ workspaces (формат 0.9–0.10)")
    if "workspace" in s and s["workspace"] != DEFAULT_WORKSPACE:
        actions.append(
            f"воркспейс {s['workspace']} сброшен на {DEFAULT_WORKSPACE} "
            f"(мог прийти из версий 0.9–0.11)"
        )
        s["workspace"] = DEFAULT_WORKSPACE
    if config_toml_path:
        actions.extend(_migrate_config_toml(config_toml_path))
    s["settings_version"] = SETTINGS_VERSION
    save_settings(s)
    for a in actions:
        log.info("настройки (миграция 0.14.0): %s", a)
    return actions


def _migrate_config_toml(path: str) -> list[str]:
    """Вернуть resolution в config.toml к альбомному дефолту 0.14.0."""
    actions: list[str] = []
    p = Path(path)
    if not p.is_file():
        return actions
    try:
        text = p.read_text(encoding="utf-8")
    except OSError as exc:
        log.warning("миграция config.toml: %s", exc)
        return actions
    new = re.sub(
        r"(?m)^(\s*workspace\s*=\s*)\d+", rf"\g<1>{DEFAULT_WORKSPACE}", text
    )
    if new != text:
        actions.append(f"в {p.name}: workspace приведён к {DEFAULT_WORKSPACE}")
    # Портрет 1080x2340 — сломанный дефолт 0.12.0–0.13.2: приложение на
    # телефоне в landscape, кадр получался «маленький, не на весь экран».
    # 1920x1080 — рабочий дефолт 0.10.0 (в 0.12.0 его насильно переписали
    # на портрет). Оба возвращаем к альбомному 2340x1080 — точное
    # соответствие экрану телефона (кадр занимает весь экран).
    new2 = re.sub(
        r'(?m)^(\s*resolution\s*=\s*")(?:1080x2340|1920x1080)("\s*(?:#.*)?)$',
        r"\g<1>2340x1080\g<2>",
        new,
    )
    if new2 != new:
        actions.append(
            f"в {p.name}: resolution → 2340x1080 (альбом под экран "
            f"телефона; портрет 0.12.0 давал «маленький экран»)"
        )
    if new2 != text:
        try:
            p.write_text(new2, encoding="utf-8")
        except OSError as exc:
            log.warning("миграция config.toml: %s", exc)
    return actions


# -- воркспейс ---------------------------------------------------------------

def get_workspace() -> int:
    """Выбранный воркспейс; если пользователь не выбирал — дефолт 6."""
    s = load_settings()
    if isinstance(s.get("workspace"), int):
        return max(1, min(99, s["workspace"]))
    return DEFAULT_WORKSPACE


def set_workspace(workspace: int) -> None:
    s = load_settings()
    s["workspace"] = max(1, min(99, int(workspace)))
    save_settings(s)


# -- FPS-режим ---------------------------------------------------------------

def get_fps_mode(default: str = "auto") -> str:
    s = load_settings()
    v = s.get("fps_mode")
    return str(v) if isinstance(v, str) and v else default


def set_fps_mode(mode: str) -> None:
    s = load_settings()
    s["fps_mode"] = mode
    save_settings(s)


# -- обои --------------------------------------------------------------------

def get_wallpaper() -> str | None:
    """Выбранный файл обоев (None — не выбраны/«без обоев»)."""
    v = load_settings().get("wallpaper")
    return str(v) if isinstance(v, str) and v else None


def set_wallpaper(path: str | None) -> None:
    s = load_settings()
    if path:
        s["wallpaper"] = path
    else:
        s.pop("wallpaper", None)
    save_settings(s)


def get_wallpaper_dir() -> str:
    """Каталог обоев для GUI/меню (по умолчанию ~/Обои)."""
    v = load_settings().get("wallpaper_dir")
    if isinstance(v, str) and v.strip():
        return v
    return WALLPAPER_DEFAULT_DIR


def set_wallpaper_dir(directory: str) -> None:
    s = load_settings()
    s["wallpaper_dir"] = directory
    save_settings(s)
