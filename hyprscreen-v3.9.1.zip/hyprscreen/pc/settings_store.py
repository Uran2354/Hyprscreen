"""Persistent-настройки HyprScreen (между запусками GUI/CLI).

Хранится в ``~/.config/hyprscreen/settings.json``:

* ``workspace``      — номер воркспейса Hyprland для показа (дефолт 6);
* ``monitor``        — имя монитора, если пользователь выбрал его явно
  (режим «весь монитор», когда workspace = 0);
* ``monitor_index``  — устаревший fallback-номер экрана (совместимость);
* ``fps_mode``       — пресет FPS (auto/eco/balance/smooth/max/custom);
* ``notifications``  — показывать ли системные уведомления;
* ``settings_version`` — версия формата.

Миграция v4: настройки v2.x (workspace/wallpaper) больше не используются —
виртуальных мониторов и обоев headless-вывода в 3.x нет.
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

from config import DEFAULT_MONITOR_INDEX, DEFAULT_WORKSPACE

log = logging.getLogger("hyprscreen.settings")

SETTINGS_VERSION = 4


def _settings_path() -> Path:
    config_home = os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config"))
    return Path(config_home) / "hyprscreen" / "settings.json"


def load_settings() -> dict[str, Any]:
    path = _settings_path()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except (OSError, json.JSONDecodeError) as exc:
        log.warning("settings: %s", exc)
    return {}


def save_settings(settings: dict[str, Any]) -> None:
    path = _settings_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(settings, indent=2, ensure_ascii=False), encoding="utf-8"
        )
    except OSError as exc:
        log.warning("settings save: %s", exc)


def migrate() -> list[str]:
    """Одноразовая миграция формата (v4: экран вместо воркспейса)."""
    actions: list[str] = []
    s = load_settings()
    if s.get("settings_version") == SETTINGS_VERSION:
        return actions
    for legacy in ("workspace", "wallpaper", "wallpaper_dir", "workspaces"):
        if legacy in s:
            del s[legacy]
            actions.append(f"удалён устаревший ключ {legacy} (виртуальных экранов больше нет)")
    s["settings_version"] = SETTINGS_VERSION
    save_settings(s)
    for a in actions:
        log.info("настройки (миграция): %s", a)
    return actions


# -- монитор -----------------------------------------------------------------

def get_workspace(default: int = DEFAULT_WORKSPACE) -> int:
    """Номер воркспейса для показа (0 — режим «весь монитор»)."""
    s = load_settings()
    v = s.get("workspace")
    if isinstance(v, int) and 0 <= v <= 99:
        return v
    return default


def set_workspace(ws: int) -> None:
    s = load_settings()
    s["workspace"] = max(0, min(99, int(ws)))
    save_settings(s)


def get_monitor_name() -> str:
    """Явно выбранное имя монитора ('' — не выбрано)."""
    v = load_settings().get("monitor")
    return str(v) if isinstance(v, str) and v.strip() else ""


def set_monitor_name(name: str) -> None:
    s = load_settings()
    name = (name or "").strip()
    if name:
        s["monitor"] = name
    else:
        s.pop("monitor", None)
    save_settings(s)


def get_monitor_index() -> int:
    s = load_settings()
    v = s.get("monitor_index")
    if isinstance(v, int) and 1 <= v <= 64:
        return v
    return DEFAULT_MONITOR_INDEX


def set_monitor_index(index: int) -> None:
    s = load_settings()
    s["monitor_index"] = max(1, min(64, int(index)))
    save_settings(s)


# -- FPS-режим ---------------------------------------------------------------

def get_fps_mode(default: str = "auto") -> str:
    s = load_settings()
    v = s.get("fps_mode")
    return str(v) if isinstance(v, str) and v else default


def set_fps_mode(mode: str) -> None:
    s = load_settings()
    s["fps_mode"] = mode
    save_settings(s)


# -- уведомления -------------------------------------------------------------

def get_notifications(default: bool = True) -> bool:
    v = load_settings().get("notifications")
    return v if isinstance(v, bool) else default


def set_notifications(value: bool) -> None:
    s = load_settings()
    s["notifications"] = bool(value)
    save_settings(s)
