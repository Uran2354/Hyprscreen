#!/usr/bin/env bash
# Запускатор HyprScreen 0.14.0.
#
# Без аргументов:  ./run.sh
#   → GUI (customtkinter); если он не установлен — интерактивное меню.
#
# Подкоманды:
#   ./run.sh gui          — графический интерфейс (customtkinter)
#   ./run.sh interactive  — консольное меню
#   ./run.sh workspace 6  — перепривязать воркспейс 6 к телефону (сервер должен работать)
#   ./run.sh list | reset | diagnose | grimtest | kill
#   ./run.sh run --workspace 6 --fps-mode auto   — прямой запуск сервера

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
cd "$SCRIPT_DIR"

PYTHON="${PYTHON:-python}"
VENV_DIR="${VENV_DIR:-$SCRIPT_DIR/.venv}"
if [[ -x "$VENV_DIR/bin/python" ]]; then
    PYTHON="$VENV_DIR/bin/python"
fi

export PYTHONPATH="$SCRIPT_DIR${PYTHONPATH:+:$PYTHONPATH}"

cmd="${1:-}"
case "$cmd" in
    gui)
        exec "$PYTHON" gui.py
        ;;
    "")
        if "$PYTHON" -c 'import customtkinter' >/dev/null 2>&1; then
            exec "$PYTHON" gui.py
        fi
        echo "customtkinter не установлен — открываю консольное меню."
        echo "  GUI:  pip install customtkinter   (или ./setup.sh)"
        exec "$PYTHON" main.py interactive
        ;;
    *)
        exec "$PYTHON" main.py "$@"
        ;;
esac
