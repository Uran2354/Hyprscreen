#!/usr/bin/env python3
"""hyprscreen 3.9.1 — CLI-движок PC-стороны.

Зеркало закреплённого воркспейса Hyprland (по умолчанию 6-го) на телефон:
воркспейс переезжает на ВИРТУАЛЬНЫЙ монитор (headless) и рендерится
всегда — кадры живые, физические экраны ПК свободно переключаются.

  hyprscreen on [N|ИМЯ]   включить трансляцию (MJPEG :8080)
  hyprscreen off          выключить
  hyprscreen toggle       переключить
  hyprscreen status       статус (--json — для quickshell-тикера и скриптов)
  hyprscreen monitors     список экранов с номерами
  hyprscreen qr           QR-код адреса подключения
  hyprscreen grimtest     тест захвата (точная причина чёрного экрана)
  hyprscreen cleanup      убить зависшие процессы и старые HEADLESS-*
  hyprscreen doctor       диагностика
  hyprscreen gui          графический интерфейс (customtkinter)
  hyprscreen menu         консольное меню
  hyprscreen serve        сервер в переднем плане (используют start и GUI)

Тачпада из телефона НЕТ, хоткеев НЕТ. Клавиатура с телефона (тап по экрану
в приложении) — через wtype, см. pc/server.py.
"""

from __future__ import annotations

import argparse
import os
import shutil
import signal
import socket
import subprocess
import sys
import time
from typing import Optional

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import config as config_mod
import discovery
import hyprctl
import input as input_mod
import settings_store
import state_file
from config import Config, DEFAULT_MONITOR_INDEX, DEFAULT_PORT

VERSION = config_mod.__version__
CACHE_DIR = os.path.join(
    os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache")), "hyprscreen"
)
SERVER_LOG = os.path.join(CACHE_DIR, "server.log")
CONFIG_PATH = os.path.join(BASE_DIR, "config.toml")


# ------------------------------------------------------------- утилиты ---
def msg(*args) -> None:
    print(*args)


def die(text: str, code: int = 1) -> "None":  # noqa: ANN201
    print(f"hyprscreen: {text}", file=sys.stderr)
    raise SystemExit(code)


def notify(title: str, body: str = "") -> None:
    if not settings_store.get_notifications(True):
        return
    if not hyprctl.have("notify-send"):
        return
    argv = ["notify-send", "-a", "HyprScreen", "-t", "4000", title]
    if body:
        argv.append(body)
    try:
        subprocess.run(argv, capture_output=True, timeout=5)
    except Exception:  # noqa: BLE001 — уведомление не критично
        pass


def port_open(host: str, port: int, timeout: float = 0.4) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def wait_port(host: str, port: int, seconds: int = 12) -> bool:
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if port_open(host, port):
            return True
        time.sleep(0.4)
    return False


LOOPBACK_BINDS = ("127.0.0.1", "localhost", "::1")


def ensure_lan_bind(cfg: Config) -> None:
    """bind_address=127.0.0.1 не даёт телефону подключиться (отчёт 3.7.1).

    GUI подменял loopback на 0.0.0.0 ещё в 3.7.1, CLI — нет: `hyprscreen on`
    с таким config.toml молча слушал только loopback, телефон не подключался,
    а doctor/GUI оставались зелёными. Чиним и в CLI, с честным предупреждением
    (для SSH-туннеля можно вернуть флагом `serve --listen 127.0.0.1`).
    """
    if cfg.bind_address in LOOPBACK_BINDS:
        cfg.bind_address = "0.0.0.0"
        msg("⚠ bind_address='127.0.0.1' заменён на 0.0.0.0 — иначе телефон не "
            "подключится (вернуть для SSH-туннеля: serve --listen 127.0.0.1)")


def listening_bind_ip(port: int) -> str:
    """Адрес, на котором порт РЕАЛЬНО слушает (по /proc/net/tcp[6]).

    Возвращает '0.0.0.0'/'::' (все интерфейсы), конкретный IP или '' —
    если никто не слушает. Ловит bind 127.0.0.1: телефон тогда не
    подключается, хотя doctor/GUI «зелёные» (SETUP.md §7.8).
    """
    want = f"{int(port):04X}"
    for path in ("/proc/net/tcp", "/proc/net/tcp6"):
        try:
            with open(path, encoding="ascii") as fh:
                lines = fh.readlines()[1:]
        except OSError:
            continue
        for line in lines:
            fields = line.split()
            if len(fields) < 4 or fields[3] != "0A":  # 0A = LISTEN
                continue
            addr, _, port_hex = fields[1].partition(":")
            if port_hex.upper() != want:
                continue
            try:
                raw = bytes.fromhex(addr)
            except ValueError:
                continue
            if len(raw) == 16:
                if raw == b"\x00" * 16:
                    return "::"
                if raw == b"\x00" * 15 + b"\x01":
                    return "::1"
                if raw[:10] == b"\x00" * 10 and raw[10:12] == b"\xff\xff":
                    raw = raw[12:]  # IPv4-mapped → разберём как IPv4 ниже
                else:
                    return "ipv6"
            if len(raw) == 4:
                # /proc хранит адрес в little-endian: 0100007F = 127.0.0.1
                return ".".join(str(b) for b in reversed(raw))
    return ""


# --------------------------------------------------------------- конфиг ---
def load_config(args: Optional[argparse.Namespace] = None) -> Config:
    path = getattr(args, "config", None) or CONFIG_PATH
    cfg = Config.from_file(path)
    if getattr(args, "monitor", None):
        cfg.monitor = str(args.monitor).strip()
    if getattr(args, "monitor_index", None):
        cfg.monitor_index = config_mod.clamp_monitor_index(args.monitor_index)
    return cfg


def apply_overrides(cfg: Config, args: argparse.Namespace) -> None:
    """Флаги CLI поверх config.toml (None = не задано)."""
    for name in ("port", "bind_address", "fps", "quality", "scale", "token",
                 "fps_mode", "rate_limit"):
        value = getattr(args, name, None)
        if value is None:
            continue
        if name == "token":
            cfg.auth_token = str(value) or None
        elif name == "bind_address":
            cfg.bind_address = str(value)
        elif name == "rate_limit":
            cfg.input_rate_limit = max(0, int(value))
        else:
            setattr(cfg, name, value)


def _die_on_config_error(args: argparse.Namespace) -> None:
    """Битый config.toml — честная ошибка вместо молчаливых дефолтов.

    Раньше ошибка парсинга глоталась: сервер стартовал с ДЕФОЛТАМИ,
    токен/порт/workspace пользовательского файла молча игнорировались,
    и телефон «не подключался» без видимой причины.
    """
    path = getattr(args, "config", None) or CONFIG_PATH
    if config_mod.LAST_LOAD_ERROR and os.path.exists(path):
        die(f"config.toml не читается: {config_mod.LAST_LOAD_ERROR}\n"
            f"  файл: {path}\n"
            f"  лечение: исправьте TOML или удалите файл (будут дефолты)")


def resolve_target(spec: str, cfg: Config) -> tuple[str, Optional[int]]:
    """Определить, ЧТО показывать: (монитор, воркспейс | None).

    Приоритет:
      1. Аргумент-ЦИФРА  — воркспейс Hyprland №N → монитор, где он открыт;
      2. Аргумент-ИМЯ    — весь монитор (DP-3 и т.п.), воркспейс не важен;
      3. config workspace — воркспейс по умолчанию (№6);
      4. config monitor / monitor_index — весь монитор (fallback, workspace=0).
    """
    hyprctl.fix_env()
    spec = (spec or "").strip()

    def ws_target(ws: int) -> tuple[str, int]:
        mon = hyprctl.workspace_monitor(ws)
        if mon:
            return mon, ws
        # Воркспейс ещё не открыт — НЕ умираем (старый die мешал вообще
        # включить трансляцию: «переключитесь на него» — а телефон-то
        # как раз и должен на него переключить). Сервер при старте САМ
        # откроет воркспейс на подходящем мониторе (3.8.0,
        # hyprctl.switch_workspace).
        fallback = (cfg.monitor or "").strip() \
            or hyprctl.focused_monitor() \
            or hyprctl.monitor_at_index(cfg.monitor_index) \
            or (hyprctl.monitor_names() or [""])[0]
        if not fallback:
            die(f"воркспейс №{ws} не открыт и мониторы не найдены — "
                f"выполните hyprscreen monitors")
        return fallback, ws

    if spec:
        if spec.isdigit():
            return ws_target(int(spec))
        if spec not in hyprctl.monitor_names():
            die(f"экран '{spec}' не найден. Доступные экраны:\n"
                + "\n".join(hyprctl.monitors_display()))
        return spec, None

    ws = int(cfg.workspace or 0)
    if ws:
        return ws_target(ws)

    # Режим «весь монитор» (workspace = 0 в config.toml)
    name = cfg.monitor or settings_store.get_monitor_name()
    if name:
        if name not in hyprctl.monitor_names():
            die(f"экран '{name}' (из конфига) не найден. Доступные экраны:\n"
                + "\n".join(hyprctl.monitors_display()))
        return name, None

    idx = cfg.monitor_index or settings_store.get_monitor_index()
    mon = hyprctl.monitor_at_index(idx)
    if not mon:
        die(f"нет экрана №{idx} (по умолчанию). Доступные экраны:\n"
            + "\n".join(hyprctl.monitors_display()))
    return mon, None


def resolve_monitor(spec: str, cfg: Config) -> str:
    """Имя монитора для захвата (grimtest/doctor — им воркспейс не важен)."""
    return resolve_target(spec, cfg)[0]


# --------------------------------------------------------------- процессы ---
def own_server_pids() -> list[int]:
    """Свои живые процессы трансляции (pc/server.py).

    Совпадение по ЛЮБОМУ признаку:
      * cmdline содержит путь до pc/server.py или слово hyprscreen + server.py;
      * cwd процесса == наш pc/ (ловит «python3 server.py» из каталога).
    """
    pids: list[int] = []
    me = os.getuid()
    server_path = os.path.join(BASE_DIR, "server.py")
    for entry in os.listdir("/proc"):
        if not entry.isdigit():
            continue
        pid = int(entry)
        try:
            if os.stat(f"/proc/{entry}").st_uid != me:
                continue
            with open(f"/proc/{entry}/cmdline", "rb") as fh:
                cmd = fh.read().decode("utf-8", "replace")
        except OSError:
            continue
        if "server.py" not in cmd or "main.py" in cmd:
            continue
        cwd = ""
        try:
            cwd = os.path.realpath(f"/proc/{entry}/cwd")
        except OSError:
            pass
        if server_path in cmd or "hyprscreen" in cmd or cwd == BASE_DIR:
            pids.append(pid)
    return pids


def stop_pids(pids: list[int]) -> None:
    for pid in pids:
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            continue
    deadline = time.monotonic() + 4
    while time.monotonic() < deadline:
        alive = [p for p in pids if _pid_alive(p)]
        if not alive:
            return
        time.sleep(0.2)
    for pid in pids:
        if _pid_alive(pid):
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def spawn_server(cfg: Config, monitor: str) -> int:
    """Запустить pc/server.py в фоне (detached); вернуть pid."""
    python = os.path.join(BASE_DIR, ".venv", "bin", "python")
    if not os.path.exists(python):
        python = sys.executable or "python3"
    os.makedirs(CACHE_DIR, exist_ok=True)
    args = [
        python, os.path.join(BASE_DIR, "server.py"),
        "--output", monitor,
        "--listen", cfg.bind_address,
        "--port", str(cfg.port),
        "--fps", str(cfg.fps),
        "--quality", str(cfg.jpeg_quality),
        "--scale", str(cfg.scale),
        "--workspace", str(int(cfg.workspace or 0)),
    ]
    if cfg.auth_token:
        args += ["--token", cfg.auth_token]
    if not cfg.keyboard_enabled:
        args += ["--no-keyboard"]
    if cfg.input_rate_limit:
        args += ["--rate-limit", str(cfg.input_rate_limit)]
    if not cfg.discovery_enabled:
        args += ["--no-discovery"]
    args += ["--discovery-port", str(cfg.discovery_port)]
    log_fh = open(SERVER_LOG, "w")  # noqa: SIM115 — живёт вместе с сервером
    proc = subprocess.Popen(
        args,
        stdout=log_fh,
        stderr=subprocess.STDOUT,
        cwd=BASE_DIR,
        start_new_session=True,
    )
    log_fh.close()
    return proc.pid


# ================================================================ команды ===
def cmd_on(args: argparse.Namespace) -> int:
    hyprctl.fix_env()
    if not hyprctl.have("hyprctl"):
        die("не найден hyprctl — установите hyprland")

    alive = state_file.state_pid_alive()
    if alive is not None:
        msg(f"HyprScreen уже запущен (pid {alive}).")
        return cmd_status(args)

    cfg = load_config(args)
    _die_on_config_error(args)
    cfg = cfg.effective()          # пресет FPS из config.toml (effective возвращает КОПИЮ)
    apply_overrides(cfg, args)     # флаги CLI поверх пресета
    ensure_lan_bind(cfg)           # loopback → 0.0.0.0 (телефон иначе не подключится)
    monitor, ws = resolve_target(getattr(args, "monitor_spec", "") or "", cfg)

    # Занятый порт: сначала лечим себя (зависший сервер), иначе — честная ошибка
    if port_open("127.0.0.1", cfg.port):
        stale = own_server_pids()
        if stale:
            msg("⚠ найден зависший процесс трансляции — завершаю")
            stop_pids(stale)
            time.sleep(0.5)
        else:
            die(f"порт {cfg.port} уже занят другим процессом — "
                f"смените port в config.toml")

    pid = spawn_server(cfg, monitor)
    if not wait_port("127.0.0.1", cfg.port):
        tail = ""
        try:
            with open(SERVER_LOG, encoding="utf-8", errors="replace") as fh:
                tail = "".join(fh.readlines()[-12:])
        except OSError:
            pass
        stop_pids([pid])
        state_file.clear_state()
        die(f"сервер не открыл порт {cfg.port}. Журнал:\n{tail}")

    state_file.write_state({
        "pid": pid,
        "version": VERSION,
        "port": cfg.port,
        "ip": discovery.lan_ip(),
        "monitor": monitor,
        "workspace": int(ws) if ws else 0,
        "fps": cfg.fps,
        "quality": cfg.jpeg_quality,
        "scale": cfg.scale,
        "clients": 0,
        "capture_ok": True,
        "last_error": "",
        "started": int(time.time()),
        "keyboard": cfg.keyboard_enabled,
        "workspace_active": True,
        "active_workspace": 0,
    })

    ip = discovery.lan_ip()
    url = f"http://{ip}:{cfg.port}"
    if cfg.auth_token:
        url += f"/?t={cfg.auth_token}"
    notify("HyprScreen включён", url)
    msg("✅ Трансляция включена")
    if ws:
        msg(f"   воркспейс: №{ws} → монитор {monitor} ({hyprctl.monitor_resolution(monitor)})")
    else:
        msg(f"   экран   : {monitor} ({hyprctl.monitor_resolution(monitor)})")
    msg(f"   телефон : приложение HyprScreen или браузер  {url}")
    if cfg.bind_address not in ("127.0.0.1", "localhost"):
        msg("   ⚠ телефон и ПК должны быть в одной сети; проверьте файрвол")
    if getattr(args, "qr", False):
        cmd_qr(args)
    return 0


def cmd_off(args: argparse.Namespace) -> int:  # noqa: ARG001
    pid = state_file.state_pid_alive()
    stopped = False
    if pid is not None:
        stop_pids([pid])
        stopped = True
    stale = own_server_pids()
    if stale:
        stop_pids(stale)
        stopped = True
    state_file.clear_state()
    notify("HyprScreen выключен")
    msg("✅ Трансляция выключена" if stopped else "Трансляция не была включена")
    return 0


def cmd_toggle(args: argparse.Namespace) -> int:
    if state_file.state_pid_alive() is not None or own_server_pids():
        return cmd_off(args)
    return cmd_on(args)


def cmd_restart(args: argparse.Namespace) -> int:
    cmd_off(args)
    time.sleep(1)
    return cmd_on(args)


def cmd_monitors(args: argparse.Namespace) -> int:  # noqa: ARG001
    hyprctl.fix_env()
    msg("Экраны (номер → имя):")
    for line in hyprctl.monitors_display():
        msg("  " + line)
    opened = hyprctl.open_workspace_numbers()
    msg("")
    msg("Открытые воркспейсы: "
        + (", ".join(map(str, opened)) if opened else "нет"))
    cfg = load_config()
    msg("")
    msg("Транслировать воркспейс:   hyprscreen on 6  (по умолчанию №6)")
    msg("Транслировать весь монитор: hyprscreen on DP-3")
    return 0


def _state_summary() -> dict:
    state = state_file.read_state() or {}
    monitor = str(state.get("monitor") or "")
    ip = str(state.get("ip") or discovery.lan_ip() or "")
    port = int(state.get("port") or DEFAULT_PORT)
    clients = int(state.get("clients") or 0)
    started = int(state.get("started") or 0)
    ws = int(state.get("workspace") or 0)
    try:
        ws_active = bool(state.get("workspace_active", True))
    except Exception:  # noqa: BLE001 — битый state не должен ронять статус
        ws_active = True
    try:
        active_ws = int(state.get("active_workspace") or 0)
    except (TypeError, ValueError):
        active_ws = 0
    headless = str(state.get("headless") or "")
    pinned_mode = str(state.get("pinned_mode") or "")
    return {
        "monitor": monitor,
        "workspace": ws,
        "workspace_active": ws_active,
        "active_workspace": active_ws,
        "headless": headless,
        "pinned_mode": pinned_mode,
        "resolution": hyprctl.monitor_resolution(monitor) if monitor else "",
        "ip": ip,
        "port": port,
        "clients": clients,
        "uptime": max(0, int(time.time()) - started) if started else 0,
        "capture_ok": bool(state.get("capture_ok", True)),
        "last_error": str(state.get("last_error") or ""),
    }


def cmd_status(args: argparse.Namespace) -> int:
    alive = state_file.state_pid_alive() is not None or bool(own_server_pids())
    if not alive:
        if getattr(args, "as_json", False):
            msg(f'{{"version":"{VERSION}","running":false}}')
        else:
            msg("HyprScreen: выключен")
        return 0

    s = _state_summary()
    if getattr(args, "as_json", False):
        import json
        msg(json.dumps({
            "version": VERSION,
            "running": True,
            "backend": "mjpeg",
            "monitor": s["monitor"],
            "workspace": s["workspace"],
            "workspace_active": s["workspace_active"],
            "active_workspace": s["active_workspace"],
            "headless": s["headless"],
            "pinned_mode": s["pinned_mode"],
            "resolution": s["resolution"],
            "port": s["port"],
            "ip": s["ip"],
            "host_port": f"{s['ip']}:{s['port']}",
            "address": f"http://{s['ip']}:{s['port']}",
            "clients": s["clients"],
            "uptime_sec": s["uptime"],
            "capture_ok": s["capture_ok"],
            "last_error": s["last_error"],
        }, ensure_ascii=False))
        return 0

    msg("HyprScreen: включён")
    if s["workspace"]:
        if s["headless"] and s["pinned_mode"] == "headless":
            msg(f"  воркспейс: №{s['workspace']} → виртуальный монитор "
                f"{s['headless']} (кадры живые всегда; экраны ПК свободны)")
            if not s["workspace_active"]:
                msg(f"  ⚠ закрепление восстанавливается (воркспейс вернётся "
                    f"на виртуальный монитор)")
        else:
            msg(f"  воркспейс: №{s['workspace']} → монитор {s['monitor']}"
                + (f" ({s['resolution']})" if s["resolution"] else "")
                + " (fallback 3.8.1)")
            if not s["workspace_active"]:
                msg(f"  ⏸ на ПК сейчас воркспейс №{s['active_workspace'] or '?'} — "
                    f"телефон показывает закреплённый №{s['workspace']} "
                    "(кадр на паузе; клавиатура с телефона вернёт №"
                    f"{s['workspace']} на ПК)")
    else:
        msg(f"  экран   : {s['monitor']}"
            + (f" ({s['resolution']})" if s["resolution"] else ""))
    msg(f"  адрес   : http://{s['ip']}:{s['port']}")
    if s["clients"]:
        msg(f"  смотрят : {s['clients']}")
    if not s["capture_ok"] and s["last_error"]:
        msg(f"  ⚠ захват не работает: {s['last_error']}")
    msg(f"  аптайм  : {s['uptime'] // 60} мин. {s['uptime'] % 60} с.")
    return 0


def cmd_qr(args: argparse.Namespace) -> int:  # noqa: ARG001
    s = _state_summary()
    cfg = load_config()
    port = s["port"] or cfg.port
    ip = s["ip"] or discovery.lan_ip()
    if not ip:
        die("не удалось определить IP (сеть не подключена?)")
    url = f"http://{ip}:{port}"
    token = cfg.auth_token or ""
    if token:
        url += f"/?t={token}"
    if hyprctl.have("qrencode"):
        subprocess.run(["qrencode", "-t", "ANSIUTF8", url], check=False)
    msg(url)
    return 0


def cmd_grimtest(args: argparse.Namespace) -> int:
    import capture
    hyprctl.fix_env()
    cfg = load_config(args)
    monitor, _ws = resolve_target(getattr(args, "monitor_spec", "") or "", cfg)
    msg(f"— grimtest: один кадр с '{monitor}' —")
    data, err = capture.capture_one(monitor)
    if data:
        msg(f"✅ захват работает: {len(data)} байт JPEG")
        return 0
    msg(f"❌ захват не удался: {err}")
    msg("")
    msg("Типовые причины и лечение:")
    msg("  • новый Hyprland убрал wlr-screencopy из grim 1.4.1 → yay -S grim-git")
    msg("  • запуск вне сессии (systemd/ssh) → hyprctl fix: перезапустите из терминала сессии")
    msg("  • монитор ушел в сон → пошевелите мышь и повторите")
    return 1


def cmd_cleanup(args: argparse.Namespace) -> int:  # noqa: ARG001
    hyprctl.fix_env()
    stale = own_server_pids()
    if stale:
        stop_pids(stale)
        msg(f"остановлены процессы трансляции: {', '.join(map(str, stale))}")
    removed = 0
    for name in hyprctl.headless_monitors():
        if hyprctl.remove_output(name):
            msg(f"удалён виртуальный монитор {name} (воркспейсы с него "
                f"переедут на оставшиеся мониторы)")
            removed += 1
        else:
            msg(f"⚠ не удалось удалить виртуальный монитор {name}")
    if not removed and not stale:
        msg("виртуальных мониторов и зависших процессов нет")
    state_file.clear_state()
    msg("✅ очистка завершена")
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    hyprctl.fix_env()
    ok, bad, warn = "✅", "❌", "⚠️ "
    problems = 0

    def chk(title: str, cmd: str, advice: str, required: bool = True) -> None:
        nonlocal problems
        if hyprctl.have(cmd):
            msg(f"{ok} {title}")
        elif required:
            msg(f"{bad} {title} — {advice}")
            problems += 1
        else:
            msg(f"{warn} {title} (опционально) — {advice}")

    msg("— HyprScreen doctor —")
    chk("hyprctl", "hyprctl", "pacman -S hyprland")
    chk("python3", "python3", "установите python")
    chk("grim", "grim", "pacman -S grim")
    chk("wtype", "wtype", "pacman -S wtype (нужен для «Клавиатуры» в приложении)",
        required=False)
    chk("qrencode", "qrencode", "pacman -S qrencode (QR адреса)", required=False)
    chk("notify-send", "notify-send", "pacman -S libnotify", required=False)

    if subprocess.run(["pgrep", "-x", "Hyprland"], capture_output=True).returncode == 0:
        msg(f"{ok} Hyprland запущен")
        rc, out, _ = hyprctl.hyprctl(["version"])
        if rc == 0:
            msg(f"{ok} hyprctl отвечает: {out.splitlines()[0] if out else 'ok'}")
        else:
            msg(f"{bad} hyprctl не отвечает (HYPRLAND_INSTANCE_SIGNATURE?)")
            problems += 1
    else:
        msg(f"{bad} Hyprland не запущен (или pgrep его не видит)")
        problems += 1

    try:
        import tkinter  # noqa: F401
        msg(f"{ok} tkinter доступен (GUI)")
    except ImportError:
        msg(f"{warn} tkinter недоступен — GUI не запустится (pacman -S tk)")
    try:
        import customtkinter  # noqa: F401
        msg(f"{ok} customtkinter доступен (GUI)")
    except ImportError:
        msg(f"{warn} customtkinter не установлен — ./pc/setup.sh соберёт venv")

    names = hyprctl.monitor_names()
    cfg = load_config(args)
    ws = int(cfg.workspace or settings_store.get_workspace())
    if ws:
        ws_mon = hyprctl.workspace_monitor(ws)
        if ws_mon and ws_mon.startswith("HEADLESS-"):
            msg(f"{ok} воркспейс №{ws} уже закреплён на виртуальном мониторе "
                f"{ws_mon}")
        elif ws_mon:
            msg(f"{ok} воркспейс №{ws} открыт на мониторе {ws_mon} — при "
                f"трансляции переедет на виртуальный монитор (headless): "
                "телефон покажет его живьём, экраны ПК останутся свободны")
        else:
            msg(f"{warn} воркспейс №{ws} сейчас не открыт — при старте "
                f"трансляции сервер создаст виртуальный монитор и откроет "
                f"на нём №{ws} (экран ПК не переключится, чужие воркспейсы "
                "в поток не попадут)")
    if names:
        idx = cfg.monitor_index or settings_store.get_monitor_index()
        default = hyprctl.monitor_at_index(idx)
        if default:
            msg(f"{ok} экран №{idx}: {default} (fallback при workspace = 0)")
        else:
            msg(f"{warn} экрана №{idx} нет — выберите другой: hyprscreen monitors")
        test_mon = resolve_target(getattr(args, "monitor_spec", "") or "", cfg)[0] \
            if getattr(args, "monitor_spec", "") else (names[0] if names else "")
        if test_mon and hyprctl.have("grim"):
            data, err = __import__("capture").capture_one(test_mon)
            if data:
                msg(f"{ok} захват экрана '{test_mon}' работает")
            else:
                msg(f"{bad} grim не может захватить '{test_mon}': {err}")
                problems += 1
    else:
        msg(f"{bad} hyprctl не верил ни одного монитора")
        problems += 1

    if os.path.exists(os.path.join(BASE_DIR, "server.py")):
        msg(f"{ok} сервер трансляции: {os.path.join(BASE_DIR, 'server.py')}")
    else:
        msg(f"{bad} pc/server.py не найден — переустановите hyprscreen")
        problems += 1

    ip = discovery.lan_ip()
    all_ips = discovery.all_lan_ips()
    if ip:
        extra = f" · все адреса ПК: {', '.join(all_ips)}" if len(all_ips) > 1 else ""
        msg(f"{ok} сетевой IP: {ip}{extra}")
        if len(all_ips) > 1:
            msg(f"{warn} у ПК несколько адресов (VPN/вторая карта?) — discovery "
                f"анонсирует ВСЕ; телефон подключайте по адресу вашей "
                f"Wi-Fi подсети (SETUP.md §7.8)")
        cfg = load_config(args)
        dport = cfg.discovery_port

        alive = state_file.state_pid_alive() is not None or bool(own_server_pids())
        if alive:
            s = _state_summary()
            port = int(s["port"] or cfg.port)
            bind = listening_bind_ip(port)
            if bind in ("127.0.0.1", "::1"):
                msg(f"{bad} сервер слушает ТОЛЬКО {bind}:{port} — телефон не "
                    f"подключится; уберите bind_address='127.0.0.1' из config.toml")
                problems += 1
            elif bind:
                msg(f"{ok} сервер слушает {bind}:{port} (TCP)")
            if port_open(ip, port):
                msg(f"{ok} HTTP-ответ с {ip}:{port} есть (проверено с самого ПК)")
            else:
                msg(f"{bad} http://{ip}:{port} недоступен даже с самого ПК — "
                    f"сервер упал или файрвол режет интерфейс")
                problems += 1
            if not int(s["clients"] or 0) and int(s["uptime"] or 0) > 30:
                msg(f"{warn} клиентов нет дольше 30 с — телефон не подключается: "
                    f"одна Wi-Fi сеть? файрвол {port}/tcp и {dport}/udp? "
                    f"AP-изоляция роутера? (SETUP.md §7.8)")
        else:
            msg(f"{warn} сервер сейчас не запущен — сетевые проверки ограничены "
                f"(запустите: hyprscreen on)")

        # Файрволы: подсказки (проверить реальную политику без root нельзя)
        if shutil.which("ufw") and subprocess.run(
            ["ufw", "status"], capture_output=True, text=True
        ).stdout.find("active") >= 0:
            msg(f"{warn} ufw активен: sudo ufw allow {cfg.port}/tcp && "
                f"sudo ufw allow {dport}/udp")
        if shutil.which("firewall-cmd") and "running" in subprocess.run(
            ["firewall-cmd", "--state"], capture_output=True, text=True
        ).stdout:
            msg(f"{warn} firewalld активен: "
                f"sudo firewall-cmd --add-port={cfg.port}/tcp "
                f"--add-port={dport}/udp --permanent && sudo firewall-cmd --reload")
        if shutil.which("nft"):
            nft = subprocess.run(["nft", "list", "ruleset"],
                                 capture_output=True, text=True)
            if nft.returncode == 0 and nft.stdout.strip():
                msg(f"{warn} активен nftables — если телефон не подключается: "
                    f"sudo nft add rule inet filter input tcp dport {cfg.port} accept; "
                    f"sudo nft add rule inet filter input udp dport {dport} accept")
        if shutil.which("iptables"):
            ipt = subprocess.run(["iptables", "-S"], capture_output=True, text=True)
            if (ipt.returncode == 0 and "INPUT DROP" in ipt.stdout
                    and f"--dport {cfg.port} " not in ipt.stdout
                    and not ipt.stdout.endswith(f"--dport {cfg.port}\n")):
                msg(f"{warn} iptables: INPUT DROP без правила для {cfg.port}/tcp — "
                    f"sudo iptables -A INPUT -p tcp --dport {cfg.port} -j ACCEPT; "
                    f"sudo iptables -A INPUT -p udp --dport {dport} -j ACCEPT")
    else:
        msg(f"{bad} не удалось определить сетевой IP")
        problems += 1

    msg("")
    if problems:
        msg(f"Проблем найдено: {problems}")
        return 1
    msg("Всё в порядке ✨")
    return 0


def cmd_serve(args: argparse.Namespace) -> int:
    """Сервер в переднем плане (GUI/start вызывает так)."""
    import logging
    import server
    import threading

    logging_setup = __import__("logging_setup")
    cfg = load_config(args)
    _die_on_config_error(args)     # битый TOML — не стартуем с полу-дефолтов
    cfg = cfg.effective()          # пресет FPS из config.toml (effective возвращает КОПИЮ)
    apply_overrides(cfg, args)     # флаги CLI поверх пресета
    # store_true-флаги serve раньше игнорировались — применяем их:
    if getattr(args, "no_keyboard", False):
        cfg.keyboard_enabled = False
    if getattr(args, "no_discovery", False):
        cfg.discovery_enabled = False
    # loopback → 0.0.0.0 (как в cmd_on), НО явный --listen не трогаем:
    # «serve --listen 127.0.0.1» — осознанный SSH-туннель.
    if getattr(args, "bind_address", None) is None:
        ensure_lan_bind(cfg)

    log_level = getattr(args, "log_level", "INFO") or "INFO"
    logging_setup.setup_logging(
        log_level, log_to_file=not getattr(args, "no_log_to_file", False),
        log_file=cfg.log_file,
    )

    monitor, ws = resolve_target(getattr(args, "monitor_spec", "") or "", cfg)

    # Самолечение занятого порта (как в cmd_on): путь GUI раньше падал с
    # «Address already in use», а зависший сервер жил дальше без state.
    if port_open("127.0.0.1", cfg.port):
        stale = own_server_pids()
        if stale:
            logging.getLogger("hyprscreen").warning(
                "порт %d занят зависшим процессом — завершаю: %s",
                cfg.port, stale,
            )
            stop_pids(stale)
            time.sleep(0.5)
        else:
            die(f"порт {cfg.port} уже занят другим процессом — "
                f"смените port в config.toml")

    import capture as capture_mod
    server.TOKEN = cfg.auth_token or ""
    server.KEYBOARD = (
        None if not cfg.keyboard_enabled
        else input_mod.KeyboardInjector(cfg.input_rate_limit)
    )
    server.INFO = {
        "monitor": monitor,
        "workspace": int(ws) if ws else 0,
        "fps": cfg.fps,
        "quality": cfg.jpeg_quality,
        "scale": cfg.scale,
    }

    # Воркспейс для показа: создаём ВИРТУАЛЬНЫЙ монитор (headless) и
    # закрепляем за телефоном ДО старта захвата (3.9.0): воркспейс
    # рендерится всегда — кадры живые, экраны ПК свободны. Без этого
    # телефон видел ТЕКУЩИЙ воркспейс ПК (корень бага «выбор воркспейса
    # не влияет», 3.8.0), потом морозил поток (3.8.1).
    # Обработчики сигналов — ДО setup (3.9.1): SIGTERM во время setup
    # раньше убивал процесс по умолчанию БЕЗ teardown — закреплённый
    # воркспейс оставался на невидимом виртуальном мониторе навсегда.
    httpd_holder: list = []

    def on_stop(signum, frame):  # noqa: ARG001
        server.STOP.set()
        if httpd_holder:
            threading.Thread(target=httpd_holder[0].shutdown,
                             daemon=True).start()

    signal.signal(signal.SIGTERM, on_stop)
    signal.signal(signal.SIGINT, on_stop)

    watch = None
    if ws:
        watch = capture_mod.WorkspaceWatch(monitor, int(ws))
        server.WATCH = watch
        log = logging.getLogger("hyprscreen")
        ok, ws_msg = watch.setup()
        (log.info if ok else log.warning)("воркспейс: %s", ws_msg)
        watch.start(server.STOP)
    state_file.write_state({
        "pid": os.getpid(),
        "version": VERSION,
        "port": cfg.port,
        "ip": discovery.lan_ip(),
        "monitor": monitor,
        "workspace": int(ws) if ws else 0,
        "fps": cfg.fps,
        "quality": cfg.jpeg_quality,
        "scale": cfg.scale,
        "clients": 0,
        "capture_ok": True,
        "last_error": "",
        "started": int(time.time()),
        "keyboard": cfg.keyboard_enabled,
        "workspace_active": True,
        "active_workspace": 0,
    })

    httpd = server.ThreadingHTTPServer((cfg.bind_address, cfg.port), server.Handler)
    httpd.daemon_threads = True
    httpd_holder.append(httpd)
    if server.STOP.is_set():
        # сигнал пришёл ВО ВРЕМЯ setup — shutdown ещё не запускался:
        # завершаемся сами (finally ниже сделает teardown)
        threading.Thread(target=httpd.shutdown, daemon=True).start()

    threading.Thread(
        target=capture_mod.capture_loop,
        args=(server.STORE, monitor, cfg.fps, cfg.jpeg_quality, cfg.scale, server.STOP),
        kwargs={"has_clients": lambda: server.CLIENTS > 0, "watch": watch,
                "watch_getter": lambda: server.WATCH},
        daemon=True,
    ).start()
    if cfg.discovery_enabled:
        discovery.start_broadcaster(
            cfg.port, cfg.discovery_port, monitor, server.STOP
        )

    def state_refresher() -> None:
        while not server.STOP.is_set():
            ws_active, active_ws = server._pinned_status()
            state_file.update_state(
                capture_ok=server.STORE.capture_ok,
                last_error=server.STORE.last_error,
                workspace_active=ws_active,
                active_workspace=active_ws,
                pinned_mode=str(server.WATCH.mode()) if server.WATCH else "",
                headless=str(server.WATCH.headless_name()) if server.WATCH else "",
            )
            server.STOP.wait(2.0)

    threading.Thread(target=state_refresher, daemon=True).start()

    logging.getLogger("hyprscreen").info(
        "сервер готов: монитор=%s порт=%d fps=%d качество=%d масштаб=%.2f "
        "клавиатура=%s", monitor, cfg.port, cfg.fps, cfg.jpeg_quality,
        cfg.scale, bool(server.KEYBOARD),
    )
    try:
        httpd.serve_forever()
    finally:
        server.STOP.set()
        # Восстановление: teardown по АКТУАЛЬНОМУ watch (POST /workspace
        # мог подменить server.WATCH — локальная переменная устарела).
        final_watch = server.WATCH if server.WATCH is not None else watch
        server.WATCH = None
        if final_watch is not None:
            try:
                final_watch.teardown()
            except Exception:  # noqa: BLE001
                logging.getLogger("hyprscreen").exception("workspace teardown")
        # state УДАЛЯЕМ при выходе (3.9.1): раньше update_state(clients=0)
        # пересоздавал файл ПОСЛЕ того, как GUI-стоп его удалял — пилюля GUI
        # снова показывала «Сервер уже работает (pid N, запущен вне GUI)»
        # («сервер не останавливается в gui»)
        state_file.clear_state()
    return 0


def cmd_gui(args: argparse.Namespace) -> int:  # noqa: ARG001
    gui_path = os.path.join(BASE_DIR, "gui.py")
    if not os.path.exists(gui_path):
        die("pc/gui.py не найден — переустановите hyprscreen")
    env = {**os.environ, "PYTHONPATH": BASE_DIR}
    os.execvpe(sys.executable or "python3",
               [sys.executable or "python3", gui_path], env)
    return 0  # unreachable


def cmd_menu(args: argparse.Namespace) -> int:  # noqa: ARG001
    actions = (
        ("1", "Включить трансляцию", cmd_on),
        ("2", "Выключить", cmd_off),
        ("3", "Статус", cmd_status),
        ("4", "Список экранов", cmd_monitors),
        ("5", "QR-код адреса", cmd_qr),
        ("6", "Тест захвата (grimtest)", cmd_grimtest),
        ("7", "Диагностика (doctor)", cmd_doctor),
    )
    while True:
        msg("")
        msg(f"—— HyprScreen {VERSION} ——")
        for key, title, _ in actions:
            msg(f"  {key}) {title}")
        msg("  0) Выход")
        try:
            choice = input("Выбор: ").strip()
        except (EOFError, KeyboardInterrupt):
            msg("")
            return 0
        if choice in ("0", "q", "quit", "exit"):
            return 0
        for key, _, fn in actions:
            if choice == key:
                fn(args)
                break


def cmd_help() -> int:
    print(__doc__.strip())
    return 0


# ------------------------------------------------------------------ парсер ---
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="hyprscreen",
        description="Зеркало экрана Hyprland на телефоне (MJPEG, только просмотр)",
    )
    sub = p.add_subparsers(dest="command")

    def common(sp: argparse.ArgumentParser) -> None:
        sp.add_argument("-c", "--config", help="путь к config.toml")

    on = sub.add_parser("on", aliases=["start"], help="включить трансляцию экрана")
    on.add_argument("monitor_spec", nargs="?",
                    help="№ воркспейса (1-10, по умолчанию 6) или имя монитора (DP-3)")
    on.add_argument("--fps", type=int)
    on.add_argument("--quality", type=int)
    on.add_argument("--scale", type=float)
    on.add_argument("--token", help="пароль в ссылке (?t=)")
    on.add_argument("--qr", action="store_true", help="показать QR-код")
    common(on)

    off = sub.add_parser("off", aliases=["stop", "kill"], help="выключить трансляцию")
    common(off)

    toggle = sub.add_parser("toggle", help="вкл/выкл")
    common(toggle)
    restart = sub.add_parser("restart", help="перезапустить")
    common(restart)

    status = sub.add_parser("status", help="статус (--json)")
    status.add_argument("--json", dest="as_json", action="store_true")
    common(status)

    monitors = sub.add_parser("monitors", help="список экранов")
    common(monitors)

    qr = sub.add_parser("qr", help="QR-код адреса")
    common(qr)

    grimtest = sub.add_parser("grimtest", help="тест захвата экрана")
    grimtest.add_argument("monitor_spec", nargs="?")
    common(grimtest)

    cleanup = sub.add_parser("cleanup", help="убить зависшие процессы/HEADLESS-*")
    common(cleanup)

    doctor = sub.add_parser("doctor", help="диагностика")
    doctor.add_argument("monitor_spec", nargs="?")
    common(doctor)

    menu = sub.add_parser("menu", help="консольное меню")
    common(menu)

    gui = sub.add_parser("gui", help="графический интерфейс (customtkinter)")
    common(gui)

    sub.add_parser("version", help="версия")
    sub.add_parser("help", help="справка")

    serve = sub.add_parser("serve", help="сервер в переднем плане")
    serve.add_argument("monitor_spec", nargs="?")
    serve.add_argument("--fps", type=int)
    serve.add_argument("--quality", type=int)
    serve.add_argument("--scale", type=float)
    serve.add_argument("--listen", "--bind", dest="bind_address")
    serve.add_argument("--port", type=int)
    serve.add_argument("--token")
    serve.add_argument("--rate-limit", type=int)
    serve.add_argument("--no-keyboard", action="store_true")
    serve.add_argument("--no-discovery", action="store_true")
    serve.add_argument("--no-log-to-file", action="store_true")
    serve.add_argument("--log-level", default="INFO")
    common(serve)

    return p


def main(argv: Optional[list[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    cmd = args.command or "serve"      # без аргументов — как в 2.2.0: сервер
    # argparse записывает в dest ТО ИМЯ, которым вызвали подпарсер:
    # `hyprscreen start` даёт command="start", а не "on" (проверено на 3.12),
    # поэтому алиасы нужно сводить к каноническим командам вручную.
    cmd = {"start": "on", "stop": "off", "kill": "off"}.get(cmd, cmd)
    if not hasattr(args, "as_json"):
        args.as_json = False
    if not hasattr(args, "monitor_spec"):
        args.monitor_spec = ""
    args.monitor_spec = getattr(args, "monitor_spec", "") or ""

    if cmd == "version":
        msg(f"hyprscreen {VERSION}")
        return 0
    if cmd in ("help", "--help"):
        return cmd_help()
    if cmd == "on":
        return cmd_on(args)
    if cmd == "off":
        return cmd_off(args)
    if cmd == "toggle":
        return cmd_toggle(args)
    if cmd == "restart":
        return cmd_restart(args)
    if cmd == "status":
        return cmd_status(args)
    if cmd == "monitors":
        return cmd_monitors(args)
    if cmd == "qr":
        return cmd_qr(args)
    if cmd == "grimtest":
        return cmd_grimtest(args)
    if cmd == "cleanup":
        return cmd_cleanup(args)
    if cmd == "doctor":
        return cmd_doctor(args)
    if cmd == "menu":
        return cmd_menu(args)
    if cmd == "gui":
        return cmd_gui(args)
    if cmd == "serve":
        return cmd_serve(args)
    parser.print_help()
    return 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
    except BrokenPipeError:
        # `hyprscreen status | head` и т.п.: пайп закрыт раньше времени —
        # это не ошибка приложения.
        try:
            devnull = os.open(os.devnull, os.O_WRONLY)
            os.dup2(devnull, sys.stdout.fileno())
        except OSError:
            pass
        sys.exit(0)
