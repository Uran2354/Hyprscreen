@file:Suppress("SpellCheckingInspection") // HyprScreen — не опечатка

package com.example.hyprscreen

import android.content.Context
import android.content.SharedPreferences

/**
 * Тонкая обёртка над SharedPreferences для HyprScreen.
 *
 * Хранит историю сохранённых хостов (не более 10, сериализуются как
 * разделённые `|` строки внутри StringSet).
 *
 * Формат записи хоста (разделитель `|`):
 * `host|port|name|lastUsed|token`
 * (поля `screen`/`overlay` из 2.x убраны: экран выбирается на PC,
 * оверлей-кнопки в 3.x нет.)
 */
class Prefs(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Сохранённые хосты, отсортированы по lastUsed по убыванию. */
    val savedHosts: List<SavedHost>
        get() {
            val set = prefs.getStringSet(KEY_HOSTS, emptySet()) ?: emptySet()
            return set.mapNotNull { line ->
                val parts = line.split('|')
                if (parts.size < 2) return@mapNotNull null
                SavedHost(
                    host = parts[0],
                    port = parts[1].toIntOrNull() ?: ServerInfo.DEFAULT_PORT,
                    name = parts.getOrNull(2)?.takeIf { it.isNotBlank() },
                    lastUsed = parts.getOrNull(3)?.toLongOrNull() ?: 0L,
                    token = parts.getOrNull(4)?.takeIf { it.isNotBlank() }
                )
            }.sortedByDescending { it.lastUsed }
        }

    fun saveHost(host: String, port: Int, name: String? = null, token: String? = null) {
        val current = savedHosts
            .filterNot { it.host == host && it.port == port }
            .toMutableList()
        current.add(
            SavedHost(
                host = host,
                port = port,
                name = name,
                lastUsed = System.currentTimeMillis(),
                token = token
            )
        )
        persistHosts(current.sortedByDescending { it.lastUsed }.take(MAX_HOSTS))
    }

    /** Удалить запись этого host:port (например, после ошибки подключения). */
    fun removeHost(host: String, port: Int) {
        persistHosts(savedHosts.filterNot { it.host == host && it.port == port })
    }

    private fun persistHosts(hosts: List<SavedHost>) {
        val serialised = hosts.map {
            "${it.host}|${it.port}|${it.name ?: ""}|${it.lastUsed}|${it.token ?: ""}"
        }.toSet()
        prefs.edit().putStringSet(KEY_HOSTS, serialised).apply()
    }

    companion object {
        private const val PREFS = "hyprscreen_prefs"
        private const val KEY_HOSTS = "saved_hosts"
        private const val MAX_HOSTS = 10
    }
}
