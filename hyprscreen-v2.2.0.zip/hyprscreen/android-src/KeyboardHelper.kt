@file:Suppress("SpellCheckingInspection") // HyprScreen/keysym — не опечатки

package com.example.hyprscreen

import android.app.Activity
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText

/**
 * Мост между мягкой клавиатурой Android (и любой аппаратной клавиатурой) и
 * входным протоколом HyprScreen.
 *
 * Стратегия:
 *  - Маленький скрытый [EditText] владеет InputConnection мягкой клавиатуры.
 *  - [TextWatcher] следит за его текстом: вставки становятся событиями `text`
 *    (с `\n` → `key` Return и `\t` → `key` Tab), удаления — событиями `key`
 *    BackSpace. EditText периодически очищается, чтобы не разрастался.
 *  - [EditText.OnEditorActionListener] ловит Enter, когда IME триггерит
 *    editor action без коммита новой строки.
 *  - [dispatchKey] вызывается из `dispatchKeyEvent` активности для обработки
 *    специальных клавиш (стрелки, F1–F12, Escape, Tab, Delete, Home, End,
 *    Page Up/Down) и Ctrl/Alt/Meta + печатные комбинации с аппаратных
 *    клавиатур.
 */
class KeyboardHelper(
    private val activity: Activity,
    private val editText: EditText,
    private val sender: (InputEvent) -> Unit
) {

    private val imm: InputMethodManager =
        activity.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager

    private var suppress = false

    init {
        editText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppress) return
                handleTextChange(s)
            }
        })

        editText.setOnEditorActionListener { _, actionId, event ->
            val isEnterAction = actionId == EditorInfo.IME_ACTION_UNSPECIFIED ||
                actionId == EditorInfo.IME_ACTION_NONE ||
                actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_NEXT ||
                actionId == EditorInfo.IME_ACTION_SEND ||
                actionId == EditorInfo.IME_ACTION_GO
            val isEnterKey = event?.keyCode == KeyEvent.KEYCODE_ENTER ||
                event?.keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER
            if (isEnterAction || isEnterKey) {
                sender(InputEvent.Key("Return", buildModifiers(event)))
                return@setOnEditorActionListener true
            }
            false
        }
    }

    /** Переключить видимость мягкой клавиатуры. */
    fun toggle() {
        if (isShowing()) hide() else show()
    }

    /** Поднять мягкую клавиатуру и сфокусировать скрытый EditText. */
    fun show() {
        editText.isEnabled = true
        editText.requestFocus()
        imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT)
    }

    /** Скрыть мягкую клавиатуру. */
    fun hide() {
        imm.hideSoftInputFromWindow(editText.windowToken, 0)
        editText.clearFocus()
    }

    /** True, если IME сейчас принимает текстовый ввод. */
    fun isShowing(): Boolean = imm.isAcceptingText

    /**
     * Вызывается из `dispatchKeyEvent` активности. Возвращает true, если
     * событие было обработано (специальная клавиша или Ctrl+печатная отправлена).
     */
    fun dispatchKey(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return false

        val keysym = keysymFor(event.keyCode)
        if (keysym != null) {
            sender(InputEvent.Key(keysym, buildModifiers(event)))
            return true
        }

        // Ctrl/Alt/Meta + печатная → событие key (аппаратные клавиатуры)
        if (event.isCtrlPressed || event.isAltPressed || event.isMetaPressed) {
            val ch = event.unicodeChar
            if (ch != 0) {
                val ks = Character.toString(ch.toChar())
                sender(InputEvent.Key(ks, buildModifiers(event)))
                return true
            }
        }
        return false
    }

    private fun handleTextChange(s: Editable?) {
        val after = s?.toString() ?: ""
        // Трактуем весь буфер как дельту против пустого «before»: всё
        // добавленное с последней очистки — новый ввод.
        if (after.isEmpty()) return
        val sb = StringBuilder()
        for (ch in after) {
            when (ch) {
                '\n' -> {
                    flushText(sb)
                    sender(InputEvent.Key("Return", emptyList()))
                }
                '\t' -> {
                    flushText(sb)
                    sender(InputEvent.Key("Tab", emptyList()))
                }
                else -> sb.append(ch)
            }
        }
        flushText(sb)
        // Очищаем буфер, чтобы EditText не разрастался и следующее изменение
        // трактовалось как свежая дельта.
        if (after.isNotEmpty()) {
            suppress = true
            s?.clear()
            suppress = false
        }
    }

    private fun flushText(sb: StringBuilder) {
        if (sb.isNotEmpty()) {
            sender(InputEvent.Text(sb.toString()))
            sb.clear()
        }
    }

    private fun keysymFor(keyCode: Int): String? = when (keyCode) {
        KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> "Return"
        KeyEvent.KEYCODE_DEL -> "BackSpace"
        KeyEvent.KEYCODE_TAB -> "Tab"
        KeyEvent.KEYCODE_ESCAPE -> "Escape"
        KeyEvent.KEYCODE_DPAD_LEFT -> "Left"
        KeyEvent.KEYCODE_DPAD_RIGHT -> "Right"
        KeyEvent.KEYCODE_DPAD_UP -> "Up"
        KeyEvent.KEYCODE_DPAD_DOWN -> "Down"
        KeyEvent.KEYCODE_HOME -> "Home"
        KeyEvent.KEYCODE_MOVE_END -> "End"
        KeyEvent.KEYCODE_PAGE_UP -> "Page_Up"
        KeyEvent.KEYCODE_PAGE_DOWN -> "Page_Down"
        KeyEvent.KEYCODE_INSERT -> "Insert"
        KeyEvent.KEYCODE_FORWARD_DEL -> "Delete"
        KeyEvent.KEYCODE_F1 -> "F1"
        KeyEvent.KEYCODE_F2 -> "F2"
        KeyEvent.KEYCODE_F3 -> "F3"
        KeyEvent.KEYCODE_F4 -> "F4"
        KeyEvent.KEYCODE_F5 -> "F5"
        KeyEvent.KEYCODE_F6 -> "F6"
        KeyEvent.KEYCODE_F7 -> "F7"
        KeyEvent.KEYCODE_F8 -> "F8"
        KeyEvent.KEYCODE_F9 -> "F9"
        KeyEvent.KEYCODE_F10 -> "F10"
        KeyEvent.KEYCODE_F11 -> "F11"
        KeyEvent.KEYCODE_F12 -> "F12"
        KeyEvent.KEYCODE_SPACE -> "space"
        else -> null
    }

    private fun buildModifiers(event: KeyEvent?): List<String> {
        if (event == null) return emptyList()
        val mods = mutableListOf<String>()
        if (event.isCtrlPressed) mods.add("ctrl")
        if (event.isShiftPressed) mods.add("shift")
        if (event.isAltPressed) mods.add("alt")
        if (event.isMetaPressed) mods.add("meta")
        return mods
    }
}
