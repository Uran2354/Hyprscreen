"""HyprScreen GUI — customtkinter (как в 2.2.0, под логику 3.9.0).

Компактный графический интерфейс вместо консольного меню:

* вкладка «Сервер» — запуск/остановка сервера, адрес для телефона;
* вкладка «Экран»  — выбор воркспейса (номер экрана, по умолчанию №6) и
  монитора, режим FPS с пресетами, клавиатура с телефона (wtype);
* вкладка «Телефон» — что сейчас на телефоне: имя экрана, статус стрима и
  кнопка «Посмотреть» — живой предпросмотр транслируемого экрана (grim).
  Вся служебная информация — ТОЛЬКО здесь, экран телефона чистый;
* вкладка «Лог»    — хвост лога сервера.

Сервер запускается отдельным процессом (``main.py serve -c config.toml``);
GUI читает его состояние из state-файла, общается с CLI, а смену
закреплённого воркспейса применяет к работающему серверу через
HTTP POST /workspace (воркспейс переезжает на виртуальный монитор, 3.9.0).

Известные грабли customtkinter, учтённые здесь:
  * секции «CTkTabview» в теме НЕТ — правим только CTkSegmentedButton/CTkFrame,
    а точечный патч идёт через _patch_theme (setdefault), иначе KeyError;
  * CTkLabel.fg_color — СТРОГО строка "transparent";
  * картинка предпросмотра — CTkImage (Pillow), с fallback на tk.PhotoImage.
"""

from __future__ import annotations

import base64
import binascii
import io
import json
import os
import subprocess
import sys
import threading
import time
import tkinter as tk
import urllib.request
from typing import Optional

import customtkinter as ctk

try:
    from PIL import Image as _PILImage
except ImportError:  # pragma: no cover
    _PILImage = None

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from config import Config, FPS_MODE_PRESETS, __version__, DEFAULT_WORKSPACE  # noqa: E402
import config as config_mod  # noqa: E402  # доступ к LAST_LOAD_ERROR в рантайме
import capture  # noqa: E402
import discovery  # noqa: E402  # все IP ПК (VPN/вторая карта — SETUP.md §7.8)
import hyprctl  # noqa: E402
import settings_store  # noqa: E402
import state_file  # noqa: E402

CACHE_DIR = os.path.join(
    os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache")), "hyprscreen"
)
SERVER_LOG = os.path.join(CACHE_DIR, "server.log")

#: Семейства шрифтов: жёсткий "Arial" ломал русский текст на системах без
#: ttf-liberation (fontconfig подставлял Nimbus Sans БЕЗ кириллицы). Ищем
#: первый установленный шрифт с полной кириллицей.
FONT_FAMILY = "Arial"
MONO_FAMILY = "Monospace"

_FONT_CANDIDATES = (
    "DejaVu Sans", "Liberation Sans", "Noto Sans", "Roboto",
    "FreeSans", "Ubuntu", "Cantarell", "Inter", "Arial",
)
_MONO_CANDIDATES = (
    "DejaVu Sans Mono", "Liberation Mono", "Noto Sans Mono",
    "FreeMono", "Monospace",
)


def _resolve_fonts() -> None:
    global FONT_FAMILY, MONO_FAMILY
    import tkinter.font as tkfont
    try:
        families = set(tkfont.families())
    except Exception:  # noqa: BLE001 — без root/шрифтов — дефолт
        return
    for name in _FONT_CANDIDATES:
        if name in families:
            FONT_FAMILY = name
            break
    for name in _MONO_CANDIDATES:
        if name in families:
            MONO_FAMILY = name
            break


MODE_LABELS = {
    "auto": "Авто (с адаптацией)",
    "eco": "Экономный",
    "balance": "Баланс",
    "smooth": "Плавный",
    "max": "Максимум",
    "custom": "Своё",
}
LABEL_TO_MODE = {v: k for k, v in MODE_LABELS.items()}

STATUS_RUNNING = "● работает"
STATUS_STOPPED = "● остановлен"

# Кэш списка IP ПК (all_lan_ips() дергает ip(8) — не чаще раза в 30 с).
_ips_cache: list[str] = []
_ips_ts = 0.0


def _cached_lan_ips() -> list[str]:
    global _ips_cache, _ips_ts
    now = time.monotonic()
    if not _ips_cache or now - _ips_ts > 30:
        try:
            _ips_cache = discovery.all_lan_ips()
        except Exception:  # noqa: BLE001 — без сети просто пусто
            _ips_cache = []
        _ips_ts = now
    return _ips_cache

# ── Палитра «чёрный + изумруд» (единый стиль док-страницы, GUI и APK) ──
BG         = "#0A0A0A"    # фон окна (neutral-950)
BG_CARD    = "#141414"    # карточки/фреймы (neutral-900)
BG_INPUT   = "#1C1C1C"    # поля ввода
BORDER     = "#262626"    # рамки (neutral-800)
TXT        = "#F5F5F5"    # основной текст
TXT_DIM    = "#A3A3A3"    # вторичный текст (neutral-400)
TXT_HINT   = "#6B6B6B"    # подсказки (neutral-500)
EMERALD    = "#10B981"    # акцент (emerald-500)
EMERALD_H  = "#34D399"    # hover (emerald-400)
EMERALD_PALE = "#6EE7B7"
ON_EMERALD = "#04150F"    # тёмный текст на изумрудной заливке
EMERALD_DIM = "#0B2E23"   # тёмная изумрудная плашка
RED        = "#F87171"    # ошибка/остановлен (red-400)
RED_BRIGHT = "#EF4444"    # захват не работает (red-500)
RED_DIM    = "#2A1212"    # тёмно-красная плашка
RED_TXT    = "#FCA5A5"    # светлый текст ошибок
STOP_BG    = "#B91C1C"    # кнопка «Остановить»
STOP_HOVER = "#DC2626"

ACCENT = EMERALD


def _patch_theme(t: dict, key: str, values: dict) -> None:
    """Точечный патч темы customtkinter, не зависящий от версии.

    Ключа может не быть в конкретной версии (например, «CTkTabview» в
    5.2.x–6.0.x темой не является вовсе). Прямой ``t["CTkTabview"].update(...)``
    падал с KeyError на старте GUI (реальный баг 2.1.3) — ``setdefault``
    создаёт отсутствующий ключ: лишние ключи виджеты игнорируют.
    """
    block = t.get(key)
    if not isinstance(block, dict):
        block = {}
        t[key] = block
    block.update(values)


def apply_ctk_theme() -> None:
    """Тема customtkinter «чёрный + изумруд» для всех виджетов сразу."""
    t = ctk.ThemeManager.theme
    _patch_theme(t, "CTkFrame", {
        "fg_color": [BG_CARD, BG_CARD], "top_fg_color": [BG_CARD, BG_CARD],
        "border_color": [BORDER, BORDER], "border_width": 1, "corner_radius": 12,
    })
    _patch_theme(t, "CTkButton", {
        "fg_color": [EMERALD, EMERALD], "hover_color": [EMERALD_H, EMERALD_H],
        "text_color": [ON_EMERALD, ON_EMERALD], "text_color_disabled": [TXT_HINT, TXT_HINT],
        "corner_radius": 10, "border_color": [BORDER, BORDER],
    })
    _patch_theme(t, "CTkEntry", {
        "fg_color": [BG_INPUT, BG_INPUT], "border_color": [BORDER, BORDER],
        "text_color": [TXT, TXT], "placeholder_text_color": [TXT_HINT, TXT_HINT],
        "corner_radius": 10, "border_width": 1,
    })
    _patch_theme(t, "CTkLabel", {
        "text_color": [TXT, TXT],
        # СТРОГО строка "transparent", НЕ список! ctk сравнивает
        # `if self._fg_color == "transparent"` со строкой: список не
        # совпадал, литерал уходил в canvas.itemconfig → TclError
        # unknown color name "transparent" (краш старта на ctk 6.0.0).
        "fg_color": "transparent",
        "corner_radius": 8,
    })
    # Секции "CTkTabview" в теме НЕТ: рамка табов — CTkFrame (выше),
    # «пилюли» вкладок — CTkSegmentedButton.
    _patch_theme(t, "CTkSegmentedButton", {
        "fg_color": [BG_INPUT, BG_INPUT],
        "selected_color": [EMERALD, EMERALD],
        "selected_hover_color": [EMERALD_H, EMERALD_H],
        "unselected_color": [BG_INPUT, BG_INPUT],
        "unselected_hover_color": [BG_CARD, BG_CARD],
        "text_color": [TXT, TXT], "text_color_disabled": [TXT_HINT, TXT_HINT],
        "corner_radius": 10,
    })
    _patch_theme(t, "CTkOptionMenu", {
        "fg_color": [BG_INPUT, BG_INPUT], "button_color": [EMERALD_DIM, EMERALD_DIM],
        "button_hover_color": [EMERALD, EMERALD], "text_color": [TXT, TXT],
        "text_color_disabled": [TXT_HINT, TXT_HINT], "corner_radius": 10,
    })
    _patch_theme(t, "CTkSlider", {
        "fg_color": [BG_INPUT, BG_INPUT], "progress_color": [EMERALD, EMERALD],
        "button_color": [EMERALD, EMERALD], "button_hover_color": [EMERALD_H, EMERALD_H],
    })
    _patch_theme(t, "CTkSwitch", {
        "fg_color": [BG_INPUT, BG_INPUT], "progress_color": [EMERALD, EMERALD],
        "button_color": [TXT, TXT], "button_hover_color": [EMERALD_PALE, EMERALD_PALE],
        "text_color": [TXT, TXT],
    })
    _patch_theme(t, "CTkCheckBox", {
        "fg_color": [EMERALD, EMERALD], "border_color": [BORDER, BORDER],
        "hover_color": [EMERALD_H, EMERALD_H], "checkmark_color": [ON_EMERALD, ON_EMERALD],
        "text_color": [TXT, TXT],
    })
    _patch_theme(t, "CTkTextbox", {
        "fg_color": ["#101010", "#101010"], "border_color": [BORDER, BORDER],
        "text_color": ["#D4D4D4", "#D4D4D4"], "border_width": 1, "corner_radius": 10,
        "scrollbar_button_color": [BG_INPUT, BG_INPUT],
        "scrollbar_button_hover_color": [BORDER, BORDER],
    })
    _patch_theme(t, "DropdownMenu", {
        "fg_color": [BG_CARD, BG_CARD], "hover_color": [EMERALD_DIM, EMERALD_DIM],
        "text_color": [TXT, TXT],
    })
    _patch_theme(t, "CTkScrollableFrame", {"label_fg_color": [BG_CARD, BG_CARD]})


class ServerController:
    """Управление серверным процессом ``main.py serve``."""

    def __init__(self) -> None:
        self.proc: Optional[subprocess.Popen] = None
        self._log_fh = None

    def running(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def start(self, cfg: Config) -> tuple[bool, str]:
        if self.running():
            return False, "Сервер уже запущен"
        # Сервер, стартованный вне GUI (CLI/тикер) — не дублируем.
        pid = state_file.state_pid_alive()
        if pid is not None:
            return False, (
                f"Сервер уже работает (pid {pid}, запущен вне GUI) — "
                "остановите его: hyprscreen off"
            )
        cfg_path = os.path.join(BASE_DIR, "config.toml")
        cfg.save(cfg_path)
        venv_python = os.path.join(BASE_DIR, ".venv", "bin", "python")
        python_bin = venv_python if os.path.exists(venv_python) else sys.executable
        env = {**os.environ, "PYTHONPATH": BASE_DIR}
        os.makedirs(CACHE_DIR, exist_ok=True)
        try:
            self._log_fh = open(SERVER_LOG, "w")
            self.proc = subprocess.Popen(
                [python_bin, os.path.join(BASE_DIR, "main.py"), "serve",
                 "-c", cfg_path, "--no-log-to-file", "--log-level", "INFO"],
                stdout=self._log_fh,
                stderr=subprocess.STDOUT,
                cwd=BASE_DIR,
                env=env,
                start_new_session=True,
            )
        except Exception as exc:  # noqa: BLE001
            self._close_log()
            self.proc = None
            return False, f"Не удалось запустить: {exc}"
        return True, f"Запущен (pid {self.proc.pid})"

    def _close_log(self) -> None:
        if self._log_fh is not None:
            try:
                self._log_fh.close()
            except Exception:  # noqa: BLE001
                pass
            self._log_fh = None

    def stop(self) -> tuple[bool, str]:
        """Остановить сервер; вернуть (успех, сообщение).

        ВЫЗЫВАТЬ ИЗ ФОНОВОГО ПОТОКА (GUI-стоп не блокирует окно).
        Внешний сервер (CLI/перезапущенный GUI) раньше получал SIGTERM,
        после чего GUI СРАЗУ сообщал «Остановлен» и удалял state — сервер
        ещё жил (teardown) и пересоздавал state, GUI снова показывал
        «Сервер уже работает» — «сервер не останавливается» (3.9.1).
        """
        if not self.running():
            self.proc = None
            self._close_log()
            # Сервер мог быть запущен CLI — остановим и его.
            pid = state_file.state_pid_alive()
            if pid is not None:
                try:
                    os.kill(pid, 15)
                except OSError:
                    pass
                # ЖДЁМ фактического выхода (teardown + восстановление
                # воркспейса занимает до нескольких секунд)
                deadline = time.monotonic() + 6.0
                while time.monotonic() < deadline:
                    if state_file.state_pid_alive() is None:
                        state_file.clear_state()
                        return True, f"Остановлен внешний сервер (pid {pid})"
                    time.sleep(0.15)
                return (False,
                        f"Сервер (pid {pid}) ещё завершается — повторите "
                        f"через несколько секунд или: kill -9 {pid}")
            state_file.clear_state()  # остатки битого state не должны мешать
            return False, "Сервер не запущен"
        assert self.proc is not None
        proc, self.proc = self.proc, None
        proc.terminate()
        forced = False
        try:
            proc.wait(timeout=8)
        except Exception:  # noqa: BLE001
            forced = True
            try:
                proc.kill()
                proc.wait(timeout=3)  # не оставляем зомби
            except Exception:  # noqa: BLE001
                pass
        self._close_log()
        state_file.clear_state()
        if forced:
            # teardown оборван SIGKILL — закрепление могло остаться;
            # путь восстановления — `hyprscreen cleanup` (и при следующем
            # старте головной монитор переиспользуется сам)
            return True, ("Остановлен принудительно (не ответил за 8 с). "
                          "Воркспейс мог остаться на виртуальном мониторе — "
                          "исправит: hyprscreen cleanup")
        return True, "Остановлен"

    def exit_code(self) -> Optional[int]:
        if self.proc is not None and self.proc.poll() is not None:
            return self.proc.returncode
        return None


class GuiApp(ctk.CTk):
    """Окно HyprScreen."""

    def __init__(self) -> None:
        super().__init__()
        self._monitor_choices_cached: list[str] = []
        _resolve_fonts()
        self.title(f"HyprScreen {__version__} — зеркало экрана на телефон")
        self.geometry("800x680")
        self.minsize(720, 600)
        ctk.set_appearance_mode("dark")
        self.configure(fg_color=BG)
        apply_ctk_theme()

        self.server = ServerController()
        self._ui_ready = False
        # асинхронная остановка (3.9.1): результат подбирает _tick_status
        self._stopping = False
        self._stop_result: Optional[tuple[bool, str]] = None
        # -- предпросмотр ----------------------------------------------------
        self._preview_on = False
        self._preview_busy = False
        self._preview_job: Optional[str] = None
        self._preview_photo: Optional[object] = None

        # Одноразовая миграция настроек (v2.x → v4).
        self._migrate_actions = settings_store.migrate()

        self._build_header()
        self._build_tabs()
        self._load_initial_values()
        self._ui_ready = True

        self.after(1000, self._tick_status)
        self.after(2000, self._tick_phone)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------------------------------------------------ UI
    def _build_header(self) -> None:
        """Шапка-карточка: слева название + версия-пилюля + подпись,
        в центре — БЫСТРЫЙ выбор воркспейса (виден всегда, без вкладки
        «Экран»), справа — статус-пилюля (работает/остановлен)."""
        header = ctk.CTkFrame(
            self, fg_color=BG_CARD, border_width=1, border_color=BORDER,
            corner_radius=16,
        )
        header.pack(fill="x", padx=16, pady=(16, 10))

        # левая часть: название, версия, подпись
        left = ctk.CTkFrame(header, fg_color="transparent")
        left.pack(side="left", padx=(16, 8), pady=10)

        title_row = ctk.CTkFrame(left, fg_color="transparent")
        title_row.pack(anchor="w")
        ctk.CTkLabel(
            title_row, text="HyprScreen",
            font=(FONT_FAMILY, 21, "bold"),
        ).pack(side="left")
        ver = ctk.CTkFrame(title_row, fg_color=EMERALD_DIM, corner_radius=8)
        ver.pack(side="left", padx=(10, 0), pady=2)
        ctk.CTkLabel(
            ver, text=f"v{__version__}", text_color=EMERALD_PALE,
            font=(FONT_FAMILY, 11, "bold"),
        ).pack(padx=8, pady=2)

        ctk.CTkLabel(
            left, text="зеркало экрана на телефон",
            text_color=TXT_DIM, font=(FONT_FAMILY, 12),
        ).pack(anchor="w")

        # центр: быстрый выбор воркспейса (зеркало селектора вкладки
        # «Экран»; выбор здесь меняет и «Воркспейс» там)
        mid = ctk.CTkFrame(header, fg_color="transparent")
        mid.pack(side="left", padx=(18, 8), pady=8)
        ctk.CTkLabel(
            mid, text="Воркспейс для показа:", text_color=TXT_DIM,
            font=(FONT_FAMILY, 11),
        ).pack(anchor="w", padx=2)
        self.opt_ws_header = ctk.CTkOptionMenu(
            mid, width=160, height=28,
            values=["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"],
            command=self._on_header_ws, font=(FONT_FAMILY, 12),
        )
        self.opt_ws_header.pack(anchor="w", pady=(3, 0))

        # правая часть: статус-пилюля (цвет фона меняется в _tick_status)
        self.status_pill = ctk.CTkFrame(header, fg_color=RED_DIM, corner_radius=14)
        self.status_pill.pack(side="right", padx=(8, 16), pady=10)
        self.status_badge = ctk.CTkLabel(
            self.status_pill, text=STATUS_STOPPED, text_color=RED,
            font=(FONT_FAMILY, 13, "bold"),
        )
        self.status_badge.pack(padx=14, pady=6)

    def _build_tabs(self) -> None:
        self.tabs = ctk.CTkTabview(self, width=760, height=540)
        self.tabs.pack(fill="both", expand=True, padx=16, pady=8)
        self.tabs.add("Сервер")
        self.tabs.add("Экран")
        self.tabs.add("Телефон")
        self.tabs.add("Лог")
        self._build_tab_server(self.tabs.tab("Сервер"))
        self._build_tab_screen(self.tabs.tab("Экран"))
        self._build_tab_phone(self.tabs.tab("Телефон"))
        self._build_tab_log(self.tabs.tab("Лог"))

    # --- вкладка «Сервер» -------------------------------------------------
    def _build_tab_server(self, tab: ctk.CTkFrame) -> None:
        row = ctk.CTkFrame(tab, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=(14, 8))
        self.btn_start = ctk.CTkButton(
            row, text="▶  Запустить сервер", command=self._on_start, width=190
        )
        self.btn_start.pack(side="left", padx=(0, 8))
        self.btn_stop = ctk.CTkButton(
            row, text="■  Остановить", command=self._on_stop,
            width=160, fg_color=STOP_BG, hover_color=STOP_HOVER,
            text_color="#FEF2F2",
        )
        self.btn_stop.pack(side="left")

        info = ctk.CTkFrame(tab)
        info.pack(fill="x", padx=12, pady=8)
        self.lbl_addr = ctk.CTkLabel(info, text="Адрес: —", anchor="w")
        self.lbl_addr.pack(fill="x", padx=12, pady=(10, 2))
        # С 3.7.1: при VPN/второй карте у ПК несколько адресов — показываем все,
        # чтобы телефон подключали по рабочему (см. SETUP.md §7.8).
        self.lbl_other_ips = ctk.CTkLabel(
            info, text="", anchor="w", text_color=TXT_HINT,
        )
        self.lbl_other_ips.pack(fill="x", padx=12, pady=(0, 2))
        self.lbl_screen_hint = ctk.CTkLabel(info, text="Экран: —", anchor="w")
        self.lbl_screen_hint.pack(fill="x", padx=12, pady=2)
        self.lbl_server_line = ctk.CTkLabel(info, text="Статус: остановлен", anchor="w")
        self.lbl_server_line.pack(fill="x", padx=12, pady=(2, 10))

        opts = ctk.CTkFrame(tab, fg_color="transparent")
        opts.pack(fill="x", padx=12, pady=8)
        ctk.CTkLabel(opts, text="Порт:").pack(side="left", padx=(0, 6))
        self.ent_port = ctk.CTkEntry(opts, width=90)
        self.ent_port.pack(side="left", padx=(0, 16))
        ctk.CTkLabel(opts, text="Токен (необязательно):").pack(side="left", padx=(0, 6))
        self.ent_token = ctk.CTkEntry(opts, width=200, show="•")
        self.ent_token.pack(side="left")

        self.lbl_server_msg = ctk.CTkLabel(tab, text="", text_color=RED_TXT)
        self.lbl_server_msg.pack(fill="x", padx=12, pady=4)

        hint = ctk.CTkLabel(
            tab, justify="left", anchor="w",
            text=(
                "Как подключить телефон:\n"
                "  1. Телефон и PC — в одной Wi-Fi сети.\n"
                "  2. Приложение HyprScreen: IP и порт подставятся сами "
                "(discovery), либо браузер — адрес выше.\n"
                "  3. В приложении: тап по экрану — клавиатура (ввод с телефона), "
                "кнопка «⏻» — отключиться."
            ),
        )
        hint.pack(fill="x", padx=12, pady=(10, 12))

    # --- вкладка «Экран» ---------------------------------------------------
    def _build_tab_screen(self, tab: ctk.CTkFrame) -> None:
        mon_frame = ctk.CTkFrame(tab)
        mon_frame.pack(fill="x", padx=12, pady=(14, 8))
        ctk.CTkLabel(
            mon_frame, text="Воркспейс Hyprland для показа:",
            font=(FONT_FAMILY, 14, "bold"),
        ).pack(anchor="w", padx=12, pady=(10, 2))

        # Выбранный воркспейс на старте переезжает на ВИРТУАЛЬНЫЙ монитор
        # (headless, 3.9.0) и рендерится там всегда — его снимает grim.
        # Селектор «Монитор» — информационный: показывает физический монитор.
        row = ctk.CTkFrame(mon_frame, fg_color="transparent")
        row.pack(anchor="w", padx=12, pady=(2, 2))
        ctk.CTkLabel(row, text="Воркспейс:").pack(side="left", padx=(0, 6))
        self.opt_ws_number = ctk.CTkOptionMenu(
            row, width=86, values=["1", "2", "3", "4", "5", "6",
                                   "7", "8", "9", "10"],
            command=self._on_ws_number,
        )
        self.opt_ws_number.pack(side="left", padx=(0, 18))
        ctk.CTkLabel(row, text="Монитор (разрешается сам):").pack(
            side="left", padx=(0, 6))
        self.opt_monitor = ctk.CTkOptionMenu(
            row, width=330, values=["…"], command=self._on_monitor_choice,
        )
        self.opt_monitor.pack(side="left")

        ctk.CTkButton(
            mon_frame, text="⟳  Обновить воркспейсы и мониторы", width=230, height=26,
            fg_color=BG_INPUT, hover_color=BORDER, text_color=TXT_DIM,
            command=self._refresh_monitors,
        ).pack(anchor="w", padx=12, pady=(6, 2))

        self.lbl_monitor_msg = ctk.CTkLabel(
            mon_frame, text="", text_color=TXT_DIM,
        )
        self.lbl_monitor_msg.pack(anchor="w", padx=12, pady=(4, 10))

        fps_frame = ctk.CTkFrame(tab)
        fps_frame.pack(fill="x", padx=12, pady=8)
        ctk.CTkLabel(
            fps_frame, text="Режим FPS (авто-настройка параметров):",
            font=(FONT_FAMILY, 14, "bold"),
        ).pack(anchor="w", padx=12, pady=(10, 2))
        self.opt_mode = ctk.CTkOptionMenu(
            fps_frame, values=list(MODE_LABELS.values()), width=240,
            command=self._on_mode_change,
        )
        self.opt_mode.pack(anchor="w", padx=12, pady=(2, 8))

        self.var_fps = tk.DoubleVar(value=24)
        self.var_quality = tk.DoubleVar(value=75)
        self.var_scale = tk.DoubleVar(value=0.75)
        self.sld_fps = self._make_slider(fps_frame, "FPS", self.var_fps, 5, 60)
        self.sld_quality = self._make_slider(fps_frame, "Качество JPEG", self.var_quality, 30, 95)
        self.sld_scale = self._make_slider(fps_frame, "Масштаб кадра", self.var_scale, 0.4, 1.0)

        kb_frame = ctk.CTkFrame(tab)
        kb_frame.pack(fill="x", padx=12, pady=8)
        self.sw_keyboard = ctk.CTkSwitch(
            kb_frame, text="Клавиатура с телефона (тап по экрану в приложении → wtype)"
        )
        self.sw_keyboard.select()
        self.sw_keyboard.pack(anchor="w", padx=12, pady=10)

        actions = ctk.CTkFrame(tab, fg_color="transparent")
        actions.pack(fill="x", padx=12, pady=(2, 8))
        ctk.CTkButton(
            actions, text="Сохранить настройки", width=180,
            command=self._on_save_config,
        ).pack(side="left")
        self.lbl_screen_msg = ctk.CTkLabel(actions, text="", text_color=RED_TXT)
        self.lbl_screen_msg.pack(side="left", padx=12)

    def _make_slider(self, parent: ctk.CTkFrame, title: str, var: tk.DoubleVar,
                     from_: float, to: float) -> ctk.CTkSlider:
        block = ctk.CTkFrame(parent, fg_color="transparent")
        block.pack(fill="x", padx=12, pady=(0, 6))
        ctk.CTkLabel(block, text=title, width=140, anchor="w").pack(side="left")
        slider = ctk.CTkSlider(block, from_=from_, to=to, variable=var, width=260)
        slider.pack(side="left", padx=(0, 10))
        value_lbl = ctk.CTkLabel(block, textvariable=var, width=52)
        value_lbl.pack(side="left")
        return slider

    # --- вкладка «Телефон» ---------------------------------------------------
    def _build_tab_phone(self, tab: ctk.CTkFrame) -> None:
        top = ctk.CTkFrame(tab, fg_color="transparent")
        top.pack(fill="x", padx=12, pady=(14, 4))

        big = ctk.CTkFrame(top)
        big.pack(side="left", fill="both", expand=True)
        ctk.CTkLabel(
            big, text="Что сейчас показывает телефон:",
            font=(FONT_FAMILY, 14, "bold"),
        ).pack(anchor="w", padx=12, pady=(10, 2))
        self.lbl_phone_monitor = ctk.CTkLabel(
            big, text="—", font=(FONT_FAMILY, 26, "bold"), text_color=ACCENT,
        )
        self.lbl_phone_monitor.pack(anchor="w", padx=12, pady=(0, 10))

        self.btn_view = ctk.CTkButton(
            top, text="👁  Посмотреть экран", width=210,
            command=self._toggle_preview,
        )
        self.btn_view.pack(side="right", padx=(8, 0), pady=(30, 0))

        info = ctk.CTkFrame(tab)
        info.pack(fill="x", padx=12, pady=8)
        self.lbl_phone_lines = ctk.CTkLabel(
            info, text="ждём сервер…", justify="left", anchor="w",
            font=(FONT_FAMILY, 13),
        )
        self.lbl_phone_lines.pack(fill="x", padx=12, pady=10)

        # --- живой предпросмотр (вся статистика — здесь, не на телефоне) ---
        self.frame_preview = ctk.CTkFrame(tab)
        self.lbl_preview = ctk.CTkLabel(
            self.frame_preview, text="", height=470,
        )
        self.lbl_preview.pack(fill="x", padx=12, pady=(10, 2))
        self.lbl_preview_caption = ctk.CTkLabel(
            self.frame_preview, text="", justify="center", text_color=TXT_DIM,
        )
        self.lbl_preview_caption.pack(fill="x", padx=12, pady=(0, 10))

        self._note_widget = ctk.CTkLabel(
            tab, justify="left", anchor="w", text_color=TXT_DIM,
            text=(
                "Экран телефона чистый: FPS/статус показываются только здесь "
                "и в предпросмотре.\nКлавиатура — тап по экрану в приложении; "
                "завершить просмотр — кнопка «⏻» в углу."
            ),
        )
        self._note_widget.pack(fill="x", padx=12, pady=8)

    # --- вкладка «Лог» -------------------------------------------------------
    def _build_tab_log(self, tab: ctk.CTkFrame) -> None:
        btn_row = ctk.CTkFrame(tab, fg_color="transparent")
        btn_row.pack(fill="x", padx=12, pady=(12, 4))
        ctk.CTkButton(btn_row, text="Обновить", width=120,
                      command=self._refresh_log).pack(side="left")
        ctk.CTkLabel(btn_row, text=f"хвост {SERVER_LOG}").pack(side="left", padx=10)
        self.txt_log = ctk.CTkTextbox(tab, font=(MONO_FAMILY, 11))
        self.txt_log.pack(fill="both", expand=True, padx=12, pady=(4, 12))

    # ------------------------------------------------------------- значения
    def _monitor_choices(self) -> list[str]:
        hyprctl.fix_env()
        return hyprctl.monitors_display()

    def _ws_choices(self) -> list[str]:
        """Воркспейсы для селекторов: всегда 1..10 + открытые сверх того."""
        nums = set(range(1, 11))
        try:
            nums.update(hyprctl.open_workspace_numbers())
        except Exception:  # noqa: BLE001 — без hyprctl остаёмся при 1..10
            pass
        return [str(n) for n in sorted(nums)]

    def _choice_index(self, choice: str) -> Optional[int]:
        """'6' или '6: DP-3 — …' → 6."""
        try:
            return int(str(choice).split(":", 1)[0].strip())
        except (ValueError, IndexError):
            return None

    def _apply_ws_choices(self, preferred_ws: Optional[int] = None) -> None:
        """Заполнить селекторы воркспейсов (шапка + вкладка «Экран»).

        Список ВСЕГДА содержит 1..10 — даже если hyprctl недоступен,
        поэтому дефолтный №6 виден всегда (не зависит от числа мониторов).
        """
        choices = self._ws_choices()
        self.opt_ws_number.configure(values=choices)
        self.opt_ws_header.configure(values=choices)
        ws = preferred_ws or settings_store.get_workspace() \
            or DEFAULT_WORKSPACE
        if str(ws) not in choices:
            choices = sorted([*choices, str(ws)], key=int)
            self.opt_ws_number.configure(values=choices)
            self.opt_ws_header.configure(values=choices)
        self.opt_ws_number.set(str(ws))
        self.opt_ws_header.set(str(ws))
        self._update_monitor_msg(str(ws))

    def _update_monitor_msg(self, ws_choice: str) -> None:
        """Подсказка: что произойдёт с этим воркспейсом при трансляции."""
        ws = self._choice_index(ws_choice)
        if not ws:
            self.lbl_monitor_msg.configure(text="выберите воркспейс")
            return
        mon = hyprctl.workspace_monitor(ws)
        if mon and mon.startswith("HEADLESS-"):
            # воркспейс уже закреплён работающей трансляцией
            self.lbl_monitor_msg.configure(
                text=(f"Показываем воркспейс №{ws} → виртуальный монитор "
                      f"{mon}: кадры живые всегда, экраны ПК свободны")
            )
            return
        if mon:
            res = hyprctl.monitor_resolution(mon)
            self.lbl_monitor_msg.configure(
                text=(f"Показываем воркспейс №{ws} → при запуске он "
                      "переедет на виртуальный монитор (экран ПК не "
                      "переключится, кадры живые всегда)"
                      + (f" · сейчас: {mon}" + (f" ({res})" if res else "")))
            )
            choice = next((c for c in self._monitor_choices_cached
                           if c.startswith(f"{mon} ")), None) \
                if self._monitor_choices_cached else None
            if choice:
                self.opt_monitor.configure(values=self._monitor_choices_cached)
                self.opt_monitor.set(choice)
            else:
                self.opt_monitor.set(f"{mon}")
        else:
            self.opt_monitor.set("воркспейс не открыт")
            self.lbl_monitor_msg.configure(
                text=(f"воркспейс №{ws} сейчас не открыт — при запуске "
                      "трансляции сервер создаст виртуальный монитор и "
                      "откроет на нём №{}: экран ПК не переключится, "
                      "телефон покажет №{} живьём (с 3.9.0)".format(ws, ws))
            )

    # --- обработчики селекторов --------------------------------------------
    def _live_ws_note(self, ws: int) -> None:
        """Мгновенно применить воркспейс к работающей трансляции и показать ответ."""
        srv_msg = self._apply_workspace_live(ws)
        if srv_msg:
            self.lbl_monitor_msg.configure(
                text=f"трансляция: {srv_msg}", text_color=ACCENT
            )

    def _on_ws_number(self, num: str) -> None:
        """Выбран воркспейс (вкладка «Экран») → синхронизировать шапку."""
        if self._choice_index(num) is None:
            return
        # Защита от версий ctk, где command зовётся ДО обновления значения.
        if self.opt_ws_number.get() != num:
            self.opt_ws_number.set(num)
        self.opt_ws_header.set(num)
        settings_store.set_workspace(self._choice_index(num) or 0)
        self._update_monitor_msg(num)
        # Работающая трансляция: закрепление меняется СРАЗУ (воркспейс
        # переезжает на виртуальный монитор), без кнопки «Сохранить» и
        # без перезапуска сервера.
        self._live_ws_note(self._choice_index(num) or 0)

    def _on_monitor_choice(self, choice: str) -> None:
        """Выбран монитор вручную → показать его АКТИВНЫЙ воркспейс.

        Источник истины — воркспейс: grim всегда снимает монитор целиком,
        поэтому «показать монитор» = «показать его текущий воркспейс».
        """
        # Защита от версий ctk, где command зовётся ДО обновления значения.
        if self.opt_monitor.get() != choice:
            self.opt_monitor.set(choice)
        name = choice.split(":", 1)[1].split("—")[0].strip() \
            if ":" in choice else choice
        if not name or " " in name or name.startswith(("воркспейс", "…", "экраны")):
            return
        ws = hyprctl.monitor_active_workspace(name)
        if ws and str(ws) in self.opt_ws_number.cget("values"):
            self.opt_ws_number.set(str(ws))
            self.opt_ws_header.set(str(ws))
            settings_store.set_workspace(ws)
            self.lbl_monitor_msg.configure(
                text=(f"Показываем воркспейс №{ws} (активный на {name}) — "
                      "выбрать другой можно селектором воркспейса")
            )
        else:
            self.lbl_monitor_msg.configure(
                text=(f"активный воркспейс {name} не определён — "
                      "выберите воркспейс селектором")
            )

    def _on_header_ws(self, choice: str) -> None:
        """Выбор воркспейса в ШАПКЕ → те же действия, что на вкладке «Экран»."""
        if self._choice_index(choice) is None:
            return
        if self.opt_ws_header.get() != choice:
            self.opt_ws_header.set(choice)
        self.opt_ws_number.set(choice)
        settings_store.set_workspace(self._choice_index(choice) or 0)
        self._update_monitor_msg(choice)
        self._live_ws_note(self._choice_index(choice) or 0)

    def _refresh_monitors(self) -> None:
        """Перечитать воркспейсы и мониторы из hyprctl, сохраняя выбор."""
        current = self._choice_index(self.opt_ws_number.get())
        self._monitor_choices_cached = self._monitor_choices()
        self._apply_ws_choices(current)

    def _load_initial_values(self) -> None:
        # Воркспейс: сохранённый выбор, иначе №6 (DEFAULT_WORKSPACE).
        # Список воркспейсов всегда содержит 1..10, поэтому №6 виден
        # даже без hyprctl и даже с одним монитором.
        self._monitor_choices_cached = self._monitor_choices()
        preferred: Optional[int] = None
        try:
            cfg_ws = Config.from_file(
                os.path.join(BASE_DIR, "config.toml")).workspace
            if cfg_ws:
                preferred = int(cfg_ws)
        except Exception:  # noqa: BLE001 — битый toml — дефолты
            pass
        self._apply_ws_choices(preferred)

        # Режим FPS + значения слайдеров из config.toml
        mode = settings_store.get_fps_mode("auto")
        fps, quality, scale = 24, 75, 0.75
        cfg_path = os.path.join(BASE_DIR, "config.toml")
        if os.path.exists(cfg_path):
            try:
                saved = Config.from_file(cfg_path)
                mode = saved.fps_mode if saved.fps_mode in MODE_LABELS else mode
                fps, quality, scale = saved.fps, saved.jpeg_quality, saved.scale
                if mode in FPS_MODE_PRESETS:
                    saved.apply_fps_mode()
                    fps, quality, scale = saved.fps, saved.jpeg_quality, saved.scale
                self.ent_port.delete(0, "end")
                self.ent_port.insert(0, str(saved.port))
                if saved.auth_token:
                    self.ent_token.delete(0, "end")
                    self.ent_token.insert(0, saved.auth_token)
                if not saved.keyboard_enabled:
                    self.sw_keyboard.deselect()
            except Exception:  # noqa: BLE001 — битый toml — дефолты
                pass
        self.var_fps.set(float(fps))
        self.var_quality.set(float(quality))
        self.var_scale.set(float(scale))
        self.opt_mode.set(MODE_LABELS.get(mode, MODE_LABELS["auto"]))
        self._on_mode_change(self.opt_mode.get())

        if self._migrate_actions:
            self.lbl_screen_msg.configure(
                text="настройки обновлены: " + "; ".join(self._migrate_actions),
                text_color=RED_TXT,
            )

    def _collect_config(self) -> Config:
        # База — СОХРАНЁННЫЙ config.toml, а не голые дефолты: раньше каждый
        # старт GUI молча сбрасывал discovery_enabled / input_rate_limit /
        # monitor и т.д. к значениям по умолчанию.
        cfg = Config.from_file(os.path.join(BASE_DIR, "config.toml"))
        # GUI поля bind не имеет, а loopback-адрес НЕ даст телефону
        # подключиться — подменяем его на «все интерфейсы».
        if cfg.bind_address in ("127.0.0.1", "localhost", "::1"):
            cfg.bind_address = "0.0.0.0"
        try:
            cfg.port = int(self.ent_port.get().strip() or "8080")
        except ValueError:
            cfg.port = 8080
        cfg.auth_token = self.ent_token.get().strip() or None
        cfg.fps_mode = LABEL_TO_MODE.get(self.opt_mode.get(), "auto")
        if cfg.fps_mode == "custom":
            cfg.fps = int(self.var_fps.get())
            cfg.jpeg_quality = int(self.var_quality.get())
            cfg.scale = float(self.var_scale.get())
        cfg.keyboard_enabled = bool(self.sw_keyboard.get())
        cfg.workspace = self._choice_index(self.opt_ws_number.get()) \
            or DEFAULT_WORKSPACE
        cfg.apply_fps_mode()
        return cfg

    # ------------------------------------------------------------- действия
    def _apply_workspace_live(self, ws: int) -> Optional[str]:
        """Живое применение воркспейса к работающему серверу (POST /workspace).

        Сервер сам обновит закрепление (воркспейс переедет на виртуальный
        монитор). Возвращает сообщение сервера или None, если применить
        через сервер нечем (не запущен / старая версия) — тогда вызывающий
        делает switch_workspace напрямую.
        """
        if state_file.state_pid_alive() is None and not self.server.running():
            return None
        state = state_file.read_state() or {}
        try:
            port = int(state.get("port") or 0) or int(
                self.ent_port.get().strip() or "8080")
        except (TypeError, ValueError):
            port = 8080
        token = self.ent_token.get().strip()
        req = urllib.request.Request(
            f"http://127.0.0.1:{port}/workspace",
            data=json.dumps({"workspace": int(ws or 0)}).encode("utf-8"),
            method="POST",
            headers={"Content-Type": "application/json",
                     "X-Hyprscreen-Token": token},
        )
        try:
            with urllib.request.urlopen(req, timeout=4) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
            if payload.get("ok"):
                return str(payload.get("message") or "ок")
            return str(payload.get("message") or "сервер ответил ошибкой")
        except Exception:  # noqa: BLE001 — старый сервер/нет связи — fallback
            return None

    def _on_start(self) -> None:
        # Битый config.toml — НЕ стартуем с полу-дефолтами (раньше ошибка
        # парсинга глоталась, и настройки пользователя молча игнорировались).
        if config_mod.LAST_LOAD_ERROR:
            self.lbl_server_msg.configure(
                text=(f"config.toml не читается: {config_mod.LAST_LOAD_ERROR} — "
                      "исправьте или удалите файл pc/config.toml"),
                text_color=RED_TXT,
            )
            return
        cfg = self._collect_config()
        settings_store.set_workspace(cfg.workspace)
        settings_store.set_fps_mode(cfg.fps_mode)
        # ВОРКСПЕЙС МОЖНО НЕ ОТКРЫВАТЬ ЗАРАНЕЕ: при старте сервер создаст
        # виртуальный монитор (headless) и откроет выбранный воркспейс на
        # нём (3.9.0). Раньше GUI отказывался стартовать («переключитесь
        # на него и повторите») — это и выглядело как «выбор воркспейса
        # не влияет на показ».
        ok, msg_txt = self.server.start(cfg)
        self.lbl_server_msg.configure(
            text=msg_txt, text_color=ACCENT if ok else RED_TXT
        )
        self._tick_status(False)
        self._tick_phone(False)

    def _on_stop(self) -> None:
        # Остановка В ФОНОВОМ ПОТОКЕ (3.9.1): proc.wait() до 8–11 с раньше
        # морозил окно — выглядело как «кнопка Стоп не работает».
        self.lbl_server_msg.configure(text="останавливаю…", text_color=ACCENT)
        self.btn_stop.configure(state="disabled")
        self._stopping = True

        def _worker() -> None:
            try:
                ok, msg_txt = self.server.stop()
            except Exception as exc:  # noqa: BLE001 — остановка не должна падать молча
                ok, msg_txt = False, f"ошибка остановки: {exc}"
            # результат подберёт _tick_status в ГЛАВНОМ потоке Tk
            self._stop_result = (ok, msg_txt)

        threading.Thread(target=_worker, daemon=True).start()

    def _on_mode_change(self, label: str) -> None:
        """Пресет лочит слайдеры к своим значениям; «Своё» — разрешает правку."""
        mode = LABEL_TO_MODE.get(label, "auto")
        preset = FPS_MODE_PRESETS.get(mode)
        readonly = preset is not None or mode == "auto"
        if preset is not None:
            self.var_fps.set(int(preset["fps"]))
            self.var_quality.set(int(preset["jpeg_quality"]))
            self.var_scale.set(float(preset["scale"]))
        for sld in (self.sld_fps, self.sld_quality, self.sld_scale):
            sld.configure(state="disabled" if readonly else "normal")

    def _on_save_config(self) -> None:
        cfg = self._collect_config()
        settings_store.set_workspace(cfg.workspace)
        settings_store.set_fps_mode(cfg.fps_mode)
        settings_store.set_notifications(True)
        cfg.save(os.path.join(BASE_DIR, "config.toml"))
        text = f"сохранено (воркспейс №{cfg.workspace}, режим {cfg.fps_mode})"
        # Работающая трансляция: выбранный воркспейс применяется СРАЗУ —
        # через POST /workspace сервер перегонит его на виртуальный
        # монитор (раньше — только после перезапуска, что тоже выглядело
        # как «выбор воркспейса не влияет на показ»).
        srv_msg = self._apply_workspace_live(cfg.workspace)
        if srv_msg is None:
            # Сервер не отвечает (не запущен/старая версия) — переключим
            # напрямую, как в 3.8.0.
            running = self.server.running() or \
                state_file.state_pid_alive() is not None
            mon = str((state_file.read_state() or {}).get("monitor") or "") \
                if running else ""
            if mon and cfg.workspace:
                ok, ws_msg = hyprctl.switch_workspace(cfg.workspace, mon)
                if ok and "уже активен" not in ws_msg:
                    text += f" · применено: {ws_msg}"
                elif not ok:
                    text += f" · {ws_msg}"
        elif srv_msg:
            text += f" · применено: {srv_msg}"
        self.lbl_screen_msg.configure(text=text, text_color=ACCENT)

    def _refresh_log(self) -> None:
        self.txt_log.configure(state="normal")
        self.txt_log.delete("1.0", "end")
        try:
            with open(SERVER_LOG, "r", encoding="utf-8", errors="replace") as fh:
                lines = fh.readlines()[-200:]
            self.txt_log.insert("1.0", "".join(lines) or "(лог пуст)")
        except OSError:
            self.txt_log.insert("1.0", "(лог ещё не создавался)")
        self.txt_log.configure(state="disabled")

    @staticmethod
    def _last_error_line(max_lines: int = 80) -> str:
        """Последняя ERROR-строка из лога сервера ('' если нет)."""
        try:
            with open(SERVER_LOG, "r", encoding="utf-8", errors="replace") as fh:
                lines = fh.readlines()[-max_lines:]
        except OSError:
            return ""
        for raw in reversed(lines):
            line = raw.rstrip()
            if "ERROR" in line or "фатальная" in line or "не удалось" in line:
                parts = line.split(": ", 1)
                text = parts[1] if len(parts) == 2 else line
                return text if len(text) <= 160 else text[:157] + "…"
        return ""

    # --- живой предпросмотр --------------------------------------------------
    def _toggle_preview(self) -> None:
        if self._preview_on:
            self._stop_preview()
        else:
            self._preview_on = True
            self.btn_view.configure(text="⏹  Остановить просмотр")
            self.frame_preview.pack(
                fill="x", padx=12, pady=8, before=self._note_widget
            )
            self._preview_tick()

    def _stop_preview(self) -> None:
        self._preview_on = False
        if self._preview_job is not None:
            try:
                self.after_cancel(self._preview_job)
            except Exception:  # noqa: BLE001
                pass
            self._preview_job = None
        self.lbl_preview.configure(image=None, text="")
        self.lbl_preview_caption.configure(text="")
        self.frame_preview.pack_forget()
        self.btn_view.configure(text="👁  Посмотреть экран")
        self._preview_photo = None

    def _preview_tick(self) -> None:
        """Раз в 1.5 с: снять транслируемый экран и показать картинку."""
        if not self._preview_on:
            return
        if not self._preview_busy:
            self._preview_busy = True
            threading.Thread(target=self._preview_grab, daemon=True).start()
        self._preview_job = self.after(1500, self._preview_tick)

    def _preview_grab(self) -> None:
        state = state_file.read_state() or {}
        monitor = state.get("monitor") if isinstance(state.get("monitor"), str) else ""
        png = b""
        err = ""
        if monitor:
            png, err = capture.capture_one(monitor, quality=1)
        else:
            err = "сервер не запущен"
        self.after(
            0, lambda: self._set_preview_image(png, state, monitor, err)
        )

    PREVIEW_BOX = (700, 470)

    def _make_photo(self, png: bytes):
        """Декодировать JPEG-кадр в image для CTkLabel (CTkImage → fallback)."""
        box_w, box_h = self.PREVIEW_BOX
        if _PILImage is not None:
            pil = _PILImage.open(io.BytesIO(png))
            k = min(box_w / pil.width, box_h / pil.height, 1.0)
            size = (
                max(1, round(pil.width * k)),
                max(1, round(pil.height * k)),
            )
            return ctk.CTkImage(light_image=pil, size=size)
        img = tk.PhotoImage(data=base64.b64encode(png))
        factor = max(
            1,
            -(-img.width() // box_w),
            -(-img.height() // box_h),
        )
        if factor > 1:
            img = img.subsample(factor, factor)
        return img

    def _set_preview_image(
        self,
        png: bytes,
        state: dict,
        monitor: Optional[str],
        err: str = "",
    ) -> None:
        self._preview_busy = False
        if not self._preview_on:
            return
        if png:
            try:
                self._preview_photo = self._make_photo(png)
                self.lbl_preview.configure(
                    image=self._preview_photo, text=""
                )
            except (tk.TclError, binascii.Error, ValueError):
                self.lbl_preview.configure(image="", text="кадр не декодирован")
        else:
            no_frame = "нет кадра — сервер не запущен или захват недоступен"
            if err:
                err_short = err if len(err) <= 140 else err[:137] + "…"
                no_frame = f"нет кадра: {err_short}"
            self.lbl_preview.configure(image="", text=no_frame)
        parts = [monitor or "экран —"]
        if state:
            if state.get("resolution"):
                pass
            fps = state.get("fps")
            quality = state.get("quality")
            parts.append(f"{fps} FPS" if fps else "")
            parts.append(f"q{quality}" if quality else "")
        parts.append(f"клиентов: {state.get('clients', 0)}")
        self.lbl_preview_caption.configure(
            text=" · ".join(p for p in parts if p)
        )

    # ------------------------------------------------------------- таймеры
    def _tick_status(self, reschedule: bool = True) -> None:
        """Статус сервера и адрес; раз в секунду (reschedule=False — разово)."""
        # результат фонового _on_stop применяем ТОЛЬКО в главном потоке Tk
        if self._stop_result is not None:
            ok, msg_txt = self._stop_result
            self._stop_result = None
            self._stopping = False
            self.lbl_server_msg.configure(
                text=msg_txt, text_color=ACCENT if ok else RED_TXT)
        if self._stopping:
            # фоновая остановка идёт: пилюля не должна мигать «остановлен»
            self.status_pill.configure(fg_color=EMERALD_DIM)
            self.status_badge.configure(text="● останавливаю…",
                                        text_color=EMERALD_H)
            self.lbl_server_line.configure(text="Статус: останавливаю…")
            self.btn_start.configure(state="disabled")
            self.btn_stop.configure(state="disabled")
        elif self.server.running():
            self.status_pill.configure(fg_color=EMERALD_DIM)
            self.status_badge.configure(
                text=STATUS_RUNNING,
                text_color=EMERALD_H,
            )
            pid = self.server.proc.pid if self.server.proc else "?"
            self.lbl_server_line.configure(text=f"Статус: работает (pid {pid})")
            self.btn_start.configure(state="disabled")
            self.btn_stop.configure(state="normal")
        elif state_file.state_pid_alive() is not None:
            # сервер жив, но запущен ВНЕ этого окна GUI (CLI / окно перезапускали) —
            # раньше пилюля врала «остановлен», а «Стоп» не блокировался
            pid = state_file.state_pid_alive()
            self.status_pill.configure(fg_color=EMERALD_DIM)
            self.status_badge.configure(text=STATUS_RUNNING,
                                        text_color=EMERALD_H)
            self.lbl_server_line.configure(
                text=f"Статус: работает (pid {pid}, запущен вне GUI)")
            self.btn_start.configure(state="disabled")
            self.btn_stop.configure(state="normal")
        else:
            code = self.server.exit_code()
            text = STATUS_STOPPED
            if code is not None and code not in (0, 130):
                text = f"● остановлен (код {code})"
            self.status_pill.configure(fg_color=RED_DIM)
            self.status_badge.configure(text=text, text_color=RED)
            reason = self._last_error_line() if code not in (None, 0, 130) else ""
            self.lbl_server_line.configure(
                text="Статус: остановлен"
                + (f" (код {code})" if code not in (None, 0, 130) else "")
            )
            if reason:
                self.lbl_server_msg.configure(
                    text=f"Причина: {reason}", text_color=RED_TXT
                )
            self.btn_start.configure(state="normal")
            self.btn_stop.configure(state="disabled")

        state = state_file.read_state() or {}
        port = state.get("port", self.ent_port.get() or "8080")
        ip = state.get("ip", "?")
        monitor = state.get("monitor")
        # Токен в адресе: без ?t= браузер телефона получит 403 и «не подключается»
        token = self.ent_token.get().strip()
        url = f"http://{ip}:{port}" + (f"/?t={token}" if token else "")
        self.lbl_addr.configure(text=f"Адрес: {ip}:{port}  ({url})")
        other = [a for a in _cached_lan_ips() if a != ip]
        self.lbl_other_ips.configure(
            text=("другие адреса этого ПК: " + ", ".join(other)) if other else ""
        )
        self.lbl_screen_hint.configure(
            text=f"Экран: {monitor or '—'}"
        )
        if reschedule:
            self.after(1000, self._tick_status)

    def _tick_phone(self, reschedule: bool = True) -> None:
        """Обновить блок «Телефон»; раз в 2 с (reschedule=False — разово)."""
        state = state_file.read_state()
        if not state:
            self.lbl_phone_monitor.configure(text="—", text_color=ACCENT)
            self.lbl_phone_lines.configure(text="сервер не запущен")
        else:
            monitor = state.get("monitor") or "—"
            self.lbl_phone_monitor.configure(text=str(monitor))
            clients = state.get("clients", 0)
            lines = [f"Подключение: {'активно' if clients else 'нет клиентов'} "
                     f"({clients} шт.)"]
            err = state.get("last_error")
            if err:
                lines.append("⚠ ЗАХВАТ НЕ РАБОТАЕТ — на телефоне последний кадр:")
                lines.append(f"   {err}")
                lines.append("   Лечение: hyprscreen grimtest "
                             "(обычно помогает yay -S grim-git)")
            else:
                def _num(key, default="?"):
                    try:
                        return float(state.get(key))
                    except (TypeError, ValueError):
                        return default  # битый state-файл не должен ронять таймер
                fps = _num("fps")
                quality = _num("quality")
                scale = _num("scale")
                fps_txt = f"{fps:g}" if isinstance(fps, float) else fps
                quality_txt = f"{quality:g}" if isinstance(quality, float) else quality
                scale_txt = f"{scale:g}" if isinstance(scale, float) else scale
                kb = "вкл" if state.get("keyboard") else "выкл"
                lines.append(
                    f"Стрим: {fps_txt} FPS, качество {quality_txt}, масштаб {scale_txt}, "
                    f"клавиатура: {kb}"
                )
            # Закреплённый воркспейс: в headless-режиме (3.9.0) кадры живые
            # всегда — пауза бывает только в fallback-режиме 3.8.1 или
            # на время восстановления закрепления.
            ws = state.get("workspace")
            if ws and state.get("workspace_active") is False:
                if state.get("pinned_mode") == "headless":
                    lines.append(
                        f"⚠ закреплённый воркспейс №{ws} восстанавливается "
                        "на виртуальном мониторе (кадр может ненадолго "
                        "подмораживать)"
                    )
                else:
                    lines.append(
                        f"⏸ на ПК сейчас воркспейс №{state.get('active_workspace') or '?'} — "
                        f"телефон показывает закреплённый №{ws} (кадр на паузе, "
                        f"чужой экран не транслируется; клавиатура с телефона "
                        f"вернёт №{ws} на ПК)"
                    )
            lines.append(f"Порт: {state.get('port', '?')} · "
                         f"версия {state.get('version', '?')}")
            # С 3.7.1: сервер работает, но телефон так и не подключился —
            # вместо тишины даём чек-лист (SETUP.md §7.8).
            if not clients:
                started = state.get("started")
                try:
                    waiting = time.time() - int(started) if started else 0
                except (TypeError, ValueError):
                    waiting = 0
                if waiting > 30:
                    lines.append("⚠ телефон не подключается — проверьте: "
                                 "одна Wi-Fi сеть; файрвол (8080/tcp, 8766/udp); "
                                 "в манифесте APK usesCleartextTraffic (§7.8)")
            self.lbl_phone_lines.configure(text="\n".join(lines))
        if reschedule:
            self.after(2000, self._tick_phone)

    def _on_close(self) -> None:
        self._preview_on = False
        if self._preview_job is not None:
            try:
                self.after_cancel(self._preview_job)
            except Exception:  # noqa: BLE001
                pass
        try:
            self.server.stop()
        except Exception:  # noqa: BLE001
            pass
        self.destroy()


def main() -> int:
    app = GuiApp()
    app.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
