package com.example.hyprscreen

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

/**
 * Полноэкранный режим стриминга. Биндится к [ScreenStreamService], чтобы
 * получить доступ к [ScreenClient], подключает сенсорный + клавиатурный ввод
 * и рисует оверлей FPS/latency/экран.
 *
 * Активность зафиксирована в landscape-ориентации (см. манифест) и использует
 * иммерсивные системные бары, пока имеет фокус.
 *
 * Мульти-экранность: из intent-экстра берётся индекс выбранного экрана
 * [EXTRA_SCREEN] и (опционально) общее число [EXTRA_TOTAL_SCREENS]. Когда
 * приходит hello, эти значения обновляются из [ServerInfo] и показываются
 * в оверлее как «Экран N/M» (1-based для пользователя).
 *
 * Дерево View строится целиком в коде в [buildUi] — никакого XML-лейаута,
 * ViewBinding и app-resource-ссылок. Скрытый [EditText] владеет InputConnection
 * мягкой клавиатуры; [ScreenView] хостит и кадры, и оверлей статуса (см.
 * [StatusOverlay]).
 *
 * 2.1.7: постоянный тулбар из 3 кнопок мешал просмотру — заменён на
 * полупрозрачную кнопку «☰» в углу: тап раскрывает вертикальное меню
 * (Клавиатура / Оверлей / Отключиться), которое автоматически прячется
 * через 4,5 c без действий.
 *
 * Все строковые литералы — русские (требование «плоского одного пакета»:
 * приложение не поставляет строковых ресурсов платформы Android).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var rootView: FrameLayout
    private lateinit var screenView: ScreenView
    private lateinit var hiddenInput: EditText
    private lateinit var keyboardButton: Button
    private lateinit var overlayToggle: Button
    private lateinit var disconnectButton: Button
    /** 2.1.7: полупрозрачный «бургер» + скрываемое вертикальное меню. */
    private lateinit var menuButton: Button
    private lateinit var menuPanel: LinearLayout
    private val menuHandler = Handler(Looper.getMainLooper())
    private val menuHideRunnable = Runnable { hideMenu() }

    private lateinit var prefs: Prefs
    private lateinit var keyboardHelper: KeyboardHelper

    /** Выбранный индекс экрана (0-based) — из intent-экстра, обновляется из hello. */
    private var screenIndex: Int = 0
    /** Всего экранов PC — из intent-экстра, обновляется из hello. */
    private var totalScreens: Int = 1

    private var service: ScreenStreamService? = null
    private var bound = false
    private var stateCollectionStarted = false

    /** Антиспам тостов onError: тот же текст в течение 3 с не показываем (2.1.2). */
    private var lastErrorMessage: String? = null
    private var lastErrorAtMs: Long = 0L

    /** 0.11.0: сервер просит скрыть служебную надпись (hello overlay=false). */
    private var serverOverlayAllowed: Boolean = true

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val s = (binder as ScreenStreamService.LocalBinder).service
            service = s
            bound = true
            attachClient(s.client)
        }

        override fun onServiceDisconnected(name: ComponentName) {
            bound = false
            service = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        prefs = Prefs(this)

        // Читаем индекс экрана из intent (передаётся ConnectActivity).
        screenIndex = intent?.getIntExtra(EXTRA_SCREEN, 0) ?: 0
        totalScreens = intent?.getIntExtra(EXTRA_TOTAL_SCREENS, 1) ?: 1
        refreshOverlayHeader()

        // Держим экран включённым во время стриминга.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableImmersive()

        // Касания → события ввода
        screenView.setOnTouchListener(
            TouchHandler(screenView) { event ->
                service?.client?.sendInput(event)
            }
        )

        // Оверлей по умолчанию
        screenView.setOverlayVisible(prefs.showOverlay)
        refreshOverlayHeader()

        // Помощник мягкой клавиатуры, привязанный к скрытому EditText
        keyboardHelper = KeyboardHelper(this, hiddenInput) { event ->
            service?.client?.sendInput(event)
        }

        keyboardButton.setOnClickListener {
            keyboardHelper.toggle()
            // Клавиатура раскрывается снизу — меню больше не нужно на виду.
            hideMenu()
        }
        overlayToggle.setOnClickListener {
            prefs.showOverlay = !prefs.showOverlay
            screenView.setOverlayVisible(overlayAllowed())
            if (!overlayAllowed()) screenView.setOverlayText("") else refreshOverlayHeader()
        }
        disconnectButton.setOnClickListener {
            service?.disconnect()
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        menuHandler.removeCallbacks(menuHideRunnable)
    }

    override fun onStart() {
        super.onStart()
        bindService(
            Intent(this, ScreenStreamService::class.java),
            connection,
            Context.BIND_AUTO_CREATE
        )
    }

    override fun onStop() {
        super.onStop()
        if (bound) {
            unbindService(connection)
            bound = false
            service?.client?.frameListener = null
        }
    }

    override fun onResume() {
        super.onResume()
        enableImmersive()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enableImmersive()
    }

    /** Сначала отправляем события клавиш в помощник клавиатуры. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (keyboardHelper.dispatchKey(event)) return true
        return super.dispatchKeyEvent(event)
    }

    /** Спрятать системные бары для иммерсивного полноэкранного режима. */
    private fun enableImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, rootView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    /** Оверлей виден только когда и пользователь включил, и сервер разрешает. */
    private fun overlayAllowed(): Boolean = prefs.showOverlay && serverOverlayAllowed

    /**
     * Обновить оверлей в верхней части экрана, показывающий «Экран N/M».
     * Вызывается при создании и при приходе hello. Если оверлей FPS выключен,
     * текст всё равно задаётся (станет виден, когда пользователь включит
     * оверлей).
     */
    private fun refreshOverlayHeader() {
        if (!overlayAllowed()) return
        val header = if (totalScreens > 1) {
            "Экран ${screenIndex + 1}/$totalScreens"
        } else {
            "Экран ${screenIndex + 1}"
        }
        screenView.setOverlayText(header)
    }

    private fun attachClient(client: ScreenClient) {
        client.frameListener = object : ScreenClient.FrameListener {
            override fun onHello(info: ServerInfo) {
                runOnUiThread {
                    // Размерность и индексы берутся из hello; overlay — решение
                    // сервера (0.11.0): чистый экран телефона по умолчанию.
                    screenView.setSourceSize(info.width, info.height)
                    screenIndex = info.screen
                    totalScreens = info.totalScreens
                    serverOverlayAllowed = info.serverOverlay
                    screenView.setOverlayVisible(overlayAllowed())
                    if (!overlayAllowed()) screenView.setOverlayText("")
                    refreshOverlayHeader()
                }
            }

            override fun onFrame(bitmap: Bitmap, decodeMs: Long) {
                runOnUiThread {
                    screenView.updateBitmap(bitmap)
                    // Первый пришедший кадр — сигнал есть (2.0.0).
                    screenView.setOverlayVisible(overlayAllowed())
                }
            }

            override fun onStats(stats: FrameStats) {
                runOnUiThread {
                    if (overlayAllowed()) {
                        // Инлайн-формат строки — исходный код использовал
                        // string-ресурс; эта версия их не поставляет.
                        // К оверлею FPS/latency добавляем заголовок «Экран N/M»,
                        // чтобы пользователь видел текущий экран PC.
                        val screenHeader = if (totalScreens > 1)
                            "Экран ${screenIndex + 1}/$totalScreens  ·  "
                        else
                            "Экран ${screenIndex + 1}  ·  "
                        val text = screenHeader +
                            "FPS %.1f  ·  Пинг %dмс  ·  Декод %dмс".format(
                                stats.fps,
                                stats.latencyMs,
                                stats.lastDecodeMs
                            )
                        screenView.setOverlayText(text)
                    }
                }
            }

            override fun onError(message: String) {
                runOnUiThread {
                    // 2.1.2: сервер может ругаться на каждое событие ввода
                    // (например, «wtype не установлен») — глушим повторы
                    // одинакового текста в течение 3 секунд.
                    val now = System.currentTimeMillis()
                    if (message == lastErrorMessage && now - lastErrorAtMs < 3000) return@runOnUiThread
                    lastErrorMessage = message
                    lastErrorAtMs = now
                    Toast.makeText(this@MainActivity, "Ошибка сервера: $message", Toast.LENGTH_LONG).show()
                }
            }
        }

        // Если сервер уже прислал hello до того, как мы забиндились (сервис
        // стартует раньше активности), достаём актуальный ServerInfo сейчас,
        // чтобы мэппинг координат касаний был корректен с первого кадра.
        client.currentServerInfo?.let { info ->
            screenView.setSourceSize(info.width, info.height)
            screenIndex = info.screen
            totalScreens = info.totalScreens
            serverOverlayAllowed = info.serverOverlay
            refreshOverlayHeader()
        }

        // Наблюдаем состояние — выходим при disconnect. Стартуем коллектор
        // один раз на экземпляр активности, чтобы не дублировать коллекторы
        // при ре-биндингах.
        if (stateCollectionStarted) return
        stateCollectionStarted = true
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                client.state.collect { state ->
                    // 2.0.0: индикатор «НЕТ СИГНАЛА» на телефоне вместо немого
                    // чёрного экрана, когда кадры не идут (grim сломан на ПК).
                    when (state) {
                        is ScreenClient.State.Connected -> screenView.setConnected(true)
                        is ScreenClient.State.Connecting,
                        is ScreenClient.State.Reconnecting -> {
                            screenView.setConnected(false)
                            screenView.setOverlayText("подключение…")
                            screenView.setOverlayVisible(true)
                        }
                        is ScreenClient.State.Disconnected,
                        is ScreenClient.State.Error -> {
                            screenView.setConnected(false)
                            // Сносим foreground-сервис тоже, чтобы он не пережил
                            // стриминговую сессию. Сообщение об ошибке (если есть)
                            // покажем тостом.
                            if (state is ScreenClient.State.Error) {
                                Toast.makeText(
                                    this@MainActivity,
                                    "Соединение разорвано: ${state.message}",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                            service?.disconnect()
                            finish()
                        }
                        else -> Unit
                    }
                }
            }
        }
    }

    // ----- UI построен целиком в коде (без XML-лейаутов) -----------------

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        rootView = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        // ScreenView заполняет всё окно.
        screenView = ScreenView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        rootView.addView(screenView)

        // 2.1.7: вместо постоянного тулбара — полупрозрачный «бургер» ☰.
        // Тап раскрывает вертикальное меню; без действий оно прячется само,
        // чтобы НЕ мешать просмотру стрима.
        menuButton = Button(this).apply {
            text = "☰"
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            textSize = 18f
            setTextColor(UiTheme.TEXT)
            stateListAnimator = null
            setPadding(0, 0, 0, 0)
            background = UiTheme.buttonDark(resources.displayMetrics.density)
            // Полупрозрачный, чтобы не бросался в глаза поверх видео.
            alpha = 0.55f
            val lp = FrameLayout.LayoutParams(dp(46), dp(40))
            lp.gravity = Gravity.TOP or Gravity.END
            lp.setMargins(dp(8), dp(8), dp(8), dp(8))
            layoutParams = lp
        }
        menuButton.setOnClickListener {
            if (menuPanel.visibility == View.VISIBLE) hideMenu() else showMenu()
        }
        rootView.addView(menuButton)

        menuPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = UiTheme.buttonDark(resources.displayMetrics.density, UiTheme.SCRIM)
            visibility = View.GONE
            alpha = 0.92f
            val lp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
            lp.gravity = Gravity.TOP or Gravity.END
            // Ниже кнопки «☰» (8 + 40 + 4 dp).
            lp.setMargins(dp(8), dp(52), dp(8), dp(8))
            layoutParams = lp
            // Касание по самому меню продлевает автоскрытие.
            setOnTouchListener { _, _ ->
                scheduleMenuHide()
                false
            }
        }
        keyboardButton = makeToolbarButton("Клавиатура")
        overlayToggle = makeToolbarButton("Оверлей")
        disconnectButton = makeToolbarButton("Отключиться").apply {
            // Опасное действие — красная пилюля (2.1.0).
            setTextColor(UiTheme.RED)
            background = UiTheme.buttonDanger(resources.displayMetrics.density)
        }
        menuPanel.addView(keyboardButton)
        menuPanel.addView(overlayToggle)
        menuPanel.addView(disconnectButton)
        rootView.addView(menuPanel)

        // Скрытый 1dp EditText, владеющий InputConnection мягкой клавиатуры.
        // Размер 1×1dp и alpha=0, чтобы пользователь его не видел, но
        // InputMethodManager показывал клавиатуру при фокусе.
        hiddenInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            alpha = 0f
            isSingleLine = false
            isFocusable = true
            isFocusableInTouchMode = true
            layoutParams = FrameLayout.LayoutParams(dp(1), dp(1))
        }
        rootView.addView(hiddenInput)

        return rootView
    }

    /** Тёмная пилюля-кнопка меню (вертикальный стек — отступ сверху). */
    private fun makeToolbarButton(text: String): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        minWidth = 0
        minimumWidth = 0
        textSize = 13f
        setTextColor(UiTheme.TEXT)
        stateListAnimator = null
        setPadding(dp(14), dp(9), dp(14), dp(9))
        background = UiTheme.buttonDark(resources.displayMetrics.density)
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(4)
        layoutParams = lp
    }

    // ----- бургер-меню (2.1.7) --------------------------------------------

    private fun showMenu() {
        menuPanel.visibility = View.VISIBLE
        menuButton.alpha = 1f
        scheduleMenuHide()
    }

    private fun hideMenu() {
        menuHandler.removeCallbacks(menuHideRunnable)
        menuPanel.visibility = View.GONE
        menuButton.alpha = 0.55f
    }

    private fun scheduleMenuHide() {
        menuHandler.removeCallbacks(menuHideRunnable)
        menuHandler.postDelayed(menuHideRunnable, MENU_AUTO_HIDE_MS)
    }

    companion object {
        /** Экстра intent: выбранный индекс экрана (0-based). */
        const val EXTRA_SCREEN = "screen"
        /** Экстра intent: общее число экранов PC (заполняется из hello). */
        const val EXTRA_TOTAL_SCREENS = "total_screens"
        /** 2.1.7: автоскрытие бургер-меню без действий. */
        private const val MENU_AUTO_HIDE_MS = 4500L
    }
}
