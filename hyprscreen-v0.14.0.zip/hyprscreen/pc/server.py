"""Асинхронный WebSocket-стриминг-сервер HyprScreen (мультиэкранный).

Слушает ``<bind_address>:<port>``, принимает соединения от Android-телефонов,
броадкастит захваченные JPEG-кадры как бинарные сообщения и направляет
входящие JSON text-сообщения в :class:`InputInjector`.

URL-путь выбирает экран: ``ws://<host>:<port>/<index>`` (0-based).
Пустой путь и ``/`` — экран 0; вне диапазона — ``close(1008)``.

hello-сообщение 0.12.0 несёт ``overlay`` (сервер просит клиента не рисовать
служебную надпись на телефоне — данные статуса вместо этого раз в 2 секунды
пишутся в state-файл и показываются в GUI) и фактический ``fps``
(в режиме ``auto`` он ниже целевого, когда grim не успевает).

Жизненный цикл
--------------
1. ``HyprScreenServer.start()`` — открывает WebSocket-сервер и capture-лупы.
2. Новый клиент: (auth) → ``hello`` → writer/reader задачи.
3. Каждые 2с — runtime-статистика в state-файл (для GUI).
4. На SIGINT/SIGTERM все задачи отменяются, сервер и discovery закрываются.
"""

from __future__ import annotations

import asyncio
import json
import logging
import socket
import time
from dataclasses import dataclass, field
from typing import Any, Optional

from capture import CaptureError, make_backend
from config import Config, ScreenConfig, __version__
from discovery import DiscoveryBroadcaster
from input import InputInjector, InputError
import state_file

log = logging.getLogger(__name__)


def lan_ip() -> str:
    """Определить LAN IP (маршрут к 8.8.8.8); при неудаче — ``?``."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            return str(s.getsockname()[0])
        finally:
            s.close()
    except Exception:
        return "?"


@dataclass
class ClientStats:
    """Статистика по одному клиенту."""

    address: tuple[str, int]
    connected_at: float = field(default_factory=time.monotonic)
    frames_sent: int = 0
    frames_dropped: int = 0
    bytes_sent: int = 0
    bytes_received: int = 0
    last_frame_at: float = 0.0
    last_latency_estimate: float = 0.0

    @property
    def uptime(self) -> float:
        return time.monotonic() - self.connected_at

    @property
    def fps(self) -> float:
        if self.frames_sent < 2:
            return 0.0
        elapsed = self.last_frame_at - self.connected_at
        if elapsed <= 0:
            return 0.0
        return self.frames_sent / elapsed

    def snapshot(self) -> dict[str, Any]:
        return {
            "address": f"{self.address[0]}:{self.address[1]}",
            "uptime_s": round(self.uptime, 1),
            "frames_sent": self.frames_sent,
            "frames_dropped": self.frames_dropped,
            "bytes_sent": self.bytes_sent,
            "bytes_received": self.bytes_received,
            "fps": round(self.fps, 2),
            "latency_ms_estimate": round(self.last_latency_estimate * 1000, 1),
        }


class StreamScreen:
    """Один стримуемый экран: вывод + capture-луп + клиенты."""

    def __init__(
        self,
        index: int,
        output_name: str,
        x_offset: int,
        screen_cfg: ScreenConfig,
        total_screens: int,
        ws_module: Any,
    ) -> None:
        self.index = index
        self.output_name = output_name
        self.x_offset = x_offset
        self.config = screen_cfg
        self.total_screens = total_screens
        self._ws_module = ws_module
        self.injector = InputInjector(screen_cfg, x_offset)
        self._clients: dict[Any, ClientStats] = {}
        self._queues: dict[Any, asyncio.Queue[bytes]] = {}
        self._capture_task: Optional[asyncio.Task[None]] = None
        self._backend = None
        self._stop_event = asyncio.Event()
        self._client_added = asyncio.Event()
        # Ссылка на владельца назначается в HyprScreenServer.__init__.
        self._server_ref: Optional[HyprScreenServer] = None  # noqa: F821

    # -- запуск / остановка capture-лупа ---------------------------------

    async def start_capture(self) -> None:
        """Создать бэкенд и запустить capture-луп."""
        self._backend = make_backend(self.config, self.output_name)
        log.info(
            "экран %d: захват grim (вывод=%s, %dx%d, fps=%d, режим=%s, масштаб=%.2f)",
            self.index, self.output_name,
            self.config.width, self.config.height, self.config.fps,
            self.config.fps_mode, self.config.scale,
        )
        self._capture_task = asyncio.create_task(
            self._capture_loop(), name=f"capture-screen-{self.index}"
        )

    async def stop_capture(self) -> None:
        """Остановить capture-луп и закрыть бэкенд."""
        self._stop_event.set()
        self._client_added.set()
        if self._capture_task is not None:
            self._capture_task.cancel()
            try:
                await self._capture_task
            except asyncio.CancelledError:
                pass
            except Exception as exc:  # noqa: BLE001
                log.warning("ошибка при остановке capture-лупа экрана %d: %s", self.index, exc)
            self._capture_task = None
        if self._backend is not None:
            try:
                await self._backend.close()
            except Exception as exc:  # noqa: BLE001
                log.warning("ошибка закрытия бэкенда экрана %d: %s", self.index, exc)
            self._backend = None

    async def _recreate_backend(self, reason: str, quiet: bool = False) -> None:
        """Закрыть текущий бэкенд и создать новый (после сбоя захвата).

        ``quiet=True`` — без INFO-строки: при постоянном сбое бэкенд
        пересоздаётся каждые ~10 с, и строка на каждый раз была спамом
        (0.13.1). Ошибки создания логируются всегда.
        """
        try:
            if self._backend is not None:
                await self._backend.close()
        except Exception:  # noqa: BLE001
            pass
        try:
            self._backend = make_backend(self.config, self.output_name)
            if not quiet:
                log.info("экран %d: бэкенд пересоздан (вывод=%s): %s",
                         self.index, self.output_name, reason)
        except Exception as exc:  # noqa: BLE001
            log.error("экран %d: не удалось пересоздать бэкенд: %s", self.index, exc)
            await asyncio.sleep(2.0)

    async def _capture_loop(self) -> None:
        """Цикл захвата: ждёт клиентов, затем гоняет frames().

        Если захват устойчиво падает (grim завершился с ошибкой), бэкенд
        пересоздаётся и захват продолжается — например, после того как
        headless-вывод был пересоздан вручную. Когда клиенты уходят,
        цикл НЕ завершается, а возвращается к ожиданию следующего
        подключения (иначе повторное подключение получало замёрзший
        экран — бэкенд жив, а задачу захвата никто не перезапускает).

        0.13.1: пересоздания идут с растущей паузой (2, 4, 6 … до 30 c),
        а сообщения о сбоях пишутся только на первой и каждой 10-й
        попытке. Раньше цикл «упал → пересоздали» повторялся каждые
        ~2.5 с и заполнял лог бесконечным спамом из диагностики.
        """
        recreate_cycles = 0
        try:
            while not self._stop_event.is_set():
                if not self._queues:
                    self._client_added.clear()
                    wait_stop = asyncio.create_task(self._stop_event.wait())
                    wait_client = asyncio.create_task(self._client_added.wait())
                    try:
                        await asyncio.wait(
                            {wait_stop, wait_client},
                            return_when=asyncio.FIRST_COMPLETED,
                        )
                    finally:
                        for t in (wait_stop, wait_client):
                            if not t.done():
                                t.cancel()
                                try:
                                    await t
                                except asyncio.CancelledError:
                                    pass
                    if self._stop_event.is_set():
                        return
                    if not self._queues:
                        continue
                    # Бэкенд мог быть закрыт в прошлом раунде (recreate) —
                    # гарантируем живой бэкенд перед стартом frames().
                    if self._backend is None:
                        await self._recreate_backend("новый клиент")
                        if self._backend is None:
                            await asyncio.sleep(1.0)
                            continue
                    log.info("экран %d: появился клиент, начинаем захват", self.index)
                # Внутренний цикл: frames() текущего бэкенда; при устойчивой
                # ошибке захвата (GrimCapture отдаёт CaptureError после 10
                # неудач) бэкенд пересоздаётся, и захват продолжается.
                while not self._stop_event.is_set() and self._queues:
                    backend = self._backend
                    if backend is None:
                        await self._recreate_backend("бэкенд отсутствует")
                        if self._backend is None:
                            break
                        continue
                    try:
                        async for frame in backend.frames():
                            if recreate_cycles:
                                log.info(
                                    "экран %d: захват восстановлен после %d неудачных попыток",
                                    self.index, recreate_cycles,
                                )
                                recreate_cycles = 0
                            if self._stop_event.is_set():
                                break
                            if not frame:
                                continue
                            if not self._queues:
                                break
                            for _ws, q in list(self._queues.items()):
                                if q.full():
                                    try:
                                        q.get_nowait()
                                        stats = self._clients.get(_ws)
                                        if stats is not None:
                                            stats.frames_dropped += 1
                                    except asyncio.QueueEmpty:
                                        pass
                                try:
                                    q.put_nowait(frame)
                                except asyncio.QueueFull:
                                    stats = self._clients.get(_ws)
                                    if stats is not None:
                                        stats.frames_dropped += 1
                    except CaptureError as exc:
                        recreate_cycles += 1
                        # Полная диагностика уже в логе (один раз на
                        # процесс, см. GrimCapture). Здесь — короткая
                        # сводка на 1-й и каждой 10-й попытке, иначе
                        # лог превращается в бесконечный спам.
                        if recreate_cycles == 1:
                            log.warning(
                                "экран %d: захват не работает — пересоздаю бэкенд: %s",
                                self.index, exc,
                            )
                            await self._recreate_backend(f"сбой захвата: {exc}")
                        else:
                            if recreate_cycles % 10 == 0:
                                log.warning(
                                    "экран %d: захват не работает (попытка %d): %s",
                                    self.index, recreate_cycles, exc,
                                )
                            await self._recreate_backend(
                                f"сбой захвата: {exc}", quiet=True,
                            )
                        # Растущая пауза 2, 4, 6 … 30 c: постоянный сбой
                        # (например, вывод удалён) не должен молотить лог.
                        await asyncio.sleep(min(30.0, 2.0 * recreate_cycles))
                        continue
                    # frames() завершился штатно: клиенты ушли или бэкенд
                    # закрыт. Не выходим из лупа — возвращаемся к ожиданию
                    # следующего клиента (фикс «замерло после reconnect»).
                    if self._stop_event.is_set():
                        return
                    if not self._queues:
                        log.info("экран %d: клиенты отключились — захват на паузу", self.index)
                        break
                    # Клиенты остались, но frames() кончился — пересоздаём.
                    # Короткая пауза гарантирует yield управления (защита от
                    # горячего цикла, если frames() завершился мгновенно).
                    await asyncio.sleep(0.05)
                    await self._recreate_backend("frames() завершился")
        except asyncio.CancelledError:
            log.info("экран %d: capture-луп отменён", self.index)
            raise
        except Exception as exc:  # noqa: BLE001
            log.exception("экран %d: capture-луп упал: %s", self.index, exc)

    # -- статистика для GUI (state-файл) ----------------------------------

    def runtime_stats(self) -> dict[str, Any]:
        """Текущая статистика экрана (для блока «Телефон» в GUI)."""
        backend = self._backend
        return {
            "index": self.index,
            "output": self.output_name,
            "clients": len(self._clients),
            "fps": self.config.fps,
            "eff_fps": getattr(backend, "effective_fps", self.config.fps),
            "quality": self.config.jpeg_quality,
            "fps_mode": self.config.fps_mode,
            "clients_detail": [c.snapshot() for c in self._clients.values()],
        }

    # -- обработка соединения ---------------------------------------------

    async def handle(self, ws: Any) -> None:
        """Обработать одно соединение, привязанное к этому экрану."""
        peer = ws.remote_address if hasattr(ws, "remote_address") else ("?", 0)

        # AUTH: если задан auth_token — ждём {"type":"auth","token":"..."}.
        auth_token = self._server_ref._auth_token if self._server_ref else None
        if auth_token:
            try:
                first_msg = await asyncio.wait_for(ws.recv(), timeout=10.0)
                msg = json.loads(first_msg)
                if msg.get("type") != "auth" or msg.get("token") != auth_token:
                    log.warning("экран %d: auth failed для %s", self.index, peer)
                    await ws.close(code=1008, reason="auth required")
                    return
                log.info("экран %d: auth OK для %s", self.index, peer)
            except asyncio.TimeoutError:
                log.warning("экран %d: auth timeout для %s", self.index, peer)
                await ws.close(code=1008, reason="auth timeout")
                return
            except Exception as exc:
                log.warning("экран %d: auth error для %s: %s", self.index, peer, exc)
                await ws.close(code=1008, reason="auth error")
                return

        stats = ClientStats(address=peer)
        queue: asyncio.Queue[bytes] = asyncio.Queue(maxsize=4)
        self._clients[ws] = stats
        self._queues[ws] = queue
        self._client_added.set()
        log.info(
            "экран %d: клиент подключён %s (всего=%d)",
            self.index, peer, len(self._clients),
        )

        # hello: width/height — размер ЭТОГО экрана (источник истины для
        # масштабирования касаний); fps — фактический; overlay — просьба
        # сервера не рисовать служебную надпись на телефоне.
        hello = {
            "type": "hello",
            "server": "hyprscreen",
            "version": __version__,
            "width": self.config.width,
            "height": self.config.height,
            "fps": int(getattr(self._backend, "effective_fps", self.config.fps)),
            "jpeg_quality": self.config.jpeg_quality,
            "overlay": bool(self._server_ref.config.phone_overlay)
            if self._server_ref else False,
            "screen": self.index,
            "total_screens": self.total_screens,
            "output": self.output_name,
            "server_time": time.time(),
        }
        try:
            await ws.send(json.dumps(hello))
        except Exception as exc:  # noqa: BLE001
            log.warning("не удалось отправить hello экрану %d клиенту %s: %s",
                        self.index, peer, exc)

        writer = asyncio.create_task(self._writer_loop(ws, queue, stats))
        reader = asyncio.create_task(self._reader_loop(ws, stats))
        try:
            await asyncio.gather(writer, reader)
        except asyncio.CancelledError:
            raise
        finally:
            writer.cancel()
            reader.cancel()
            for t in (writer, reader):
                try:
                    await t
                except asyncio.CancelledError:
                    pass
                except Exception as exc:  # noqa: BLE001
                    log.warning("ошибка при ожидании задачи клиента %s: %s", peer, exc)
            self._clients.pop(ws, None)
            self._queues.pop(ws, None)
            log.info(
                "экран %d: клиент отключён %s (осталось=%d) stats=%s",
                self.index, peer, len(self._clients), stats.snapshot(),
            )

    async def _writer_loop(
        self, ws: Any, queue: asyncio.Queue[bytes], stats: ClientStats
    ) -> None:
        """Отправлять кадры из очереди в WebSocket."""
        try:
            while True:
                frame = await queue.get()
                if not frame:
                    return
                t0 = time.monotonic()
                await ws.send(frame)
                dt = time.monotonic() - t0
                stats.frames_sent += 1
                stats.bytes_sent += len(frame)
                stats.last_frame_at = time.monotonic()
                stats.last_latency_estimate = dt
        except self._ws_module.ConnectionClosed:
            return
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            log.warning("writer-луп ошибка для %s: %s", stats.address, exc)

    async def _reader_loop(self, ws: Any, stats: ClientStats) -> None:
        """Читать JSON-ввод от телефона и диспетчеризировать его."""
        rate_limit = 0
        if self._server_ref is not None:
            rate_limit = int(getattr(self._server_ref.config, "input_rate_limit", 0) or 0)
        _rl_timestamps: list[float] = []
        _rl_last_logged = 0.0
        try:
            async for message in ws:
                if isinstance(message, (bytes, bytearray)):
                    stats.bytes_received += len(message)
                else:
                    stats.bytes_received += len(message.encode("utf-8"))
                if rate_limit > 0:
                    now = time.monotonic()
                    _rl_timestamps.append(now)
                    _rl_timestamps[:] = [t for t in _rl_timestamps if now - t < 1.0]
                    if len(_rl_timestamps) > rate_limit:
                        # Троттлинг: при превышении лимита предупреждение
                        # раз в 5 c, а не на каждое отброшенное сообщение
                        # (свайп = 100+ сообщений — был спам).
                        if now - _rl_last_logged >= 5.0:
                            _rl_last_logged = now
                            log.warning(
                                "rate-limit: %s превысил %d сообщ/сек — drop (дальше "
                                "пишется раз в 5 c, если не прекратит)",
                                stats.address, rate_limit,
                            )
                        continue
                try:
                    await self.injector.handle_message(message)
                except InputError as exc:
                    log.warning("некорректное сообщение от %s: %s", stats.address, exc)
                    try:
                        await ws.send(json.dumps({"type": "error", "error": str(exc)}))
                    except self._ws_module.ConnectionClosed:
                        return
        except self._ws_module.ConnectionClosed:
            return
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            log.warning("reader-луп ошибка для %s: %s", stats.address, exc)


class HyprScreenServer:
    """Мультиэкранный WebSocket-сервер.

    Конструируется из :class:`Config` и списка экранов
    ``(output_name, x_offset, ScreenConfig)``. :meth:`start` — привязать
    сокет, :meth:`serve` — работать вечно.
    """

    def __init__(
        self,
        config: Config,
        screens: list[tuple[str, int, ScreenConfig]],
    ) -> None:
        if not screens:
            raise ValueError("нужен хотя бы один экран")
        self.config = config
        self._ws_module = _import_websockets()
        self._server: Any = None
        self._stop_event = asyncio.Event()
        self._auth_token = config.auth_token
        self._started_at = time.time()
        self._state_task: Optional[asyncio.Task[None]] = None
        self.screens: list[StreamScreen] = [
            StreamScreen(
                index=i,
                output_name=name,
                x_offset=x_offset,
                screen_cfg=sc,
                total_screens=len(screens),
                ws_module=self._ws_module,
            )
            for i, (name, x_offset, sc) in enumerate(screens)
        ]
        for s in self.screens:
            s._server_ref = self
        self._discovery: Optional[DiscoveryBroadcaster] = None
        if config.discovery_enabled:
            self._discovery = DiscoveryBroadcaster(config, screens=len(self.screens))

    # -- публичный API -----------------------------------------------------

    async def start(self) -> None:
        """Привязать WebSocket-сервер и запустить фоновые задачи."""
        serve = self._ws_module.serve
        ssl_context = None
        if self.config.tls_enabled:
            ssl_context = _build_ssl_context(self.config)
            if ssl_context is None:
                log.warning("TLS включён, но SSLContext не создан — запускаю без TLS")
        self._server = await serve(
            self._handler,
            self.config.bind_address,
            self.config.port,
            max_size=1 << 20,
            ping_interval=20,
            ping_timeout=20,
            close_timeout=5,
            ssl=ssl_context,
        )
        log.info(
            "HyprScreen WebSocket-сервер слушает %s:%d (экранов=%d, воркспейс=%d)",
            self.config.bind_address, self.config.port, len(self.screens),
            self.config.workspace,
        )
        for s in self.screens:
            await s.start_capture()
        if self._discovery is not None:
            await self._discovery.start()
        # Базовое состояние + LAN IP для GUI; далее runtime-статистика каждые 2с.
        state_file.update_state(ip=lan_ip(), version=__version__,
                                workspace=self.config.workspace,
                                started_at=self._started_at)
        self._state_task = asyncio.create_task(self._state_loop(), name="state-loop")

    async def serve(self) -> None:
        """Работать вечно, рассылая кадры всем клиентам."""
        if self._server is None:
            await self.start()
        try:
            await self._server.serve_forever()
        finally:
            await self.shutdown()

    async def stop(self) -> None:
        """Сигнал к остановке (идемпотентно)."""
        self._stop_event.set()
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
        if self._discovery is not None:
            await self._discovery.stop()

    async def shutdown(self) -> None:
        """Отменить все задачи, закрыть клиентов и InputInjector."""
        log.info("остановка сервера")
        if self._state_task is not None:
            self._state_task.cancel()
            try:
                await self._state_task
            except asyncio.CancelledError:
                pass
            self._state_task = None
        for s in self.screens:
            await s.stop_capture()
        for s in self.screens:
            for q in list(s._queues.values()):
                q.put_nowait(b"")
        for s in self.screens:
            try:
                s.injector.close()
            except Exception as exc:  # noqa: BLE001
                log.warning("ошибка закрытия injector экрана %d: %s", s.index, exc)
        if self._discovery is not None:
            await self._discovery.stop()
        log.info("остановка сервера завершена")

    # -- runtime-статистика -------------------------------------------------

    def runtime_stats(self) -> dict[str, Any]:
        """Сводная статистика по всем экранам (для GUI)."""
        return {
            "clients": sum(len(s._clients) for s in self.screens),
            "screens": [s.runtime_stats() for s in self.screens],
        }

    async def _state_loop(self) -> None:
        """Каждые 2 секунды писать runtime-статистику в state-файл."""
        try:
            while True:
                await asyncio.sleep(2.0)
                state_file.update_state(runtime=self.runtime_stats())
        except asyncio.CancelledError:
            raise

    # -- внутренний: роутинг входящих соединений ---------------------------

    async def _handler(self, ws: Any) -> None:
        """Точка входа для каждого нового соединения."""
        # websockets < 13: ws.path; websockets >= 13: ws.request.path.
        path = getattr(ws, "path", None)
        if not path:
            request = getattr(ws, "request", None)
            path = getattr(request, "path", "") or ""
        path = path.lstrip("/")
        if not path:
            idx = 0
        else:
            first = path.split("?", 1)[0].split("/", 1)[0]
            try:
                idx = int(first)
            except ValueError:
                await ws.close(code=1008, reason="unknown screen index")
                return
        if idx < 0 or idx >= len(self.screens):
            try:
                await ws.close(code=1008, reason="unknown screen index")
            except Exception as exc:  # noqa: BLE001
                log.debug("не удалось закрыть ws (idx=%d): %s", idx, exc)
            return
        screen = self.screens[idx]
        try:
            await screen.handle(ws)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            log.warning("экран %d: ошибка обработчика соединения: %s", idx, exc)


# ---------------------------------------------------------------------------


def _import_websockets():
    """Импортировать ``websockets`` или поднять чёткую ошибку."""
    try:
        import websockets  # type: ignore[import-not-found]
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "Требуется библиотека 'websockets'. Установите: pip install websockets"
        ) from exc
    return websockets


def _build_ssl_context(config: Config) -> Any:
    """Построить SSLContext для wss:// (self-signed при отсутствии путей)."""
    import ssl
    import os
    import subprocess

    cert = config.tls_cert
    key = config.tls_key
    if not cert or not key:
        data_dir = os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share"))
        hs_dir = os.path.join(data_dir, "hyprscreen")
        os.makedirs(hs_dir, exist_ok=True)
        cert = os.path.join(hs_dir, "cert.pem")
        key = os.path.join(hs_dir, "key.pem")
        if not os.path.exists(cert) or not os.path.exists(key):
            log.info("TLS: генерирую self-signed сертификат: %s", cert)
            try:
                subprocess.run([
                    "openssl", "req", "-x509", "-newkey", "rsa:2048",
                    "-keyout", key, "-out", cert, "-days", "365", "-nodes",
                    "-subj", "/CN=hyprscreen",
                ], check=True, capture_output=True, timeout=30)
            except Exception as exc:
                log.error("TLS: не удалось сгенерировать сертификат: %s", exc)
                return None
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(cert, key)
        log.info("TLS: SSLContext создан (cert=%s)", cert)
        return ctx
    except Exception as exc:
        log.error("TLS: не удалось загрузить сертификат: %s", exc)
        return None
