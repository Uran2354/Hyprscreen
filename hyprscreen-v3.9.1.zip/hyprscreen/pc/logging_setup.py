"""Конфигурация логирования для HyprScreen.

Логируем в stderr (журнал systemd ловит автоматически) И в файл с ротацией
(RotatingFileHandler, 5 МБ × 3 бэкапа) в ``~/.local/share/hyprscreen/hyprscreen.log``.
Компактный формат: время, уровень, имя логгера, сообщение.
"""

from __future__ import annotations

import logging
import logging.handlers
import os
import sys
from typing import Optional

DEFAULT_FORMAT = "%(asctime)s %(levelname)-7s %(name)s: %(message)s"
DEFAULT_DATEFMT = "%H:%M:%S"


def default_log_path() -> str:
    data_home = os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share"))
    return os.path.join(data_home, "hyprscreen", "hyprscreen.log")


def setup_logging(
    level: int | str = logging.INFO,
    *,
    stream: Optional[object] = None,
    fmt: str = DEFAULT_FORMAT,
    datefmt: str = DEFAULT_DATEFMT,
    log_to_file: bool = True,
    log_file: Optional[str] = None,
) -> logging.Logger:
    """Настроить корневое логирование и вернуть логгер ``hyprscreen``."""
    if isinstance(level, str):
        level = getattr(logging, level.upper(), logging.INFO)
    formatter = logging.Formatter(fmt, datefmt)
    root = logging.getLogger()
    for h in list(root.handlers):
        root.removeHandler(h)
    stderr_handler = logging.StreamHandler(stream or sys.stderr)
    stderr_handler.setFormatter(formatter)
    root.addHandler(stderr_handler)
    if log_to_file:
        path = log_file or default_log_path()
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            file_handler = logging.handlers.RotatingFileHandler(
                path, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8",
            )
            file_handler.setFormatter(formatter)
            root.addHandler(file_handler)
        except Exception as exc:  # noqa: BLE001 — stderr работает всегда
            logging.getLogger("hyprscreen").warning(
                "не удалось создать файл лога %s: %s", path, exc
            )
    root.setLevel(level)
    log = logging.getLogger("hyprscreen")
    log.debug("логирование инициализировано на уровне %s", logging.getLevelName(level))
    return log
