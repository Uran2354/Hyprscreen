@file:Suppress("SpellCheckingInspection") // keysym/HyprScreen — не опечатки

package com.example.hyprscreen

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Collections
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

/**
 * HTTP-клиент к PC-серверу HyprScreen 3.9.1 (MJPEG вместо WebSocket 2.x).
 *
 * Жизненный цикл:
 *  1. [connect] в фоне запрашивает `GET /info` (JSON: монитор/fps/размер кадра),
 *     затем открывает `GET /stream.mjpeg` — multipart/x-mixed-replace, где
 *     каждый part — JPEG-кадр. Кадры вырезаются по маркерам SOI/EOI, поэтому
 *     клиент не зависит от деталей обрамления multipart.
 *  2. Кадры декодируются ВНЕ главного треда (однопоточный декод сохраняет
 *     порядок; пул битмапов — без аллокаций на кадр) и отдаются листенеру.
 *  3. Клавиатура: [sendInput] шлёт `POST /key` / `POST /text` с JSON-телом
 *     (см. ../PROTOCOL.md). Тача/указателя в 3.x нет.
 *  4. Обрыв → автопереподключение с нарастающей задержкой (1.5с→5с);
 *     403 (неверный токен) — финальная ошибка БЕЗ реконнекта.
 *
 * Состояние соединения экспонируется как [StateFlow], чтобы коллекторы (UI)
 * всегда имели свежее значение.
 */
class ScreenClient {

    /** Высокоуровневое состояние соединения, экспонируемое в UI. */
    sealed class State {
        object Idle : State()
        data class Connecting(val host: String, val port: Int) : State()
        data class Connected(val info: ServerInfo) : State()
        data class Reconnecting(val attempt: Int) : State()
        data class Error(val message: String) : State()
        object Disconnected : State()
    }

    /** Получает декодированные кадры и статистику на главном треде. */
    interface FrameListener {
        fun onInfo(info: ServerInfo)
        fun onFrame(bitmap: Bitmap, decodeMs: Long)
        fun onStats(stats: FrameStats)
        fun onError(message: String)
    }

    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()

    /**
     * Scope декодера. Пересоздаётся в [connect] ([disconnect] отменяет его;
     * без пересоздания повторное подключение «замирало» до пересоздания сервиса).
     */
    private var scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val decodeMutex = Mutex()

    @Volatile private var streamThread: Thread? = null
    @Volatile private var serverInfo: ServerInfo? = null
    @Volatile var frameListener: FrameListener? = null
    /** Активный поток кадров: закрывается в [disconnect], чтобы разблокировать read(). */
    @Volatile private var activeStream: InputStream? = null

    // --- Auto-reconnect ---
    @Volatile private var shouldReconnect: Boolean = false
    @Volatile private var reconnectAttempt: Int = 0
    @Volatile private var running: Boolean = false

    private var connectParams: ConnectParams? = null

    /** Свежий [ServerInfo] из /info, если уже получен. */
    val currentServerInfo: ServerInfo? get() = serverInfo

    private val stats = FrameStats()
    private val framesDropped = AtomicLong(0)
    private var connectStartMs = 0L
    private var firstFrameSeen = false
    private var lastFpsCheckMs = 0L
    private var framesSinceFpsCheck = 0
    private val pending = AtomicLong(0)

    /** Однопоточный исполнитель POST-запросов клавиатуры (fire-and-forget). */
    private val inputExecutor: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(r, "hyprscreen-input").apply { isDaemon = true }
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private data class ConnectParams(val host: String, val port: Int, val token: String?)

    // --- Пул битмапов (декод без аллокаций) ---------------------------------
    // Слот годен, только если он НЕ «в полёте» и НЕ текущий битмап ScreenView.
    private val bitmapSlots = arrayOfNulls<Bitmap>(4)
    private val inFlight = Collections.synchronizedSet(mutableSetOf<Bitmap>())
    @Volatile private var lastDrawnBitmap: Bitmap? = null

    private fun obtainBitmapSlot(w: Int, h: Int): Bitmap? {
        val current = lastDrawnBitmap
        for (slot in bitmapSlots) {
            val b = slot ?: continue
            if (!b.isRecycled && b !in inFlight && b !== current &&
                b.width == w && b.height == h
            ) return b
        }
        val fresh = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        for (i in bitmapSlots.indices) {
            val s = bitmapSlots[i]
            if (s != null && (s in inFlight || s === current)) continue
            bitmapSlots[i] = fresh
            s?.recycle()
            return fresh
        }
        return null
    }

    // ------------------------------------------------------------------ API

    /**
     * Подключиться к PC. URL: `http://<host>:<port>/stream.mjpeg[?t=<token>]`.
     */
    fun connect(host: String, port: Int, token: String? = null) {
        connectParams = ConnectParams(host, port, token)
        shouldReconnect = true
        reconnectAttempt = 0
        running = true
        if (!scope.isActive) {
            scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        }
        connectStartMs = System.currentTimeMillis()
        firstFrameSeen = false
        stats.run {
            framesDecoded = 0; framesDropped = 0; lastDecodeMs = 0
            fps = 0.0; connectMs = 0; connectedForMs = 0
        }
        framesDropped.set(0)
        inFlight.clear()
        lastDrawnBitmap = null
        _state.value = State.Connecting(host, port)
        serverInfo = ServerInfo(host = host, port = port)
        startStreamThread()
    }

    /**
     * Отправить событие клавиатуры на PC: POST /key или /text (JSON-тело).
     * Fire-and-forget: UI не блокируется, но ошибка сервера (нет wtype,
     * лимит) отдаётся в [FrameListener.onError] — как сообщения error из 2.x.
     */
    fun sendInput(event: InputEvent) {
        val params = connectParams ?: return
        val payload: JSONObject = when (event) {
            is InputEvent.Key -> keyPayload(event.keysym, event.modifiers)
            is InputEvent.Text -> textPayload(event.text)
        }
        val path = when (event) {
            is InputEvent.Key -> "/key"
            is InputEvent.Text -> "/text"
        }
        inputExecutor.execute {
            val (code, error) = runCatching { postJson(params, path, payload) }
                .getOrElse { -1 to (it.message ?: "сеть недоступна") }
            if (code == -1) {
                Log.w(TAG, "Не удалось отправить ввод: $error")
                // Сеть отвалилась — тихо: реконнект потока сам покажет состояние.
            } else if (code !in 200..299) {
                postOnMain { frameListener?.onError(error.ifBlank { "HTTP $code" }) }
            }
        }
    }

    /**
     * Аккуратно остановить поток стрима и сбросить состояние.
     * Также отменяем [scope], чтобы декодер не работал после disconnect.
     */
    fun disconnect() {
        shouldReconnect = false
        running = false
        // Сначала закрываем поток: read() обычного InputStream НЕ прерывается
        // через interrupt — без close() поток декодера висел бы до таймаута.
        runCatching { activeStream?.close() }
        activeStream = null
        streamThread?.interrupt()
        streamThread = null
        serverInfo = null
        _state.value = State.Disconnected
        scope.cancel()
    }

    // ------------------------------------------------------------ транспорт

    private fun baseUrl(params: ConnectParams) = "http://${params.host}:${params.port}"

    private fun urlWithToken(params: ConnectParams, path: String): URL {
        val token = params.token
        val query = if (token.isNullOrBlank()) "" else "?t=${java.net.URLEncoder.encode(token, "UTF-8")}"
        return URL(baseUrl(params) + path + query)
    }

    /** POST JSON-тела (клавиатура). Возвращает (код, сообщение об ошибке). */
    private fun postJson(params: ConnectParams, path: String, body: JSONObject): Pair<Int, String> {
        val conn = urlWithToken(params, path).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 2500
            conn.readTimeout = 4000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            val bytes = body.toString().toByteArray(Charsets.UTF_8)
            conn.setFixedLengthStreamingMode(bytes.size)
            conn.useCaches = false
            val out: OutputStream = conn.outputStream
            out.write(bytes)
            out.flush()
            val code = conn.responseCode
            if (code in 200..299) return code to ""
            // Тело ошибки — в error-stream (400: "wtype не установлен…" и т.п.)
            val text = runCatching {
                conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            }.getOrNull().orEmpty()
            val message = runCatching {
                JSONObject(text).optString("error", "")
            }.getOrDefault("")
            return code to message
        } finally {
            conn.disconnect()
        }
    }

    /** GET /info (JSON). null — сервер недоступен/битый ответ. */
    private fun fetchInfo(params: ConnectParams): ServerInfo? {
        var conn: HttpURLConnection? = null
        return try {
            conn = urlWithToken(params, "/info").openConnection() as HttpURLConnection
            conn.connectTimeout = 3000
            conn.readTimeout = 3000
            conn.useCaches = false
            if (conn.responseCode != 200) return null
            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            ServerInfo.fromJson(params.host, params.port, JSONObject(text))
        } catch (e: Exception) {
            Log.w(TAG, "GET /info не удался: ${e.message}")
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun startStreamThread() {
        val params = connectParams ?: return
        streamThread = Thread({
            streamLoop(params)
        }, "hyprscreen-stream").apply {
            isDaemon = true
            start()
        }
    }

    private fun streamLoop(params: ConnectParams) {
        var attempt = 0
        while (running && shouldReconnect) {
            if (attempt > 0) {
                _state.value = State.Reconnecting(attempt)
                val delay = minOf(RECONNECT_DELAY_BASE_MS * attempt, RECONNECT_DELAY_MAX_MS)
                if (!sleepInterruptibly(delay)) break
                if (!running || !shouldReconnect) break
            }
            try {
                // 1) /info — монитор/fps/размер кадра (для мгновенного масштаба)
                fetchInfo(params)?.let { info ->
                    if (!running) return
                    serverInfo = info
                    _state.value = State.Connected(info)
                    postOnMain { frameListener?.onInfo(info) }
                }
                // 2) сам поток
                openStream(params)?.use { input ->
                    activeStream = input
                    try {
                        if (serverInfo == null) {
                            // /info не дошёл — считаем подключённым «вслепую»
                            val info = ServerInfo(host = params.host, port = params.port)
                            serverInfo = info
                            _state.value = State.Connected(info)
                            postOnMain { frameListener?.onInfo(info) }
                        }
                        attempt = 0
                        reconnectAttempt = 0
                        readMjpeg(input, params)
                    } finally {
                        activeStream = null
                    }
                } ?: throw IOException("не удалось открыть поток")
            } catch (e: SecurityException) {
                // HTTP 403 обрабатывается в openStream как финальная ошибка.
                Log.e(TAG, "Поток отклонён: ${e.message}")
            } catch (e: IOException) {
                // «Cleartext HTTP traffic to … not permitted» — в манифесте
                // нет usesCleartextTraffic (Android 9+ режет http молча).
                // Реконнект бессмыслен — ошибка НЕ сетевая, а политика ОС
                // (SETUP.md §7.8). Показываем точное лечение и останавливаемся.
                if (e.message.orEmpty().contains("Cleartext", ignoreCase = true)) {
                    shouldReconnect = false
                    running = false
                    _state.value = State.Error(
                        "Android блокирует HTTP: добавьте в манифест " +
                            "android:usesCleartextTraffic=\"true\" (SETUP.md §7.8)"
                    )
                    return
                }
                Log.w(TAG, "Поток прервался: ${e.message}")
            } catch (e: Exception) {
                Log.w(TAG, "Поток прервался: ${e.message}")
            }
            if (!running || !shouldReconnect) break
            attempt += 1
            reconnectAttempt = attempt
            if (attempt > MAX_RECONNECT_ATTEMPTS) {
                _state.value = State.Error(
                    "Не удалось подключиться за $MAX_RECONNECT_ATTEMPTS попыток"
                )
                return
            }
        }
    }

    /** Открыть поток; 403 → финальная ошибка (null, без реконнекта). */
    private fun openStream(params: ConnectParams): InputStream? {
        val conn = urlWithToken(params, "/stream.mjpeg").openConnection() as HttpURLConnection
        conn.connectTimeout = 4000
        conn.readTimeout = 15000
        conn.useCaches = false
        conn.setRequestProperty("Accept", "multipart/x-mixed-replace, image/jpeg")
        val code = conn.responseCode
        if (code == 403) {
            conn.disconnect()
            shouldReconnect = false
            running = false
            _state.value = State.Error("сервер требует токен (403) — проверьте на PC")
            return null
        }
        if (code != 200) {
            conn.disconnect()
            throw IOException("HTTP $code на /stream.mjpeg")
        }
        // Инкапсулируем соединение в поток: disconnect вызовется при close().
        return object : BufferedInputStream(conn.inputStream, 128 * 1024) {
            @Volatile private var closed = false
            override fun close() {
                if (!closed) {
                    closed = true
                    runCatching { super.close() }
                    runCatching { conn.disconnect() }
                }
            }
        }
    }

    // -------------------------------------------------------------- MJPEG ---
    private fun readMjpeg(input: InputStream, params: ConnectParams) {
        while (running && shouldReconnect) {
            val frame = readOneFrame(input) ?: return
            // Backpressure: если в декоде уже 2 кадра — сбрасываем.
            if (pending.incrementAndGet() > MAX_PENDING) {
                pending.decrementAndGet()
                framesDropped.incrementAndGet()
                continue
            }
            scope.launch {
                try {
                    decodeMutex.withLock { decodeFrame(frame) }
                } finally {
                    pending.decrementAndGet()
                }
            }
        }
    }

    /**
     * Вырезать ОДИН JPEG-кадр по маркерам SOI (FFD8) … EOI (FFD9).
     * Не зависит от границ multipart-parts и от Content-Length.
     */
    private fun readOneFrame(input: InputStream): ByteArray? {
        // 1) пропускаем всё до SOI
        var prev = -1
        while (true) {
            val b = input.read()
            if (b == -1) return null
            if (prev == 0xFF && b == 0xD8) break
            prev = b
        }
        // 2) копим кадр до EOI (с защитой от бесконечного роста)
        val out = ByteArrayOutputStream(48 * 1024)
        out.write(0xFF); out.write(0xD8)
        prev = 0xD8
        while (true) {
            val b = input.read()
            if (b == -1) return if (out.size() > 2) out.toByteArray() else null
            if (out.size() > MAX_FRAME_BYTES) return null  // EOI потерян — кадр бит
            out.write(b)
            if (prev == 0xFF && b == 0xD9) return out.toByteArray()
            prev = b
        }
    }

    private suspend fun decodeFrame(data: ByteArray) {
        val t0 = System.currentTimeMillis()
        // Сначала только заголовок (дёшево) — чтобы взять слот нужного размера.
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        val reuse = if (bounds.outWidth > 0 && bounds.outHeight > 0) {
            obtainBitmapSlot(bounds.outWidth, bounds.outHeight)
        } else null
        val opts = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            if (reuse != null) {
                inBitmap = reuse
                inMutable = true
            }
        }
        val bitmap = try {
            BitmapFactory.decodeByteArray(data, 0, data.size, opts)
        } catch (_: IllegalArgumentException) {
            // Слот не подошёл (изменился размер/формат) — обычный декод.
            BitmapFactory.decodeByteArray(data, 0, data.size)
        } ?: run {
            Log.w(TAG, "Не удалось декодировать JPEG-кадр (${data.size} байт)")
            return
        }
        val decodeMs = System.currentTimeMillis() - t0
        updateStats(decodeMs)
        inFlight.add(bitmap)
        postOnMain {
            lastDrawnBitmap = bitmap
            inFlight.remove(bitmap)
            frameListener?.onFrame(bitmap, decodeMs)
        }
        postOnMain { frameListener?.onStats(stats.copy()) }
    }

    private fun updateStats(decodeMs: Long) {
        stats.framesDecoded++
        stats.framesDropped = framesDropped.get()
        stats.lastDecodeMs = decodeMs
        val now = System.currentTimeMillis()
        if (!firstFrameSeen) {
            firstFrameSeen = true
            lastFpsCheckMs = now
            stats.connectMs = now - connectStartMs
        } else {
            framesSinceFpsCheck++
            val elapsed = now - lastFpsCheckMs
            if (elapsed >= FPS_WINDOW_MS) {
                stats.fps = framesSinceFpsCheck * 1000.0 / elapsed
                lastFpsCheckMs = now
                framesSinceFpsCheck = 0
            }
        }
        stats.connectedForMs = now - connectStartMs
    }

    private fun postOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block()
        else mainHandler.post(block)
    }

    private fun sleepInterruptibly(ms: Long): Boolean = try {
        Thread.sleep(ms)
        true
    } catch (_: InterruptedException) {
        false
    }

    companion object {
        private const val TAG = "HyprScreen/ScreenClient"
        private const val MAX_PENDING = 2
        private const val FPS_WINDOW_MS = 500L
        private const val MAX_RECONNECT_ATTEMPTS = 10
        private const val RECONNECT_DELAY_BASE_MS = 1500L
        private const val RECONNECT_DELAY_MAX_MS = 5000L
        /** Предохранитель: кадр больше 32 МБ — поток бит (EOI потерян). */
        private const val MAX_FRAME_BYTES = 32 * 1024 * 1024
    }
}
