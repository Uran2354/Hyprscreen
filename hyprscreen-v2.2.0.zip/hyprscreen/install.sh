#!/usr/bin/env bash
# =============================================================================
#  HyprScreen 2.2.0 — установщик (CachyOS / Hyprland)
#
#  Делает:
#    1) копирует программу в ~/.local/share/hyprscreen
#    2) запускает pc/setup.sh (пакеты, venv, config.toml)
#    3) ставит CLI-хелпер ~/.local/bin/hyprscreen (бинды)
#    4) ставит бинды Win+N: ~/.config/hypr/hyprscreen.conf + source
#
#  Использование:  ./install.sh          (из распакованного архива)
# =============================================================================
set -euo pipefail

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST_DIR="$HOME/.local/share/hyprscreen"
BIN_DIR="$HOME/.local/bin"

ok()   { printf '✅ %s\n' "$*"; }
warn() { printf '⚠️  %s\n' "$*"; }
err()  { printf '❌ %s\n' "$*"; }

[[ -f "$SRC_DIR/pc/main.py" ]] || { err "запускайте install.sh из корня распакованного HyprScreen"; exit 1; }

# Исходник должен быть ПОЛНЫМ до копирования. Локальные *.py — файлы
# проекта (их НЕТ в requirements.txt, pip их не ставит): если settings_store.py
# и т. п. не докопировались в распаковку, установленная копия упадёт в
# рантайме с «ModuleNotFoundError». Проверяем сразу и падаем с точным списком.
missing_src=()
for mod in main gui config hyprctl settings_store state_file wallpaper \
           capture logging_setup server virtual_output workspaces \
           discovery input; do
    [[ -f "$SRC_DIR/pc/$mod.py" ]] || missing_src+=("pc/$mod.py")
done
if ((${#missing_src[@]})); then
    err "исходник неполный — нет файлов: ${missing_src[*]}"
    err "это ЛОКАЛЬНЫЕ модули HyprScreen (не pip-пакеты, в requirements.txt их нет)"
    err "лечение: скопируйте перечисленные файлы в распаковку ИЛИ заново"
    err "распакуйте полный архив hyprscreen-v2.2.0.zip и запустите ./install.sh"
    exit 1
fi

echo "— HyprScreen 2.2.0: установка —"

# 1. Копирование программы -----------------------------------------------------
# Перед rm -rf сохраняем пользовательские config.toml (там auth-токен!)
# и .venv (чтобы переустановка не пересобирала окружение) и возвращаем их после.
BACKUP_DIR=""
if [[ "$SRC_DIR" != "$DEST_DIR" ]]; then
  if [[ -d "$DEST_DIR" ]]; then
    BACKUP_DIR="$(mktemp -d)"
    [[ -f "$DEST_DIR/pc/config.toml" ]] && cp "$DEST_DIR/pc/config.toml" "$BACKUP_DIR/config.toml"
    [[ -d "$DEST_DIR/pc/.venv" ]] && mv "$DEST_DIR/pc/.venv" "$BACKUP_DIR/venv"
  fi
  mkdir -p "$(dirname "$DEST_DIR")"
  rm -rf "$DEST_DIR"
  mkdir -p "$DEST_DIR"
  cp -r "$SRC_DIR/." "$DEST_DIR/"
  # Не тащим мусор исходников в установленную копию.
  rm -rf "$DEST_DIR/.git"
  if [[ -n "$BACKUP_DIR" ]]; then
    mkdir -p "$DEST_DIR/pc"
    [[ -f "$BACKUP_DIR/config.toml" ]] && cp "$BACKUP_DIR/config.toml" "$DEST_DIR/pc/config.toml" && ok "config.toml сохранён (токен/настройки не потеряны)"
    [[ -d "$BACKUP_DIR/venv" ]] && mv "$BACKUP_DIR/venv" "$DEST_DIR/pc/.venv" && ok ".venv перенесён (без пересборки окружения)"
    rm -rf "$BACKUP_DIR"
  fi
fi
ok "программа: $DEST_DIR"

# 2. Зависимости + venv + config.toml -------------------------------------------
if [[ -x "$DEST_DIR/pc/setup.sh" ]]; then
  "$DEST_DIR/pc/setup.sh" || warn "setup.sh завершился с предупреждениями — проверьте вывод выше"
fi

# 3. CLI-хелпер -------------------------------------------------------------------
mkdir -p "$BIN_DIR"
sed "s|__INSTALL_DIR__|$DEST_DIR|g" "$DEST_DIR/bin/hyprscreen" > "$BIN_DIR/hyprscreen"
chmod +x "$BIN_DIR/hyprscreen"
ok "CLI: $BIN_DIR/hyprscreen (status|focus|movewin|start|kill|toggle|gui|menu)"

# 4. Бинды Hyprland ----------------------------------------------------------------
mkdir -p "$HOME/.config/hypr"
if [[ -f "$HOME/.config/hypr/hyprscreen.conf" ]]; then
  warn "бинды уже существуют — не перезаписаны: ~/.config/hypr/hyprscreen.conf"
else
  install -m 644 "$DEST_DIR/hypr/hyprscreen.conf" "$HOME/.config/hypr/hyprscreen.conf"
  ok "бинды: ~/.config/hypr/hyprscreen.conf (Win+N, Win+Shift+N, Win+Alt+N)"
fi

HYPRLAND_CONF="$HOME/.config/hypr/hyprland.conf"
if [[ -f "$HYPRLAND_CONF" ]]; then
  if ! grep -q "hypr/hyprscreen.conf" "$HYPRLAND_CONF"; then
    printf '\n# HyprScreen: бинды Win+N и др.\nsource = ~/.config/hypr/hyprscreen.conf\n' >> "$HYPRLAND_CONF"
    ok "source добавлен в hyprland.conf"
  else
    ok "source уже прописан в hyprland.conf"
  fi
else
  warn "hyprland.conf не найден — добавьте вручную: source = ~/.config/hypr/hyprscreen.conf"
fi

# 5. PATH ----------------------------------------------------------------------------
case ":$PATH:" in
  *":$HOME/.local/bin:"*) ;;
  *) warn "~/.local/bin не в PATH — добавьте в ~/.zshenv: export PATH=\"\$HOME/.local/bin:\$PATH\" " ;;
esac

echo ""
echo "Готово. Быстрый старт:"
echo "  1) hyprctl reload            — применить бинды"
echo "  2) hyprscreen start          — сервер в фоне (или hyprscreen gui)"
echo "  3) телефон: приложение HyprScreen → IP ПК:8765 (воркспейс 6)"
echo "  4) Win+N                     — фокус на экран телефона"
echo ""
echo "Если на телефоне ЧЁРНЫЙ ЭКРАН / «НЕТ СИГНАЛА»:"
echo "  hyprscreen grimtest          — покажет точную причину и лечение"
echo "  (типово: yay -S grim-git — новый Hyprland убрал wlr-screencopy из grim 1.4.1)"
