#!/usr/bin/env bash
# HyprScreen 2.0 — удаление
set -euo pipefail

echo "— Удаление HyprScreen —"

# 1. Остановить сервер, подчистить HEADLESS и правила
if command -v hyprscreen >/dev/null 2>&1; then
  hyprscreen kill >/dev/null 2>&1 || true
fi

# 2. Файлы
rm -f  "$HOME/.local/bin/hyprscreen" 2>/dev/null && echo "✅ удалён CLI" || true
rm -rf "$HOME/.local/share/hyprscreen"          && echo "✅ удалена программа" || true
# quickshell-виджетов в поставке нет; зачищаем и старые установки.
rm -rf "$HOME/.config/quickshell/hyprscreen"    && echo "✅ удалены quickshell-виджеты (если были)" || true
rm -rf "$HOME/.cache/hyprscreen"                && echo "✅ удалён state-кэш" || true

# 3. Конфиг и бинды — только с --purge
if [[ "${1:-}" == "--purge" ]]; then
  rm -f "$HOME/.config/hypr/hyprscreen.conf" && echo "✅ удалены бинды" || true
  HYPRLAND_CONF="$HOME/.config/hypr/hyprland.conf"
  if [[ -f "$HYPRLAND_CONF" ]]; then
    sed -i '/hypr\/hyprscreen\.conf/d' "$HYPRLAND_CONF"
    echo "✅ source убран из hyprland.conf"
  fi
else
  echo "ℹ️  бинды сохранены. Полное удаление: ./uninstall.sh --purge"
fi

echo "Готово."
