"""Конфигурация HyprScreen.

Здесь живёт :class:`Config` (верхнеуровневые настройки сервера) и
:class:`ScreenConfig` (настройки отдельного виртуального экрана). Конфиг
читается из TOML-файла (в Python 3.11+ есть стандартный :mod:`tomllib`, на
более старых версиях используется бэкпорт ``tomli``).

Пример конфигурационного файла лежит рядом со скриптом: ``config.toml.example``.

Этот модуль также экспортирует :data:`__version__` (раньше она жила в
``hyprscreen/__init__.py``, но проект был переупакован из пакета в набор
плоских скриптов).

Мультиэкранность
----------------
Начиная с версии 0.2.0 PC может отдавать несколько независимых виртуальных
экранов (1..4). Каждый описывается своим :class:`ScreenConfig`. В конфиге
поддерживаются две формы:

* простая — ``screen_count = N`` под ``[hyprscreen]`` создаёт N одинаковых
  экранов из общих полей (``resolution``, ``fps`` и т.д.);
* явная — массив таблиц ``[[hyprscreen.screens]]`` с покадровыми настройками.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Mapping

__version__ = "0.2.0"

log = logging.getLogger(__name__)

# В Python 3.11+ tomllib уже в стандартной библиотеке; на старых версиях
# нужен бэкпорт tomli.
try:
    import tomllib as _toml  # type: ignore[import-not-found]
except ModuleNotFoundError:  # pragma: no cover - exercised only on <3.11
    try:
        import tomli as _toml  # type: ignore[import-not-found]
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "Нет TOML-парсера. На Python <3.11 установите 'tomli': "
            "pip install tomli"
        ) from exc


def _parse_resolution(value: str | tuple[int, int]) -> tuple[int, int]:
    """Разобрать ``"1920x1080"`` или ``(1920, 1080)`` в кортеж ``(width, height)``."""
    if isinstance(value, tuple):
        if len(value) != 2:
            raise ValueError(f"кортеж разрешения должен быть (W, H), получено {value!r}")
        w, h = int(value[0]), int(value[1])
        if w <= 0 or h <= 0:
            raise ValueError(f"разрешение должно быть положительным: {(w, h)!r}")
        return w, h
    if not isinstance(value, str):
        raise TypeError(
            f"разрешение должно быть строкой 'WxH' или (W,H), получено {type(value)}"
        )
    text = value.strip().lower()
    if "x" not in text:
        raise ValueError(f"разрешение должно выглядеть как '1920x1080', получено {value!r}")
    w_str, h_str = text.split("x", 1)
    w, h = int(w_str), int(h_str)
    if w <= 0 or h <= 0:
        raise ValueError(f"разрешение должно быть положительным: {value!r}")
    return w, h


@dataclass
class ScreenConfig:
    """Настройки одного виртуального экрана.

    Атрибуты
    --------
    resolution:
        ``(width, height)`` этого виртуального headless-вывода в пикселях.
    refresh_rate:
        Частота обновления (Гц), которую получит headless-вывод от Hyprland.
        Влияет на keyword-форму ``WxH@rate``.
    fps:
        Целевая частота кадров, отправляемая WebSocket-клиентам. Capture-loop
        ограничивается этой частотой, устаревшие кадры отбрасываются, если
        клиент не успевает.
    jpeg_quality:
        Качество JPEG (1-100), пробрасывается в ``grim -q``.
    capture_backend:
        ``"grim"`` (по умолчанию, всегда доступен) либо ``"portal"`` для
        xdg-desktop-portal ScreenCast + PipeWire (экспериментально — D-Bus
        флоу не дописан, при отсутствии библиотек авто-откат на grim).
    output_name:
        Если задано — заставить Hyprland использовать именно это имя для
        headless-вывода. Если ``None`` — имя вычисляется через
        ``hyprctl monitors -j`` после создания (обычно ``HEADLESS-1``).
    """

    resolution: tuple[int, int] = (1920, 1080)
    refresh_rate: float = 60.0
    fps: int = 30
    jpeg_quality: int = 80
    capture_backend: str = "grim"
    output_name: str | None = None
    wallpaper: str | None = None
    image_format: str = "jpeg"
    adaptive_fps: bool = False
    delta_frames: bool = False
    h264_encoder: str = "libx264"

    @property
    def width(self) -> int:
        """Ширина виртуального вывода в пикселях."""
        return self.resolution[0]

    @property
    def height(self) -> int:
        """Высота виртуального вывода в пикселях."""
        return self.resolution[1]

    @property
    def mode_string(self) -> str:
        """Hyprland-строка режима ``WxH@rate`` (например ``1920x1080@60``)."""
        rate = int(self.refresh_rate) if self.refresh_rate.is_integer() else self.refresh_rate
        return f"{self.width}x{self.height}@{rate}"

    def to_dict(self) -> dict[str, Any]:
        """Сериализация в плоский словарь (для логов / hello-сообщения)."""
        d = asdict(self)
        d["resolution"] = list(self.resolution)
        return d


@dataclass
class Config:
    """Верхнеуровневая конфигурация HyprScreen.

    Атрибуты
    --------
    port:
        TCP-порт WebSocket-сервера.
    bind_address:
        Адрес привязки; по умолчанию ``0.0.0.0`` — чтобы телефон в LAN мог
        подключиться. Поставьте ``127.0.0.1`` для SSH-туннеля.
    screens:
        Список :class:`ScreenConfig` (по умолчанию один экран).
    discovery_port:
        UDP-порт для рассылки discovery-анонсов (по умолчанию 8766).
    discovery_enabled:
        Включить/выключить UDP discovery-бродкастер.
    host_name:
        Имя, которое увидит Android-клиент в списке "Discovered PCs".
        Если ``None`` — берётся ``socket.gethostname()``.
    ydotool_socket:
        Необязательный путь к unix-сокету ydotoold. Обычно не нужен —
        ydotool находит его через ``YDOTOOL_SOCKET`` или дефолтное место.
    extra:
        Произвольные неструктурированные поля из TOML (для расширений).
    """

    port: int = 8765
    bind_address: str = "0.0.0.0"
    screens: list[ScreenConfig] = field(default_factory=lambda: [ScreenConfig()])
    discovery_port: int = 8766
    discovery_enabled: bool = True
    host_name: str | None = None
    ydotool_socket: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)
    # --- новые поля (opt-in, по умолчанию безопасные) ---
    auth_token: str | None = None       # если задан — клиент обязан прислать {"type":"auth","token":"..."}
    input_rate_limit: int = 0           # max input сообщ/сек на клиент (0 = без лимита)
    tls_enabled: bool = False           # wss:// вместо ws://
    tls_cert: str | None = None         # путь к PEM-сертификату (если None — генерится self-signed)
    tls_key: str | None = None          # путь к PEM-ключу
    log_to_file: bool = True            # писать лог в файл с ротацией
    log_file: str | None = None         # путь к файлу лога (None = авто)

    # -- backward-compat свойства (делегируют к screens[0]) ----------------
    # Старый одноэкранный код мог читать cfg.width / cfg.fps и т.д. напрямую.
    # Эти свойства сохраняют обратную совместимость, транслируя обращения к
    # первому экрану списка.

    @property
    def width(self) -> int:
        """Ширина первого экрана (для обратной совместимости)."""
        return self.screens[0].width

    @property
    def height(self) -> int:
        """Высота первого экрана (для обратной совместимости)."""
        return self.screens[0].height

    @property
    def resolution(self) -> tuple[int, int]:
        """Разрешение первого экрана (для обратной совместимости)."""
        return self.screens[0].resolution

    @resolution.setter
    def resolution(self, value: tuple[int, int]) -> None:
        # Позволяет старому коду cfg.resolution = (w,h) менять первый экран.
        self.screens[0].resolution = value

    @property
    def refresh_rate(self) -> float:
        return self.screens[0].refresh_rate

    @refresh_rate.setter
    def refresh_rate(self, value: float) -> None:
        for s in self.screens:
            s.refresh_rate = value

    @property
    def fps(self) -> int:
        return self.screens[0].fps

    @fps.setter
    def fps(self, value: int) -> None:
        for s in self.screens:
            s.fps = value

    @property
    def jpeg_quality(self) -> int:
        return self.screens[0].jpeg_quality

    @jpeg_quality.setter
    def jpeg_quality(self, value: int) -> None:
        for s in self.screens:
            s.jpeg_quality = value

    @property
    def capture_backend(self) -> str:
        return self.screens[0].capture_backend

    @capture_backend.setter
    def capture_backend(self, value: str) -> None:
        for s in self.screens:
            s.capture_backend = value

    @property
    def mode_string(self) -> str:
        """Строка режима первого экрана (для обратной совместимости)."""
        return self.screens[0].mode_string

    @property
    def virtual_output_name(self) -> str | None:
        return self.screens[0].output_name

    @virtual_output_name.setter
    def virtual_output_name(self, value: str | None) -> None:
        # Старый код считал это глобальной настройкой; кладём в первый экран.
        self.screens[0].output_name = value

    def to_dict(self) -> dict[str, Any]:
        """Сериализация в плоский словарь (для логов). auth_token маскируется."""
        return {
            "port": self.port,
            "bind_address": self.bind_address,
            "screens": [s.to_dict() for s in self.screens],
            "discovery_port": self.discovery_port,
            "discovery_enabled": self.discovery_enabled,
            "host_name": self.host_name,
            "ydotool_socket": self.ydotool_socket,
            "extra": dict(self.extra),
            "auth_token": self.auth_token,
            "input_rate_limit": self.input_rate_limit,
            "tls_enabled": self.tls_enabled,
            "log_to_file": self.log_to_file,
        }

    # -- конструкторы ----------------------------------------------------

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any]) -> "Config":
        """Построить :class:`Config` из маппинга (например, разобранного TOML).

        Поддерживаются обе формы задания экранов:

        * ``screen_count = N`` (целое) — создаёт N одинаковых экранов из
          общих полей ``resolution``, ``refresh_rate``, ``fps``,
          ``jpeg_quality``, ``capture_backend``, ``output_name``;
        * массив таблиц ``[[screens]]`` — каждый экран со своими полями.
        """
        # Список полей ScreenConfig для переноса из общих ключей.
        screen_field_names = set(ScreenConfig.__dataclass_fields__.keys())
        # Список полей Config верхнего уровня.
        cfg_field_names = set(cls.__dataclass_fields__.keys()) - {"screens", "extra"}

        known: dict[str, Any] = {}
        extra: dict[str, Any] = {}
        # Сначала собираем верхнеуровневые поля.
        for key, value in data.items():
            if key in cfg_field_names:
                known[key] = value
            elif key in screen_field_names or key in ("screen_count", "screens"):
                # Обрабатываем ниже.
                pass
            else:
                extra[key] = value

        # Разбираем экраны.
        screens: list[ScreenConfig] = []
        raw_screens = data.get("screens")
        if isinstance(raw_screens, list):
            # Явная форма: массив таблиц [[screens]].
            for entry in raw_screens:
                if not isinstance(entry, Mapping):
                    raise ValueError(f"каждый [[screens]] должен быть таблицей, получено {type(entry)}")
                fields: dict[str, Any] = {}
                for k, v in entry.items():
                    if k in screen_field_names:
                        fields[k] = v
                    else:
                        extra[f"screen.{k}"] = v
                if "resolution" in fields:
                    fields["resolution"] = _parse_resolution(fields["resolution"])
                screens.append(ScreenConfig(**fields))
        else:
            # Простая форма: общие поля + необязательный screen_count.
            shared: dict[str, Any] = {}
            for k in screen_field_names:
                if k in data:
                    v = data[k]
                    if k == "resolution":
                        v = _parse_resolution(v)
                    shared[k] = v
            count = int(data.get("screen_count", 1))
            if count < 1 or count > 4:
                raise ValueError(f"screen_count должен быть 1..4, получено {count}")
            for _ in range(count):
                # Клонируем shared в каждый экран (независимые объекты).
                screens.append(ScreenConfig(**dict(shared)))

        if not screens:
            screens = [ScreenConfig()]

        cfg = cls(**known)
        cfg.screens = screens
        cfg.extra = extra
        return cfg

    @classmethod
    def from_file(cls, path: str | os.PathLike[str]) -> "Config":
        """Загрузить конфиг из TOML-файла.

        Файл может содержать либо плоские ключи, либо таблицу ``[hyprscreen]``
        — табличная форма предпочтительна.
        """
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"конфиг не найден: {p}")
        with p.open("rb") as fh:
            data = _toml.load(fh)
        # Допускаем либо таблицу [hyprscreen], либо плоские ключи сверху.
        section = data.get("hyprscreen", data) if isinstance(data, dict) else data
        if not isinstance(section, dict):
            raise ValueError(f"некорректная структура конфига в {p}")
        cfg = cls.from_mapping(section)
        log.info("конфиг загружен из %s: %s", p, cfg.to_dict())
        return cfg

    @classmethod
    def default(cls, screen_count: int = 1) -> "Config":
        """Вернуть встроенную конфигурацию по умолчанию с N экранами."""
        if screen_count < 1 or screen_count > 4:
            raise ValueError(f"screen_count должен быть 1..4, получено {screen_count}")
        return cls(screens=[ScreenConfig() for _ in range(screen_count)])
