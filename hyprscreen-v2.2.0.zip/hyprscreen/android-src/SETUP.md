# HyprScreen — интеграция Android-клиента в ваш проект

HyprScreen превращает Android-телефон или планшет в беспроводной второй экран
для PC с CachyOS + Hyprland. PC (Python-сервер) стримит рабочий стол Wayland
как WebSocket-JPEG-поток на порту `8765`; Android-клиент рисует каждый кадр и
шлёт обратно касания/клавиатуру через тот же сокет. UDP-broadcast discovery
работает на порту `8766`.

## Содержание

1. [Обзор](#1-обзор)
2. [Создание проекта](#2-создание-проекта)
3. [Копирование 13 .kt](#3-копирование-13-kt)
4. [AndroidManifest.xml](#4-androidmanifestxml)
5. [app/build.gradle.kts — зависимости](#5-appbuildgradlekts--зависимости)
6. [libs.versions.toml](#6-libsversionsstoml)
7. [Сборка и запуск](#7-сборка-и-запуск)
8. [Выбор экрана (multi-screen)](#8-выбор-экрана-multi-screen)
9. [Заметки и решение проблем](#9-заметки-и-решение-проблем)

## 1. Обзор

Архитектура проста и симметрична:

```
   ┌───────────────┐                          ┌────────────────┐
   │  CachyOS PC   │  ws://host:8765/<index>  │   Android      │
   │  Hyprland +   │ ──────────JPEG──────────▶│   телефон/     │
   │  grim capture │                          │   планшет      │
   │  evdev/wtype  │ ◀─────────JSON input─────│                │
   └───────────────┘                          └────────────────┘
            │                                          │
            │  UDP broadcast 8766                       │
            │  {"hyprscreen":true,                      │
            │   "host":"192.168.1.42",                  │
            │   "port":8765,"screens":2,                │
            │   "name":"cachyos-pc"}                    │
            └──────────────────────────────────────────┘
```

- PC может отдать **N независимых экранов** (по умолчанию 1, до 4). Каждый
  экран — отдельный виртуальный Wayland-вывод `HEADLESS-<i>`, стримится
  независимо ровно одному Android-устройству.
- WebSocket-URL выбирает экран через путь: `ws://<host>:<port>/<index>`,
  где `index` ∈ {0,1,…,N-1}. Путь `/` или пустой = экран 0.
- PC каждые ~2 с рассылает UDP-анонс на `8766` с числом экранов `screens`.
  Android слушает `8766` и в UI показывает чипы «Экран 1» / «Экран 2» / …

Подробно wire-протокол описан в `PROTOCOL.md`.

## 2. Создание проекта

В Android Studio создайте новый проект:

- Шаблон: **Empty Views Activity** (НЕ Compose).
- Язык: **Kotlin**.
- Minimum SDK: **API 24** (Android 7.0).
- Package name: **`com.example.hyprscreen`**.

Дефолтный `MainActivity` из шаблона будет ЗАМЕНЁН тем, что лежит в этой
папке.

## 3. Копирование 13 .kt

Скопируйте 13 `.kt`-файлов из этой папки в:

```
app/src/main/java/com/example/hyprscreen/
├── HyprScreenApp.kt           ← подкласс Application
├── UiTheme.kt                 ← единая палитра «чёрный + изумруд» + скруглённые drawable
├── Models.kt                  ← data-классы + sealed InputEvent + wire-объекты
├── Prefs.kt                   ← обёртка SharedPreferences (сохранённые хосты + тумблер оверлея)
├── Discovery.kt               ← UDP-слушатель 8766 (StateFlow<List<DiscoveredHost>>)
├── ScreenClient.kt            ← OkHttp WebSocket-клиент (декодер кадров + JSON-ввод)
├── ScreenStreamService.kt     ← Foreground-сервис (wake lock + постоянное notification)
├── ScreenView.kt              ← Custom View: fit-center bitmap + мэппинг view→source + плашка «НЕТ СИГНАЛА»
├── TouchHandler.kt            ← тап / drag / long-press / 2-пальцевый скролл → InputEvent
├── KeyboardHelper.kt          ← TextWatcher мягкой клавиатуры + dispatchKey для хардверных клавиш
├── StatusOverlay.kt           ← изумрудный оверлей FPS/latency на ScreenView
├── ConnectActivity.kt         ← ввод host/port + выбор экрана + списки обнаруженных/сохранённых
└── MainActivity.kt            ← полноэкранный landscape-стрим
```

Если шаблон сгенерил `MainActivity.kt` — **удалите или перезапишите** его.

> **ВАЖНО: копируйте РОВНО все 13 файлов и ЗАМЕНЯЙТЕ ими старые.**
> В проекте не должны оставаться `.kt` из старых поставок:
> имена классов совпадают, но API разные — это главная причина ошибок
> `Unresolved reference: UiTheme / serverOverlay / setConnected` в
> Android Studio. Самый надёжный способ — удалить всё содержимое
> `app/src/main/java/com/example/hyprscreen/` и скопировать все 13 файлов
> из этой папки заново.

Все активности строят UI целиком в коде (`setContentView(buildUi())`),
так что шаблонный `activity_main.xml` можно оставить — он просто не
используется. В поставке **нет** `activity_connect.xml`, `host_row.xml`,
`strings.xml`, `themes.xml`, `ic_notification.xml` — приложение от них не
зависит.

## 4. AndroidManifest.xml

Добавьте следующие разрешения **до** тега `<application>`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC" />
<uses-permission android:name="android.permission.WAKE_LOCK" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

Внутри `<application>` добавьте атрибуты:

```xml
android:name=".HyprScreenApp"
android:usesCleartextTraffic="true"
android:theme="@style/Theme.Material3.DayNight.NoActionBar"
```

(`usesCleartextTraffic="true"` нужен, т.к. протокол WebSocket `ws://` — это
plain TCP в LAN; TLS в этой версии нет.)

Объявите две активности и сервис внутри `<application>`:

```xml
<activity
    android:name=".ConnectActivity"
    android:exported="true"
    android:configChanges="orientation|screenSize|keyboardHidden|keyboard"
    android:windowSoftInputMode="adjustResize">
    <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
    </intent-filter>
</activity>

<activity
    android:name=".MainActivity"
    android:exported="false"
    android:screenOrientation="landscape"
    android:configChanges="orientation|screenSize|keyboardHidden|keyboard|smallestScreenSize|screenLayout" />

<service
    android:name=".ScreenStreamService"
    android:exported="false"
    android:foregroundServiceType="dataSync" />
```

**Лаунчер-иконка:** используйте дефолтную (шаблон «Empty Views Activity» её
уже генерит). Кастомная иконка не поставляется. **Иконка notification:**
`ScreenStreamService` разрешает platform-иконку по имени в рантайме (сначала
пробует `stat_sys_data_bluetooth`, потом несколько fallback'ов), поэтому
app-drawable не нужен.

## 5. app/build.gradle.kts — зависимости

Шаблон уже даёт `core-ktx`, `appcompat`, `material`, `constraintlayout`.
Добавьте OkHttp, kotlinx-coroutines, kotlinx-serialization и lifecycle:

```kotlin
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "com.example.hyprscreen"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.hyprscreen"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.activity.ktx)
    implementation(libs.androidx.fragment.ktx)

    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")

    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
}
```

ViewBinding **не** нужен — активности строят UI в коде.

## 6. libs.versions.toml

Если предпочитаете version-catalog, добавьте в `[versions]`:

```toml
okhttp = "4.12.0"
coroutines = "1.8.1"
serialization = "1.6.3"
lifecycle = "2.8.4"
```

в `[libraries]`:

```toml
okhttp = { group = "com.squareup.okhttp3", name = "okhttp", version.ref = "okhttp" }
kotlinx-coroutines-android = { group = "org.jetbrains.kotlinx", name = "kotlinx-coroutines-android", version.ref = "coroutines" }
kotlinx-serialization-json = { group = "org.jetbrains.kotlinx", name = "kotlinx-serialization-json", version.ref = "serialization" }
androidx-lifecycle-runtime-ktx = { group = "androidx.lifecycle", name = "lifecycle-runtime-ktx", version.ref = "lifecycle" }
androidx-lifecycle-viewmodel-ktx = { group = "androidx.lifecycle", name = "lifecycle-viewmodel-ktx", version.ref = "lifecycle" }
androidx-lifecycle-service = { group = "androidx.lifecycle", name = "lifecycle-service", version.ref = "lifecycle" }
```

в `[plugins]`:

```toml
kotlin-serialization = { id = "org.jetbrains.kotlin.plugin.serialization", version.ref = "kotlin" }
```

## 7. Сборка и запуск

1. Sync Gradle.
2. Запустите на телефоне/планшете (USB-отладка) — либо на эмуляторе с
   LAN-маршрутом до PC.
3. Убедитесь, что PC-сторона запущена:
   - CachyOS + Hyprland, установлены `evdev` (pip), `wtype`.
   - `./run.sh` из корня Python-проекта (см. `pc/`).
4. На телефоне экран **Подключение** показывает:
   - Обнаруженные PC (через UDP-broadcast на 8766) — тап подключает.
   - Недавние хосты (сохраняются автоматически).
   - Или вручную введите LAN-IP PC и порт (по умолчанию `8765`), выберите
     экран (см. раздел 8) и нажмите **Подключиться**.
5. Экран переключается в полноэкранный landscape, появляется стрим рабочего
   стола. Тап = левый клик, долгое нажатие = правый клик, перетаскивание =
   движение мыши, двухпальцевое перетаскивание = скролл. Кнопка **Клавиатура**
   показывает мягкую клавиатуру, **Оверлей** переключает индикатор FPS/пинга,
   **Отключиться** закрывает сессию.

## 8. Выбор экрана (multi-screen)

Если PC отдаёт несколько экранов (поле `screens` в UDP-анонсе > 1),
`ConnectActivity` покажет горизонтальный ряд чипов «Экран 1» / «Экран 2» / …
по числу экранов. Тап по чипу выбирает индекс (внутреннее значение 0-based,
на кнопке — 1-based). Также доступно числовое поле «Индекс экрана» для
ручного ввода (на случай, если вы подключаетесь к PC без discovery и не
знаете заранее `screens`).

- При тапе по обнаруженному PC `host`/`port` подставляются автоматически, а
  чипы строятся по числу `screens` из анонса.
- При тапе по сохранённому хосту подставляются `host`/`port`/`screen` из
  истории (индекс последнего использованного экрана).
- Выбранный индекс прокидывается extras=`screen` в `ScreenStreamService`,
  тот формирует WebSocket URL `ws://<host>:<port>/<screen>`.
- После прихода hello MainActivity обновляет оверлей до «Экран N/M», где
  M = `total_screens` из hello. До прихода hello показывается «Экран N».

Если индекс вне диапазона 0..N-1, сервер закрывает соединение с кодом 1008
(policy violation) и текстом `unknown screen index` (PROTOCOL.md §2).
Android-клиент получит `State.Error` и покажет тост.

## 9. Заметки и решение проблем

- **Ориентация:** `MainActivity` зафиксирована в landscape в манифесте;
  `ConnectActivity` переживает смену ориентации через `configChanges`.
- **Keep-screen-on:** `MainActivity` выставляет `FLAG_KEEP_SCREEN_ON` во
  время стриминга.
- **Оптимизация батареи:** на Android 6+ foreground-сервис держит partial
  wake lock (без таймаута — исправление бага аудита #22), чтобы CPU не
  засыпал при выключенном экране. На некоторых OEM (Xiaomi, Huawei, …)
  всё равно может потребоваться ручное исключение приложения из «экономии
  заряда» / «автозапуска».
- **Уведомления (Android 13+):** `POST_NOTIFICATIONS` запрашивается в
  рантайме при первом открытии `ConnectActivity` (исправление бага аудита
  #27). Без разрешения notification foreground-сервиса невидим, но сам
  сервис работает.
- **Тип foreground-сервиса (Android 14+):** объявлен как `dataSync` —
  требует разрешение `FOREGROUND_SERVICE_DATA_SYNC` (шаг 4).
- **UDP discovery:** слушает порт `8766` для broadcast'ов
  `{"hyprscreen":true,"host":"<ip>","port":8765,"screens":N,"name":"<hostname>"}`
  от Python-сервера. Discovery стартует/останавливается вместе с жизненным
  циклом `ConnectActivity`. Сокет открывается с `reuseAddress=true`, чтобы
  быстрый перезапуск приложения не падал с `BindException` (исправление
  бага аудита #20).
- **Cleartext traffic:** включён, т.к. протокол стриминга — plain `ws://`
  (без TLS). Держите приложение в своей LAN.
- **Различение hello/error:** `ScreenClient.onMessage(text)` сначала читает
  только поле `type` через `WireEnvelope`. Если `type == "error"` →
  декодируется `ErrorMessage` и зовётся `FrameListener.onError`, hello НЕ
  трактуется. Если `type == "hello"` или отсутствует (обратная совместимость)
  → декодируется `HelloMessage`. Это исправляет критический баг аудита #7:
  раньше любое text-сообщение молча парсилось как hello.
- **Размер источника для касаний:** `ScreenView.setSourceSize` вызывается
  из `MainActivity.onHello` с `info.width`/`info.height` (взятых из hello —
  НЕ дефолт 1920×1080). Это исправляет критический баг аудита #1: при любом
  non-1080p разрешении инверсная матрица корректна.

### Возможные ошибки сборки

| Ошибка | Причина / решение |
|---|---|
| **Warnings в Models.kt: «This declaration is opt-in and its usage should be marked with `@kotlinx.serialization.InternalSerializationApi`»** (по одному на каждый `@Serializable`-класс) | Это ПРЕДУПРЕЖДЕНИЯ, а не ошибки — assembleDebug проходит. Возникают, когда IDE резолвит сериализацию через reflection-fallback: в проекте не применён/не совпадает плагин `kotlin-serialization` (шаг 5) или он новее/старее версии Kotlin. Здесь все явные вызовы `.serializer()` заменены на reified `json.encodeToString(...)` / `json.decodeFromString<T>(...)` (стабильный API) — предупреждения уходят. Дополнительно проверьте в `app/build.gradle(.kts)`: плагин `kotlin("plugin.serialization")` с ТОЙ ЖЕ версией, что и Kotlin, и зависимость `org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3+`. |
| **«Property name 'total_screens' should not contain underscores»** (Models.kt) | Свойство переименовано в `totalScreens`, wire-имя `total_screens` сохранено через `@SerialName`. Замените `Models.kt` и `ScreenClient.kt` файлами из этой папки. |
| **Typo: In word «HyprScreen» / «keysym»** | Не ошибка — проверка орфографии IDE. Во все затронутые файлы добавлено `@file:Suppress("SpellCheckingInspection")` — после замены файлов предупреждения исчезнут. |
| `Unresolved reference: isActive` (ScreenClient.kt, строка 160) | В проекте старый ScreenClient.kt. Замените его файлом из этой папки — там есть `import kotlinx.coroutines.isActive` (обращение `scope.isActive` — это extension-свойство корутин, без импорта оно не резолвится). |
| `Unresolved reference 'UiTheme'` (MainActivity, 6 мест) | В проекте нет `UiTheme.kt`. Скопируйте `UiTheme.kt` из этой папки в `app/src/main/java/com/example/hyprscreen/`. |
| `Unresolved reference 'serverOverlay'` (MainActivity, 2 места) | В проекте старый `Models.kt` без поля `serverOverlay`. Замените `Models.kt` файлом из этой папки. |
| `Unresolved reference 'setConnected'` (MainActivity, 3 места) | В проекте старый `ScreenView.kt` без метода `setConnected`. Замените `ScreenView.kt`. |
| Линт: `Custom view ScreenView has setOnTouchListener ... does not override performClick` | Замените `ScreenView.kt` — там есть `override fun performClick()`. Это предупреждение, не ошибка, но сборка с `-Werror`/play-публикация может падать. |
| Подсказка «Remove redundant qualifier name» | Замените `ScreenClient.kt` (там убран избыточный квалификатор `this@ScreenClient` в `isStale`). Это подсказка IDE, на сборку не влияет. |
| «Download grammar and spelling checker for Russian?» | Не ошибка: IDE предлагает установить проверку русской орфографии для комментариев. Можно нажать **Download** или **Skip / Don't show again** — на компиляцию не влияет. |
| `Unresolved reference: AppCompatActivity` | Шаблон не «Empty Views Activity». Добавьте `androidx.appcompat:appcompat`. |
| `Unresolved reference: kotlinx.serialization` | Примените плагин `kotlin-serialization` и добавьте `kotlinx-serialization-json` (шаг 5). |
| `Unresolved reference: okhttp3` | Добавьте зависимость OkHttp (шаг 5). |
| Много `Unresolved reference` сразу в MainActivity | В проекте смешаны файлы разных версий. Удалите ВСЕ .kt из `app/src/main/java/com/example/hyprscreen/` и скопируйте заново ровно 13 файлов из этой папки (см. предупреждение в шаге 3). |
| Crash on launch: «You need to use a Theme.AppCompat theme» | Тема приложения не Material3/AppCompat. В `themes.xml` выставьте родителем `Theme.Material3.DayNight.NoActionBar`. |
| `ForegroundServiceStartNotAllowedException` | Попытка старта сервиса из фона. `ConnectActivity` всегда стартует его с foreground (тап по «Подключиться»), так что этой ошибки быть не должно. |
| `cleartext traffic permitted` warning | Добавьте `android:usesCleartextTraffic="true"` (шаг 4). |
| Crash на Android 12+: «exported» | У `<activity>` для `ConnectActivity` должно быть `android:exported="true"`, т.к. у неё LAUNCHER intent-filter (шаг 4). |
| `BindException: Address already in use` на 8766 | Старая версия без `reuseAddress=true`. Перепроверьте, что `Discovery.kt` использует `DatagramSocket(null)` + `bind(InetSocketAddress(port))` + `reuseAddress = true`. |
