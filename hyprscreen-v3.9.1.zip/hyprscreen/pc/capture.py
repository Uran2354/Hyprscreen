"""Захват кадров для HyprScreen — grim с монитора закреплённого воркспейса.

Кадр — JPEG (`grim -o MONITOR -t jpeg -q Q [-s SCALE] -`).

ЗАКРЕПЛЁННЫЙ ВОРКСПЕЙС КАК ВИРТУАЛЬНЫЙ МОНИТОР (3.9.0, запрос «телефон
должен показывать выбранный воркспейс — это же монитор — и НЕ ЗАМИРАТЬ»):

  grim физически снимает ВЕСЬ выход, а Hyprland рендерит только активный
  воркспейс каждого выхода. Поэтому в 3.8.1 воркспейс «пинили» на
  физическом мониторе, а при переключении на ПК другой воркспейс поток
  ЗАМИРАЛ (пауза на последнем кадре) — grim не может снять невидимый
  воркспейс. Пользователю пауза не подошла.

  РЕШЕНИЕ — официальный рецепт Hyprland для стримов (VNC/RDP/Sunshine):
  `hyprctl output create headless` создаёт ВИРТУАЛЬНЫЙ монитор
  (HEADLESS-hyprscreen); закреплённый воркспейс переезжает на него
  (`moveworkspacetomonitor`) и рендерится там ВСЕГДА. grim снимает
  виртуальный монитор: телефон показывает закреплённый воркспейс ЖИВЬЁМ,
  а физические экраны ПК свободно переключаются (воркспейсы на ПК нас
  больше не касаются — общих воркспейсов у виртуального монитора нет).
  Пауз больше нет НИКАКИХ.

  Частота: без правила монитора Hyprland создаёт headless с
  частотой ~0.06 Гц — клиенты троттлят отрисовку до слайдшоу. Поэтому
  сразу после создания ставим `keyword monitor NAME,WxH@Hz,auto,SCALE`
  с параметрами физического монитора ПК.

  Восстановление (:meth:`WorkspaceWatch.teardown`): при остановке сервера
  воркспейс возвращается на исходный физический монитор, виртуальный
  монитор удаляется. Watch также чинит закрепление, если воркспейс кто-то
  утащил на физический экран, и пересоздаёт виртуальный монитор после
  перезапуска Hyprland.

  FALLBACK для старых Hyprland (нет `output create`, до ~0.41) — режим
  ``"pause"`` с поведением 3.8.1: активен → живые кадры; переключили на
  ПК другой воркспейс → пауза (копии последнего кадра ~1 кадр/с, ЧУЖОЙ
  экран не транслируется). Если hyprctl недоступен вовсе — обычное
  зеркало монитора (режим ``""``).

Модель данных: :class:`FrameStore` — потокобезопасное хранилище последнего
кадра с Condition; медленный клиент всегда получает СВЕЖИЙ кадр и не
накапливает отставание. Луп захвата (:func:`capture_loop`) живёт в отдельном
потоке и не спешит: если grim занял больше интервала — просто не спим.
"""

from __future__ import annotations

import logging
import shutil
import socket
import subprocess
import threading
import time

import hyprctl  # мониторы/воркспейсы + IPC-сокет .socket2.sock

log = logging.getLogger("hyprscreen.capture")

GRIM_TIMEOUT = 10.0

#: имя нашего виртуального монитора (начинается с HEADLESS- — чтобы
#: `hyprscreen cleanup` и headless_monitors() находили его и после сбоя)
HEADLESS_NAME = "HEADLESS-hyprscreen"


class FrameStore:
    """Последний кадр + счётчик + состояние захвата (thread-safe)."""

    def __init__(self) -> None:
        self._cond = threading.Condition()
        self._frame: bytes = b""
        self._seq: int = 0
        self._capture_ok: bool = True
        self._last_error: str = ""

    @property
    def seq(self) -> int:
        with self._cond:
            return self._seq

    @property
    def capture_ok(self) -> bool:
        with self._cond:
            return self._capture_ok

    @property
    def last_error(self) -> str:
        with self._cond:
            return self._last_error

    def publish(self, frame: bytes) -> None:
        with self._cond:
            self._frame = frame
            self._seq += 1
            self._capture_ok = True
            self._last_error = ""
            self._cond.notify_all()

    def fail(self, message: str) -> None:
        with self._cond:
            self._capture_ok = False
            self._last_error = message

    def wait_frame(self, last_seq: int, timeout: float) -> tuple[bytes, int]:
        """Дождаться кадра новее last_seq; вернуть (data, seq)."""
        with self._cond:
            if self._seq == last_seq:
                self._cond.wait(timeout=timeout)
            return self._frame, self._seq

    def snapshot(self) -> bytes:
        """Копия последнего кадра (для /info и превью GUI)."""
        with self._cond:
            return self._frame


class WorkspaceWatch:
    """Виртуальный монитор для закреплённого воркспейса (thread-safe).

    Режимы (:meth:`mode`):
      * ``"headless"`` — воркспейс живёт на виртуальном мониторе и
        рендерится ВСЕГДА: кадры живые в любой момент, переключения
        воркспейсов на ПК на поток не влияют (3.9.0);
      * ``"pause"`` — fallback для старых Hyprland: поведение 3.8.1
        (воркспейс активен на мониторе → живые кадры; переключили →
        пауза, в поток идут копии последнего кадра);
      * ``""`` — закрепление невозможно (hyprctl недоступен): обычное
        зеркало монитора.

    Источники информации о Hyprland:
      * поток-слушатель IPC-сокета ``.socket2.sock`` — события
        ``workspace>>``/``focusedmon>>``/``moveworkspace>>``/``monitoradded>>``
        будят мгновенную проверку (и мгновенный РЕМОНТ закрепления);
      * резервный опрос ``hyprctl -j monitors`` — раз в 2 с при живых
        событиях или раз в 0.5 с без них.
    """

    #: период плановой проверки при живых событиях и без них, сек
    POLL_WITH_EVENTS = 2.0
    POLL_NO_EVENTS = 0.5
    #: минимальная пауза между проверками (анти-шторм событий), сек
    POLL_MIN_GAP = 0.15
    #: тик потока-опросника, сек
    TICK = 0.25
    #: не чаще этого ремонт закрепления (не воевать с пользователем), сек
    REPAIR_COOLDOWN = 5.0
    #: сколько ждать появления созданного виртуального монитора, сек
    HEADLESS_WAIT = 2.0

    def __init__(self, monitor: str, workspace: int) -> None:
        self._monitor = (monitor or "").strip()  # физический монитор ПК
        self._lock = threading.Lock()
        self._pinned = max(0, int(workspace or 0))
        self._mode = ""               # "headless" | "pause" | ""
        self._headless = ""           # имя виртуального монитора
        self._headless_created = False
        self._orig_monitor = ""       # где воркспейс жил ДО закрепления
        self._live = False            # headless: воркспейс активен на нём
        self._active_ws = 0           # активный ws монитора захвата (статус)
        self._checked = False         # первая проверка выполнена
        self._available = False       # hyprctl отвечает
        self._events_ok = False       # socket2 подключён
        self._poll_requested = threading.Event()
        self._last_repair = 0.0
        self._started = False
        self._torn_down = False
        self.stop: threading.Event | None = None

    # ------------------------------------------------------------ состояние
    @property
    def enabled(self) -> bool:
        """Закрепление включено (воркспейс > 0)."""
        return self._pinned_ws() > 0

    def _pinned_ws(self) -> int:
        with self._lock:
            return self._pinned

    def workspace(self) -> int:
        """Закреплённый номер воркспейса (0 = режим «весь монитор»)."""
        return self._pinned_ws()

    def mode(self) -> str:
        """Текущий режим закрепления: 'headless' | 'pause' | ''."""
        with self._lock:
            return self._mode

    def headless_name(self) -> str:
        """Имя виртуального монитора ('' — нет/не создан)."""
        with self._lock:
            return self._headless

    def capture_output(self) -> str:
        """Что снимать grim-ом: виртуальный монитор или физический."""
        with self._lock:
            if self._mode == "headless" and self._headless:
                return self._headless
        return self._monitor

    def pinned_active(self) -> bool:
        """True — можно снимать: закреплённый воркспейс доступен и ЖИВОЙ.

        headless-режим: воркспейс активен на виртуальном мониторе.
        pause-режим: воркспейс активен на физическом мониторе.
        Режим «зеркало»: всегда True.
        """
        with self._lock:
            if self._pinned <= 0:
                return True          # режим «весь монитор»
            if not self._checked:
                return False         # ещё не проверяли — НЕ рискуем чужим кадром
            if self._mode == "headless":
                return self._live
            if not self._available:
                return True          # hyprctl недоступен — обычное зеркало
            return self._active_ws == self._pinned

    def active_workspace(self) -> int:
        """Последний известный активный воркспейс монитора захвата."""
        with self._lock:
            return self._active_ws

    def set_workspace(self, ws: int) -> tuple[bool, str]:
        """Живая смена закрепления (GUI/POST /workspace) без перезапуска.

        Старый воркспейс возвращается на своё место, новый переезжает на
        виртуальный монитор. ws = 0 снимает закрепление (и убирает
        виртуальный монитор).
        """
        ws = max(0, min(99, int(ws or 0)))
        with self._lock:
            old = self._pinned
            self._pinned = ws
        self.request_poll()
        if ws == 0:
            # важно: вернуть СТАРЫЙ воркспейс (self._pinned уже 0)
            self.teardown(ws_from=old or None)
            return True, "закрепление снято — режим «весь монитор»"
        if ws == old:
            return True, f"воркспейс №{ws} уже закреплён"
        if self.mode() == "headless":
            self._restore_pinned(ws_from=old)
            with self._lock:
                self._orig_monitor = ""
            ok, msg = self._pin(ws)
            self.request_poll()
            return ok, (msg or f"воркспейс №{ws} закреплён")
        if self.mode() == "pause":
            ok, msg = hyprctl.switch_workspace(
                ws, self._monitor or hyprctl.focused_monitor())
            return ok, msg or f"воркспейс №{ws} открыт на мониторе"
        # режим "" (hyprctl не отвечал при старте) — попробуем закрепить заново
        ok, msg = self.setup()
        if ok:
            return True, msg or f"воркспейс №{ws} закреплён"
        return True, (f"воркспейс №{ws} выбран (закрепление недоступно: {msg})")

    # ------------------------------------------------------------- установка
    def setup(self) -> tuple[bool, str]:
        """Установить закрепление (однократно, до старта захвата).

        1. Создать/найти виртуальный монитор и задать ему режим
           (частота/разрешение физического монитора — иначе ~0.06 Гц).
        2. Перегнать закреплённый воркспейс на виртуальный монитор.
        3. Вернуть фокус/экран пользователя как были.

        При неудаче — FALLBACK в режим 3.8.1 (пауза), трансляция всё равно
        начинается. Возвращает (успех, человекочитаемое сообщение).
        """
        ws = self._pinned_ws()
        if ws <= 0:
            self._mode = ""
            return True, ""
        hyprctl.fix_env()
        if not hyprctl.have("hyprctl"):
            self._mode = ""
            return True, "hyprctl недоступен — режим «весь монитор»"
        ok, headless, msg = self._ensure_headless()
        if ok:
            ok2, msg2 = self._pin(ws)
            if ok2:
                with self._lock:
                    self._mode = "headless"
                self.request_poll()
                return True, msg2
            log.warning("headless создан, но закрепить не удалось: %s", msg2)
            # не оставляем созданный пустой виртуальный монитор
            hyprctl.remove_output(headless)
            with self._lock:
                self._headless = ""
                self._headless_created = False
            msg = f"{msg}; {msg2}"
        # FALLBACK: старые Hyprland без `output create` → поведение 3.8.1
        with self._lock:
            self._mode = "pause"
        phys = self._phys_anchor()
        if not phys:
            return False, (f"виртуальный монитор недоступен ({msg}) и "
                           "физические мониторы не найдены")
        ok3, msg3 = hyprctl.switch_workspace(ws, phys)
        base = f"виртуальный монитор недоступен ({msg}) — режим 3.8.1"
        if ok3:
            return True, f"{base}: {msg3}" if msg3 else base
        return False, f"{base}; {msg3}"

    def _phys_anchor(self) -> str:
        """Физический монитор-якорь (фокус/создание воркспейса)."""
        for name in (self._monitor, hyprctl.focused_monitor(),
                     *(hyprctl.physical_monitors()[:1])):
            name = (name or "").strip()
            if name and not name.startswith("HEADLESS-"):
                return name
        return ""

    def _ensure_headless(self) -> tuple[bool, str, str]:
        """Найти или создать виртуальный монитор; вернуть (ok, имя, ошибка)."""
        names = hyprctl.monitor_names()
        if HEADLESS_NAME in names:
            # наш по построению (в т.ч. остаток после сбоя/kill -9) — reused
            with self._lock:
                self._headless = HEADLESS_NAME
                self._headless_created = True
            self._apply_headless_mode(HEADLESS_NAME)
            return True, HEADLESS_NAME, ""
        ok, err = hyprctl.create_headless(HEADLESS_NAME)
        if ok and self._wait_monitor(HEADLESS_NAME):
            with self._lock:
                self._headless = HEADLESS_NAME
                self._headless_created = True
            self._apply_headless_mode(HEADLESS_NAME)
            return True, HEADLESS_NAME, ""
        if not ok:
            log.warning("output create headless не сработал (%s) — "
                        "пробуем без имени", err)
        # Fallback: имя не принято (или create упал по иной причине) —
        # создаём без имени и находим новый HEADLESS-* по разнице списков.
        before = set(hyprctl.monitor_names())
        ok2, err2 = hyprctl.create_headless("")
        if ok2:
            deadline = time.monotonic() + self.HEADLESS_WAIT
            while time.monotonic() < deadline:
                created = [n for n in hyprctl.monitor_names()
                           if n not in before and n.startswith("HEADLESS-")]
                if created:
                    with self._lock:
                        self._headless = created[0]
                        self._headless_created = True
                    self._apply_headless_mode(created[0])
                    return True, created[0], ""
                time.sleep(0.1)
        return False, "", err or err2 or "виртуальный монитор не появился"

    def _wait_monitor(self, name: str) -> bool:
        """Дождаться появления монитора name в `hyprctl monitors`."""
        deadline = time.monotonic() + self.HEADLESS_WAIT
        while time.monotonic() < deadline:
            if name in hyprctl.monitor_names():
                return True
            time.sleep(0.1)
        return False

    def _apply_headless_mode(self, name: str) -> None:
        """Частота/разрешение как у физического монитора (иначе ~0.06 Гц:
        клиенты троттлят отрисовку — видео на телефоне = слайдшоу)."""
        phys = self._phys_anchor()
        if phys:
            w, h, hz, scale = hyprctl.monitor_size(phys)
        else:
            w, h, hz, scale = 1920, 1080, 60, 1.0
        hz = max(24, min(hz if hz else 60, 120))
        if not hyprctl.keyword_monitor(name, f"{w}x{h}@{hz}", "auto", scale):
            log.warning("не удалось задать режим виртуальному монитору "
                        "%s (%dx%d@%d) — оставлен дефолтный", name, w, h, hz)

    def _pin(self, ws: int) -> tuple[bool, str]:
        """Перегнать воркспейс ws на виртуальный монитор и активировать там.

        Порядок важен (исходники Hyprland): воркспейс становится активным
        на новом мониторе только если был активен на старом, поэтому
        сначала активируем его (создаём при необходимости), потом
        moveworkspacetomonitor, потом возвращаем пользователю его
        предыдущий воркспейс и фокус.
        """
        headless = self._headless_name_for_pin()
        if not headless:
            return False, "виртуальный монитор не создан"
        phys = self._phys_anchor()
        if not phys:
            return False, "физические мониторы не найдены"
        active = hyprctl.monitor_active_workspaces()
        if active.get(headless, 0) == ws:
            with self._lock:
                if not self._orig_monitor:
                    self._orig_monitor = phys
                self._live = True
                self._checked = True
                self._available = True
                self._active_ws = ws
            return True, (f"воркспейс №{ws} уже на виртуальном мониторе "
                          f"{headless}")
        ws_mon = hyprctl.workspace_monitor(ws)
        with self._lock:
            if ws_mon and ws_mon != headless and not self._orig_monitor:
                self._orig_monitor = ws_mon
        prev_user_ws = 0
        if ws_mon != headless:
            # что смотрит пользователь — вернём после переезда
            prev_user_ws = active.get(phys, 0)
            if ws_mon is None:
                # воркспейса нет — создаём на физическом мониторе;
                # он наш «исходный» для будущего восстановления
                with self._lock:
                    if not self._orig_monitor:
                        self._orig_monitor = phys
                hyprctl.focus_monitor(phys)
                hyprctl.dispatch_workspace(ws)
            elif active.get(ws_mon, 0) != ws:
                hyprctl.dispatch_workspace(ws)   # активировать на его мониторе
        # переезд на виртуальный монитор
        ok, merr = hyprctl.move_workspace_to_monitor(ws, headless)
        if not ok:
            return False, f"moveworkspacetomonitor: {merr}"
        if hyprctl.monitor_active_workspaces().get(headless, 0) != ws:
            hyprctl.dispatch_workspace(ws)       # активировать на headless
        if hyprctl.monitor_active_workspaces().get(headless, 0) != ws:
            return False, "воркспейс не стал активным на виртуальном мониторе"
        # вернуть пользователю его экран и фокус (фокус мог уйти на
        # виртуальный монитор при активации — Hyprland даёт фокус
        # новому активному воркспейсу)
        if prev_user_ws and prev_user_ws != ws \
                and hyprctl.workspace_monitor(prev_user_ws) == phys:
            hyprctl.dispatch_workspace(prev_user_ws)
        if hyprctl.focused_monitor() not in ("", phys):
            hyprctl.focus_monitor(phys)
        with self._lock:
            self._live = True
            self._checked = True
            self._available = True
            self._active_ws = ws
        return True, (f"воркспейс №{ws} закреплён на виртуальном мониторе "
                      f"{headless} — экраны ПК свободны, кадры живые")

    def _headless_name_for_pin(self) -> str:
        with self._lock:
            return self._headless

    # ------------------------------------------------------------ восстановл.
    def _restore_pinned(self, ws_from: int | None = None) -> None:
        """Вернуть закреплённый воркспейс на исходный физический монитор.

        БЕЗ активации (пользователю не нужно внезапное переключение
        экрана): если воркспейс был активен на headless, переезд молча
        помещает его на исходный монитор неактивным.
        """
        ws = int(ws_from or self._pinned_ws())
        if ws <= 0:
            return
        with self._lock:
            orig = self._orig_monitor
            headless = self._headless
        names = hyprctl.physical_monitors()
        target = orig if orig in names else (names[0] if names else "")
        if target and target != headless:
            ok, err = hyprctl.move_workspace_to_monitor(ws, target)
            if not ok:
                log.warning("не удалось вернуть воркспейс №%d на %s: %s",
                            ws, target, err)
            else:
                log.info("воркспейс №%d возвращён на %s", ws, target)

    def teardown(self, ws_from: int | None = None) -> None:
        """Полностью убрать закрепление (остановка сервера / ws=0).

        Воркспейс возвращается на исходный монитор, виртуальный монитор
        удаляется. Идемпотентно; безопасен при уже удалённом headless.
        """
        with self._lock:
            mode = self._mode
            headless = self._headless
            created = self._headless_created
            self._mode = ""
            self._live = False
        if mode != "headless":
            with self._lock:
                self._headless = ""
            return
        self._restore_pinned(ws_from=ws_from)
        if headless and created:
            if hyprctl.remove_output(headless):
                log.info("виртуальный монитор %s удалён", headless)
            else:
                log.warning("не удалось удалить виртуальный монитор %s "
                            "(hyprctl output remove)", headless)
        with self._lock:
            self._headless = ""
            self._headless_created = False
            self._orig_monitor = ""

    # -------------------------------------------------------------- механика
    def request_poll(self) -> None:
        """Попросить внеплановую проверку (событие сокета / смена закрепл.)."""
        self._poll_requested.set()

    def wait_checked(self, timeout: float = 2.5) -> None:
        """Дождаться первой проверки (чтобы не отправить чужой кадр)."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with self._lock:
                if self._checked:
                    return
            time.sleep(0.05)

    def poll_once(self) -> None:
        """Одна проверка Hyprland (+ ремонт закрепления при необходимости)."""
        try:
            if self._pinned_ws() <= 0:
                with self._lock:
                    self._checked = True
                    self._available = True
                    self._live = True
                return
            if self.mode() == "headless":
                self._verify_headless()
            else:
                self._poll_pause_mode()
        except Exception:  # noqa: BLE001 — сломанный hyprctl не роняет луп
            log.exception("ошибка проверки закрепления")
            with self._lock:
                self._checked = True

    def _poll_pause_mode(self) -> None:
        """Проверка для fallback-режима 3.8.1 (воркспейс на физ. мониторе)."""
        try:
            ws_now = hyprctl.monitor_active_workspace(self._monitor)
        except Exception:  # noqa: BLE001
            ws_now = 0
        with self._lock:
            self._checked = True
            if ws_now > 0:
                self._active_ws = ws_now
                self._available = True
            else:
                # hyprctl нет/не отвечает — закрепление не проверить:
                # не морозим поток (иначе телефон навсегда «зависнет»)
                self._available = False

    def _verify_headless(self) -> None:
        """Проверить закрепление на виртуальном мониторе и починить.

        Два случая ремонта:
          * воркспейс утащили на физический монитор (bindings/действие
            пользователя) — возвращаем на виртуальный;
          * виртуальный монитор исчез (перезапуск Hyprland) — создаём
            заново и закрепляем повторно.
        """
        ws = self._pinned_ws()
        active = hyprctl.monitor_active_workspaces()
        headless = self._headless_name_for_pin()
        if headless and headless not in active:
            log.warning("виртуальный монитор %s исчез (Hyprland "
                        "перезапущен?) — пересоздаю", headless)
            with self._lock:
                self._headless = ""
                self._headless_created = False
                self._live = False
            ok, headless_new, _msg = self._ensure_headless()
            if ok:
                headless = headless_new
                self._pin(ws)
                active = hyprctl.monitor_active_workspaces()
            else:
                headless = ""
        live = bool(headless) and active.get(headless, 0) == ws
        if not live and headless \
                and time.monotonic() - self._last_repair >= self.REPAIR_COOLDOWN:
            self._last_repair = time.monotonic()
            log.info("воркспейс №%d не на виртуальном мониторе %s — "
                     "возвращаю (закрепление)", ws, headless)
            ok, _msg = self._pin(ws)
            if ok:
                live = hyprctl.monitor_active_workspaces().get(headless, 0) == ws
        with self._lock:
            self._checked = True
            self._available = True
            self._live = live
            self._active_ws = ws if live else active.get(headless, 0)

    def start(self, stop: threading.Event) -> None:
        """Запустить поток-опросник и поток-слушатель событий (идемпотентно)."""
        if self._started:
            return
        self._started = True
        self.stop = stop
        threading.Thread(target=self._poll_loop, daemon=True,
                         name="hyprscreen-ws-poll").start()
        threading.Thread(target=self._event_loop, daemon=True,
                         name="hyprscreen-ws-events").start()

    def _poll_loop(self) -> None:
        self.poll_once()
        last = time.monotonic()
        stop = self.stop
        assert stop is not None
        while not stop.is_set():
            requested = self._poll_requested.is_set()
            if requested:
                self._poll_requested.clear()
            now = time.monotonic()
            planned = self.POLL_WITH_EVENTS if self._events_ok else self.POLL_NO_EVENTS
            if (requested and now - last >= self.POLL_MIN_GAP) \
                    or now - last >= planned:
                self.poll_once()
                last = time.monotonic()
            stop.wait(self.TICK)

    def _event_loop(self) -> None:
        """Слушать события Hyprland (.socket2.sock) и будить проверку.

        Данные события не разбираем: имя события — триггер, источником
        истины остаётся ``hyprctl -j monitors`` (проверка мгновенная).
        """
        stop = self.stop
        assert stop is not None
        path = hyprctl.socket2_path()
        if not path:
            return                      # без сокета остаётся опрос 0.5 с
        while not stop.is_set():
            sock: socket.socket | None = None
            try:
                sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                sock.settimeout(2.0)
                sock.connect(path)
                self._events_ok = True
                buf = b""
                while not stop.is_set():
                    chunk = sock.recv(4096)
                    if not chunk:
                        break           # Hyprland закрыл сокет — переподключение
                    buf += chunk
                    while b"\n" in buf:
                        line, buf = buf.split(b"\n", 1)
                        name = line.split(b">>", 1)[0].decode("utf-8", "replace")
                        if name in ("workspace", "workspacev2", "focusedmon",
                                    "moveworkspace", "moveworkspacev2",
                                    "monitoradded", "monitorremoved",
                                    "configreloaded"):
                            self.request_poll()
            except OSError:
                pass
            finally:
                if sock is not None:
                    try:
                        sock.close()
                    except OSError:
                        pass
            self._events_ok = False
            stop.wait(2.0)              # Hyprland перезапустился — попробуем снова


def build_grim_cmd(output: str, quality: int, scale: float) -> list[str]:
    cmd = ["grim", "-o", output, "-t", "jpeg", "-q", str(quality)]
    if scale and abs(scale - 1.0) > 1e-6:
        cmd += ["-s", str(scale)]
    cmd += ["-"]
    return cmd


def capture_one(output: str, quality: int = 1, scale: float = 1.0,
                timeout: float = GRIM_TIMEOUT) -> tuple[bytes, str]:
    """Один кадр (для grimtest/превью GUI): (jpeg_bytes, ошибка|'')."""
    grim = shutil.which("grim")
    if not grim:
        return b"", "grim не найден (pacman -S grim)"
    try:
        proc = subprocess.run(
            build_grim_cmd(output, quality, scale),
            capture_output=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return b"", f"grim timeout ({int(timeout)}с)"
    except OSError as exc:
        return b"", str(exc)
    if proc.returncode == 0 and proc.stdout:
        return proc.stdout, ""
    err = proc.stderr.decode("utf-8", "replace").strip()
    return b"", err or f"grim exit {proc.returncode}"


def capture_loop(
    store: FrameStore,
    output: str,
    fps: int,
    quality: int,
    scale: float,
    stop: threading.Event,
    has_clients=None,
    watch: WorkspaceWatch | None = None,
    watch_getter=None,
) -> None:
    """Цикл захвата: grim -> FrameStore с частотой ~fps.

    has_clients — колбэк без аргументов (True, если есть зрители). Когда
    зрителей нет, луп замедляется до ~2 кадров/с (экономия CPU и Wi-Fi,
    как в 2.2.0: «неизменные кадры не отправляются»); после подключения
    клиента скорость возвращается к цели автоматически.

    watch — закрепление воркспейса (:class:`WorkspaceWatch`):
      * режим headless: снимаем ВИРТУАЛЬНЫЙ монитор — закреплённый
        воркспейс рендерится всегда, кадры живые, пауз нет (3.9.0);
      * fallback-режим 3.8.1: пока закреплённый воркспейс активен на
        мониторе — кадры живые; при переключении на ПК другого воркспейса
        луп ПАУЗИТСЯ — в поток уходят копии последнего кадра (~1 кадр/с),
        чужой экран не снимается.

    watch_getter — колбэк, возвращающий АКТУАЛЬНЫЙ watch: живая смена
    закрепления/повторное закрепление через POST /workspace может
    подменить объект (старый teardown → новый setup) — луп обязан каждый
    кадр брать текущий, иначе после подмены снимал бы не тот монитор.
    """
    grim = shutil.which("grim")
    if not grim:
        store.fail("grim не найден (pacman -S grim)")
        log.error("grim не найден — захват невозможен")
        return
    interval = 1.0 / max(1, fps)
    fails = 0

    def current_watch() -> WorkspaceWatch | None:
        if watch_getter is not None:
            try:
                return watch_getter()
            except Exception:  # noqa: BLE001
                return watch
        return watch

    w0 = current_watch()
    if w0 is not None and w0.enabled:
        # Ни ОДНОГО кадра, пока не подтвердим закреплённый воркспейс:
        # сервер мог не успеть/не смочь подготовить виртуальный монитор —
        # и первым кадром в телефон улетел бы ЧУЖОЙ воркспейс.
        w0.wait_checked(timeout=2.5)
        if not w0.pinned_active():
            if w0.mode() == "pause":
                log.warning(
                    "закреплённый воркспейс №%d не активен на %s — трансляция "
                    "на паузе (кадр не обновляется, чужой экран не "
                    "показывается)", w0.workspace(), output,
                )
            else:
                log.warning(
                    "закреплённый воркспейс №%d ещё не подтвержден — первые "
                    "кадры подождут проверки (чужой экран не транслируется)",
                    w0.workspace(),
                )
    while not stop.is_set():
        t0 = time.monotonic()
        watch = current_watch()
        out = watch.capture_output() if watch is not None else output
        if watch is not None and watch.mode() == "pause" \
                and not watch.pinned_active():
            # ПАУЗА (fallback 3.8.1): ПК показывает другой воркспейс.
            # Новый захват НЕ делаем (чужой экран не должен попасть в
            # поток), но соединение держим: повторно отправляем кадр.
            frozen = store.snapshot()
            if frozen:
                store.publish(frozen)
            stop.wait(1.0)
            continue
        data, err = capture_one(out, quality, scale)
        if data and watch is not None and watch.enabled \
                and not watch.pinned_active():
            # Закрепление переходно (ремонт/проверка) — кадр подозрителен:
            # не публикуем, следующий тик повторит проверку.
            continue
        if data:
            store.publish(data)
            fails = 0
        else:
            fails += 1
            store.fail(err)
            if fails == 1 or fails % 10 == 0:
                log.warning("grim failed (#%d): %s", fails, err)
            stop.wait(1.0)
            continue
        dt = time.monotonic() - t0
        if not stop.is_set():
            pause = max(0.0, interval - dt)
            if has_clients is not None and not has_clients():
                pause = max(pause, 0.5)  # ~2 кадра/с без зрителей
            stop.wait(pause)
    log.info("цикл захвата остановлен")
