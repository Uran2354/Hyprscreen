"""Асинхронный WebSocket-стриминг-сервер HyprScreen (мультиэкранный).

Слушает ``<bind_address>:<port>``, принимает соединения от Android-телефонов,
броадкастит захваченные JPEG-кадры как бинарные сообщения и направляет
входящие JSON text-сообщения в :class:`InputInjector`.

Мультиэкранность
----------------
Сервер держит список :class:`StreamScreen` — по одному на виртуальный вывод.
URL-путь выбирает экран: ``ws://<host>:<port>/<index>`` (0-based). Пустой
путь и ``/`` трактуются как экран 0. Путь вне диапазона → соединение
закрывается с кодом 1008 и текстом ``unknown screen index``.

Каждый :class:`StreamScreen` имеет:

* свой ``index`` и ``output_name``;
* ``x_offset`` в глобальных координатах Hyprland-стола;
* ссылку на свой :class:`ScreenConfig`;
* собственный :class:`InputInjector` (привязан к x_offset этого экрана);
* собственные ``_clients`` / ``_queues`` словари;
* собственную capture-задачу (засыпает при нуле клиентов, просыпается
  при появлении первого).

Жизненный цикл
--------------
1. ``HyprScreenServer.start()`` — открывает WebSocket-сервер.
2. Для каждого нового клиента: парсится путь, выбирается экран, экран
   отправляет JSON ``hello`` с полями ``width``/``height`` (НЕ
   ``resolution``), ``screen``, ``total_screens``, ``fps`` и т.д.
3. Capture-loop экрана читает кадры из бэкенда и кладёт их в
   :class:`asyncio.Queue` каждого клиента. Медленные клиенты теряют
   устаревшие кадры, чтобы один телефон на плохой сети не тормозил остальных.
4. Каждое соединение имеет reader-задачу (диспетчер ввода в InputInjector)
   и writer-задачу (отправка кадров).
5. На shutdown (SIGINT/SIGTERM) все задачи отменяются, сервер закрывается,
   UDP discovery останавливается. ``asyncio.CancelledError`` пробрасывается
   (не глотается).
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Optional

from capture import CaptureBackend, make_backend
from config import Config, ScreenConfig, __version__
from discovery import DiscoveryBroadcaster
from input import InputInjector, InputError

log = logging.getLogger(__name__)


@dataclass
class ClientStats:
    """Статистика по одному клиенту."""

    address: tuple[str, int]
    connected_at: float = field(default_factory=time.monotonic)
    frames_sent: int = 0
    frames_dropped: int = 0
    bytes_sent: int = 0
    bytes_received: int = 0
    last_frame_at: float = 0.0
    last_latency_estimate: float = 0.0

    @property
    def uptime(self) -> float:
        return time.monotonic() - self.connected_at

    @property
    def fps(self) -> float:
        if self.frames_sent < 2:
            return 0.0
        elapsed = self.last_frame_at - self.connected_at
        if elapsed <= 0:
            return 0.0
        return self.frames_sent / elapsed

    def snapshot(self) -> dict[str, Any]:
        return {
            "address": f"{self.address[0]}:{self.address[1]}",
            "uptime_s": round(self.uptime, 1),
            "frames_sent": self.frames_sent,
            "frames_dropped": self.frames_dropped,
            "bytes_sent": self.bytes_sent,
            "bytes_received": self.bytes_received,
            "fps": round(self.fps, 2),
            "latency_ms_estimate": round(self.last_latency_estimate * 1000, 1),
        }


class StreamScreen:
    """Один стримуемый экран: связка виртуального вывода, capture-loop и клиентов.

    Каждый :class:`StreamScreen` самостоятелен: свои очереди, свои задачи,
    свой InputInjector. Несколько экранов работают параллельно, не мешая
    друг другу.
    """

    def __init__(
        self,
        index: int,
        output_name: str,
        x_offset: int,
        screen_cfg: ScreenConfig,
        total_screens: int,
        ws_module: Any,
    ) -> None:
        self.index = index
        self.output_name = output_name
        self.x_offset = x_offset
        self.config = screen_cfg
        self.total_screens = total_screens
        self._ws_module = ws_module
        self.injector = InputInjector(screen_cfg, x_offset)
        self._clients: dict[Any, ClientStats] = {}
        self._queues: dict[Any, asyncio.Queue[bytes]] = {}
        self._capture_task: Optional[asyncio.Task[None]] = None
        self._backend: Optional[CaptureBackend] = None
        self._stop_event = asyncio.Event()
        # Событие, сигнализирующее о появлении первого клиента — будит
        # capture-loop, если он ждёт в режиме «нет клиентов».
        self._client_added = asyncio.Event()

    # -- запуск / остановка capture-loop --------------------------------

    async def start_capture(self) -> None:
        """Создать бэкенд и запустить capture-loop."""
        self._backend = make_backend(self.config, self.output_name)
        log.info(
            "экран %d: capture-бэкенд %s (вывод=%s, %dx%d, fps=%d)",
            self.index, self._backend.__class__.__name__, self.output_name,
            self.config.width, self.config.height, self.config.fps,
        )
        self._capture_task = asyncio.create_task(
            self._capture_loop(), name=f"capture-screen-{self.index}"
        )

    async def stop_capture(self) -> None:
        """Остановить capture-loop и закрыть бэкенд."""
        self._stop_event.set()
        self._client_added.set()  # разбудить, если ждёт
        if self._capture_task is not None:
            self._capture_task.cancel()
            try:
                await self._capture_task
            except asyncio.CancelledError:
                pass
            except Exception as exc:  # noqa: BLE001
                log.warning("ошибка при остановке capture-loop экрана %d: %s", self.index, exc)
            self._capture_task = None
        if self._backend is not None:
            try:
                await self._backend.close()
            except Exception as exc:  # noqa: BLE001
                log.warning("ошибка закрытия бэкенда экрана %d: %s", self.index, exc)
            self._backend = None

    async def _capture_loop(self) -> None:
        """Цикл захвата: ждёт клиентов, затем гоняет frames()."""
        backend = self._backend
        if backend is None:
            return
        try:
            while not self._stop_event.is_set():
                # Если клиентов нет — спим, не дёргаем grim. Это экономия CPU.
                if not self._queues:
                    self._client_added.clear()
                    # Ждём либо появления клиента, либо остановки.
                    wait_stop = asyncio.create_task(self._stop_event.wait())
                    wait_client = asyncio.create_task(self._client_added.wait())
                    try:
                        done, pending = await asyncio.wait(
                            {wait_stop, wait_client},
                            return_when=asyncio.FIRST_COMPLETED,
                        )
                    finally:
                        for t in (wait_stop, wait_client):
                            if not t.done():
                                t.cancel()
                                try:
                                    await t
                                except asyncio.CancelledError:
                                    pass
                    if self._stop_event.is_set():
                        return
                    if not self._queues:
                        # Событие сработало, но клиентов всё ещё нет —
                        # цикл повторится.
                        continue
                    log.info("экран %d: появился клиент, запускаем захват", self.index)
                # Есть клиенты — крутим frames().
                async for frame in backend.frames():
                    if self._stop_event.is_set():
                        break
                    if not frame:
                        continue
                    if not self._queues:
                        # Все клиенты ушли прямо во время итерации — выходим
                        # из for и снова засыпаем в верхней части while.
                        break
                    # Кладём кадр в каждую клиентскую очередь, отбрасывая
                    # устаревшие, если очередь переполнена.
                    for ws, q in list(self._queues.items()):
                        if q.full():
                            try:
                                q.get_nowait()
                                stats = self._clients.get(ws)
                                if stats is not None:
                                    stats.frames_dropped += 1
                            except asyncio.QueueEmpty:
                                pass
                        try:
                            q.put_nowait(frame)
                        except asyncio.QueueFull:
                            stats = self._clients.get(ws)
                            if stats is not None:
                                stats.frames_dropped += 1
        except asyncio.CancelledError:
            log.info("экран %d: capture-loop отменён", self.index)
            raise
        except Exception as exc:  # noqa: BLE001
            log.exception("экран %d: capture-loop упал: %s", self.index, exc)

    # -- обработка соединения -------------------------------------------

    async def handle(self, ws: Any) -> None:
        """Обработать одно соединение, привязанное к этому экрану."""
        peer = ws.remote_address if hasattr(ws, "remote_address") else ("?", 0)

        # --- AUTH: если задан auth_token, ждём {"type":"auth","token":"..."} ---
        auth_token = getattr(self._server_ref, '_auth_token', None) if hasattr(self, '_server_ref') else None
        if auth_token:
            try:
                first_msg = await asyncio.wait_for(ws.recv(), timeout=10.0)
                import json as _json
                msg = _json.loads(first_msg)
                if msg.get("type") != "auth" or msg.get("token") != auth_token:
                    log.warning("экран %d: auth failed для %s", self.index, peer)
                    await ws.close(code=1008, reason="auth required")
                    return
                log.info("экран %d: auth OK для %s", self.index, peer)
            except asyncio.TimeoutError:
                log.warning("экран %d: auth timeout для %s", self.index, peer)
                await ws.close(code=1008, reason="auth timeout")
                return
            except Exception as exc:
                log.warning("экран %d: auth error для %s: %s", self.index, peer, exc)
                await ws.close(code=1008, reason="auth error")
                return

        stats = ClientStats(address=peer)
        queue: asyncio.Queue[bytes] = asyncio.Queue(maxsize=4)
        self._clients[ws] = stats
        self._queues[ws] = queue
        # Разбудить capture-loop, если он ждал первого клиента.
        self._client_added.set()
        log.info(
            "экран %d: клиент подключён %s (всего=%d)",
            self.index, peer, len(self._clients),
        )

        # hello-сообщение: ИМЕННО width/height, НЕ resolution (фикс протокола).
        hello = {
            "type": "hello",
            "server": "hyprscreen",
            "version": __version__,
            "width": self.config.width,
            "height": self.config.height,
            "fps": self.config.fps,
            "jpeg_quality": self.config.jpeg_quality,
            "image_format": self.config.image_format,
            "capture_backend": self.config.capture_backend,
            "screen": self.index,
            "total_screens": self.total_screens,
            "output": self.output_name,
            "server_time": time.time(),
        }
        try:
            await ws.send(json.dumps(hello))
        except Exception as exc:  # noqa: BLE001
            log.warning("не удалось отправить hello экрану %d клиенту %s: %s",
                        self.index, peer, exc)

        writer = asyncio.create_task(self._writer_loop(ws, queue, stats))
        reader = asyncio.create_task(self._reader_loop(ws, stats))
        try:
            await asyncio.gather(writer, reader)
        except asyncio.CancelledError:
            raise
        finally:
            writer.cancel()
            reader.cancel()
            for t in (writer, reader):
                try:
                    await t
                except asyncio.CancelledError:
                    pass
                except Exception as exc:  # noqa: BLE001
                    log.warning("ошибка при ожидании задачи клиента %s: %s", peer, exc)
            self._clients.pop(ws, None)
            self._queues.pop(ws, None)
            log.info(
                "экран %d: клиент отключён %s (осталось=%d) stats=%s",
                self.index, peer, len(self._clients), stats.snapshot(),
            )

    async def _writer_loop(
        self, ws: Any, queue: asyncio.Queue[bytes], stats: ClientStats
    ) -> None:
        """Отправлять кадры из очереди в WebSocket."""
        try:
            while True:
                frame = await queue.get()
                if not frame:
                    # Сигнал завершения.
                    return
                t0 = time.monotonic()
                await ws.send(frame)
                dt = time.monotonic() - t0
                stats.frames_sent += 1
                stats.bytes_sent += len(frame)
                stats.last_frame_at = time.monotonic()
                # Грубая оценка задержки: время блокировки на ws.send.
                stats.last_latency_estimate = dt
        except self._ws_module.ConnectionClosed:
            return
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            log.warning("writer-loop ошибка для %s: %s", stats.address, exc)

    async def _reader_loop(self, ws: Any, stats: ClientStats) -> None:
        """Читать JSON-ввод от телефона и диспетчеризировать его."""
        # Rate-limit: не более N сообщений в секунду (0 = без лимита).
        rate_limit = getattr(self._server_ref.config, 'input_rate_limit', 0) if hasattr(self, '_server_ref') and self._server_ref else 0
        _rl_timestamps: list[float] = []
        try:
            async for message in ws:
                if isinstance(message, (bytes, bytearray)):
                    stats.bytes_received += len(message)
                else:
                    stats.bytes_received += len(message.encode("utf-8"))
                # Rate-limit check.
                if rate_limit > 0:
                    now = time.monotonic()
                    _rl_timestamps.append(now)
                    # Чистим старые (>1 сек назад).
                    _rl_timestamps[:] = [t for t in _rl_timestamps if now - t < 1.0]
                    if len(_rl_timestamps) > rate_limit:
                        log.warning("rate-limit: %s превысил %d сообщ/сек — drop", stats.address, rate_limit)
                        continue
                try:
                    await self.injector.handle_message(message)
                except InputError as exc:
                    log.warning("некорректное сообщение от %s: %s", stats.address, exc)
                    try:
                        await ws.send(json.dumps({"type": "error", "error": str(exc)}))
                    except self._ws_module.ConnectionClosed:
                        return
        except self._ws_module.ConnectionClosed:
            return
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            log.warning("reader-loop ошибка для %s: %s", stats.address, exc)


class HyprScreenServer:
    """Мультиэкранный WebSocket-сервер.

    Конструируется из :class:`Config` и списка экранов (каждый — кортеж
    ``(output_name, x_offset, ScreenConfig)``). Вызовите :meth:`start`
    чтобы привязать сокет, и :meth:`serve` чтобы работать вечно.
    """

    def __init__(
        self,
        config: Config,
        screens: list[tuple[str, int, ScreenConfig]],
    ) -> None:
        if not screens:
            raise ValueError("нужен хотя бы один экран")
        self.config = config
        self._ws_module = _import_websockets()
        self._server: Any = None
        self._stop_event = asyncio.Event()
        self._auth_token = config.auth_token  # для auth-проверки в StreamScreen.handle
        # Строим StreamScreen'ы.
        self.screens: list[StreamScreen] = [
            StreamScreen(
                index=i,
                output_name=name,
                x_offset=x_offset,
                screen_cfg=sc,
                total_screens=len(screens),
                ws_module=self._ws_module,
            )
            for i, (name, x_offset, sc) in enumerate(screens)
        ]
        # Каждому StreamScreen даём ссылку на сервер (для auth_token).
        for s in self.screens:
            s._server_ref = self
        self._discovery: Optional[DiscoveryBroadcaster] = None
        if config.discovery_enabled:
            self._discovery = DiscoveryBroadcaster(config, screens=len(self.screens))

    # -- публичный API ---------------------------------------------------

    async def start(self) -> None:
        """Привязать WebSocket-сервер к ``bind_address:port``."""
        serve = self._ws_module.serve
        # TLS: если включён — строим SSLContext.
        ssl_context = None
        if self.config.tls_enabled:
            ssl_context = _build_ssl_context(self.config)
            if ssl_context is None:
                log.warning("TLS включён, но SSLContext не создан — запускаю без TLS")
        self._server = await serve(
            self._handler,
            self.config.bind_address,
            self.config.port,
            max_size=1 << 20,
            ping_interval=20,
            ping_timeout=20,
            close_timeout=5,
            ssl=ssl_context,
        )
        log.info(
            "HyprScreen WebSocket-сервер слушает %s:%d (экранов=%d)",
            self.config.bind_address, self.config.port, len(self.screens),
        )
        # Запускаем capture-loop'ы для всех экранов.
        for s in self.screens:
            await s.start_capture()
        # Запускаем UDP discovery-бродкастер.
        if self._discovery is not None:
            await self._discovery.start()

    async def serve(self) -> None:
        """Работать вечно, рассылая кадры всем клиентам."""
        if self._server is None:
            await self.start()
        try:
            await self._server.serve_forever()
        finally:
            await self.shutdown()

    async def stop(self) -> None:
        """Сигнал к остановке (идемпотентно)."""
        self._stop_event.set()
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
        # Останавливаем discovery.
        if self._discovery is not None:
            await self._discovery.stop()

    async def shutdown(self) -> None:
        """Отменить все задачи, закрыть клиентов и InputInjector."""
        log.info("остановка сервера")
        # Останавливаем capture-loop'ы экранов.
        for s in self.screens:
            await s.stop_capture()
        # Будим все клиентские очереди, чтобы writer-loop'ы вышли.
        for s in self.screens:
            for q in list(s._queues.values()):
                q.put_nowait(b"")  # sentinel
        # Закрываем evdev UInput каждого экрана.
        for s in self.screens:
            try:
                s.injector.close()
            except Exception as exc:  # noqa: BLE001
                log.warning("ошибка закрытия injector экрана %d: %s", s.index, exc)
        # Останавливаем discovery (на случай если stop() не вызывали).
        if self._discovery is not None:
            await self._discovery.stop()
        log.info("остановка сервера завершена")

    # -- внутренний: роутинг входящих соединений ------------------------

    async def _handler(self, ws: Any) -> None:
        """Точка входа для каждого нового соединения.

        Парсит URL-путь, выбирает экран и делегирует в :meth:`StreamScreen.handle`.
        """
        path = getattr(ws, "path", "") or ""
        # Нормализуем путь: «/» и пустой → 0. Иначе берём первый сегмент.
        path = path.lstrip("/")
        if not path:
            idx = 0
        else:
            # Берём только первый сегмент пути (до '?' или '/').
            first = path.split("?", 1)[0].split("/", 1)[0]
            try:
                idx = int(first)
            except ValueError:
                await ws.close(code=1008, reason="unknown screen index")
                return
        if idx < 0 or idx >= len(self.screens):
            try:
                await ws.close(code=1008, reason="unknown screen index")
            except Exception as exc:  # noqa: BLE001
                log.debug("не удалось закрыть ws (idx=%d): %s", idx, exc)
            return
        screen = self.screens[idx]
        try:
            await screen.handle(ws)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            log.warning("экран %d: ошибка обработчика соединения: %s", idx, exc)


# ---------------------------------------------------------------------------


def _import_websockets():
    """Импортировать асинхронную библиотеку ``websockets`` или поднять чёткую ошибку."""
    try:
        import websockets  # type: ignore[import-not-found]
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "Требуется библиотека 'websockets'. Установите: "
            "pip install websockets"
        ) from exc
    return websockets


def _build_ssl_context(config: Config) -> Any:
    """Построить SSLContext для wss:// из config.tls_cert/tls_key.

    Если пути не заданы — генерирует self-signed сертификат через openssl CLI
    в ``~/.local/share/hyprscreen/cert.pem`` + ``key.pem``.
    Возвращает SSLContext или None при ошибке.
    """
    import ssl
    import os
    import subprocess

    cert = config.tls_cert
    key = config.tls_key
    if not cert or not key:
        data_dir = os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share"))
        hs_dir = os.path.join(data_dir, "hyprscreen")
        os.makedirs(hs_dir, exist_ok=True)
        cert = os.path.join(hs_dir, "cert.pem")
        key = os.path.join(hs_dir, "key.pem")
        if not os.path.exists(cert) or not os.path.exists(key):
            log.info("TLS: генерирую self-signed сертификат: %s", cert)
            try:
                subprocess.run([
                    "openssl", "req", "-x509", "-newkey", "rsa:2048",
                    "-keyout", key, "-out", cert, "-days", "365", "-nodes",
                    "-subj", "/CN=hyprscreen",
                ], check=True, capture_output=True, timeout=30)
            except Exception as exc:
                log.error("TLS: не удалось сгенерировать сертификат: %s", exc)
                return None
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(cert, key)
        log.info("TLS: SSLContext создан (cert=%s)", cert)
        return ctx
    except Exception as exc:
        log.error("TLS: не удалось загрузить сертификат: %s", exc)
        return None
