"""Инъекция ввода для HyprScreen — через evdev UInput.

Создаёт виртуальное устройство /dev/input/eventX через evdev.UInput с
абсолютными осями ABS_X/ABS_Y. Wayland/Hyprland читает его как настоящий
touchscreen — НЕТ дрейфа, НЕТ subprocess на каждое движение (ydotool),
курсор двигается мгновенно.

Подход заимствован у github.com/Uran2354/RemoteController.
Текст — через wtype.
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import subprocess
from typing import Mapping

from config import ScreenConfig

log = logging.getLogger(__name__)

try:
    from evdev import UInput, AbsInfo, ecodes as _E
    _HAS_EVDEV = True
except ImportError:
    _E = None
    _HAS_EVDEV = False

BTN_LEFT = 0x110
BTN_RIGHT = 0x111
BTN_MIDDLE = 0x112

BUTTON_NAME_TO_CODE = {
    "left": BTN_LEFT, "right": BTN_RIGHT, "middle": BTN_MIDDLE,
    "1": BTN_LEFT, "2": BTN_MIDDLE, "3": BTN_RIGHT,
}

WTYPE_MODIFIERS = {
    "ctrl": "ctrl", "control": "ctrl", "shift": "shift",
    "alt": "alt", "super": "super", "meta": "super", "win": "super", "logo": "super",
}


class InputError(RuntimeError):
    pass


class InputInjector:
    """evdev UInput — абсолютные координаты, мгновенно, без subprocess."""

    def __init__(self, config: ScreenConfig, x_offset: int = 0):
        self.config = config
        self.x_offset = int(x_offset)
        self._wtype = shutil.which("wtype")
        self._global_w = self.x_offset + config.width
        self._global_h = config.height
        self._ui = self._init_uinput()
        log.info("InputInjector (evdev): %dx%d x=%d gw=%dx%d wtype=%s",
                 config.width, config.height, self.x_offset,
                 self._global_w, self._global_h, self._wtype)

    def _init_uinput(self):
        if not _HAS_EVDEV:
            raise InputError("evdev не установлен: pip install evdev")
        K = {
            "ESC":1,"1":2,"2":3,"3":4,"4":5,"5":6,"6":7,"7":8,"8":9,"9":10,"0":11,
            "BACKSPACE":14,"TAB":15,"Q":16,"W":17,"E":18,"R":19,"T":20,"Y":21,
            "U":22,"I":23,"O":24,"P":25,"A":30,"S":31,"D":32,"F":33,"G":34,
            "H":35,"J":36,"K":37,"L":38,"Z":44,"X":45,"C":46,"V":47,"B":48,
            "N":49,"M":50,"ENTER":28,"LCTRL":29,"LSHIFT":42,"LALT":56,
            "LMETA":125,"SPACE":57,"HOME":102,"UP":103,"PGUP":104,"LEFT":105,
            "RIGHT":106,"END":107,"DOWN":108,"PGDN":109,"INS":110,"DEL":111,
            "F1":59,"F2":60,"F3":61,"F4":62,"F5":63,"F6":64,"F7":65,"F8":66,
            "F9":67,"F10":68,"F11":87,"F12":88,
        }
        cap = {
            _E.EV_KEY: [
                _E.BTN_LEFT, _E.BTN_RIGHT, _E.BTN_MIDDLE,
                K["LMETA"], K["BACKSPACE"], K["SPACE"], K["ENTER"], K["TAB"],
                K["LCTRL"], K["LALT"], K["LSHIFT"],
                K["A"],K["B"],K["C"],K["D"],K["E"],K["F"],K["G"],K["H"],K["I"],
                K["J"],K["K"],K["L"],K["M"],K["N"],K["O"],K["P"],K["Q"],K["R"],
                K["S"],K["T"],K["U"],K["V"],K["W"],K["X"],K["Y"],K["Z"],
                K["1"],K["2"],K["3"],K["4"],K["5"],K["6"],K["7"],K["8"],K["9"],K["0"],
                K["F1"],K["F2"],K["F3"],K["F4"],K["F5"],K["F6"],
                K["F7"],K["F8"],K["F9"],K["F10"],K["F11"],K["F12"],
                K["ESC"],K["DEL"],K["HOME"],K["END"],K["INS"],K["PGUP"],K["PGDN"],
                K["LEFT"],K["RIGHT"],K["UP"],K["DOWN"],
            ],
            _E.EV_ABS: [
                (_E.ABS_X, AbsInfo(0, 0, self._global_w, 0, 0, 0)),
                (_E.ABS_Y, AbsInfo(0, 0, self._global_h, 0, 0, 0)),
            ],
            _E.EV_REL: [_E.REL_WHEEL, _E.REL_HWHEEL],
        }
        try:
            ui = UInput(cap, name="HyprScreen-Virtual-Input", version=0x1)
            log.info("evdev UInput создан")
            return ui
        except Exception as exc:
            raise InputError(f"evdev UInput: {exc}. sudo usermod -aG input $USER") from exc

    async def handle_message(self, raw: str | bytes) -> None:
        if isinstance(raw, (bytes, bytearray)):
            raw = raw.decode("utf-8", "replace")
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise InputError(f"JSON: {exc}") from exc
        if not isinstance(msg, Mapping):
            raise InputError(f"ожидался объект, получено {type(msg)}")
        mtype = msg.get("type")
        handler = self._DISPATCH.get(mtype)
        if handler is None:
            raise InputError(f"неизвестный тип: {mtype!r}")
        # pointer/scroll — evdev syscall, синхронно (без to_thread).
        if mtype in ("pointer_move", "pointer_down", "pointer_up", "scroll"):
            handler(self, msg)
        else:
            await asyncio.to_thread(handler, self, msg)

    def _pointer_move(self, msg):
        x = self._as_float(msg.get("x"))
        y = self._as_float(msg.get("y"))
        if x is None or y is None:
            raise InputError("pointer_move требует x и y")
        gx = int(self.x_offset + max(0.0, min(self.config.width - 1, x)))
        gy = int(max(0.0, min(self.config.height - 1, y)))
        try:
            self._ui.write(_E.EV_ABS, _E.ABS_X, gx)
            self._ui.write(_E.EV_ABS, _E.ABS_Y, gy)
            self._ui.syn()
        except Exception as exc:
            log.warning("evdev move: %s", exc)

    def _pointer_down(self, msg):
        x = self._as_float(msg.get("x"))
        y = self._as_float(msg.get("y"))
        code = self._button_code(msg.get("button"))
        if x is not None and y is not None:
            self._pointer_move({"x": x, "y": y})
        try:
            self._ui.write(_E.EV_KEY, code, 1)
            self._ui.syn()
        except Exception as exc:
            log.warning("evdev down: %s", exc)

    def _pointer_up(self, msg):
        code = self._button_code(msg.get("button"))
        try:
            self._ui.write(_E.EV_KEY, code, 0)
            self._ui.syn()
        except Exception as exc:
            log.warning("evdev up: %s", exc)

    def _scroll(self, msg):
        dx = self._as_float(msg.get("dx")) or 0.0
        dy = self._as_float(msg.get("dy")) or 0.0
        try:
            if dy > 0:
                self._ui.write(_E.EV_REL, _E.REL_WHEEL, int(abs(dy)))
            elif dy < 0:
                self._ui.write(_E.EV_REL, _E.REL_WHEEL, -int(abs(dy)))
            if dx > 0:
                self._ui.write(_E.EV_REL, _E.REL_HWHEEL, int(abs(dx)))
            elif dx < 0:
                self._ui.write(_E.EV_REL, _E.REL_HWHEEL, -int(abs(dx)))
            self._ui.syn()
        except Exception as exc:
            log.warning("evdev scroll: %s", exc)

    def _key(self, msg):
        keysym = msg.get("keysym")
        if not isinstance(keysym, str) or not keysym:
            raise InputError("key требует keysym")
        modifiers = msg.get("modifiers", [])
        args = [self._wtype]
        for mod in modifiers:
            flag = WTYPE_MODIFIERS.get(str(mod).lower())
            if flag is None:
                raise InputError(f"неизвестный модификатор: {mod!r}")
            args.extend(["-M", flag])
        args.extend(["-k", keysym])
        self._run(args)

    def _text(self, msg):
        text = msg.get("text")
        if not isinstance(text, str):
            raise InputError("text требует строку")
        if not text:
            return
        self._run([self._wtype, "-d", "0", text])

    def _run(self, argv):
        try:
            proc = subprocess.run(list(argv), check=False,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
        except FileNotFoundError as exc:
            raise InputError(f"команда не найдена: {argv[0]!r}") from exc
        except subprocess.TimeoutExpired:
            return
        if proc.returncode != 0:
            log.warning("%s exit %d: %s", argv[0], proc.returncode,
                        (proc.stdout or proc.stderr or "").strip())

    @staticmethod
    def _as_float(v):
        if v is None: return None
        try: return float(v)
        except (TypeError, ValueError): return None

    @staticmethod
    def _button_code(name):
        if name is None: raise InputError("button обязателен")
        key = str(name).lower()
        if key not in BUTTON_NAME_TO_CODE:
            raise InputError(f"неизвестная кнопка: {name!r}")
        return BUTTON_NAME_TO_CODE[key]

    def close(self):
        if self._ui is not None:
            try:
                self._ui.close()
                log.info("evdev UInput закрыт")
            except Exception as exc:
                log.warning("close UInput: %s", exc)

    _DISPATCH = {}


InputInjector._DISPATCH = {  # type: ignore[attr-defined]
    "pointer_move": InputInjector._pointer_move,
    "pointer_down": InputInjector._pointer_down,
    "pointer_up": InputInjector._pointer_up,
    "scroll": InputInjector._scroll,
    "key": InputInjector._key,
    "text": InputInjector._text,
}
