# HyprScreen — спецификация wire-протокола

Версия: 0.2.0. Этот документ — **единый источник истины** для PC (Python) и
Android (Kotlin) реализаций.

## 1. Топология

Один PC может отдать **N независимых экранов** (1–4). Каждый — отдельный
виртуальный Wayland-вывод `HEADLESS-<i>`, стримится независимо на одно
Android-устройство по пути `ws://<host>:<port>/<index>` (index = 0..N-1).

## 2. WebSocket

- TCP-сервер на `bind_address:port` (по умолчанию `0.0.0.0:8765`).
- URL-путь выбирает экран: `ws://<host>:<port>/<index>`.
- Путь `/` и пустой → экран **0**.
- Путь вне диапазона → `close(1008, "unknown screen index")`.
- При `tls_enabled = true` — `wss://` (self-signed сертификат).

## 3. Auth (опционально)

Если на PC задан `auth_token` (в `config.toml` или `--auth-token`):

1. Клиент подключается к WebSocket.
2. Клиент отправляет **первым сообщением**: `{"type":"auth","token":"<значение>"}`
3. Сервер проверяет токен (timeout 10 сек).
4. При успехе → отправляет `hello`.
5. При неудаче → `close(1008, "auth required")`.

Если `auth_token` не задан — auth-шаг пропускается, hello отправляется сразу.

## 4. Сообщения PC → телефон

### 4.1. hello (text, один раз после auth)

```json
{
  "type": "hello",
  "server": "hyprscreen",
  "version": "0.2.0",
  "width": 1920,
  "height": 1080,
  "fps": 30,
  "jpeg_quality": 80,
  "image_format": "jpeg",
  "capture_backend": "grim",
  "screen": 0,
  "total_screens": 1,
  "output": "HEADLESS-1",
  "server_time": 1719480000.123
}
```

Обязательные поля: `width`, `height`, `fps`, `screen`, `total_screens`.
Остальные — информационные.

### 4.2. frame (binary)

Одно бинарное WebSocket-сообщение = один полный кадр (JPEG или WebP, в
зависимости от `image_format`). Частота ≈ `fps`.

### 4.3. error (text, опционально)

```json
{"type": "error", "error": "описание ошибки"}
```

## 5. Сообщения телефон → PC

Все — text JSON. Координаты — в пикселях экрана (0..width, 0..height).

### 5.1. auth (первым сообщением, если задан auth_token)

```json
{"type":"auth","token":"mysecret"}
```

### 5.2. pointer_move

```json
{"type":"pointer_move","x":842.0,"y":510.0}
```

### 5.3. pointer_down

```json
{"type":"pointer_down","x":842.0,"y":510.0,"button":"left"}
```

`button` ∈ `"left" | "right" | "middle"`.

### 5.4. pointer_up

```json
{"type":"pointer_up","button":"left"}
```

### 5.5. scroll

```json
{"type":"scroll","dx":0.0,"dy":-3.0}
```

`dy > 0` = вниз, `dy < 0` = вверх. `dx > 0` = вправо.

### 5.6. key

```json
{"type":"key","keysym":"c","modifiers":["ctrl","shift"]}
```

`modifiers` — список из `"ctrl"|"shift"|"alt"|"super"`.

### 5.7. text

```json
{"type":"text","text":"neofetch\n"}
```

## 6. UDP discovery (PC → широковещательно)

PC каждые 2 секунды рассылает UDP-датаграмму на порт `8766`:

```json
{"hyprscreen":true,"host":"192.168.1.42","port":8765,"screens":1,"name":"cachyos-pc"}
```

## 7. Ввод (поведение PC)

- **evdev UInput** — виртуальное устройство с абсолютными осями ABS_X/ABS_Y.
  Wayland читает его как touchscreen — курсор ставится мгновенно, без дрейфа.
- Координаты: глобальные = `(x_offset + x, y)`.
- Кнопки: `BTN_LEFT=0x110`, `BTN_RIGHT=0x111`, `BTN_MIDDLE=0x112` через
  `EV_KEY`.
- Скролл: `REL_WHEEL` / `REL_HWHEEL` (настоящие оси колеса).
- Текст/клавиши: `wtype` (subprocess, в отдельном потоке).
- Rate-limit: если `input_rate_limit > 0` — не более N сообщений/сек на клиент.

## 8. Захват кадров (поведение PC)

- Бэкенд `grim` (по умолчанию): `grim -o HEADLESS-<i> -t <format> -q <q> -`.
- `image_format`: `"jpeg"` (по умолчанию) или `"webp"` (лучше качество/размер).
- Если к экрану нет клиентов — capture-loop засыпает.
- Устаревшие кадры отбрасываются при переполнении очереди клиента.

## 9. Завершение работы

- SIGINT/SIGTERM: сервер отменяет задачи, закрывает клиентов, закрывает
  evdev UInput (`injector.close()`), удаляет HEADLESS-выводы (с эвакуацией
  воркспейсов), останавливает discovery, чистит state-файл.
- `./run.sh kill`: ищет и останавливает процесс сервера, освобождает порт,
  очищает HEADLESS.
