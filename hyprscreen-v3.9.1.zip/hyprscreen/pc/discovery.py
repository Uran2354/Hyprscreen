"""UDP discovery-бродкастер для HyprScreen (PC-сторона).

Android-клиент (:file:`android-src/Discovery.kt`) слушает UDP-порт 8766
и собирает датаграммы вида::

    {"hyprscreen":true,"host":"192.168.1.42","port":8080,"screens":1,
     "monitor":"DP-3","name":"cachyos-pc"}

:class:`DiscoveryBroadcaster` каждые 2 секунды шлёт такую датаграмму на
broadcast-адрес подсети (или 255.255.255.255). Поле ``screens`` оставлено
для совместимости с клиентами 2.x — с 3.x PC отдаёт один реальный экран.
"""

from __future__ import annotations

import json
import logging
import socket
import threading
import time

log = logging.getLogger("hyprscreen.discovery")

BROADCAST_INTERVAL_SEC = 2.0
_WARN_MIN_INTERVAL = 60.0
_last_net_warn = 0.0


def _warn_throttled(msg: str, *args: object) -> None:
    global _last_net_warn
    now = time.monotonic()
    if now - _last_net_warn >= _WARN_MIN_INTERVAL:
        _last_net_warn = now
        log.warning(msg, *args)


def lan_ip() -> str:
    """IPv4 этого PC в LAN (UDP-трюк без отправки пакетов).

    Если трюк не сработал (нет маршрута по умолчанию — ПК в LAN без
    интернета), fallback на `ip route get`: иначе анонсировался
    127.0.0.1, и телефон «подключался к самому себе».
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return str(s.getsockname()[0])
    except OSError:
        pass
    finally:
        s.close()
    # Fallback: источник маршрута по умолчанию (работает и без интернета)
    try:
        import subprocess
        out = subprocess.run(
            ["ip", "-4", "route", "get", "1.1.1.1"],
            capture_output=True, text=True, timeout=3,
        )
        tokens = out.stdout.split()
        if "src" in tokens:
            return tokens[tokens.index("src") + 1]
    except Exception:  # noqa: BLE001 — без ip(8) остаётся 127.0.0.1
        pass
    return "127.0.0.1"


def all_lan_ips() -> list[str]:
    """Все глобальные IPv4 этого ПК (маршрут по умолчанию — первым).

    Раньше анонсировался только IP маршрута по умолчанию: при активном VPN
    (tun0) или второй сетевой карте телефон получал недостижимый адрес —
    при «зелёных» doctor/GUI (отчёт 3.7.1). Теперь бродкастер шлёт
    датаграмму на КАЖДЫЙ адрес: приложение покажет все варианты, а
    пользователь подключится к рабочему (см. SETUP.md §7.8).
    """
    ips: list[str] = []
    try:
        import subprocess
        out = subprocess.run(
            ["ip", "-4", "-o", "addr", "show", "scope", "global"],
            capture_output=True, text=True, timeout=4,
        )
        for line in out.stdout.splitlines():
            parts = line.split()
            try:
                i = parts.index("inet")
            except ValueError:
                continue
            # обычная запись: inet 192.168.1.42/24 ...
            # p2p-интерфейсы (VPN): inet 10.8.0.2 peer 10.8.0.1/32 ...
            if i + 2 < len(parts) and parts[i + 1] == "peer":
                continue                     # peer — чужой адрес, не наш
            addr = parts[i + 1] if i + 1 < len(parts) else ""
            ip = addr.split("/", 1)[0]
            if ip.count(".") == 3 and ip not in ips \
                    and not ip.startswith(("127.", "169.254.")):
                ips.append(ip)
    except Exception:  # noqa: BLE001 — без ip(8) остаётся lan_ip()
        pass
    primary = lan_ip()
    if primary and primary != "127.0.0.1":
        if primary in ips:
            ips.remove(primary)
        ips.insert(0, primary)
    return ips


def broadcast_addresses() -> list[str]:
    """Адреса рассылки: <subnet>.255 по всем интерфейсам + 255.255.255.255."""
    targets = {"255.255.255.255"}
    for info in _interface_networks():
        targets.add(f"{info}.255")
    return sorted(targets)


def _interface_networks() -> list[str]:
    """Префиксы подсетей вида '192.168.1' (по ip-адресам хоста)."""
    nets: list[str] = []
    try:
        import subprocess
        out = subprocess.run(
            ["ip", "-4", "-o", "addr", "show", "scope", "global"],
            capture_output=True, text=True, timeout=4,
        )
        for token in out.stdout.split():
            if "/" in token and token.count(".") == 3 and not token.startswith("127."):
                nets.append(token.rsplit("/", 1)[0].rsplit(".", 1)[0])
    except Exception:  # noqa: BLE001 — без ip(8) обойдёмся широковещательным
        pass
    return nets


class DiscoveryBroadcaster(threading.Thread):
    """Периодическая рассылка анонса PC (UDP)."""

    def __init__(
        self,
        http_port: int,
        discovery_port: int = 8766,
        monitor: str = "",
        stop: threading.Event | None = None,
        interval: float = BROADCAST_INTERVAL_SEC,
    ) -> None:
        super().__init__(daemon=True, name="hyprscreen-discovery")
        self.http_port = int(http_port)
        self.discovery_port = int(discovery_port)
        self.monitor = monitor
        self.stop_event = stop or threading.Event()
        self.interval = interval

    def _payloads(self) -> list[bytes]:
        """По датаграмме на КАЖДЫЙ IPv4 ПК (VPN/вторая карта — §7.8)."""
        import socket as _s
        try:
            hostname = _s.gethostname()
        except Exception:  # noqa: BLE001
            hostname = "PC"
        payloads: list[bytes] = []
        for ip in (all_lan_ips() or [lan_ip()]):
            data = {
                "hyprscreen": True,
                "host": ip,
                "port": self.http_port,
                "screens": 1,
                "monitor": self.monitor,
                "name": hostname,
            }
            payloads.append(json.dumps(data, ensure_ascii=False).encode("utf-8"))
        return payloads

    def run(self) -> None:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            while not self.stop_event.is_set():
                for payload in self._payloads():
                    for target in broadcast_addresses():
                        try:
                            sock.sendto(payload, (target, self.discovery_port))
                        except OSError as exc:
                            _warn_throttled("discovery sendto %s: %s", target, exc)
                self.stop_event.wait(self.interval)
        finally:
            sock.close()
            log.info("discovery остановлен")


def start_broadcaster(
    http_port: int,
    discovery_port: int,
    monitor: str,
    stop: threading.Event,
) -> DiscoveryBroadcaster:
    broadcaster = DiscoveryBroadcaster(http_port, discovery_port, monitor, stop)
    broadcaster.start()
    return broadcaster
