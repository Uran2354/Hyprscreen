#!/usr/bin/env bash
# Запускатор HyprScreen 3.9.1 (pc/).
#
# Без аргументов:  ./run.sh
#   → сервер в переднем плане (как в 2.2.0 без аргументов запускалась
#     программа; логика 3.9.0: main.py без команды = serve).
#
# Подкоманды:
#   ./run.sh gui          — графический интерфейс (customtkinter)
#   ./run.sh menu         — консольное меню
#   ./run.sh on|off|toggle|status|monitors|qr|grimtest|cleanup|doctor
#   ./run.sh serve -c config.toml   — прямой запуск сервера
#
# Всё остальное передаётся main.py без изменений.

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
cd "$SCRIPT_DIR"

# python3 → python (в части дистрибутивов бинарника `python` нет).
PYTHON="${PYTHON:-}"
if [[ -z "$PYTHON" ]]; then
    if command -v python3 >/dev/null 2>&1; then
        PYTHON="python3"
    else
        PYTHON="python"
    fi
fi
VENV_DIR="${VENV_DIR:-$SCRIPT_DIR/.venv}"
if [[ -x "$VENV_DIR/bin/python" ]]; then
    PYTHON="$VENV_DIR/bin/python"
fi

export PYTHONPATH="$SCRIPT_DIR${PYTHONPATH:+:$PYTHONPATH}"

# Проверка целостности ЛОКАЛЬНЫХ модулей проекта до запуска Python:
# settings_store.py и прочие *.py — файлы ПРОЕКТА, их нет в requirements.txt
# и pip их не ставит. Неполная копия падала с невнятным
# «ModuleNotFoundError» — падаем сразу, с точным списком и лечением.
missing_files=()
for mod in main server capture input config hyprctl discovery \
           settings_store state_file logging_setup gui; do
    [[ -f "$SCRIPT_DIR/$mod.py" ]] || missing_files+=("$mod.py")
done
if ((${#missing_files[@]})); then
    echo "ОШИБКА: копия HyprScreen неполная — в pc/ нет файлов:"
    printf '    pc/%s\n' "${missing_files[@]}"
    echo "Это ЛОКАЛЬНЫЕ модули проекта (не pip-пакеты)."
    echo "Лечение: заново распакуйте полный архив hyprscreen и запустите ./install.sh"
    exit 1
fi

cmd="${1:-}"
case "$cmd" in
    gui)
        exec "$PYTHON" gui.py
        ;;
    menu)
        exec "$PYTHON" main.py menu
        ;;
    "")
        exec "$PYTHON" main.py serve
        ;;
    *)
        exec "$PYTHON" main.py "$@"
        ;;
esac
