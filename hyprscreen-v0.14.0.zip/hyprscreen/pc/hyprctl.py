"""Маленькая обёртка над командой ``hyprctl`` для Hyprland.

Hyprland открывает IPC-сокет через ``hyprctl``. Большинство команд
принимает флаг ``-j`` для вывода JSON — его гораздо проще парсить, чем
человекочитаемую форму.

Этот модуль намеренно stateless; это тонкая, строго-типизированная обёртка,
чтобы остальная кодовая база не повторяла ``subprocess.run`` бойлерплейт.

Все вызовы идут с ``timeout=10`` — если hyprctl зависнет, тред не
заблокируется навсегда (а с ``asyncio.to_thread`` это была бы утечка треда).

Ссылки
------
* ``man hyprctl`` (пакет CachyOS / Arch ``hyprland``)
* https://wiki.hyprland.org/Configuring/Using-hyprctl/
"""

from __future__ import annotations

import json
import logging
import shutil
import subprocess
from typing import Any, Sequence

log = logging.getLogger(__name__)


class HyprctlError(RuntimeError):
    """Поднимается, когда ``hyprctl`` завершается с non-zero или не найден."""


def _find_binary() -> str:
    """Вернуть абсолютный путь к ``hyprctl`` или поднять исключение."""
    path = shutil.which("hyprctl")
    if path is None:
        raise HyprctlError(
            "hyprctl не найден в PATH. На CachyOS установите: "
            "sudo pacman -S hyprland"
        )
    return path


def run_raw(args: Sequence[str], *, json_output: bool = False, check: bool = True) -> str:
    """Вызвать ``hyprctl <args...>`` и вернуть stdout как строку.

    Параметры
    ---------
    args:
        Аргументы после ``hyprctl`` (например ``["monitors"]``).
    json_output:
        Если True — добавить ``-j``, чтобы hyprctl выдал JSON.
    check:
        Если True — поднять :class:`HyprctlError` на non-zero exit.

    Возвращает
    ----------
    str
        Декодированный stdout (trailing whitespace обрезан).
    """
    binary = _find_binary()
    cmd: list[str] = [binary]
    if json_output:
        cmd.append("-j")
    cmd.extend(args)
    log.debug("hyprctl запуск: %s", " ".join(cmd))
    try:
        proc = subprocess.run(
            cmd,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=10,
        )
    except subprocess.TimeoutExpired as exc:
        msg = f"hyprctl {' '.join(args)} таймаут ({exc.timeout}s)"
        if check:
            raise HyprctlError(msg) from exc
        log.warning(msg)
        return ""
    if proc.returncode != 0:
        msg = (
            f"hyprctl {' '.join(args)} упал (exit {proc.returncode}): "
            f"{proc.stderr.strip() or proc.stdout.strip()}"
        )
        if check:
            raise HyprctlError(msg)
        log.warning(msg)
    return proc.stdout.strip()


def run_json(args: Sequence[str], *, check: bool = True) -> Any:
    """Вызвать ``hyprctl -j <args...>`` и разобрать JSON-вывод.

    Возвращает декодированный JSON-объект (обычно list или dict).
    """
    raw = run_raw(args, json_output=True, check=check)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise HyprctlError(f"hyprctl вернул некорректный JSON: {exc}: {raw!r}") from exc


def keyword(option: str, value: str) -> None:
    """Установить keyword конфига Hyprland в рантайме: ``hyprctl keyword <opt> <val>``.

    Пример: ``keyword("monitor", "HEADLESS-1,1920x1080@60,2560x0,1")``
    """
    run_raw(["keyword", option, value])


def unkeyword(option: str) -> str:
    """Снять runtime-keyword(ы): ``hyprctl unkeyword <opt>``.

    HyprScreen ставит правила воркспейсов через ``keyword workspace``;
    эта команда снимает их все (правила из hyprland.conf пользователя
    не затрагиваются). Возвращает ответ hyprctl.
    """
    return run_raw(["unkeyword", option], check=False)


def dispatch(rule: str, *args: str) -> None:
    """Вызвать ``hyprctl dispatch <rule> [args...]``.

    Пример: ``dispatch("output", "remove", "HEADLESS-1")``
    """
    run_raw(["dispatch", rule, *args])


def monitors() -> list[dict[str, Any]]:
    """Вернуть текущий список мониторов как разобранный JSON.

    Каждая запись имеет поля ``name``, ``x``, ``y``, ``width``, ``height``,
    ``transform``, ``scale``, ``refreshRate``. См. ``hyprctl monitors -j``.
    """
    data = run_json(["monitors"])
    if data is None:
        return []
    if not isinstance(data, list):
        raise HyprctlError(f"неожиданный вывод monitors: {data!r}")
    return data


def output_create_headless() -> str:
    """Создать headless (виртуальный) вывод: ``hyprctl output create headless``.

    БЕЗ аргумента режима! В Hyprland 0.55 второй аргумент ``output create`` —
    это ИМЯ вывода, а не режим. Передача ``1920x1080@60`` создаёт вывод с
    именем ``1920x1080@60`` вместо ``HEADLESS-N``. Режим задаётся отдельной
    командой ``keyword monitor`` после создания.
    """
    return run_raw(["output", "create", "headless"])


def output_remove(name: str) -> None:
    """Удалить виртуальный вывод: ``hyprctl output remove <name>``."""
    run_raw(["output", "remove", name])


def list_workspaces() -> list[dict[str, Any]]:
    """Список воркспейсов (``hyprctl -j workspaces``)."""
    data = run_json(["workspaces"])
    if data is None:
        return []
    if not isinstance(data, list):
        raise HyprctlError(f"неожиданный вывод workspaces: {data!r}")
    return data


def dispatch_lua(lua_expr: str) -> str:
    """Вызвать ``hyprctl dispatch '<lua_expr>'`` (Hyprland 0.55+ Lua-синтаксис)."""
    return run_raw(["dispatch", lua_expr])


def _lua_escape(s: str) -> str:
    """Экранировать строку для Lua-литерала."""
    return s.replace("\\", "\\\\").replace('"', '\\"')


def move_workspace_to_monitor(workspace: str | int, monitor: str) -> None:
    """Перенести воркспейс на монитор: ``hl.dsp.workspace.move({ workspace, monitor })``."""
    ws = _lua_escape(str(workspace))
    mon = _lua_escape(monitor)
    reply = dispatch_lua(f'hl.dsp.workspace.move({{ workspace = "{ws}", monitor = "{mon}" }})')
    if reply and ("error" in reply.lower() or "not found" in reply.lower()):
        raise HyprctlError(f"workspace.move: {reply}")


def move_workspace_to_monitor_checked(workspace: str | int, monitor: str) -> str:
    """Как move_workspace_to_monitor, но возвращает ответ (не валидирует)."""
    ws = _lua_escape(str(workspace))
    mon = _lua_escape(monitor)
    return dispatch_lua(f'hl.dsp.workspace.move({{ workspace = "{ws}", monitor = "{mon}" }})')


def find_headless_monitors() -> list[str]:
    """Имена всех HEADLESS-* мониторов."""
    try:
        return [
            str(m.get("name", ""))
            for m in monitors()
            if str(m.get("name", "")).startswith("HEADLESS")
        ]
    except HyprctlError:
        return []


def _evacuate_workspaces_from_monitor(monitor: str, target: str | None = None) -> None:
    """Перенести все воркспейсы с monitor на target (best-effort).

    Правила воркспейсов НЕ регистрируются (старая версия делала здесь
    workspace_rule — из-за этого правила накапливались).
    """
    if target is None:
        target = (real_monitors()[:1] or [None])[0]
        if target is None:
            try:
                mons = monitors()
            except HyprctlError:
                mons = []
            target = next(
                (str(m.get("name", "")) for m in mons
                 if str(m.get("name", "")).startswith("HEADLESS")
                 and str(m.get("name", "")) != monitor),
                None,
            )
    if target is None:
        return
    try:
        workspaces = list_workspaces()
    except HyprctlError as exc:
        log.warning("эвакуация: не удалось получить workspaces: %s", exc)
        return
    for w in workspaces:
        if str(w.get("monitor", "")) != monitor:
            continue
        ws_id = w.get("id", w.get("name", ""))
        if ws_id == "" or ws_id is None:
            continue
        try:
            log.info("эвакуация воркспейса %s с %s → %s", ws_id, monitor, target)
            move_workspace_to_monitor(ws_id, target)
        except HyprctlError as exc:
            log.warning("эвакуация: %s: %s", ws_id, exc)


def cleanup_phantom_outputs() -> list[str]:
    """Удалить фантомные HEADLESS-* выводы. Возвращает список удалённых."""
    removed: list[str] = []
    try:
        mons = monitors()
    except HyprctlError as exc:
        log.warning("cleanup: не удалось получить monitors: %s", exc)
        return removed
    real_monitors = [
        str(m.get("name", "")) for m in mons
        if not str(m.get("name", "")).startswith("HEADLESS")
        and not ("x" in str(m.get("name", "")) and "@" in str(m.get("name", "")))
    ]
    fallback = real_monitors[0] if real_monitors else None
    for m in mons:
        name = str(m.get("name", ""))
        if not name:
            continue
        is_headless = name.startswith("HEADLESS")
        is_mode_like = "x" in name and "@" in name
        if not (is_headless or is_mode_like):
            continue
        target = fallback
        if target is None:
            target = next(
                (str(x.get("name", "")) for x in mons
                 if str(x.get("name", "")).startswith("HEADLESS")
                 and str(x.get("name", "")) != name),
                None,
            )
        _evacuate_workspaces_from_monitor(name, target)
        try:
            log.info("cleanup: удаляем фантомный вывод %s", name)
            output_remove(name)
            removed.append(name)
        except HyprctlError as exc:
            log.warning("cleanup: не удалось удалить %s: %s", name, exc)
    if removed:
        log.info("cleanup: удалено %d фантомных выводов: %s", len(removed), removed)
    return removed


def real_monitors() -> list[str]:
    """Имена физических мониторов (всё, что не HEADLESS-* и не режим-подобное)."""
    names: list[str] = []
    try:
        mons = monitors()
    except HyprctlError:
        return names
    for m in mons:
        name = str(m.get("name", ""))
        if not name or name.startswith("HEADLESS"):
            continue
        if "x" in name and "@" in name:  # выводы, созданные со случайным именем-режимом
            continue
        names.append(name)
    return names


def diagnose() -> None:
    """Диагностика IPC-протокола Hyprland (мониторы определяются динамически)."""
    import os
    print("=== Диагностика IPC Hyprland ===")
    sign = os.environ.get("HYPRLAND_INSTANCE_SIGNATURE", "")
    print(f"  HYPRLAND_INSTANCE_SIGNATURE = {sign!r}")
    try:
        ver = run_raw(["version"])
        print(f"  hyprctl version: {ver[:120]}")
    except HyprctlError as e:
        print(f"  hyprctl version: ОШИБКА: {e}")
    mon_names: list[str] = []
    try:
        mons = monitors()
        mon_names = [str(m.get("name", "")) for m in mons]
        print(f"  мониторы: {', '.join(mon_names) if mon_names else '(нет)'}")
        print(f"  физические: {', '.join(real_monitors()) or '(нет)'}")
        headless = [n for n in mon_names if n.startswith("HEADLESS")]
        print(f"  headless: {', '.join(headless) if headless else '(нет)'}")
    except HyprctlError as e:
        print(f"  hyprctl monitors: ОШИБКА: {e}")
    try:
        raw = run_raw(["-j", "workspaces"])
        print(f"  hyprctl -j workspaces: OK ({len(raw)} байт)")
    except HyprctlError as e:
        print(f"  hyprctl -j workspaces: ОШИБКА: {e}")
    try:
        raw = unkeyword("__hyprscreen_probe__")
        print(f"  hyprctl unkeyword: OK ({raw[:60]!r})")
    except HyprctlError as e:
        print(f"  hyprctl unkeyword: ОШИБКА: {e}")
    print()
    print("--- dispatch ---")
    target = real_monitors()[:1]
    move_target = target[0] if target else (mon_names[0] if mon_names else None)
    probes = [('hl.dsp.focus({ workspace = "1" })', "focus workspace 1")]
    if move_target:
        probes.append(
            (
                f'hl.dsp.workspace.move({{ workspace = "1", monitor = "{move_target}" }})',
                f"workspace.move 1→{move_target}",
            )
        )
    for expr, desc in probes:
        try:
            raw = run_raw(["dispatch", expr])
            print(f"  [{desc:35s}] → {raw[:80]!r}")
        except HyprctlError as e:
            print(f"  [{desc:35s}] → ОШИБКА: {e}")
