package com.example.hyprscreen

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Foreground-сервис, владеющий [ScreenClient] и удерживающий WebSocket живым,
 * пока приложение в фоне.
 *
 * [ConnectActivity] запускает этот сервис с extras `host`/`port`/`screen`;
 * [MainActivity] затем биндится к нему, чтобы читать кадры и слать ввод. Сервис
 * переводит сам себя в foreground с постоянным notification и захватывает
 * partial wake lock, чтобы CPU не засыпал во время стриминга.
 *
 * Жизненный цикл:
 *  - [onStartCommand] → startForeground + connect(host, port, screen)
 *  - активность биндится → [LocalBinder.service] отдаёт [client]
 *  - пользователь жмёт «Отключиться» → [disconnect]
 *  - [onDestroy] → всё снести
 *
 * XML-ресурсы НЕ используются: иконка notification разрешается в рантайме
 * по имени из таблицы platform drawable (приложение не поставляет собственных
 * иконок), текст notification строится из инлайн-строковых литералов.
 *
 * Мульти-экранность: extras `screen` (0..N-1) пробрасывается в
 * [ScreenClient.connect] → формирует URL `ws://<host>:<port>/<screen>`.
 *
 * Wake lock: захватывается без таймаута (исправление бага аудита #22 —
 * 12-часовой таймаут мог отпустить wakelock посреди долгой сессии). Явный
 * release делается в [disconnect] и [onDestroy].
 */
class ScreenStreamService : Service() {

    /** Binder, отдающий сервис связанной активности. */
    inner class LocalBinder : Binder() {
        val service: ScreenStreamService get() = this@ScreenStreamService
    }

    private val binder = LocalBinder()

    /** WebSocket-клиент, которым владеет этот сервис. */
    val client: ScreenClient by lazy {
        ScreenClient(client = okHttpClient)
    }

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .pingInterval(20, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    private var wakeLock: PowerManager.WakeLock? = null
    @Volatile private var currentHost: String? = null
    @Volatile private var currentPort: Int = 8765
    @Volatile private var currentScreen: Int = 0

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, WAKE_TAG).apply { setReferenceCounted(false) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_DISCONNECT) {
            disconnect()
            return START_NOT_STICKY
        }
        val host = intent?.getStringExtra(EXTRA_HOST)
        val port = intent?.getIntExtra(EXTRA_PORT, 8765) ?: 8765
        val screen = intent?.getIntExtra(EXTRA_SCREEN, 0) ?: 0
        val authToken = intent?.getStringExtra(EXTRA_AUTH_TOKEN)
        if (host.isNullOrBlank()) {
            Log.w(TAG, "onStartCommand без host extra — останавливаюсь")
            stopSelf()
            return START_NOT_STICKY
        }
        currentHost = host
        currentPort = port
        currentScreen = screen
        startForeground(NOTIF_ID, buildNotification(host, port, screen))
        // Без таймаута: держим до явного disconnect/onDestroy (баг аудита #22).
        wakeLock?.takeIf { !it.isHeld }?.acquire()
        client.connect(host, port, screen, authToken)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    /** Отключиться от сервера и остановить foreground-сервис. */
    fun disconnect() {
        Log.i(TAG, "disconnect()")
        client.disconnect()
        wakeLock?.runCatching { if (isHeld) release() }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        client.disconnect()
        wakeLock?.runCatching { if (isHeld) release() }
        wakeLock = null
        super.onDestroy()
    }

    private fun buildNotification(host: String, port: Int, screen: Int): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPi = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val disconnectIntent = Intent(this, ScreenStreamService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val disconnectPi = PendingIntent.getService(
            this, 1, disconnectIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(NOTIF_TITLE)
            .setContentText("Стрим с $host:$port экран $screen")
            // Иконка notification разрешается по имени из таблицы platform
            // drawable — приложение не поставляет собственных иконок.
            .setSmallIcon(platformNotificationIcon())
            .setContentIntent(openPi)
            .addAction(0, ACTION_LABEL_DISCONNECT, disconnectPi)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                NOTIF_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = NOTIF_CHANNEL_NAME
                setShowBadge(false)
            }
            nm.createNotificationChannel(channel)
        }
    }

    /**
     * Разрешает platform-иконку notification по имени. Перебирает несколько
     * известных platform drawable по порядку и возвращает первый существующий.
     * Это избавляет приложение от поставки собственных иконок, но всё равно
     * даёт notification осмысленный small icon. Все четыре имени существуют
     * с API 1, поэтому fallback на иконку приложения в конце — чисто
     * защитный.
     */
    private fun platformNotificationIcon(): Int {
        val names = listOf(
            "stat_sys_data_bluetooth",
            "stat_notify_sync",
            "stat_sys_download",
            "ic_dialog_info"
        )
        for (name in names) {
            val id = resources.getIdentifier(name, "drawable", "android")
            if (id != 0) return id
        }
        // Защитный fallback: иконка приложения (всегда задаётся шаблоном
        // Android Studio через android:icon на <application>).
        return applicationInfo.icon
    }

    companion object {
        private const val TAG = "HyprScreen/Service"
        private const val NOTIF_ID = 0x101
        private const val CHANNEL_ID = "hyprscreen_connection"
        private const val WAKE_TAG = "hyprscreen::stream"

        // Инлайн-строковые литералы — РУССКИЙ UI. Эта версия приложения
        // не поставляет string-ресурсов.
        private const val NOTIF_TITLE = "HyprScreen активен"
        private const val NOTIF_CHANNEL_NAME = "Активное соединение"
        private const val ACTION_LABEL_DISCONNECT = "Отключиться"

        const val EXTRA_HOST = "host"
        const val EXTRA_PORT = "port"
        const val EXTRA_SCREEN = "screen"
        const val EXTRA_AUTH_TOKEN = "auth_token"
        const val ACTION_DISCONNECT = "com.example.hyprscreen.action.DISCONNECT"
    }
}
