"""State-файл для межзапусковой координации PC-стороны HyprScreen.

Сервер при старте пишет сюда pid/порт/экран (``write_state``), в процессе
работы дописывает счётчик клиентов и ошибки захвата (``update_state``) —
это читают GUI и CLI (``hyprscreen status --json``). При остановке файл
удаляется (``clear_state``). Формат — JSON, атомарная запись (tmp +
os.replace): читатель никогда не видит наполовину записанный файл.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from pathlib import Path
from typing import Any

log = logging.getLogger("hyprscreen.state")

#: Сервер пишет state из НЕСКОЛЬКИХ потоков (set_clients при подключении
#: клиентов, state_refresher каждые 2 с) — read-modify-write в update_state
#: должен быть атомарным, иначе клиенты «теряются»/дублируются, а два потока
#: могут одновременно писать в один и тот же tmp-файл.
_LOCK = threading.Lock()

#: Предупреждения о недоступном state-файле — не чаще раза в минуту.
_WARN_MIN_INTERVAL = 60.0
_last_warn_ts = 0.0


def _warn_throttled(msg: str, *args: Any) -> None:
    global _last_warn_ts
    now = time.monotonic()
    if now - _last_warn_ts >= _WARN_MIN_INTERVAL:
        _last_warn_ts = now
        log.warning(msg, *args)


def state_path() -> Path:
    cache = os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache"))
    return Path(cache) / "hyprscreen" / "state.json"


def _write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def write_state(data: dict[str, Any]) -> None:
    """Записать состояние сервера (заменяет файл целиком)."""
    path = state_path()
    try:
        with _LOCK:
            _write_json(path, data)
    except OSError as exc:
        _warn_throttled("не удалось записать state-файл %s: %s", path, exc)


def update_state(**kwargs: Any) -> None:
    """Дописать/обновить ключи, не трогая остальное.

    Атомарно в пределах процесса (через _LOCK): read-modify-write без
    блокировки терял обновления при одновременной записи из двух потоков.
    Межпроцессная гонка (CLI ↔ сервер) не фатальна: os.replace атомарен,
    читатель всегда видит цельный JSON.
    """
    path = state_path()
    try:
        with _LOCK:
            data = read_state() or {}
            data.update(kwargs)
            _write_json(path, data)
    except OSError as exc:
        _warn_throttled("не удалось обновить state-файл %s: %s", path, exc)


def read_state() -> dict[str, Any] | None:
    path = state_path()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except (OSError, json.JSONDecodeError) as exc:
        _warn_throttled("не удалось прочитать state-файл %s: %s", path, exc)
    return None


def clear_state() -> None:
    path = state_path()
    try:
        if path.exists():
            path.unlink()
    except OSError as exc:
        _warn_throttled("не удалось удалить state-файл %s: %s", path, exc)


def _pid_is_hyprscreen(pid: int) -> bool:
    """True — в /proc/<pid>/cmdline виден наш сервер.

    Защита от ПЕРЕИСПОЛЬЗОВАНИЯ PID (3.9.1): устаревший state.json с номером
    процесса, который ОС выдала посторонней программе, делал PID «вечно
    живым» — GUI показывал «Сервер уже работает (pid N)», кнопка «Стоп»
    отправляла SIGTERM невиновному, а сервер при этом не запускался
    («сервер не останавливается в GUI»). Наш сервер всегда виден в cmdline
    (python .../server.py, main.py serve, hyprscreen ...).
    """
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as fh:
            cmd = fh.read().decode("utf-8", "replace")
    except OSError:
        return False  # процесс чужой или уже исчез — это не наш сервер
    return ("hyprscreen" in cmd or "server.py" in cmd or "main.py" in cmd)


def state_pid_alive() -> int | None:
    """pid живого сервера hyprscreen из state-файла или None.

    Проверка ОС (os.kill 0) дополнена сверкой cmdline: переиспользованный
    PID постороннего процесса больше не считается живым сервером.
    """
    state = read_state()
    if not state:
        return None
    try:
        pid = int(state.get("pid"))
    except (TypeError, ValueError):
        return None
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return None
    except PermissionError:
        pass  # жив, но, возможно, чужой — решит проверка cmdline
    return pid if _pid_is_hyprscreen(pid) else None
