@file:Suppress("SpellCheckingInspection") // HyprScreen/keysym — не опечатки

package com.example.hyprscreen

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

/**
 * Экран настройки: ввести host/port, выбрать экран PC, тапнуть по сохранённому
 * или обнаруженному хосту, подключиться.
 *
 * При нажатии «Подключиться» запускается [ScreenStreamService] (он владеет
 * WebSocket-клиентом) и показывается [MainActivity], который биндится к сервису.
 *
 * Мульти-экранность (PROTOCOL.md §1, §2):
 *  - Если выбранный обнаруженный хост анонсирует `screens=N`, UI показывает
 *    чипы «Экран 1» … «Экран N» для выбора индекса (0..N-1).
 *  - Тап по сохранённому хосту подставляет host+port+screen из истории.
 *  - Выбранный индекс прокидывается extras=screen в [ScreenStreamService],
 *    тот формирует URL `ws://<host>:<port>/<screen>`.
 *
 * UI строится целиком в коде ([buildUi]) — никаких XML-лейаутов, ViewBinding
 * и `R.*`-ссылок. Каждая строка в списках сохранённых/обнаруженных хостов —
 * карточка с изумрудной точкой и platform-ripple (`foreground`), разрешённым
 * через `android.R.attr.selectableItemBackground`.
 *
 * 2.1.0: единый стиль «чёрный + изумруд» ([UiTheme]) — раньше палитра была
 * разнородной (teal + сланец), поля ввода и кнопка были дефолтными Material.
 *
 * Все строковые литералы — русские (требование «плоского одного пакета»:
 * приложение не поставляет строковых ресурсов платформы Android).
 */
class ConnectActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var discovery: Discovery

    private lateinit var hostInput: EditText
    private lateinit var portInput: EditText
    private lateinit var screenInput: EditText
    private lateinit var tokenInput: EditText
    private lateinit var screenChipsContainer: LinearLayout
    private lateinit var screenHint: TextView
    private lateinit var connectButton: Button
    private lateinit var statusText: TextView

    private lateinit var discoveredEmpty: TextView
    private lateinit var discoveredHostsContainer: LinearLayout
    private lateinit var savedEmpty: TextView
    private lateinit var savedHostsContainer: LinearLayout

    /** Текущий выбранный индекс экрана (0-based). По умолчанию 0. */
    private var selectedScreen: Int = 0
    /** Известное число экранов PC (по последнему выбранному обнаруженному хосту). */
    private var availableScreens: Int = 1

    /** Лаунчер запроса runtime-разрешения POST_NOTIFICATIONS (Android 13+, баг аудита #27). */
    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* результат игнорируем: сервис работает и без разрешения */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())

        prefs = Prefs(this)
        discovery = Discovery()

        connectButton.setOnClickListener { onConnectClicked() }

        renderSavedHosts()
        renderDiscoveredHosts(emptyList())
        rebuildScreenChips()

        // Предзаполнение из последнего хоста (IP, порт, экран, токен).
        prefs.savedHosts.firstOrNull()?.let { h ->
            hostInput.setText(h.host)
            portInput.setText(h.port.toString())
            screenInput.setText(h.screen.toString())
            selectedScreen = h.screen
            h.token?.let { tokenInput.setText(it) }
            statusText.text = "Последний: ${h.host}:${h.port}"
        }

        // Наблюдаем discovery-анонсы
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                discovery.hosts.collect { hosts -> renderDiscoveredHosts(hosts) }
            }
        }

        // Запрос POST_NOTIFICATIONS на Android 13+ (баг аудита #27 — без него
        // notification foreground-сервиса не виден, хотя сам сервис работает).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { finishAffinity() }
        })
    }

    override fun onStart() {
        super.onStart()
        discovery.start()
    }

    override fun onStop() {
        super.onStop()
        discovery.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        discovery.stop()
    }

    private fun onConnectClicked() {
        val host = hostInput.text?.toString()?.trim().orEmpty()
        val portStr = portInput.text?.toString()?.trim().orEmpty()
        if (host.isEmpty()) {
            statusText.text = "Введите адрес хоста"
            hostInput.requestFocus()
            return
        }
        // Невалидный порт раньше молча подменялся на 8765 и пользователь
        // подключался «не туда» — теперь ошибка видна.
        val port = portStr.toIntOrNull()
        if (port == null || port !in 1..65535) {
            statusText.text = "Порт должен быть числом 1–65535"
            portInput.requestFocus()
            return
        }
        // Индекс экрана — из поля ввода (оно синхронизировано с чипами).
        val screen = screenInput.text?.toString()?.trim()?.toIntOrNull()
            ?.coerceAtLeast(0) ?: 0
        val token = tokenInput.text?.toString()?.trim().orEmpty()
        connectTo(host, port, screen, name = null, authToken = token.ifBlank { null })
    }

    /**
     * Запустить foreground-сервис с extras host/port/screen и открыть MainActivity.
     * MainActivity получает screen/totalScreens через intent-extras.
     */
    private fun connectTo(host: String, port: Int, screen: Int, name: String?, authToken: String? = null) {
        prefs.saveHost(host, port, name, screen, authToken)
        statusText.text = "Подключение к $host:$port экран $screen…"

        val intent = Intent(this, ScreenStreamService::class.java).apply {
            putExtra(ScreenStreamService.EXTRA_HOST, host)
            putExtra(ScreenStreamService.EXTRA_PORT, port)
            putExtra(ScreenStreamService.EXTRA_SCREEN, screen)
            if (authToken != null) putExtra(ScreenStreamService.EXTRA_AUTH_TOKEN, authToken)
        }
        ContextCompat.startForegroundService(this, intent)

        // MainActivity покажет «Экран N/M». M (totalScreens) становится точно
        // известен из hello, но если пользователь подключался через discovery,
        // мы уже знаем его заранее — передаём, чтобы оверлей был корректен
        // ещё до прихода hello.
        val main = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(MainActivity.EXTRA_SCREEN, screen)
            putExtra(MainActivity.EXTRA_TOTAL_SCREENS, availableScreens)
        }
        startActivity(main)
    }

    /** Перерисовать список сохранённых хостов из [Prefs]. */
    private fun renderSavedHosts() {
        val hosts = prefs.savedHosts
        savedHostsContainer.removeAllViews()
        savedEmpty.visibility = if (hosts.isEmpty()) View.VISIBLE else View.GONE
        for (host in hosts) {
            savedHostsContainer.addView(buildHostRow(host))
        }
    }

    /** Перерисовать список обнаруженных хостов из flow [Discovery]. */
    private fun renderDiscoveredHosts(hosts: List<DiscoveredHost>) {
        discoveredHostsContainer.removeAllViews()
        discoveredEmpty.visibility = if (hosts.isEmpty()) View.VISIBLE else View.GONE
        for (host in hosts) {
            discoveredHostsContainer.addView(buildDiscoveredRow(host))
        }
    }

    /** Программно построить строку сохранённого хоста. */
    private fun buildHostRow(host: SavedHost): View = makeHostRow(
        title = host.name ?: host.host,
        subtitle = "${host.host}:${host.port}  ·  экран ${host.screen}",
        onClick = {
            // Подставляем host/port/screen/token из истории.
            hostInput.setText(host.host)
            portInput.setText(host.port.toString())
            screenInput.setText(host.screen.toString())
            selectedScreen = host.screen
            tokenInput.setText(host.token ?: "")
            // Скрываем чипы (нам не известно, сколько экранов у PC сейчас).
            availableScreens = 1
            rebuildScreenChips()
            screenHint.text = "Экран: ${host.screen}"
        },
        onLongClick = {
            prefs.removeHost(host.host, host.port)
            renderSavedHosts()
            Toast.makeText(this, "Удалён ${host.host}:${host.port}", Toast.LENGTH_SHORT).show()
            true
        }
    )

    private fun buildDiscoveredRow(host: DiscoveredHost): View = makeHostRow(
        title = host.name,
        subtitle = "${host.host}:${host.port}  ·  экранов: ${host.screens}",
        onClick = {
            // Подставляем host/port; экран по умолчанию 0; показываем чипы.
            hostInput.setText(host.host)
            portInput.setText(host.port.toString())
            availableScreens = host.screens.coerceAtLeast(1)
            selectedScreen = 0
            screenInput.setText("0")
            rebuildScreenChips()
            screenHint.text = "Доступно экранов: ${host.screens}"
        },
        onLongClick = { false }
    )

    /** Общий строитель строки хоста — карточка с изумрудной точкой и двумя TextView (2.1.0). */
    private fun makeHostRow(
        title: String,
        subtitle: String,
        onClick: () -> Unit,
        onLongClick: () -> Boolean
    ): View {
        val density = resources.displayMetrics.density
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = UiTheme.card(density)
            isClickable = true
            isFocusable = true
            // Platform ripple поверх карточки — без зависимости от app drawable.
            val outValue = TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackground, outValue, true)
            foreground = ContextCompat.getDrawable(context, outValue.resourceId)
        }
        // Изумрудная точка-индикатор слева от названия хоста.
        val dot = View(this).apply {
            val sz = dp(8)
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                gravity = android.view.Gravity.CENTER_VERTICAL
                marginEnd = dp(10)
            }
            background = UiTheme.rounded(UiTheme.EMERALD, 4f, density)
        }
        row.addView(dot)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val titleView = TextView(this).apply {
            text = title
            setTextColor(UiTheme.TEXT)
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val subtitleView = TextView(this).apply {
            text = subtitle
            setTextColor(UiTheme.TEXT_DIM)
            textSize = 12f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(2)
            layoutParams = lp
        }
        col.addView(titleView)
        col.addView(subtitleView)
        row.addView(col)
        row.setOnClickListener { onClick() }
        row.setOnLongClickListener { onLongClick() }

        // Равномерный отступ между карточками в вертикальных списках.
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(8)
        row.layoutParams = lp
        return row
    }

    /**
     * Перестроить чипы выбора экрана. Если доступен только 1 экран — чипы
     * скрываются, остаётся только числовое поле. Если 2 и более — рисуем
     * «Экран 1» … «Экран N», активный чип подсвечиваем.
     */
    private fun rebuildScreenChips() {
        screenChipsContainer.removeAllViews()
        if (availableScreens <= 1) {
            screenChipsContainer.visibility = View.GONE
            return
        }
        screenChipsContainer.visibility = View.VISIBLE
        for (i in 0 until availableScreens) {
            val density = resources.displayMetrics.density
            val chip = Button(this).apply {
                text = "Экран ${i + 1}"   // пользователь видит 1-based
                isAllCaps = false
                minWidth = 0
                minimumWidth = 0
                stateListAnimator = null
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(dp(18), dp(9), dp(18), dp(9))
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = dp(8)
                layoutParams = lp
                if (i == selectedScreen) {
                    background = UiTheme.rounded(UiTheme.EMERALD, 20f, density)
                    setTextColor(UiTheme.ON_EMERALD)
                } else {
                    background = UiTheme.rounded(UiTheme.CARD, 20f, density, UiTheme.BORDER, 1f)
                    setTextColor(UiTheme.TEXT_DIM)
                }
            }
            chip.setOnClickListener {
                selectedScreen = i
                screenInput.setText(i.toString())
                rebuildScreenChips()
            }
            screenChipsContainer.addView(chip)
        }
    }

    // ----- UI построен целиком в коде (без XML-лейаутов) -----------------

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).toInt()

    /** Единый вид поля ввода: тёмная карточка с рамкой (2.1.0). */
    private fun styleInput(et: EditText) {
        et.setTextColor(UiTheme.TEXT)
        et.setHintTextColor(UiTheme.TEXT_HINT)
        et.background = UiTheme.input(resources.displayMetrics.density)
        et.setPadding(dp(14), dp(13), dp(14), dp(13))
    }

    private fun buildUi(): View {
        val root = ScrollView(this).apply {
            setBackgroundColor(UiTheme.BG)
            isFillViewport = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
        }

        // Заголовок: «Hypr» белым, «Screen» изумрудным (как на док-странице).
        val title = TextView(this).apply {
            val t = SpannableString("HyprScreen")
            t.setSpan(
                ForegroundColorSpan(UiTheme.EMERALD_BRIGHT), 4, 10,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            text = t
            setTextColor(UiTheme.TEXT)
            textSize = 34f
            letterSpacing = -0.02f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        col.addView(title)

        val subtitle = TextView(this).apply {
            text = "Превратите это устройство в беспроводной второй экран для вашего Hyprland-PC."
            setTextColor(UiTheme.TEXT_DIM)
            textSize = 14f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(4)
            layoutParams = lp
        }
        col.addView(subtitle)

        hostInput = EditText(this).apply {
            hint = "Адрес / IP PC"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
            styleInput(this)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(28)
            layoutParams = lp
        }
        col.addView(hostInput)

        portInput = EditText(this).apply {
            hint = "Порт"
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine()
            setText("8765")
            styleInput(this)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(12)
            layoutParams = lp
        }
        col.addView(portInput)

        tokenInput = EditText(this).apply {
            hint = "Токен авторизации (необязательно)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
            styleInput(this)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(12)
            layoutParams = lp
        }
        col.addView(tokenInput)

        // Метка раздела выбора экрана.
        col.addView(makeSectionLabel("Экран", topMargin = dp(20)))
        screenHint = TextView(this).apply {
            text = "Индекс экрана PC (0..N-1). По умолчанию 0."
            setTextColor(UiTheme.TEXT_DIM)
            textSize = 12f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(2)
            layoutParams = lp
        }
        col.addView(screenHint)

        // Контейнер чипов «Экран 1» / «Экран 2» / …
        screenChipsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8)
            layoutParams = lp
        }
        col.addView(screenChipsContainer)

        // Числовое поле ввода (manual fallback, синхронизировано с чипами).
        screenInput = EditText(this).apply {
            hint = "Индекс экрана (0, 1, …)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine()
            setText("0")
            styleInput(this)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8)
            layoutParams = lp
        }
        col.addView(screenInput)

        // 2.1.0: изумрудная кнопка-пилюля вместо дефолтной Material.
        connectButton = Button(this).apply {
            text = "Подключиться"
            isAllCaps = false
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(UiTheme.ON_EMERALD)
            stateListAnimator = null
            background = UiTheme.buttonAccent(resources.displayMetrics.density)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(20)
            layoutParams = lp
        }
        col.addView(connectButton)

        statusText = TextView(this).apply {
            setTextColor(UiTheme.TEXT_DIM)
            textSize = 13f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(12)
            layoutParams = lp
        }
        col.addView(statusText)

        col.addView(makeSectionLabel("Обнаруженные PC", topMargin = dp(28)))
        discoveredEmpty = TextView(this).apply {
            text = "Поиск PC в вашей сети…"
            setTextColor(UiTheme.TEXT_HINT)
            textSize = 13f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(6)
            layoutParams = lp
        }
        col.addView(discoveredEmpty)
        discoveredHostsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        col.addView(discoveredHostsContainer)

        col.addView(makeSectionLabel("Недавние хосты", topMargin = dp(28)))
        savedEmpty = TextView(this).apply {
            text = "Сохранённых хостов пока нет."
            setTextColor(UiTheme.TEXT_HINT)
            textSize = 13f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(6)
            layoutParams = lp
        }
        col.addView(savedEmpty)
        savedHostsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        col.addView(savedHostsContainer)

        root.addView(col)
        return root
    }

    private fun makeSectionLabel(text: String, topMargin: Int): TextView =
        TextView(this).apply {
            this.text = text
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = topMargin
            layoutParams = lp
            UiTheme.styleSectionLabel(this)
        }
}
