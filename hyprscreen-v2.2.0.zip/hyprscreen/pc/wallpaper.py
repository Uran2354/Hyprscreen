"""Обои для экрана телефона (headless-вывода Hyprland).

Телефонный воркспейс пуст, поэтому на нём видны обои. ``swww`` хранит
картинку на КАЖДОМ выводе отдельно, так что можно поставить обои только
на HEADLESS-*, не трогая физический монитор.

Каталог по умолчанию — ``~/Обои`` (пользовательский; меняется в GUI).
«Без обоев» заливает вывод чёрным: генерируется 1×1 PNG, swww растягивает
его на весь экран (своего «очистить» у swww нет).

Использование::

    import wallpaper
    files = wallpaper.list_wallpapers("~/Обои")
    ok, msg = wallpaper.apply(files[0], ["HEADLESS-1"])
    ok, msg = wallpaper.clear(["HEADLESS-1"])          # чёрный
"""

from __future__ import annotations

import logging
import os
import shutil
import struct
import subprocess
import zlib
from pathlib import Path

log = logging.getLogger(__name__)

#: Каталог обоев по умолчанию: ``~/Обои``.
DEFAULT_DIR = "~/Обои"

#: Расширения, которые понимает swww.
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"}

#: Подпись пункта «без обоев» в GUI/меню.
NO_WALLPAPER = "— без обоев (чёрный) —"


def default_dir() -> str:
    """Каталог обоев по умолчанию (``~/Обои``)."""
    return DEFAULT_DIR


def list_wallpapers(directory: str, limit: int = 500) -> list[str]:
    """Список картинок в каталоге (рекурсивно, отсортировано по пути)."""
    d = Path(os.path.expanduser(directory))
    if not d.is_dir():
        return []
    files: list[str] = []
    for p in sorted(d.rglob("*")):
        if p.is_file() and p.suffix.lower() in IMAGE_EXTS:
            files.append(str(p))
            if len(files) >= limit:
                log.info("list_wallpapers: показаны первые %d файлов", limit)
                break
    return files


def swww_available() -> bool:
    """Установлен ли swww."""
    return shutil.which("swww") is not None


def _black_png_bytes() -> bytes:
    """Минимальный валидный 1×1 чёрный PNG (собирается на месте)."""

    def chunk(tag: bytes, data: bytes) -> bytes:
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    ihdr = struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0)  # 1x1, 8 бит, RGB
    idat = zlib.compress(b"\x00\x00\x00\x00")  # фильтр 0 + пиксель (0,0,0)
    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", ihdr)
        + chunk(b"IDAT", idat)
        + chunk(b"IEND", b"")
    )


def _black_png_file() -> str:
    """Путь к кэшированному чёрному PNG (``~/.cache/hyprscreen/black.png``)."""
    cache = os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache"))
    d = Path(cache) / "hyprscreen"
    d.mkdir(parents=True, exist_ok=True)
    p = d / "black.png"
    if not p.exists():
        p.write_bytes(_black_png_bytes())
    return str(p)


def apply(path: str | None, outputs: list[str]) -> tuple[bool, str]:
    """Поставить обои на перечисленные headless-выводы.

    ``path=None`` — залить чёрным («без обоев»). Возвращает
    ``(успех, сообщение для GUI/лога)``; физические мониторы не
    затрагиваются.

    Если swww не установлен — пробуем hyprpaper (он часто уже
    стоит с Hyprland). Если нет ни того, ни другого — на headless-выводе
    виден пустой стол (выглядит как чёрный экран), сообщение об этом
    возвращается вызывающему.
    """
    if not outputs:
        return False, "нет headless-выводов — сначала запустите сервер"
    if not swww_available():
        return _apply_hyprpaper(path, outputs)
    if path is None:
        target = _black_png_file()
        title = "чёрный (без обоев)"
    else:
        target = os.path.expanduser(str(path))
        if not os.path.isfile(target):
            return False, f"файл не найден: {target}"
        title = os.path.basename(target)
    errors: list[str] = []
    for out in outputs:
        try:
            proc = subprocess.run(
                ["swww", "img", "-o", out, "--resize", "crop", target],
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=10,
            )
            if proc.returncode != 0:
                err = (proc.stderr or proc.stdout or "").strip()
                errors.append(f"{out}: {err or f'код {proc.returncode}'}")
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{out}: {exc}")
    if errors:
        hint = ""
        if any("daemon" in e.lower() or "not init" in e.lower() for e in errors):
            hint = " (swww-daemon не запущен? выполните: swww init)"
        msg = "не удалось: " + "; ".join(errors) + hint
        log.warning("обои: %s", msg)
        return False, msg
    msg = f"обои применены: {title} → {', '.join(outputs)}"
    log.info("обои: %s", msg)
    return True, msg


def clear(outputs: list[str]) -> tuple[bool, str]:
    """Залить headless-выводы чёрным (= «без обоев»)."""
    return apply(None, outputs)


def _apply_hyprpaper(path: str | None, outputs: list[str]) -> tuple[bool, str]:
    """Fallback-обои через hyprpaper (когда swww не установлен)."""
    if shutil.which("hyprctl") is None:
        return False, (
            "нет ни swww, ни hyprpaper: sudo pacman -S swww. Без обоев "
            "на телефоне виден пустой стол (чёрный экран) — это НЕ сбой стрима"
        )
    target = _black_png_file() if path is None else os.path.expanduser(str(path))
    if not os.path.isfile(target):
        return False, f"файл не найден: {target}"
    errors: list[str] = []
    for out in outputs:
        try:
            subprocess.run(
                ["hyprctl", "hyprpaper", "preload", target],
                check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, timeout=10,
            )
            proc = subprocess.run(
                ["hyprctl", "hyprpaper", "wallpaper", f"{out},{target}"],
                check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, timeout=10,
            )
            if proc.returncode != 0:
                err = (proc.stderr or proc.stdout or "").strip()
                errors.append(f"{out}: {err or f'код {proc.returncode}'}")
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{out}: {exc}")
    if errors:
        msg = "hyprpaper: не удалось: " + "; ".join(errors)
        log.warning("обои: %s", msg)
        return False, msg
    msg = f"обои применены (hyprpaper): {os.path.basename(target)} → {', '.join(outputs)}"
    log.info("обои: %s", msg)
    return True, msg
