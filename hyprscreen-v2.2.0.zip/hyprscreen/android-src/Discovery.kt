@file:Suppress("SpellCheckingInspection") // HyprScreen — не опечатка

package com.example.hyprscreen

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException

/**
 * Слушает discovery-анонсы, которые PC рассылает по UDP (PROTOCOL.md §5).
 *
 * Python-сервер каждые ~2 секунды шлёт датаграмму на порт [DEFAULT_PORT] (8766)
 * с JSON `{"hyprscreen":true,"host":"<ip>","port":8765,"screens":N,"name":"<hostname>"}`.
 * Поле `screens` показывает, сколько экранов отдаёт PC (мульти-экранный режим).
 *
 * Обнаруженные хранятся в [StateFlow]; коллекторы (экран подключения)
 * обновляют список по мере поступления анонсов.
 *
 * Сокет открывается с `reuseAddress = true`, чтобы быстрый перезапуск приложения
 * не падал с `BindException` (когда предыдущий сокет ещё в TIME_WAIT).
 * `broadcast = true` здесь оставлен для совместимости (безвредно на receive-сокете).
 */
class Discovery(
    private val port: Int = DEFAULT_PORT,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
) {

    private val _hosts = MutableStateFlow<List<DiscoveredHost>>(emptyList())
    val hosts: StateFlow<List<DiscoveredHost>> = _hosts.asStateFlow()

    private val json = Json { ignoreUnknownKeys = true }
    private var listenJob: Job? = null
    @Volatile private var socket: DatagramSocket? = null

    /** Начать слушать broadcast. Безопасно вызывать многократно. */
    fun start() {
        if (listenJob?.isActive == true) return
        listenJob = scope.launch { runListener() }
    }

    /** Остановить слушатель и освободить UDP-сокет. */
    fun stop() {
        listenJob?.cancel()
        listenJob = null
        socket?.runCatching { close() }
        socket = null
    }

    /** Очистить список обнаруженных хостов в памяти. */
    fun clear() {
        _hosts.value = emptyList()
    }

    private suspend fun runListener() = withContext(Dispatchers.IO) {
        try {
            val s = DatagramSocket(null).apply {
                reuseAddress = true   // переживает быстрый перезапуск приложения
                bind(java.net.InetSocketAddress(port))
                soTimeout = RECEIVE_TIMEOUT_MS
                broadcast = true
            }
            socket = s
            Log.i(TAG, "Discovery слушает UDP $port")
            val buf = ByteArray(2048)
            while (isActive) {
                val packet = DatagramPacket(buf, buf.size)
                try {
                    s.receive(packet)
                } catch (_: SocketTimeoutException) {
                    continue
                }
                handlePacket(packet.data, packet.length, packet.address)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Ошибка слушателя Discovery", e)
        } finally {
            socket?.runCatching { close() }
            socket = null
        }
    }

    private fun handlePacket(data: ByteArray, length: Int, from: InetAddress) {
        val text = String(data, 0, length).trim()
        val msg = runCatching {
            json.decodeFromString<DiscoveryAnnouncement>(text)
        }.getOrNull() ?: return
        if (!msg.hyprscreen) return
        val resolvedHost = msg.host.ifBlank { from.hostAddress ?: return }
        val host = DiscoveredHost(
            host = resolvedHost,
            port = msg.port,
            name = msg.name,
            screens = msg.screens.coerceAtLeast(1)
        )
        Log.i(TAG, "Обнаружен: $host")
        _hosts.update { existing ->
            val others = existing.filterNot { it.host == host.host && it.port == host.port }
            others + host
        }
    }

    companion object {
        private const val TAG = "HyprScreen/Discovery"
        const val DEFAULT_PORT = 8766
        private const val RECEIVE_TIMEOUT_MS = 1500
    }
}
