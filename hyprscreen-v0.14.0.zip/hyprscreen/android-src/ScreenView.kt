package com.example.hyprscreen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/**
 * Custom View, рисующий последний JPEG-кадр, полученный от PC.
 *
 * Отрисовка — «fit-center»: исходный bitmap масштабируется равномерно (с
 * сохранением соотношения сторон) и центрируется внутри View, оставляя
 * letterbox-полосы там, где соотношения сторон не совпадают. Та же самая
 * [drawMatrix] инвертируется и даёт [viewToSource], который [TouchHandler]
 * использует для перевода координат пальца обратно в пиксели источника.
 *
 * Кадры публикуются [ScreenClient] через [updateBitmap], который атомарно
 * меняет ссылку [currentBitmap] и зовёт [invalidate]. Отрисовка читает
 * последний bitmap без дальнейшей синхронизации — `@Volatile` даёт нам
 * безопасную публикацию.
 *
 * [StatusOverlay] рисуется поверх в левом-нижнем углу, поэтому активности
 * не нужен отдельный overlay-View.
 *
 * Размер источника (`srcWidth`/`srcHeight`) устанавливается из hello-полей
 * `width`/`height` [ServerInfo] (см. [MainActivity.onHello]). Это устраняет
 * баг аудита #1: при любом non-1080p разрешении инверсная матрица корректна.
 */
class ScreenView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    @Volatile private var currentBitmap: Bitmap? = null

    private val srcRect = RectF()
    private val dstRect = RectF()
    private val drawMatrix = Matrix()
    private val inverseMatrix = Matrix()

    private var srcWidth = 1920
    private var srcHeight = 1080
    private var matrixDirty = true

    private val bgPaint = Paint().apply { color = Color.BLACK }
    private val bmpPaint = Paint().apply {
        isFilterBitmap = true
        isDither = true
    }

    private val overlay = StatusOverlay()

    /** Установить размер источника из hello-сообщения. */
    fun setSourceSize(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        if (w == srcWidth && h == srcHeight) return
        srcWidth = w
        srcHeight = h
        matrixDirty = true
        invalidate()
    }

    /** Атомарно подменить последний декодированный bitmap и попросить перерисовку. */
    fun updateBitmap(bitmap: Bitmap) {
        currentBitmap = bitmap
        invalidate()
    }

    /** Обновить текст оверлея FPS/latency в углу. */
    fun setOverlayText(text: String) {
        overlay.setText(text)
        invalidate()
    }

    /** Показать или скрыть оверлей. */
    fun setOverlayVisible(visible: Boolean) {
        overlay.setVisible(visible)
        invalidate()
    }

    /**
     * Перевести точку из координат View в пиксели источника.
     * Возвращает массив из двух float: [x, y] в пикселях источника.
     */
    fun viewToSource(x: Float, y: Float): FloatArray {
        ensureMatrix()
        val pts = floatArrayOf(x, y)
        inverseMatrix.mapPoints(pts)
        // Ограничиваем границами источника, чтобы касания вне letterbox
        // оставались корректными.
        pts[0] = pts[0].coerceIn(0f, srcWidth.toFloat())
        pts[1] = pts[1].coerceIn(0f, srcHeight.toFloat())
        return pts
    }

    private fun ensureMatrix() {
        if (!matrixDirty) return
        if (width == 0 || height == 0) return
        srcRect.set(0f, 0f, srcWidth.toFloat(), srcHeight.toFloat())
        dstRect.set(0f, 0f, width.toFloat(), height.toFloat())
        drawMatrix.setRectToRect(srcRect, dstRect, Matrix.ScaleToFit.CENTER)
        drawMatrix.invert(inverseMatrix)
        matrixDirty = false
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        matrixDirty = true
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        val bmp = currentBitmap ?: return
        ensureMatrix()
        canvas.drawBitmap(bmp, drawMatrix, bmpPaint)
        overlay.draw(canvas, width, height)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        currentBitmap = null
    }
}
