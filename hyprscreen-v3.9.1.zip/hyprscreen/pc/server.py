#!/usr/bin/env python3
"""hyprscreen — HTTP-сервер трансляции экрана (MJPEG) + клавиатура с телефона.

Зеркало ЗАКРЕПЛЁННОГО воркспейса Hyprland на телефон/планшет/браузер:

  GET  /              — страница-просмотрщик (полноэкранная картинка)
  GET  /stream.mjpeg  — поток multipart/x-mixed-replace
  GET  /info          — JSON о сервере (монитор/fps/качество/клиенты)
  GET  /status        — JSON-статус
  POST /key           — {"keysym":"c","modifiers":["ctrl"]}  -> wtype
  POST /text          — {"text":"привет"}                      -> wtype
  POST /workspace     — {"workspace":6} — живая смена закреплённого воркспейса

ЗАКРЕПЛЕНИЕ (3.9.0, запрос «телефон должен показывать выбранный воркспейс
— это же монитор — и не замирать»): сервер создаёт ВИРТУАЛЬНЫЙ монитор
(`hyprctl output create headless` — официальный рецепт Hyprland для
стримов) и перегоняет выбранный воркспейс на него. Там воркспейс
рендерится ВСЕГДА — телефон показывает ЖИВЫЕ кадры, а физические экраны
ПК свободно переключаются (пауз 3.8.1 больше нет). Клавиатура с телефона
(/key, /text) перед вводом передаёт ФОКУС на виртуальный монитор
(экран ПК при этом НЕ переключается) и возвращает фокус обратно после
ввода. На старых Hyprland без `output create` — автоматический fallback
в режим 3.8.1 (пауза при переключении на ПК).

Только stdlib. Авторизация (опционально) — параметр ?t=<TOKEN> в URL
(или заголовок X-Hyprscreen-Token). Ввода УКАЗАТЕЛЯ нет (тачпад из экрана
телефона убран по решению пользователя) — клавиатура и всё (тап по видео
поднимает её в приложении, кнопка питания отключает).
"""

from __future__ import annotations

import argparse
import json
import os
import signal
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import capture
import discovery
import hyprctl
import input as input_mod
import state_file

__version__ = "3.9.1"

STOP = threading.Event()

TOKEN = ""
KEYBOARD: input_mod.KeyboardInjector | None = None
CLIENTS = 0
CLIENTS_LOCK = threading.Lock()
STORE = capture.FrameStore()
INFO: dict = {}
#: закрепление воркспейса (3.9.0): виртуальный монитор (headless), на
#: котором закреплённый воркспейс рендерится ВСЕГДА — кадры живые без пауз.
#: Создаётся в main() / cmd_serve / POST /workspace.
WATCH: capture.WorkspaceWatch | None = None


def log_line(text: str) -> None:
    print(time.strftime("[%F %T] "), text, sep="", file=sys.stderr, flush=True)


def set_clients(delta: int) -> None:
    global CLIENTS
    with CLIENTS_LOCK:
        CLIENTS = max(0, CLIENTS + delta)
        n = CLIENTS
    state_file.update_state(clients=n)


# ------------------------------------------------------------------ JPEG ---
def jpeg_size(data: bytes) -> tuple[int, int]:
    """Размер JPEG по маркеру SOF (0xFFC0..0xFFCF, кроме C4/C8/CC)."""
    i = 2
    n = len(data)
    while i + 9 < n:
        if data[i] != 0xFF:
            i += 1
            continue
        marker = data[i + 1]
        if marker in (0xC4, 0xC8, 0xCC, 0xD8) or 0xD0 <= marker <= 0xD9:
            i += 2
            continue
        if 0xC0 <= marker <= 0xCF:
            height = (data[i + 5] << 8) | data[i + 6]
            width = (data[i + 7] << 8) | data[i + 8]
            return width, height
        seg_len = (data[i + 2] << 8) | data[i + 3]
        if seg_len < 2:
            break
        i += 2 + seg_len
    return 0, 0


# ------------------------------------------------------------------- HTML ---
VIEWER_HTML = """<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="mobile-web-app-capable" content="yes">
<title>hyprscreen</title>
<style>
  html, body { margin: 0; padding: 0; height: 100%; background: #000; overflow: hidden; }
  img#screen { width: 100%; height: 100%; object-fit: contain; display: block; }
  #err {
    position: fixed; inset: 0; display: flex; align-items: center; justify-content: center;
    color: #777; font: 15px system-ui, sans-serif; background: #000;
  }
</style>
</head>
<body>
<img id="screen" src="/stream.mjpeg" alt="Трансляция экрана">
<div id="err" hidden>Переподключение…</div>
<script>
  const img = document.getElementById("screen");
  const err = document.getElementById("err");
  let timer = null;
  const qs = location.search;              // сохраняет ?t=TOKEN
  const sep = qs ? "&" : "?";
  img.onerror = () => {
    err.hidden = false;
    clearTimeout(timer);
    timer = setTimeout(() => { img.src = "/stream.mjpeg" + qs + sep + Date.now(); }, 1200);
  };
  img.onload = () => { err.hidden = true; };
</script>
</body>
</html>
"""


# ------------------------------------------------------------ закрепление ---
def _prepare_input() -> tuple[str, "callable"]:
    """Передать фокус закреплённому воркспейсу перед вводом с телефона.

    Клавиатура с телефона печатает в ФОКУС ПК. Телефон показывает
    закреплённый воркспейс на ВИРТУАЛЬНОМ мониторе — значит, перед вводом
    фокус должен быть там (экран ПК при этом НЕ переключается), а после
    ввода фокус возвращается на монитор пользователя (restore), чтобы
    физическая клавиатура не начала печатать «в невидимое окно».

    FALLBACK-режим 3.8.1 (старые Hyprland): закреплённый воркспейс живёт
    на физическом мониторе — возвращаем ПК на него, как раньше.

    Возвращает (ошибка|'', restore-функция; restore всегда можно звать).
    """
    watch = WATCH
    if watch is None or not watch.enabled:
        return "", lambda: None
    if watch.mode() != "headless":
        # fallback 3.8.1: вернуть ПК на закреплённый воркспейс
        ws = watch.workspace()
        ok, msg = hyprctl.switch_workspace(ws, str(INFO.get("monitor") or ""))
        if ok:
            return "", lambda: None
        return (f"закреплённый воркспейс №{ws} не активен на ПК "
                f"(ввод отменён): {msg}"), lambda: None
    if not watch.pinned_active():
        return (f"закреплённый воркспейс №{watch.workspace()} сейчас "
                "недоступен (ввод отменён, повторите через секунду)"
                ), lambda: None
    headless = watch.headless_name()
    prev = hyprctl.focused_monitor()
    if not headless or prev == headless:
        return "", lambda: None
    if not hyprctl.focus_monitor(headless):
        return "не удалось передать фокус закреплённому воркспейсу "\
               "(ввод отменён)", lambda: None

    def restore() -> None:
        if prev and prev != headless:
            hyprctl.focus_monitor(prev)

    return "", restore


def apply_workspace(ws: int) -> tuple[bool, str]:
    """Живая смена закреплённого воркспейса (POST /workspace от GUI/CLI).

    Обновляет закрепление в работающем capture-лупе: новый воркспейс
    переезжает на виртуальный монитор (старый — на своё место).
    ws = 0 снимает закрепление (режим «весь монитор», виртуальный
    монитор удаляется).
    """
    global WATCH
    ws = max(0, min(99, int(ws or 0)))
    if ws == 0:
        watch = WATCH
        WATCH = None
        if watch is not None:
            watch.set_workspace(0)
        INFO["workspace"] = 0
        state_file.update_state(workspace=0, workspace_active=True,
                                active_workspace=0, pinned_mode="",
                                headless="")
        return True, "режим «весь монитор» — закрепление снято"
    watch = WATCH
    if watch is None:
        watch = capture.WorkspaceWatch(str(INFO.get("monitor") or ""), ws)
        WATCH = watch
        ok, msg = watch.setup()
        watch.start(STOP)
    else:
        ok, msg = watch.set_workspace(ws)
    INFO["workspace"] = ws
    state_file.update_state(
        workspace=ws,
        workspace_active=bool(WATCH.pinned_active()) if WATCH else True,
        active_workspace=int(WATCH.active_workspace()) if WATCH else 0,
        pinned_mode=str(WATCH.mode()) if WATCH else "",
        headless=str(WATCH.headless_name()) if WATCH else "",
    )
    return ok, msg


def _pinned_status() -> tuple[bool, int]:
    """(закреплённый активен?, активный воркспейс) для /info, /status, state."""
    if WATCH is None:
        return True, 0
    return WATCH.pinned_active(), WATCH.active_workspace()


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "hyprscreen"

    def log_message(self, fmt, *args):  # тишина вместо access-лог-спама
        pass

    # ------------------------------------------------------------- служебное
    def _authed(self, url_path: str, query: dict) -> bool:
        """Токен нужен только на «контентных» эндпоинтах."""
        if not TOKEN:
            return True
        if url_path not in ("/", "/index.html", "/stream.mjpeg", "/info",
                            "/key", "/text", "/workspace"):
            return True
        if query.get("t", [""])[0] == TOKEN:
            return True
        return self.headers.get("X-Hyprscreen-Token", "") == TOKEN

    def _route(self) -> tuple[str, dict]:
        url = urlparse(self.path)
        return url.path, parse_qs(url.query)

    def _send_json(self, payload: dict, code: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _read_json_body(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", 0) or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > 64 * 1024:
            return {}
        try:
            data = json.loads(self.rfile.read(length).decode("utf-8"))
            return data if isinstance(data, dict) else {}
        except (json.JSONDecodeError, UnicodeDecodeError):
            return {}

    # -------------------------------------------------------------------- GET
    def do_GET(self):  # noqa: N802 — API http.server
        path, query = self._route()
        if not self._authed(path, query):
            # message/explain только ASCII — попадают в status-line
            self.send_error(403, "Forbidden", "token required: ?t=<TOKEN>")
            return
        if path in ("/", "/index.html"):
            self.send_html()
        elif path == "/stream.mjpeg":
            self.send_stream()
        elif path == "/info":
            self.send_info()
        elif path == "/status":
            self.send_status()
        else:
            self.send_error(404)

    # ------------------------------------------------------------------- POST
    def do_POST(self):  # noqa: N802 — API http.server
        path, query = self._route()
        if not self._authed(path, query):
            self.send_error(403, "Forbidden", "token required: ?t=<TOKEN>")
            return
        if path not in ("/key", "/text", "/workspace"):
            self.send_error(404)
            return
        if path == "/workspace":
            # Живая смена закреплённого воркспейса (GUI/CLI) — работает
            # и при отключённой клавиатуре.
            body = self._read_json_body()
            ws_raw = body.get("workspace")
            if not isinstance(ws_raw, int):
                # Нет валидного поля — ничего не меняем (иначе мусорный
                # запрос молча снимал бы закрепление).
                self._send_json(
                    {"ok": False, "error": "нужно JSON-поле workspace (число)"},
                    400)
                return
            ok, msg = apply_workspace(ws_raw)
            self._send_json({
                "ok": ok,
                "workspace": max(0, int(INFO.get("workspace") or 0)),
                "message": msg,
            }, 200 if ok else 503)
            return
        if not KEYBOARD:
            self._send_json(
                {"ok": False, "error": "клавиатура отключена в конфиге"}, 503)
            return
        # Клавиатура с телефона: фокус — в закреплённый воркспейс
        # (на виртуальный монитор), после ввода — обратно пользователю.
        err, restore_focus = _prepare_input()
        if err:
            self._send_json({"ok": False, "error": err}, 503)
            return
        try:
            if path == "/key":
                body = self._read_json_body()
                keysym = body.get("keysym")
                modifiers = body.get("modifiers") or []
                if not isinstance(modifiers, list):
                    modifiers = []
                try:
                    if isinstance(keysym, list):
                        # пачка клавиш (макро из приложения)
                        for ks in keysym:
                            KEYBOARD.inject_key(str(ks),
                                                [str(m) for m in modifiers])
                    else:
                        KEYBOARD.inject_key(str(keysym or ""),
                                            [str(m) for m in modifiers])
                    self._send_json({"ok": True})
                except input_mod.InputError as exc:
                    self._send_json({"ok": False, "error": str(exc)}, 400)
            elif path == "/text":
                body = self._read_json_body()
                try:
                    KEYBOARD.inject_text(str(body.get("text") or ""))
                    self._send_json({"ok": True})
                except input_mod.InputError as exc:
                    self._send_json({"ok": False, "error": str(exc)}, 400)
            else:
                self.send_error(404)
        finally:
            restore_focus()

    # ------------------------------------------------------------- обработчики
    def send_html(self) -> None:
        html = VIEWER_HTML
        if TOKEN:
            # токен должен попасть и в src потока, иначе браузер получит 403
            html = html.replace('src="/stream.mjpeg"', f'src="/stream.mjpeg?t={TOKEN}"')
        body = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_info(self) -> None:
        width, height = jpeg_size(STORE.snapshot())
        ws_active, active_ws = _pinned_status()
        self._send_json({
            "server": "hyprscreen",
            "version": __version__,
            **INFO,
            "clients": CLIENTS,
            "frame_seq": STORE.seq,
            "capture_ok": STORE.capture_ok,
            "last_error": STORE.last_error,
            "width": width,
            "height": height,
            "keyboard": bool(KEYBOARD),
            "workspace_active": ws_active,
            "active_workspace": active_ws,
        })

    def send_status(self) -> None:
        ws_active, active_ws = _pinned_status()
        self._send_json({
            "running": True,
            "clients": CLIENTS,
            "frame_seq": STORE.seq,
            "capture_ok": STORE.capture_ok,
            "last_error": STORE.last_error,
            "workspace_active": ws_active,
            "active_workspace": active_ws,
        })

    def send_stream(self) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        set_clients(+1)
        last = 0
        try:
            while not STOP.is_set():
                data, seq = STORE.wait_frame(last, timeout=1.0)
                if seq == last or not data:
                    continue
                last = seq
                header = (
                    "--frame\r\n"
                    "Content-Type: image/jpeg\r\n"
                    f"Content-Length: {len(data)}\r\n\r\n"
                ).encode("ascii")
                self.wfile.write(header + data + b"\r\n")
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError,
                ConnectionAbortedError, TimeoutError, OSError):
            pass
        finally:
            set_clients(-1)


# ------------------------------------------------------------------- main ---
def main() -> None:
    global TOKEN, KEYBOARD, INFO, WATCH

    parser = argparse.ArgumentParser(description="hyprscreen MJPEG-сервер "
                                                 "с закреплением воркспейса")
    parser.add_argument("--output", required=True, help="имя монитора Hyprland")
    parser.add_argument("--listen", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--fps", type=int, default=24)
    parser.add_argument("--quality", type=int, default=75)
    parser.add_argument("--scale", type=float, default=0.75)
    parser.add_argument("--workspace", type=int, default=0,
                        help="воркспейс Hyprland, ЗАКРЕПЛЯЕМЫЙ за телефоном "
                             "(переедет на виртуальный монитор — экраны ПК "
                             "останутся свободны; 0 = весь монитор)")
    parser.add_argument("--token", default="")
    parser.add_argument("--no-keyboard", action="store_true",
                        help="отключить POST /key и /text")
    parser.add_argument("--rate-limit", type=int, default=0,
                        help="лимит событий клавиатуры в секунду")
    parser.add_argument("--no-discovery", action="store_true",
                        help="не рассылать UDP-анонсы")
    parser.add_argument("--discovery-port", type=int, default=8766)
    args = parser.parse_args()

    TOKEN = args.token
    KEYBOARD = None if args.no_keyboard else input_mod.KeyboardInjector(args.rate_limit)
    INFO = {
        "monitor": args.output,
        "workspace": max(0, int(args.workspace or 0)),
        "fps": args.fps,
        "quality": args.quality,
        "scale": args.scale,
    }

    state_file.write_state({
        "pid": os.getpid(),
        "version": __version__,
        "port": args.port,
        "ip": discovery.lan_ip(),
        "monitor": args.output,
        "fps": args.fps,
        "quality": args.quality,
        "scale": args.scale,
        "clients": 0,
        "capture_ok": True,
        "last_error": "",
        "started": int(time.time()),
        "keyboard": bool(KEYBOARD),
    })

    # Обработчики сигналов — ДО setup() закрепления (3.9.1): раньше SIGTERM
    # во время setup убивал процесс по умолчанию БЕЗ teardown — виртуальный
    # монитор и воркспейс оставались закреплёнными навсегда (пустой экран).
    httpd_holder: list[ThreadingHTTPServer] = []

    def on_stop(signum, frame):  # noqa: ARG001
        STOP.set()
        if httpd_holder:
            threading.Thread(target=httpd_holder[0].shutdown,
                             daemon=True).start()

    signal.signal(signal.SIGTERM, on_stop)
    signal.signal(signal.SIGINT, on_stop)

    # Воркспейс для показа: создаём ВИРТУАЛЬНЫЙ монитор (headless) и
    # перегоняем выбранный воркспейс на него (3.9.0). Там он рендерится
    # ВСЕГДА — телефон показывает живые кадры, а физические экраны ПК
    # свободно переключаются (пауз 3.8.1 больше нет). При неудаче —
    # fallback в режим 3.8.1 (пауза). Раньше сервер переключал сам
    # монитор ПК (3.8.0), а потом морозил поток (3.8.1).
    ws = max(0, int(args.workspace or 0))
    watch = None
    if ws > 0:
        watch = capture.WorkspaceWatch(args.output, ws)
        WATCH = watch
        ok, ws_msg = watch.setup()
        log_line(("workspace: " if ok else "workspace WARNING: ") + ws_msg)
        watch.start(STOP)

    httpd = ThreadingHTTPServer((args.listen, args.port), Handler)
    httpd.daemon_threads = True
    httpd_holder.append(httpd)
    if STOP.is_set():
        # сигнал пришёл ВО ВРЕМЯ setup — полный shutdown не запускался:
        # завершаемся сами (finally ниже сделает teardown)
        threading.Thread(target=httpd.shutdown, daemon=True).start()

    threading.Thread(
        target=capture.capture_loop,
        args=(STORE, args.output, args.fps, args.quality, args.scale, STOP),
        kwargs={"has_clients": lambda: CLIENTS > 0, "watch": watch,
                "watch_getter": lambda: WATCH},
        daemon=True,
    ).start()

    if not args.no_discovery:
        discovery.start_broadcaster(
            args.port, args.discovery_port, args.output, STOP
        )

    # runtime-ошибки захвата и состояние закреплённого воркспейса — в state
    # каждые 2 с (GUI/тикер показывают паузу трансляции в fallback-режиме)
    def state_refresher() -> None:
        while not STOP.is_set():
            ws_active, active_ws = _pinned_status()
            state_file.update_state(
                capture_ok=STORE.capture_ok, last_error=STORE.last_error,
                workspace_active=ws_active, active_workspace=active_ws,
                pinned_mode=str(WATCH.mode()) if WATCH else "",
                headless=str(WATCH.headless_name()) if WATCH else "",
            )
            STOP.wait(2.0)

    threading.Thread(target=state_refresher, daemon=True).start()

    if ws > 0 and WATCH is not None:
        hl = WATCH.headless_name()
        ws_note = (f" (закреплён на виртуальном мониторе {hl})"
                   if hl else " (fallback 3.8.1: на физ. мониторе)")
    else:
        ws_note = ""
    log_line(
        f"ready: output={args.output} port={args.port} fps={args.fps} "
        f"quality={args.quality} scale={args.scale} "
        f"workspace={ws}{ws_note} "
        f"keyboard={bool(KEYBOARD)} discovery={not args.no_discovery}"
    )
    try:
        httpd.serve_forever()
    finally:
        STOP.set()
        # Восстановление: воркспейс — на исходный монитор, виртуальный
        # монитор — удалить (иначе после «hyprscreen off» воркспейс
        # останется на невидимом экране). ВАЖНО: teardown идёт по
        # АКТУАЛЬНОМУ watch — живая смена закрепления (POST /workspace)
        # могла подменить объект (WATCH), локальная переменная устарела.
        final_watch = WATCH if WATCH is not None else watch
        WATCH = None
        if final_watch is not None:
            try:
                final_watch.teardown()
            except Exception:  # noqa: BLE001 — teardown не должен маскировать ошибки
                log_line("workspace teardown: ошибка (см. лог)")
        try:
            state_file.clear_state()
        except Exception:  # noqa: BLE001
            pass
        log_line("server stopped")


if __name__ == "__main__":
    main()
