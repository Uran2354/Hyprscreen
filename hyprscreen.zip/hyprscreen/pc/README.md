# HyprScreen — PC-сторона

Превратите Android-телефон/планшет в **беспроводной второй экран** для PC
на **CachyOS** (Arch-based) с Wayland-композитором **Hyprland**.

PC создаёт виртуальный headless-вывод Hyprland, захватывает его через
`grim` (либо экспериментальный `xdg-desktop-portal-hyprland` ScreenCast
portal), стримит JPEG-кадры по WebSocket на один или несколько телефонов
и инъектирует касания/клавиши обратно в PC через `ydotool` (указатель) и
`wtype` (клавиатура).

Начиная с версии **0.2.0** поддерживается **мультиэкранность**: 1..4
независимых виртуальных выводов в ряд, каждый стримится на свой
WebSocket-путь `ws://<host>:<port>/<index>`.

В этом каталоге лежат **плоские Python-скрипты** (не пакет). Запуск:
`python main.py` (или `./run.sh`). Соседние модули импортируются как
top-level (`from config import Config`, `from server import ...`).

---

## 1. Одноразовая настройка

```bash
cd pc
./setup.sh
```

`setup.sh` идемпотентен и сделает:

- `sudo pacman -S --needed grim wtype ydotool python python-pip`
- опционально поставит `xdg-desktop-portal-hyprland` + `pipewire` (для
  portal-бэкенда; можно пропустить — `grim` работает и без)
- включит + запустит user-сервис `ydotoothy` (откат на `ydotoold`)
- создаст Python-venv в `./.venv` и `pip install -r requirements.txt`
- скопирует `config.toml.example` → `config.toml`, если ещё нет

`./setup.sh --install` дополнительно создаст симлинк
`~/.local/bin/hyprscreen` → `./run.sh`, чтобы команда `hyprscreen` была в
PATH (удобно для `exec-once = hyprscreen` в `hyprland.conf`).

`./setup.sh --dry-run` — показать, что было бы сделано, без изменений.

## 2. Запуск

```bash
./run.sh                                 # дефолты: 1920x1080@60, 30fps, порт 8765
./run.sh --screens 2                     # два виртуальных экрана в ряд
./run.sh --config config.toml            # конфиг-файл
./run.sh --resolution 1280x720 --fps 24  # быстрые переопределения (все экраны)
./run.sh --capture-backend portal        # попробовать PipeWire-бэкенд (экспериментальный)
./run.sh --bind 127.0.0.1                # только localhost (SSH-туннель)
./run.sh --no-discovery                  # выключить UDP-анонс
```

`run.sh` активирует `./.venv`, если есть, ставит `PYTHONPATH=.`, чтобы
плоские модули импортировались, и exec-ает `python main.py "$@"`.

## 3. Подключение с телефона

Узнайте LAN-IP PC (`ip -4 addr`), затем укажите Android-приложению:

```
ws://<pc-ip>:8765/0      # экран 0 (или просто ws://<pc-ip>:8765/)
ws://<pc-ip>:8765/1      # экран 1 (если запущено --screens 2)
```

Если включён UDP discovery (по умолчанию), PC каждые 2 секунды шлёт
анонс в подсеть на порт 8766 — Android-приложение автоматически найдёт
PC в списке «Discovered PCs».

## 4. Файрвол

Откройте порт WebSocket и UDP-порт discovery:

```bash
sudo firewall-cmd --permanent --add-port=8765/tcp
sudo firewall-cmd --permanent --add-port=8766/udp
sudo firewall-cmd --reload
```

(Через `ufw`: `sudo ufw allow 8765/tcp && sudo ufw allow 8766/udp`.)

Для более безопасной схемы — привяжите к localhost и туннелируйте через SSH:

```bash
./run.sh --bind 127.0.0.1
# на телефоне: ssh -L 8765:localhost:8765 user@pc
```

## 5. Ключи `config.toml`

Все ключи опциональны (под таблицей `[hyprscreen]`):

| Ключ                  | Дефолт       | Заметки                                                |
|----------------------|--------------|--------------------------------------------------------|
| `screen_count`       | `1`          | Кол-во экранов (1..4). Создаёт N одинаковых из общих полей. |
| `[[screens]]`        | —            | Массив таблиц: покадровые настройки. Альтернатива `screen_count`. |
| `resolution`         | `"1920x1080"`| `"WxH"` виртуального вывода.                            |
| `refresh_rate`       | `60.0`       | Гц для Hyprland.                                       |
| `fps`                | `30`         | Целевое FPS клиентам.                                  |
| `jpeg_quality`       | `80`         | 1-100, в `grim -q`.                                    |
| `port`               | `8765`       | TCP-порт WebSocket.                                    |
| `bind_address`       | `"0.0.0.0"`  | `127.0.0.1` для SSH-туннеля.                            |
| `discovery_port`     | `8766`       | UDP-порт discovery.                                    |
| `discovery_enabled`  | `true`       | Включить/выключить UDP-бродкастер.                     |
| `host_name`          | _(hostname)_ | Имя в списке Discovered PCs.                           |
| `capture_backend`    | `"grim"`     | `"portal"` для PipeWire (экспериментальный, авто-откат).|
| `ydotool_socket`     | _(нет)_      | Необязательный путь к сокету ydotoold.                 |

## 6. Troubleshooting

| Симптом | Решение |
|---|---|
| `hyprctl: command not found` | `sudo pacman -S hyprland` и запускайте внутри Hyprland-сессии. |
| `grim exited 1: ...` | Проверьте, что задано `WAYLAND_DISPLAY`. При запуске через SSH выполните сначала `systemctl --user import-environment WAYLAND_DISPLAY XDG_CURRENT_DESKTOP`. |
| Чёрный экран на телефоне | Headless-вывод пуст по умолчанию — сфокусируйте его (`hyprctl dispatch focusmonitor HEADLESS-1`) и откройте на нём окно. |
| Указатель не двигается | Проверьте `systemctl --user status ydotoothy`. Если `ydotool: Permission denied`, добавьте пользователя в группу `input` (`sudo usermod -aG input "$USER"`, затем выйдите/войдите). |
| Печать / клавиши не работают | `wtype` требует запущенной Hyprland-сессии. Проверьте `wtype --help`. |
| Скролл не работает | Скролл эмулируется кнопками колеса (BTN_4/BTN_5 = 260/261). Не все Wayland-приложения их интерпретируют; если совсем не работает — используйте перетаскивание ползунка. |
| Высокая задержка | Снизьте `--fps` до 15–20 и `--jpeg-quality` до 60. |
| `portal backend unavailable` | pydbus/dasbus или PyGObject отсутствуют — авто-откат на `grim`. Для включения: `sudo pacman -S python-gobject gstreamer gst-plugin-pipewire gst-plugins-base gst-plugins-good`. |
| Порт занят | Поменяйте через `--port 8766` (и обновите приложение + файрвол). |
| Несколько экранов накладываются | Менеджер создаёт выводы последовательно и перевычитывает `monitors -j` после каждого — каждый следующий вывод ложится справа от предыдущего. Если имена `HEADLESS-*` переиспользуются, убедитесь, что не осталось «висящих» headless-выводов от прошлых сессий (`hyprctl monitors -j`). |
| Телефон не находит PC в Discovered PCs | Проверьте, что UDP 8766 открыт в файрволе и `--no-discovery` не передан. PC шлёт анонс каждые 2 сек. |

## 7. Файлы

| Файл | Назначение |
|---|---|
| `main.py`            | Точка входа: argparse, конфиг, lifecycle виртуальных выводов + сервера, SIGINT/SIGTERM. |
| `config.py`          | `Config` / `ScreenConfig` + TOML-загрузка; также экспортирует `__version__`. |
| `hyprctl.py`         | Типизированная обёртка над `hyprctl -j ...` (с timeout). |
| `virtual_output.py`  | `VirtualOutput` + `VirtualOutputManager`: создание/позиционирование/удаление `HEADLESS-*`. |
| `capture.py`         | Бэкенды `grim` + экспериментальный portal/PipeWire. |
| `server.py`          | Мультиэкранный async WebSocket-сервер, роутинг по пути, fan-out кадров. |
| `discovery.py`       | UDP discovery-бродкастер (анонс PC каждые 2 сек на порт 8766). |
| `input.py`           | Инъекция ввода через ydotool (указатель, скролл) + wtype (клавиатура). |
| `logging_setup.py`   | Настройка логирования в stderr. |
| `config.toml.example`| Документированный пример конфига (обе формы: screen_count и [[screens]]). |
| `requirements.txt`   | Python-зависимости (websockets; tomli <3.11; опц. pydbus/PyGObject). |
| `setup.sh`           | Одноразовая настройка CachyOS (pacman + ydotoothy + venv + config; `--install` для симлинка). |
| `run.sh`             | Bash-запускатор (`python main.py`). |

См. корневой README проекта для полной архитектуры и соответствующего
Android-клиента.
