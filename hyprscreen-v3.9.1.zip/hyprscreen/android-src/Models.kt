@file:Suppress("SpellCheckingInspection") // HyprScreen/keysym — не опечатки

package com.example.hyprscreen

import org.json.JSONArray
import org.json.JSONObject

/**
 * Классы данных и алгебра [InputEvent] Android-клиента HyprScreen 3.9.1.
 *
 * Протокол 3.8.1 (см. ../PROTOCOL.md) — HTTP, а не WebSocket:
 *  - кадры: `GET /stream.mjpeg` (multipart/x-mixed-replace, JPEG);
 *  - информация о сервере: `GET /info` (JSON: monitor/fps/качество/размер);
 *  - клавиатура: `POST /key` и `POST /text` (JSON-тело);
 *  - discovery: UDP :8766 (как в 2.x).
 *
 * Ввода УКАЗАТЕЛЯ в 3.x нет (тачпад из экрана телефона убран) —
 * [InputEvent] содержит только [InputEvent.Key] и [InputEvent.Text].
 *
 * Сериализация — org.json (платформенный, без внешних зависимостей):
 * внешние библиотеки 2.x (OkHttp, kotlinx.serialization) больше не нужны.
 */

/** Информация о PC-сервере из `GET /info`. */
data class ServerInfo(
    val host: String,
    val port: Int = DEFAULT_PORT,
    val name: String? = null,
    val monitor: String = "",
    val width: Int = 0,
    val height: Int = 0,
    val fps: Int = 0,
    val quality: Int = 0,
    val scale: Float = 1f,
    val clients: Int = 0,
    val keyboard: Boolean = true,
) {
    companion object {
        const val DEFAULT_PORT = 8080

        /** Разобрать JSON из GET /info. */
        fun fromJson(host: String, port: Int, body: JSONObject): ServerInfo = ServerInfo(
            host = host,
            port = port,
            name = body.optString("name", ""),
            monitor = body.optString("monitor", ""),
            width = body.optInt("width", 0),
            height = body.optInt("height", 0),
            fps = body.optInt("fps", 0),
            quality = body.optInt("quality", 0),
            scale = body.optDouble("scale", 1.0).toFloat(),
            clients = body.optInt("clients", 0),
            keyboard = body.optBoolean("keyboard", true),
        )
    }
}

/**
 * Статистика соединения/рендеринга для оверлея. Мутится на месте декодером;
 * копируется при отправке листенерам.
 */
data class FrameStats(
    var framesDecoded: Long = 0,
    var framesDropped: Long = 0,
    var lastDecodeMs: Long = 0,
    var fps: Double = 0.0,
    var connectMs: Long = 0,
    var connectedForMs: Long = 0
)

/** Сохранённый хост из истории экрана подключения. */
data class SavedHost(
    val host: String,
    val port: Int,
    val name: String? = null,
    val lastUsed: Long = System.currentTimeMillis(),
    val token: String? = null
)

/** Хост, обнаруженный через UDP-broadcast (см. [Discovery]). */
data class DiscoveredHost(
    val host: String,
    val port: Int,
    val name: String,
    val monitor: String = "",
    val screens: Int = 1
)

/** События клавиатуры, пересылаемые в [ScreenClient.sendInput]. */
sealed class InputEvent {
    /** Нажатие клавиши с опциональными модификаторами (ctrl/shift/alt/meta). */
    data class Key(val keysym: String, val modifiers: List<String> = emptyList()) : InputEvent()
    /** Порция текста для инъекции (например, с мягкой клавиатуры). */
    data class Text(val text: String) : InputEvent()
}

// ---- wire-объекты (JSON-тела POST-запросов) ----------------------------

/** Тело POST /key: {"keysym":"c","modifiers":["ctrl"]}. */
internal fun keyPayload(keysym: String, modifiers: List<String>): JSONObject =
    JSONObject().apply {
        put("keysym", keysym)
        put("modifiers", JSONArray(modifiers))
    }

/** Тело POST /text: {"text":"привет"}. */
internal fun textPayload(text: String): JSONObject =
    JSONObject().apply { put("text", text) }

/** Discovery-анонс, рассылаемый PC по UDP. */
internal data class DiscoveryAnnouncement(
    val hyprscreen: Boolean = false,
    val host: String = "",
    val port: Int = ServerInfo.DEFAULT_PORT,
    val screens: Int = 1,
    val monitor: String = "",
    val name: String = "PC",
) {
    companion object {
        fun fromJson(text: String): DiscoveryAnnouncement? = runCatching {
            val body = JSONObject(text)
            DiscoveryAnnouncement(
                hyprscreen = body.optBoolean("hyprscreen", false),
                host = body.optString("host", ""),
                port = body.optInt("port", ServerInfo.DEFAULT_PORT),
                screens = body.optInt("screens", 1),
                monitor = body.optString("monitor", ""),
                name = body.optString("name", "PC"),
            )
        }.getOrNull()
    }
}
