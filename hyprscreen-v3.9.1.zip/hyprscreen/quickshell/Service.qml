// HyprScreen Service.qml — логика статуса для quickshell.
// Опрашивает `hyprscreen status --json` каждые 2 секунды.
//
// Использование (в любом QML-файле вашего шелла):
//   import "./hyprscreen" as HyprScreen
//   HyprScreen.Service { id: hyprscreenService }
//   // далее читайте hyprscreenService.running / .hostPort / .clients
// =============================================================================
import QtQuick
import Quickshell
import Quickshell.Io

Scope {
    id: root

    // Путь к CLI. Поменяйте, если hyprscreen не в PATH quickshell-процесса.
    property string cliPath: "hyprscreen"

    // ---- состояние (заполняется из status --json) ----
    property bool   running: false
    property string monitor: ""
    property string resolution: ""
    property string hostPort: ""     // "192.168.1.5:8080"
    property string address: ""      // "http://192.168.1.5:8080"
    property int    port: 0
    property int    clients: 0
    property real   uptimeSec: 0
    readonly property bool connected: running && clients > 0

    function refresh() {
        if (!statusProc.running) statusProc.running = true;
    }

    function exec(args: var) {
        actionProc.command = [cliPath].concat(args);
        actionProc.running = true;
    }
    function toggle() { exec(["toggle"]); }

    Process {
        id: statusProc
        command: [root.cliPath, "status", "--json"]
        stdout: StdioCollector {
            onStreamFinished: {
                try {
                    const j = JSON.parse(this.text.trim());
                    root.running    = j.running === true;
                    root.monitor    = j.monitor || "";
                    root.resolution = j.resolution || "";
                    root.hostPort   = j.host_port || "";
                    root.address    = j.address || "";
                    root.port       = j.port || 0;
                    root.clients    = j.clients || 0;
                    root.uptimeSec  = j.uptime_sec || 0;
                } catch (e) {
                    root.running = false;
                }
            }
        }
    }

    Process {
        id: actionProc
        onExited: Qt.callLater(root.refresh)
    }

    Timer {
        interval: 2000
        running: true
        repeat: true
        onTriggered: root.refresh()
    }

    Component.onCompleted: root.refresh()
}
