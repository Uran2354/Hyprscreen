package com.example.hyprscreen

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

/**
 * Экран настройки: ввести host/port, выбрать экран PC, тапнуть по сохранённому
 * или обнаруженному хосту, подключиться.
 *
 * При нажатии «Подключиться» запускается [ScreenStreamService] (он владеет
 * WebSocket-клиентом) и показывается [MainActivity], который биндится к сервису.
 *
 * Мульти-экранность (PROTOCOL.md §1, §2):
 *  - Если выбранный обнаруженный хост анонсирует `screens=N`, UI показывает
 *    чипы «Экран 1» … «Экран N» для выбора индекса (0..N-1).
 *  - Тап по сохранённому хосту подставляет host+port+screen из истории.
 *  - Выбранный индекс прокидывается extras=screen в [ScreenStreamService],
 *    тот формирует URL `ws://<host>:<port>/<screen>`.
 *
 * UI строится целиком в коде ([buildUi]) — никаких XML-лейаутов, ViewBinding
 * и `R.*`-ссылок. Каждая строка в списках сохранённых/обнаруженных хостов
 * строится программно с platform-ripple фоном, разрешённым через
 * `android.R.attr.selectableItemBackground`.
 *
 * Все строковые литералы — русские (требование «плоского одного пакета»:
 * приложение не поставляет строковых ресурсов платформы Android).
 */
class ConnectActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var discovery: Discovery

    private lateinit var hostInput: EditText
    private lateinit var portInput: EditText
    private lateinit var screenInput: EditText
    private lateinit var tokenInput: EditText
    private lateinit var screenChipsContainer: LinearLayout
    private lateinit var screenHint: TextView
    private lateinit var connectButton: Button
    private lateinit var statusText: TextView

    private lateinit var discoveredEmpty: TextView
    private lateinit var discoveredHostsContainer: LinearLayout
    private lateinit var savedEmpty: TextView
    private lateinit var savedHostsContainer: LinearLayout

    /** Текущий выбранный индекс экрана (0-based). По умолчанию 0. */
    private var selectedScreen: Int = 0
    /** Известное число экранов PC (по последнему выбранному обнаруженному хосту). */
    private var availableScreens: Int = 1

    /** Лаунчер запроса runtime-разрешения POST_NOTIFICATIONS (Android 13+, баг аудита #27). */
    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* результат игнорируем: сервис работает и без разрешения */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())

        prefs = Prefs(this)
        discovery = Discovery()

        connectButton.setOnClickListener { onConnectClicked() }

        renderSavedHosts()
        renderDiscoveredHosts(emptyList())
        rebuildScreenChips()

        // Предзаполнение из последнего хоста (IP, порт, экран, токен).
        prefs.savedHosts.firstOrNull()?.let { h ->
            hostInput.setText(h.host)
            portInput.setText(h.port.toString())
            screenInput.setText(h.screen.toString())
            selectedScreen = h.screen
            h.token?.let { tokenInput.setText(it) }
            statusText.text = "Последний: ${h.host}:${h.port}"
        }

        // Наблюдаем discovery-анонсы
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                discovery.hosts.collect { hosts -> renderDiscoveredHosts(hosts) }
            }
        }

        // Запрос POST_NOTIFICATIONS на Android 13+ (баг аудита #27 — без него
        // notification foreground-сервиса не виден, хотя сам сервис работает).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { finishAffinity() }
        })
    }

    override fun onStart() {
        super.onStart()
        discovery.start()
    }

    override fun onStop() {
        super.onStop()
        discovery.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        discovery.stop()
    }

    private fun onConnectClicked() {
        val host = hostInput.text?.toString()?.trim().orEmpty()
        val portStr = portInput.text?.toString()?.trim().orEmpty()
        if (host.isEmpty()) {
            statusText.text = "Введите адрес хоста"
            hostInput.requestFocus()
            return
        }
        // Невалидный порт раньше молча подменялся на 8765 и пользователь
        // подключался «не туда» — теперь ошибка видна.
        val port = portStr.toIntOrNull()
        if (port == null || port !in 1..65535) {
            statusText.text = "Порт должен быть числом 1–65535"
            portInput.requestFocus()
            return
        }
        // Индекс экрана — из поля ввода (оно синхронизировано с чипами).
        val screen = screenInput.text?.toString()?.trim()?.toIntOrNull()
            ?.coerceAtLeast(0) ?: 0
        val token = tokenInput.text?.toString()?.trim().orEmpty()
        connectTo(host, port, screen, name = null, authToken = token.ifBlank { null })
    }

    /**
     * Запустить foreground-сервис с extras host/port/screen и открыть MainActivity.
     * MainActivity получает screen/totalScreens через intent-extras.
     */
    private fun connectTo(host: String, port: Int, screen: Int, name: String?, authToken: String? = null) {
        prefs.saveHost(host, port, name, screen, authToken)
        statusText.text = "Подключение к $host:$port экран $screen…"

        val intent = Intent(this, ScreenStreamService::class.java).apply {
            putExtra(ScreenStreamService.EXTRA_HOST, host)
            putExtra(ScreenStreamService.EXTRA_PORT, port)
            putExtra(ScreenStreamService.EXTRA_SCREEN, screen)
            if (authToken != null) putExtra(ScreenStreamService.EXTRA_AUTH_TOKEN, authToken)
        }
        ContextCompat.startForegroundService(this, intent)

        // MainActivity покажет «Экран N/M». M (totalScreens) становится точно
        // известен из hello, но если пользователь подключался через discovery,
        // мы уже знаем его заранее — передаём, чтобы оверлей был корректен
        // ещё до прихода hello.
        val main = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(MainActivity.EXTRA_SCREEN, screen)
            putExtra(MainActivity.EXTRA_TOTAL_SCREENS, availableScreens)
        }
        startActivity(main)
    }

    /** Перерисовать список сохранённых хостов из [Prefs]. */
    private fun renderSavedHosts() {
        val hosts = prefs.savedHosts
        savedHostsContainer.removeAllViews()
        savedEmpty.visibility = if (hosts.isEmpty()) View.VISIBLE else View.GONE
        for (host in hosts) {
            savedHostsContainer.addView(buildHostRow(host))
        }
    }

    /** Перерисовать список обнаруженных хостов из flow [Discovery]. */
    private fun renderDiscoveredHosts(hosts: List<DiscoveredHost>) {
        discoveredHostsContainer.removeAllViews()
        discoveredEmpty.visibility = if (hosts.isEmpty()) View.VISIBLE else View.GONE
        for (host in hosts) {
            discoveredHostsContainer.addView(buildDiscoveredRow(host))
        }
    }

    /** Программно построить строку сохранённого хоста. */
    private fun buildHostRow(host: SavedHost): View = makeHostRow(
        title = host.name ?: host.host,
        subtitle = "${host.host}:${host.port}  ·  экран ${host.screen}",
        onClick = {
            // Подставляем host/port/screen/token из истории.
            hostInput.setText(host.host)
            portInput.setText(host.port.toString())
            screenInput.setText(host.screen.toString())
            selectedScreen = host.screen
            tokenInput.setText(host.token ?: "")
            // Скрываем чипы (нам не известно, сколько экранов у PC сейчас).
            availableScreens = 1
            rebuildScreenChips()
            screenHint.text = "Экран: ${host.screen}"
        },
        onLongClick = {
            prefs.removeHost(host.host, host.port)
            renderSavedHosts()
            Toast.makeText(this, "Удалён ${host.host}:${host.port}", Toast.LENGTH_SHORT).show()
            true
        }
    )

    private fun buildDiscoveredRow(host: DiscoveredHost): View = makeHostRow(
        title = host.name,
        subtitle = "${host.host}:${host.port}  ·  экранов: ${host.screens}",
        onClick = {
            // Подставляем host/port; экран по умолчанию 0; показываем чипы.
            hostInput.setText(host.host)
            portInput.setText(host.port.toString())
            availableScreens = host.screens.coerceAtLeast(1)
            selectedScreen = 0
            screenInput.setText("0")
            rebuildScreenChips()
            screenHint.text = "Доступно экранов: ${host.screens}"
        },
        onLongClick = { false }
    )

    /** Общий строитель строки хоста — вертикальный LinearLayout с двумя TextView. */
    private fun makeHostRow(
        title: String,
        subtitle: String,
        onClick: () -> Unit,
        onLongClick: () -> Boolean
    ): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            isClickable = true
            isFocusable = true
            // Platform ripple — без зависимости от app drawable.
            val outValue = TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackground, outValue, true)
            setBackgroundResource(outValue.resourceId)
        }
        val titleView = TextView(this).apply {
            text = title
            setTextColor(Color.parseColor("#E5E7EB"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val subtitleView = TextView(this).apply {
            text = subtitle
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 12f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(2)
            layoutParams = lp
        }
        row.addView(titleView)
        row.addView(subtitleView)
        row.setOnClickListener { onClick() }
        row.setOnLongClickListener { onLongClick() }
        return row
    }

    /**
     * Перестроить чипы выбора экрана. Если доступен только 1 экран — чипы
     * скрываются, остаётся только числовое поле. Если 2 и более — рисуем
     * «Экран 1» … «Экран N», активный чип подсвечиваем.
     */
    private fun rebuildScreenChips() {
        screenChipsContainer.removeAllViews()
        if (availableScreens <= 1) {
            screenChipsContainer.visibility = View.GONE
            return
        }
        screenChipsContainer.visibility = View.VISIBLE
        for (i in 0 until availableScreens) {
            val chip = Button(this).apply {
                text = "Экран ${i + 1}"   // пользователь видит 1-based
                minWidth = 0
                setPadding(dp(16), dp(8), dp(16), dp(8))
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = dp(8)
                layoutParams = lp
                if (i == selectedScreen) {
                    setBackgroundColor(Color.parseColor("#0F766E"))
                    setTextColor(Color.WHITE)
                } else {
                    setBackgroundColor(Color.parseColor("#1E293B"))
                    setTextColor(Color.parseColor("#CBD5E1"))
                }
            }
            chip.setOnClickListener {
                selectedScreen = i
                screenInput.setText(i.toString())
                rebuildScreenChips()
            }
            screenChipsContainer.addView(chip)
        }
    }

    // ----- UI построен целиком в коде (без XML-лейаутов) -----------------

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        val root = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B0F14"))
            isFillViewport = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }

        val title = TextView(this).apply {
            text = "HyprScreen"
            setTextColor(Color.parseColor("#5EEAD4"))
            textSize = 34f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        col.addView(title)

        val subtitle = TextView(this).apply {
            text = "Превратите это устройство в беспроводной второй экран для вашего Hyprland-PC."
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 14f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(4)
            layoutParams = lp
        }
        col.addView(subtitle)

        hostInput = EditText(this).apply {
            hint = "Адрес / IP PC"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
            setTextColor(Color.parseColor("#E5E7EB"))
            setHintTextColor(Color.parseColor("#64748B"))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(28)
            layoutParams = lp
        }
        col.addView(hostInput)

        portInput = EditText(this).apply {
            hint = "Порт"
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine()
            setText("8765")
            setTextColor(Color.parseColor("#E5E7EB"))
            setHintTextColor(Color.parseColor("#64748B"))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(12)
            layoutParams = lp
        }
        col.addView(portInput)

        tokenInput = EditText(this).apply {
            hint = "Токен авторизации (необязательно)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
            setTextColor(Color.parseColor("#E5E7EB"))
            setHintTextColor(Color.parseColor("#64748B"))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(12)
            layoutParams = lp
        }
        col.addView(tokenInput)

        // Метка раздела выбора экрана.
        col.addView(makeSectionLabel("Экран", topMargin = dp(20)))
        screenHint = TextView(this).apply {
            text = "Индекс экрана PC (0..N-1). По умолчанию 0."
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 12f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(2)
            layoutParams = lp
        }
        col.addView(screenHint)

        // Контейнер чипов «Экран 1» / «Экран 2» / …
        screenChipsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8)
            layoutParams = lp
        }
        col.addView(screenChipsContainer)

        // Числовое поле ввода (manual fallback, синхронизировано с чипами).
        screenInput = EditText(this).apply {
            hint = "Индекс экрана (0, 1, …)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine()
            setText("0")
            setTextColor(Color.parseColor("#E5E7EB"))
            setHintTextColor(Color.parseColor("#64748B"))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8)
            layoutParams = lp
        }
        col.addView(screenInput)

        connectButton = Button(this).apply {
            text = "Подключиться"
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(20)
            layoutParams = lp
        }
        col.addView(connectButton)

        statusText = TextView(this).apply {
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 13f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(12)
            layoutParams = lp
        }
        col.addView(statusText)

        col.addView(makeSectionLabel("Обнаруженные PC", topMargin = dp(28)))
        discoveredEmpty = TextView(this).apply {
            text = "Поиск PC в вашей сети…"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 13f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(6)
            layoutParams = lp
        }
        col.addView(discoveredEmpty)
        discoveredHostsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        col.addView(discoveredHostsContainer)

        col.addView(makeSectionLabel("Недавние хосты", topMargin = dp(28)))
        savedEmpty = TextView(this).apply {
            text = "Сохранённых хостов пока нет."
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 13f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(6)
            layoutParams = lp
        }
        col.addView(savedEmpty)
        savedHostsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        col.addView(savedHostsContainer)

        root.addView(col)
        return root
    }

    private fun makeSectionLabel(text: String, topMargin: Int): TextView =
        TextView(this).apply {
            this.text = text
            setTextColor(Color.parseColor("#E5E7EB"))
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = topMargin
            layoutParams = lp
        }
}
