package com.example.hyprscreen

import android.content.Context
import android.content.SharedPreferences

/**
 * Тонкая обёртка над SharedPreferences для HyprScreen.
 *
 * Хранит историю сохранённых хостов (не более 10, сериализуются как
 * разделённые `|` строки внутри StringSet) и пару UI-тумблеров.
 * Подпакета `data/` нет — класс живёт в едином плоском пакете
 * `com.example.hyprscreen` рядом с остальным приложением.
 *
 * Формат записи хоста (разделитель `|`):
 * `host|port|name|screen|lastUsed`
 * Поле `screen` (индекс выбранного экрана PC) добавлено в этой версии.
 */
class Prefs(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Сохранённые хосты, отсортированы по lastUsed по убыванию. */
    val savedHosts: List<SavedHost>
        get() {
            val set = prefs.getStringSet(KEY_HOSTS, emptySet()) ?: emptySet()
            return set.mapNotNull { line ->
                val parts = line.split('|')
                if (parts.size < 2) return@mapNotNull null
                SavedHost(
                    host = parts[0],
                    port = parts[1].toIntOrNull() ?: 8765,
                    name = parts.getOrNull(2)?.takeIf { it.isNotBlank() },
                    screen = parts.getOrNull(3)?.toIntOrNull() ?: 0,
                    lastUsed = parts.getOrNull(4)?.toLongOrNull() ?: 0L,
                    token = parts.getOrNull(5)?.takeIf { it.isNotBlank() }
                )
            }.sortedByDescending { it.lastUsed }
        }

    fun saveHost(host: String, port: Int, name: String? = null, screen: Int = 0, token: String? = null) {
        val current = savedHosts
            .filterNot { it.host == host && it.port == port && it.screen == screen }
            .toMutableList()
        current.add(
            SavedHost(
                host = host,
                port = port,
                name = name,
                screen = screen,
                lastUsed = System.currentTimeMillis(),
                token = token
            )
        )
        val sorted = current.sortedByDescending { it.lastUsed }.take(MAX_HOSTS)
        persistHosts(sorted)
    }

    /** Удалить все записи этого host:port (для любого экрана). */
    fun removeHost(host: String, port: Int) {
        val remaining = savedHosts.filterNot { it.host == host && it.port == port }
        persistHosts(remaining)
    }

    /** Рисовать ли оверлей FPS/latency во время соединения.
     *  0.11.0: по умолчанию ВЫКЛ — чистый экран телефона; статус виден в PC GUI. */
    var showOverlay: Boolean
        get() = prefs.getBoolean(KEY_OVERLAY, false)
        set(value) = prefs.edit().putBoolean(KEY_OVERLAY, value).apply()

    private fun persistHosts(hosts: List<SavedHost>) {
        val serialised = hosts.map {
            "${it.host}|${it.port}|${it.name ?: ""}|${it.screen}|${it.lastUsed}|${it.token ?: ""}"
        }.toSet()
        prefs.edit().putStringSet(KEY_HOSTS, serialised).apply()
    }

    companion object {
        private const val PREFS = "hyprscreen_prefs"
        private const val KEY_HOSTS = "saved_hosts"
        private const val KEY_OVERLAY = "show_overlay"
        private const val MAX_HOSTS = 10
    }
}
