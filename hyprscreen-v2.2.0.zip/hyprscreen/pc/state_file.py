"""State-файл для межзапусковой координации PC-стороны HyprScreen.

Сервер при старте пишет сюда pid/порт/привязки экранов (``write_state``),
в процессе работы дописывает runtime-статистику (``update_state``) — её
читает GUI в блоке «Телефон» (то, что раньше рисовалось надписью на
самом телефоне). При остановке файл удаляется (``clear_state``).
"""

from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

#: Предупреждения о недоступном state-файле — не чаще раза в минуту
#: (цикл статистики пишет state каждые 2 c, при недоступном
#: диске предупреждение на каждую запись было спамом).
_WARN_MIN_INTERVAL = 60.0
_last_warn_ts = 0.0


def _warn_throttled(msg: str, *args: Any) -> None:
    """log.warning, но не чаще раза в ``_WARN_MIN_INTERVAL`` секунд."""
    global _last_warn_ts
    now = time.monotonic()
    if now - _last_warn_ts >= _WARN_MIN_INTERVAL:
        _last_warn_ts = now
        log.warning(msg, *args)


def state_path() -> Path:
    """Вернуть путь к state-файлу."""
    cache = os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache"))
    return Path(cache) / "hyprscreen" / "state.json"


def _write_json(path: Path, data: dict[str, Any]) -> None:
    """Атомарная запись JSON (tmp + os.replace): читатель (GUI) никогда не
    видит наполовину записанный файл, а гонка сервер/CLI не даёт битого JSON."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def write_state(screens: list[dict[str, Any]], port: int = 8765, pid: int | None = None) -> None:
    """Записать базовое состояние сервера (заменяет файл целиком)."""
    path = state_path()
    try:
        data = {
            "pid": pid if pid is not None else os.getpid(),
            "port": port,
            "screens": screens,
        }
        _write_json(path, data)
    except OSError as exc:
        _warn_throttled("не удалось записать state-файл %s: %s", path, exc)


def update_state(**kwargs: Any) -> None:
    """Дописать/обновить ключи (например, ``runtime``), не трогая остальное."""
    path = state_path()
    data = read_state() or {}
    data.update(kwargs)
    try:
        _write_json(path, data)
    except OSError as exc:
        _warn_throttled("не удалось обновить state-файл %s: %s", path, exc)


def read_state() -> dict[str, Any] | None:
    """Прочитать state-файл."""
    path = state_path()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except (OSError, json.JSONDecodeError) as exc:
        _warn_throttled("не удалось прочитать state-файл %s: %s", path, exc)
    return None


def clear_state() -> None:
    """Удалить state-файл."""
    path = state_path()
    try:
        if path.exists():
            path.unlink()
    except OSError as exc:
        _warn_throttled("не удалось удалить state-файл %s: %s", path, exc)


def monitor_for_screen(screen_index: int) -> str | None:
    """Вернуть имя монитора для экрана из state-файла (или fallback на HEADLESS-*)."""
    state = read_state()
    if state and isinstance(state.get("screens"), list):
        for s in state["screens"]:
            try:
                if int(s.get("index", -1)) == screen_index:
                    mon = s.get("monitor")
                    if isinstance(mon, str) and mon:
                        return mon
            except (TypeError, ValueError):
                continue
    # Fallback: ищем HEADLESS-* в Hyprland.
    try:
        import hyprctl
        headless = hyprctl.find_headless_monitors()
        if headless:
            def _idx(name: str) -> int:
                try:
                    return int(name.split("-", 1)[1])
                except (ValueError, IndexError):
                    return 0
            headless_sorted = sorted(headless, key=_idx)
            if screen_index < len(headless_sorted):
                return headless_sorted[screen_index]
            return headless_sorted[0]
    except Exception:
        pass
    return None
