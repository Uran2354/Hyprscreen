package com.example.hyprscreen

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.util.concurrent.atomic.AtomicInteger

/**
 * WebSocket-клиент к PC-серверу HyprScreen.
 *
 * Жизненный цикл:
 *  1. [connect] открывает WebSocket на `ws://<host>:<port>/<screen>` — путь
 *     выбирает конкретный экран PC (PROTOCOL.md §2, мульти-экранный режим).
 *  2. Сервер присылает текстовое JSON-сообщение hello с полями `width`,
 *     `height`, `fps`, `screen`, `total_screens`. СНАЧАЛА читается
 *     дискриминатор `type` через [WireEnvelope]: если `type == "error"` →
 *     декодируем [ErrorMessage] и зовём [FrameListener.onError], НЕ трактуя
 *     как hello. Иначе (или при отсутствии `type` для обратной совместимости)
 *     декодируем [HelloMessage] и строим [ServerInfo]. Это исправляет баг
 *     аудита #7: любое текстовое сообщение больше не парсится молча как hello.
 *  3. Далее сервер стримит бинарные WS-сообщения — каждый кадр JPEG.
 *     Кадры декодируются вне главного треда и возвращаются (по порядку)
 *     листенеру для отрисовки.
 *  4. Активность отправляет события ввода через [sendInput]; каждое
 *     сериализуется в JSON-формат, ожидаемый Python-сервером.
 *
 * Состояние соединения экспонируется как [StateFlow], чтобы коллекторы (UI)
 * всегда имели свежее значение.
 */
class ScreenClient(
    private val client: OkHttpClient,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
) {

    /** Высокоуровневое состояние соединения, экспонируемое в UI. */
    sealed class State {
        object Idle : State()
        data class Connecting(val host: String, val port: Int, val screen: Int) : State()
        data class Connected(val info: ServerInfo) : State()
        data class Reconnecting(val attempt: Int) : State()
        data class Error(val message: String) : State()
        object Disconnected : State()
    }

    /**
     * Получает декодированные кадры и статистику на главном треде.
     * [onError] вызывается, когда сервер прислал `{"type":"error",...}`.
     */
    interface FrameListener {
        fun onHello(info: ServerInfo)
        fun onFrame(bitmap: Bitmap, decodeMs: Long)
        fun onStats(stats: FrameStats)
        fun onError(message: String)
    }

    private val json = Json {
        ignoreUnknownKeys = true   // сервер шлёт доп. поля (server, version, output, …) — игнорируем
        encodeDefaults = true      // чтобы поле `type` всегда попадало в исходящие JSON
    }

    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()

    /** Однопоточный декодер сохраняет порядок кадров и ограничивает CPU. */
    private val decodeDispatcher = Dispatchers.IO.limitedParallelism(1)
    private val decodeMutex = Mutex()

    @Volatile private var webSocket: WebSocket? = null
    @Volatile private var serverInfo: ServerInfo? = null
    @Volatile var frameListener: FrameListener? = null

    // --- Auto-reconnect ---
    @Volatile private var shouldReconnect: Boolean = false
    @Volatile private var reconnectAttempt: Int = 0
    private var connectParams: ConnectParams? = null

    /** Свежий [ServerInfo] из hello-сообщения, если уже получен. */
    val currentServerInfo: ServerInfo? get() = serverInfo

    private val stats = FrameStats()
    private var connectStartMs = 0L
    private var firstFrameSeen = false
    private var lastFpsCheckMs = 0L
    private var framesSinceFpsCheck = 0
    private val pending = AtomicInteger(0)

    private val mainHandler = Handler(Looper.getMainLooper())

    /** Параметры подключения для auto-reconnect. */
    private data class ConnectParams(
        val host: String, val port: Int, val screen: Int, val authToken: String?
    )

    /** Переподключение с backoff 1→30с, max 10 попыток. */
    private fun scheduleReconnect() {
        if (!shouldReconnect) return
        val params = connectParams ?: return
        reconnectAttempt++
        if (reconnectAttempt > MAX_RECONNECT_ATTEMPTS) {
            Log.w(TAG, "Превышено max попыток переподключения")
            _state.value = State.Error("Не удалось переподключиться за $MAX_RECONNECT_ATTEMPTS попыток")
            return
        }
        val delay = minOf(1000L * (1L shl (reconnectAttempt - 1)), 30000L)
        Log.i(TAG, "Переподключение: попытка $reconnectAttempt через ${delay}мс")
        _state.value = State.Reconnecting(reconnectAttempt)
        mainHandler.postDelayed({
            if (!shouldReconnect) return@postDelayed
            webSocket = null
            serverInfo = null
            val url = "ws://${'$'}{params.host}:${'$'}{params.port}/${'$'}{params.screen}"
            Log.i(TAG, "Переподключение к $url")
            val req = Request.Builder().url(url).build()
            webSocket = client.newWebSocket(req, SocketListener(params.host, params.port, params.screen, params.authToken))
        }, delay)
    }


    /**
     * Открыть WebSocket-соединение к выбранному экрану PC.
     * URL формируется как `ws://<host>:<port>/<screen>` (PROTOCOL.md §2).
     */
    fun connect(host: String, port: Int, screen: Int = 0, authToken: String? = null) {
        connectParams = ConnectParams(host, port, screen, authToken)
        shouldReconnect = true
        reconnectAttempt = 0
        if (webSocket != null) {
            Log.w(TAG, "connect() вызван, но соединение уже активно — игнорируем")
            return
        }
        connectStartMs = System.currentTimeMillis()
        firstFrameSeen = false
        stats.run {
            framesDecoded = 0; framesDropped = 0; lastDecodeMs = 0
            fps = 0.0; latencyMs = 0; connectedForMs = 0
        }
        _state.value = State.Connecting(host, port, screen)
        // Заранее строим ServerInfo с выбранным экраном; width/height/fps
        // обновятся из hello. totalScreens тоже обновится.
        serverInfo = ServerInfo(host = host, port = port, screen = screen, totalScreens = 1)
        val url = "ws://$host:$port/$screen"
        Log.i(TAG, "Подключение к $url")
        val req = Request.Builder().url(url).build()
        webSocket = client.newWebSocket(req, SocketListener(host, port, screen, authToken))
    }

    /** Отправить событие ввода на сервер как JSON text-сообщение. */
    fun sendInput(event: InputEvent) {
        val ws = webSocket ?: return
        val payload: String = when (event) {
            is InputEvent.PointerMove ->
                json.encodeToString(PointerMovePayload.serializer(), PointerMovePayload(x = event.x, y = event.y))
            is InputEvent.PointerDown ->
                json.encodeToString(PointerDownPayload.serializer(), PointerDownPayload(x = event.x, y = event.y, button = event.button))
            is InputEvent.PointerUp ->
                json.encodeToString(PointerUpPayload.serializer(), PointerUpPayload(button = event.button))
            is InputEvent.Scroll ->
                json.encodeToString(ScrollPayload.serializer(), ScrollPayload(dx = event.dx, dy = event.dy))
            is InputEvent.Key ->
                json.encodeToString(KeyPayload.serializer(), KeyPayload(keysym = event.keysym, modifiers = event.modifiers))
            is InputEvent.Text ->
                json.encodeToString(TextPayload.serializer(), TextPayload(text = event.text))
        }
        if (!ws.send(payload)) {
            Log.w(TAG, "Не удалось поставить в очередь ввод: $payload")
        }
    }

    /**
     * Аккуратно закрыть WebSocket и сбросить состояние.
     * Также отменяем [scope], чтобы декодер-корутины не продолжали работать
     * после disconnect (исправление бага аудита performance #7).
     */
    fun disconnect() {
        shouldReconnect = false
        webSocket?.runCatching { close(NORMAL_CLOSURE, "client disconnect") }
        webSocket = null
        serverInfo = null
        _state.value = State.Disconnected
        scope.cancel()
    }

    private inner class SocketListener(
        private val host: String,
        private val port: Int,
        private val screen: Int,
        private val authToken: String?
    ) : WebSocketListener() {

        override fun onOpen(webSocket: WebSocket, response: Response) {
            Log.i(TAG, "WebSocket открыт: $host:$port/$screen")
            if (!authToken.isNullOrBlank()) {
                val payload = json.encodeToString(AuthPayload.serializer(), AuthPayload(token = authToken))
                Log.i(TAG, "Отправка auth-токена")
                webSocket.send(payload)
            }
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            handleTextMessage(text)
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            handleFrame(bytes.toByteArray())
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            webSocket.close(code, reason)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            Log.i(TAG, "WebSocket закрыт: $code $reason")
            this@ScreenClient.webSocket = null
            if (code == 1008 && reason.contains("auth", ignoreCase = true)) {
                shouldReconnect = false
                _state.value = State.Error("Auth failed: $reason")
            } else {
                scheduleReconnect()
            }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            Log.e(TAG, "Сбой WebSocket", t)
            this@ScreenClient.webSocket = null
            scheduleReconnect()
        }
    }

    /**
     * Разобрать входящее текстовое сообщение.
     *
     * СНАЧАЛА читаем только поле `type` через [WireEnvelope] (это исправляет
     * критический баг аудита #7: раньше любое text-сообщение молча парсилось
     * как hello). Дальнейшее поведение зависит от типа:
     *  - `"error"` → разбираем [ErrorMessage], зовём [FrameListener.onError],
     *    переводим клиент в [State.Error]. Hello НЕ трактуем.
     *  - `"hello"` ИЛИ `type` отсутствует (обратная совместимость) →
     *    разбираем [HelloMessage], строим [ServerInfo], переходим в
     *    [State.Connected].
     *  - любой другой тип → логируем и игнорируем.
     */
    private fun handleTextMessage(text: String) {
        val envelope = runCatching {
            json.decodeFromString(WireEnvelope.serializer(), text)
        }.getOrNull() ?: run {
            Log.w(TAG, "Не удалось разобрать конверт text-сообщения: $text")
            return
        }

        when (envelope.type) {
            "error" -> {
                val err = runCatching {
                    json.decodeFromString(ErrorMessage.serializer(), text)
                }.getOrNull() ?: ErrorMessage(error = "неизвестная ошибка сервера")
                Log.w(TAG, "Сервер вернул ошибку: ${err.error}")
                _state.value = State.Error(err.error.ifBlank { "ошибка сервера" })
                postOnMain { frameListener?.onError(err.error) }
            }
            "hello", null -> handleHello(text)
            else -> Log.w(TAG, "Неизвестный type=${envelope.type}, игнорирую: $text")
        }
    }

    private fun handleHello(text: String) {
        val hello = runCatching {
            json.decodeFromString(HelloMessage.serializer(), text)
        }.getOrNull() ?: run {
            Log.w(TAG, "Не удалось разобрать hello: $text")
            return
        }
        val base = serverInfo ?: ServerInfo(host = "", port = 8765)
        // Гарантируем, что screen берётся из hello, если сервер его прислал,
        // иначе — из базового ServerInfo (выбранный пользователем индекс).
        val info = ServerInfo(
            host = base.host,
            port = base.port,
            name = base.name,
            width = hello.width,
            height = hello.height,
            fps = hello.fps,
            screen = hello.screen,
            totalScreens = hello.total_screens.coerceAtLeast(1)
        )
        serverInfo = info
        _state.value = State.Connected(info)
        postOnMain { frameListener?.onHello(info) }
    }

    private fun handleFrame(data: ByteArray) {
        // Backpressure: если в очереди на декодирование уже 2 кадра — сбрасываем.
        if (pending.incrementAndGet() > MAX_PENDING) {
            pending.decrementAndGet()
            stats.framesDropped++
            return
        }
        scope.launch(decodeDispatcher) {
            try {
                decodeMutex.withLock {
                    val t0 = System.currentTimeMillis()
                    val bitmap = BitmapFactory.decodeByteArray(data, 0, data.size) ?: run {
                        Log.w(TAG, "Не удалось декодировать JPEG-кадр (${data.size} байт)")
                        return@withLock
                    }
                    val decodeMs = System.currentTimeMillis() - t0
                    updateStats(decodeMs)
                    postOnMain { frameListener?.onFrame(bitmap, decodeMs) }
                    postOnMain { frameListener?.onStats(stats.copy()) }
                }
            } finally {
                pending.decrementAndGet()
            }
        }
    }

    private fun updateStats(decodeMs: Long) {
        stats.framesDecoded++
        stats.lastDecodeMs = decodeMs
        val now = System.currentTimeMillis()
        if (!firstFrameSeen) {
            firstFrameSeen = true
            lastFpsCheckMs = now
            stats.latencyMs = now - connectStartMs
        } else {
            framesSinceFpsCheck++
            val elapsed = now - lastFpsCheckMs
            if (elapsed >= FPS_WINDOW_MS) {
                stats.fps = framesSinceFpsCheck * 1000.0 / elapsed
                lastFpsCheckMs = now
                framesSinceFpsCheck = 0
            }
        }
        stats.connectedForMs = now - connectStartMs
    }

    private fun postOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block()
        else mainHandler.post(block)
    }

    companion object {
        private const val TAG = "HyprScreen/ScreenClient"
        private const val NORMAL_CLOSURE = 1000
        private const val MAX_PENDING = 2
        private const val FPS_WINDOW_MS = 500L
        private const val MAX_RECONNECT_ATTEMPTS = 10
    }
}
