# PC-сторона HyprScreen 3.9.1 (`pc/`)

Структура повторяет 2.2.0; логика — 3.x: зеркало **ЗАКРЕПЛЁННОГО**
воркспейса Hyprland (по умолчанию №6) на телефон по HTTP MJPEG.
Закреплённый воркспейс живёт на ВИРТУАЛЬНОМ мониторе (headless, 3.9.0)
и рендерится ВСЕГДА — кадры живые, переключения воркспейсов на ПК не
влияют на телефон, экраны ПК свободны (на старых Hyprland — fallback
3.8.1 с паузой). Ввода указателя нет, хоткеев нет.

## Модули

| Файл | Назначение |
|---|---|
| `main.py` | CLI-движок: `on/off/toggle/status/monitors/qr/grimtest/cleanup/doctor/gui/menu/serve`; запускает `server.py` в фоне, пишет state |
| `server.py` | HTTP-сервер (только stdlib): `GET /`, `/stream.mjpeg`, `/info`, `/status`; `POST /key`, `/text` (клавиатура с телефона → wtype), `POST /workspace` (живая смена закреплённого воркспейса); UDP-discovery |
| `capture.py` | Захват кадров: `grim -o MONITOR -t jpeg -q Q [-s SCALE] -`; потокобезопасный `FrameStore` («всегда свежий кадр», без отставания); `WorkspaceWatch` — закреплённый воркспейс (события `.socket2.sock` + опрос `hyprctl -j monitors`), пауза захвата при переключении на ПК |
| `input.py` | Клавиатура через **wtype** (`-k keysym`, `-M mod`, текст `-d 0`); rate-limit |
| `config.py` | `Config` (TOML) + пресеты FPS (eco/balance/smooth/max), clamp-функции, `__version__` |
| `config.toml.example` | Пример конфигурации → копируется setup.sh в `config.toml` |
| `state_file.py` | `~/.cache/hyprscreen/state.json` — pid/порт/экран/клиенты/ошибки (атомарная запись); при остановке сервер УДАЛЯЕТ файл; `state_pid_alive` сверяет cmdline (защита от переиспользованного PID, 3.9.1) |
| `settings_store.py` | `~/.config/hyprscreen/settings.json` — выбранный экран (№6), FPS-режим, миграции формата |
| `hyprctl.py` | Список мониторов, разрешение, `switch_workspace` (открыть закреплённый воркспейс), путь IPC-сокета `.socket2.sock`, восстановление окружения Wayland, поиск забытых HEADLESS-* (для cleanup), LAN IP; dispatch в двух синтаксисах (3.9.1): классика `hyprctl dispatch …` и Lua-конфиг 0.55+ `hyprctl eval 'hl.dispatch(hl.dsp.…)'` (детект по `systeminfo`, самолечение по stderr) |
| `discovery.py` | UDP-бродкастер `:8766` каждые 2 с — приложение находит PC само |
| `logging_setup.py` | Логи: stderr + ротация 5 МБ × 3 в `~/.local/share/hyprscreen/hyprscreen.log` |
| `gui.py` | GUI customtkinter: вкладки «Сервер / Экран / Телефон / Лог», живой предпросмотр (grim) |
| `run.sh` | Запускатор: `gui`, `menu`, остальное → `main.py`; проверяет целостность модулей до запуска |
| `setup.sh` | Пакеты (hyprland, grim, wtype, tk), venv + customtkinter, создание `config.toml` |
| `requirements.txt` | customtkinter, Pillow (GUI); сервер — чистый stdlib |

## Протокол

См. `../PROTOCOL.md`. Кратко:

* `GET /stream.mjpeg` — multipart/x-mixed-replace, JPEG-кадры;
* `GET /info` — JSON: монитор, закреплённый/активный воркспейс, fps, качество, размер кадра, клиенты;
* `POST /key` `{"keysym":"c","modifiers":["ctrl"]}` — клавиша (сначала сервер возвращает ПК на закреплённый воркспейс);
* `POST /text` `{"text":"привет"}` — текст (Enter/Tab — отдельно);
* `POST /workspace` `{"workspace":6}` — живая смена закреплённого воркспейса: переезд на виртуальный монитор (3.9.0);
* токен `?t=` (или заголовок `X-Hyprscreen-Token`) — если задан в конфиге;
* UDP `:8766` — `{"hyprscreen":true,"host":...,"port":8080,"name":...}`.

## Запуск

```bash
./run.sh                 # сервер в переднем плане
./run.sh gui             # GUI (customtkinter)
./run.sh menu            # консольное меню
./setup.sh               # зависимости + venv + config.toml
```

Установленный CLI: `hyprscreen on|off|status|monitors|qr|grimtest|cleanup|doctor|gui|menu`.
