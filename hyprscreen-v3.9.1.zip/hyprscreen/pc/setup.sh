#!/usr/bin/env bash
# Зависимости HyprScreen 3.9.1 (PC-сторона): пакеты, venv, config.toml.
# Вызывается install.sh; можно запускать и вручную: ./pc/setup.sh

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"

ok()   { printf '✅ %s\n' "$*"; }
warn() { printf '⚠️  %s\n' "$*"; }

PACMAN=""
if command -v pacman >/dev/null 2>&1; then PACMAN="pacman"; fi

pkg_install() {
    if [[ -n "$PACMAN" ]]; then
        sudo pacman -S --needed --noconfirm "$@" || warn "не удалось поставить: $*"
    else
        warn "установите вручную: $*"
    fi
}

# 1. Системные пакеты -----------------------------------------------------------
missing=()
command -v hyprctl >/dev/null 2>&1 || missing+=("hyprland")
command -v grim    >/dev/null 2>&1 || missing+=("grim")
command -v wtype   >/dev/null 2>&1 || missing+=("wtype")
command -v python3 >/dev/null 2>&1 || missing+=("python")
if ((${#missing[@]})); then
    warn "не хватает системных пакетов: ${missing[*]}"
    pkg_install "${missing[@]}"
fi
command -v grim    >/dev/null 2>&1 && ok "grim"    || warn "grim отсутствует — захват работать не будет"
command -v hyprctl >/dev/null 2>&1 && ok "hyprctl" || warn "hyprctl отсутствует"
command -v wtype   >/dev/null 2>&1 && ok "wtype (клавиатура с телефона)" \
    || warn "wtype отсутствует — «Клавиатура» в приложении вернёт ошибку"

# tkinter — для GUI
if python3 -c 'import tkinter' >/dev/null 2>&1; then
    ok "tkinter"
else
    warn "tkinter недоступен — ставим tk"
    pkg_install tk
fi

# 2. venv с customtkinter (GUI) ---------------------------------------------------
VENV="$SCRIPT_DIR/.venv"
if [[ ! -x "$VENV/bin/python" ]]; then
    echo "— создаю venv: $VENV —"
    python3 -m venv "$VENV" || warn "python3 -m venv не сработал (нужен пакет python)"
fi
if [[ -x "$VENV/bin/python" ]]; then
    if "$VENV/bin/pip" install -q -r "$SCRIPT_DIR/requirements.txt"; then
        ok "customtkinter + Pillow установлены в venv"
    else
        warn "pip install не удался (нет сети?) — GUI можно запустить позже: $VENV/bin/pip install -r requirements.txt"
    fi
fi

# 3. config.toml -------------------------------------------------------------------
if [[ ! -f "$SCRIPT_DIR/config.toml" ]]; then
    cp "$SCRIPT_DIR/config.toml.example" "$SCRIPT_DIR/config.toml"
    ok "создан config.toml (из примера)"
else
    ok "config.toml уже существует (не тронут)"
fi

echo "Готово: pc/setup.sh"
