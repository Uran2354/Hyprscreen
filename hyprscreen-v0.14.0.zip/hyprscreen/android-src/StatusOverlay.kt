package com.example.hyprscreen

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect

/**
 * Маленький помощник, рисующий текстовый оверлей статуса (FPS / пинг /
 * время декодирования) в левом-нижнем углу [ScreenView]. Включается/выключается
 * в рантайме.
 *
 * Намеренно крошечный — без ресурсов, без ветвления по версии платформы:
 * всего два предсозданных [Paint] и переиспользуемый [Rect].
 */
class StatusOverlay {

    private val textPaint = Paint().apply {
        color = Color.parseColor("#5EEAD4")
        textSize = 26f
        isAntiAlias = true
        setShadowLayer(5f, 1f, 1f, Color.BLACK)
    }
    private val bgPaint = Paint().apply { color = Color.parseColor("#CC000000") }
    private val bounds = Rect()

    private var text: String = ""
    private var visible: Boolean = true

    fun setText(t: String) {
        if (t != text) text = t
    }

    fun setVisible(v: Boolean) {
        visible = v
    }

    fun draw(canvas: Canvas, w: Int, h: Int) {
        if (!visible || text.isBlank()) return
        textPaint.getTextBounds(text, 0, text.length, bounds)
        val pad = 14f
        val left = 16f
        val bottom = h - 16f
        val top = bottom - bounds.height() - pad
        canvas.drawRect(
            left - pad,
            top - pad,
            left + bounds.width() + pad,
            bottom + pad,
            bgPaint
        )
        canvas.drawText(text, left, bottom, textPaint)
    }
}
