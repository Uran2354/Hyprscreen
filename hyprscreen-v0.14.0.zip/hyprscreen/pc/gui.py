"""HyprScreen GUI — customtkinter (0.14.0).

Компактный графический интерфейс вместо консольного меню:

* вкладка «Сервер» — запуск/остановка сервера, адрес для телефона;
* вкладка «Экран»  — воркспейс (по умолчанию 6), режим FPS с пресетами,
  разрешение (пресеты под экран телефона), обои телефона из ~/Обои;
* вкладка «Телефон» — что сейчас на телефоне: «Рабочий стол N», статус
  стрима и кнопка «Посмотреть» — живой предпросмотр экрана телефона
  (grim с headless-вывода). Вся служебная информация — ТОЛЬКО здесь,
  экран телефона чистый;
* вкладка «Лог»    — хвост лога сервера.

Сервер запускается отдельным процессом (``main.py -c config.toml``),
GUI общается с ним через state-файл (чтение), CLI ``main.py workspace N``
(перепривязка на лету) и модуль ``wallpaper`` (обои через swww).
"""

from __future__ import annotations

import base64
import binascii
import copy
import os
import shutil
import subprocess
import sys
import threading
import tkinter as tk
from typing import Optional

import customtkinter as ctk

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from config import Config, FPS_MODE_PRESETS, __version__, DEFAULT_WORKSPACE  # noqa: E402
import hyprctl  # noqa: E402
import settings_store  # noqa: E402
import state_file  # noqa: E402
import wallpaper  # noqa: E402

SERVER_LOG = "/tmp/hyprscreen-server.log"

MODE_LABELS = {
    "auto": "Авто (с адаптацией)",
    "eco": "Экономный",
    "balance": "Баланс",
    "smooth": "Плавный",
    "max": "Максимум",
    "custom": "Своё",
}
LABEL_TO_MODE = {v: k for k, v in MODE_LABELS.items()}

#: Пресеты разрешения. Дефолт — АЛЬБОМ 2340x1080: приложение на телефоне
#: зафиксировано в landscape, и альбомный кадр с тем же соотношением
#: сторон занимает весь экран (портрет 0.12.0–0.13.2 давал «маленькую»
#: картинку с большими полями).
RES_PRESETS: dict[str, str] = {
    "Телефон · альбом 2340×1080": "2340x1080",
    "Телефон · альбом HD 1600×720": "1600x720",
    "Телефон · портрет 1080×2340": "1080x2340",
    "ПК · Full HD 1920×1080": "1920x1080",
    "ПК · QHD 2560×1440": "2560x1440",
}
RES_CUSTOM = "Своё…"

ACCENT = "#5EEAD4"


class ServerController:
    """Управление серверным процессом ``main.py``."""

    def __init__(self) -> None:
        self.proc: Optional[subprocess.Popen] = None
        self._log_fh = None

    def running(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def start(self, cfg: Config) -> tuple[bool, str]:
        if self.running():
            return False, "Сервер уже запущен"
        # Защита от двойного запуска (0.13.2): живой процесс из state-файла
        # означает, что сервер стартован вне GUI (консоль/меню) — иначе
        # новый экземпляр падал с «порт занят» и exit-кодом 1.
        state = state_file.read_state()
        if state and state.get("pid"):
            try:
                pid = int(state["pid"])
                os.kill(pid, 0)  # проверка существования (без сигнала)
            except (ValueError, TypeError, ProcessLookupError, PermissionError):
                pid = None
            if pid is not None:
                return False, (
                    f"Сервер уже работает (pid {pid}, запущен вне GUI) — "
                    "остановите его: ./run.sh kill"
                )
        cfg_path = os.path.join(BASE_DIR, "config.toml")
        cfg.save(cfg_path)
        venv_python = os.path.join(BASE_DIR, ".venv", "bin", "python")
        python_bin = venv_python if os.path.exists(venv_python) else sys.executable
        env = {**os.environ, "PYTHONPATH": BASE_DIR}
        try:
            self._log_fh = open(SERVER_LOG, "w")
            self.proc = subprocess.Popen(
                [python_bin, os.path.join(BASE_DIR, "main.py"),
                 "-c", cfg_path, "--no-log-to-file", "--log-level", "INFO"],
                stdout=self._log_fh,
                stderr=subprocess.STDOUT,
                cwd=BASE_DIR,
                env=env,
                start_new_session=True,
            )
        except Exception as exc:
            self._close_log()
            self.proc = None
            return False, f"Не удалось запустить: {exc}"
        return True, f"Запущен (pid {self.proc.pid})"

    def _close_log(self) -> None:
        if self._log_fh is not None:
            try:
                self._log_fh.close()
            except Exception:
                pass
            self._log_fh = None

    def stop(self) -> tuple[bool, str]:
        if not self.running():
            self.proc = None
            self._close_log()
            return False, "Сервер не запущен"
        assert self.proc is not None
        proc, self.proc = self.proc, None
        proc.terminate()
        try:
            proc.wait(timeout=8)
        except Exception:
            try:
                proc.kill()
                proc.wait(timeout=3)  # не оставляем зомби
            except Exception:
                pass
        self._close_log()
        return True, "Остановлен"

    def exit_code(self) -> Optional[int]:
        if self.proc is not None and self.proc.poll() is not None:
            return self.proc.returncode
        return None


class GuiApp(ctk.CTk):
    """Окно HyprScreen."""

    def __init__(self) -> None:
        super().__init__()
        self.title(f"HyprScreen {__version__} — второй экран из телефона")
        self.geometry("800x680")
        self.minsize(720, 600)
        ctk.set_appearance_mode("dark")

        self.server = ServerController()
        self._ui_ready = False
        # -- предпросмотр телефона ------------------------------------------
        self._preview_on = False
        self._preview_busy = False
        self._preview_job: Optional[str] = None
        self._preview_photo: Optional[tk.PhotoImage] = None
        # -- обои -------------------------------------------------------------
        self._wp_map: dict[str, str] = {}

        # Одноразовая миграция настроек (воркспейс → 6 и т.п.).
        self._migrate_actions = settings_store.migrate(
            os.path.join(BASE_DIR, "config.toml")
        )

        self._build_header()
        self._build_tabs()
        self._load_initial_values()
        self._ui_ready = True

        self.after(1000, self._tick_status)
        self.after(2000, self._tick_phone)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
    # ------------------------------------------------------------------ UI

    def _build_header(self) -> None:
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=16, pady=(12, 4))
        ctk.CTkLabel(
            header, text=f"HyprScreen {__version__}",
            font=("Arial", 20, "bold"),
        ).pack(side="left")
        self.status_badge = ctk.CTkLabel(
            header, text="● остановлен", text_color="#F87171",
            font=("Arial", 13, "bold"),
        )
        self.status_badge.pack(side="right")

    def _build_tabs(self) -> None:
        self.tabs = ctk.CTkTabview(self, width=760, height=540)
        self.tabs.pack(fill="both", expand=True, padx=16, pady=8)
        self.tabs.add("Сервер")
        self.tabs.add("Экран")
        self.tabs.add("Телефон")
        self.tabs.add("Лог")
        self._build_tab_server(self.tabs.tab("Сервер"))
        self._build_tab_screen(self.tabs.tab("Экран"))
        self._build_tab_phone(self.tabs.tab("Телефон"))
        self._build_tab_log(self.tabs.tab("Лог"))

    # --- вкладка «Сервер» -------------------------------------------------

    def _build_tab_server(self, tab: ctk.CTkFrame) -> None:
        row = ctk.CTkFrame(tab, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=(14, 8))
        self.btn_start = ctk.CTkButton(
            row, text="▶  Запустить сервер", command=self._on_start, width=190
        )
        self.btn_start.pack(side="left", padx=(0, 8))
        self.btn_stop = ctk.CTkButton(
            row, text="■  Остановить", command=self._on_stop,
            width=160, fg_color="#7F1D1D", hover_color="#991B1B",
        )
        self.btn_stop.pack(side="left")

        info = ctk.CTkFrame(tab)
        info.pack(fill="x", padx=12, pady=8)
        self.lbl_addr = ctk.CTkLabel(info, text="Адрес: —", anchor="w")
        self.lbl_addr.pack(fill="x", padx=12, pady=(10, 2))
        self.lbl_ws_hint = ctk.CTkLabel(info, text="Воркспейс: —", anchor="w")
        self.lbl_ws_hint.pack(fill="x", padx=12, pady=2)
        self.lbl_server_line = ctk.CTkLabel(info, text="Статус: остановлен", anchor="w")
        self.lbl_server_line.pack(fill="x", padx=12, pady=(2, 10))

        opts = ctk.CTkFrame(tab, fg_color="transparent")
        opts.pack(fill="x", padx=12, pady=8)
        ctk.CTkLabel(opts, text="Порт:").pack(side="left", padx=(0, 6))
        self.ent_port = ctk.CTkEntry(opts, width=90)
        self.ent_port.pack(side="left", padx=(0, 16))
        ctk.CTkLabel(opts, text="Токен (необязательно):").pack(side="left", padx=(0, 6))
        self.ent_token = ctk.CTkEntry(opts, width=200, show="•")
        self.ent_token.pack(side="left")

        self.lbl_server_msg = ctk.CTkLabel(tab, text="", text_color="#FCA5A5")
        self.lbl_server_msg.pack(fill="x", padx=12, pady=4)

        hint = ctk.CTkLabel(
            tab, justify="left", anchor="w",
            text=(
                "Как подключить телефон:\n"
                "  1. Телефон и PC — в одной Wi-Fi сети.\n"
                "  2. Приложение HyprScreen (APK) → IP и порт выше "
                "(или подождите discovery).\n"
                "  3. Экран телефона показывает выбранный воркспейс; "
                "переключение — win+<номер>."
            ),
        )
        hint.pack(fill="x", padx=12, pady=(10, 12))

    # --- вкладка «Экран» ---------------------------------------------------

    def _build_tab_screen(self, tab: ctk.CTkFrame) -> None:
        ws_frame = ctk.CTkFrame(tab)
        ws_frame.pack(fill="x", padx=12, pady=(14, 8))
        ctk.CTkLabel(
            ws_frame, text="Воркспейс телефона:",
            font=("Arial", 14, "bold"),
        ).pack(anchor="w", padx=12, pady=(10, 2))
        ws_row = ctk.CTkFrame(ws_frame, fg_color="transparent")
        ws_row.pack(fill="x", padx=12, pady=(2, 10))
        self.ent_workspace = ctk.CTkEntry(ws_row, width=80, justify="center")
        self.ent_workspace.pack(side="left")
        ctk.CTkButton(ws_row, text="Применить", width=120,
                      command=self._on_apply_workspace).pack(side="left", padx=8)
        self.lbl_ws_apply = ctk.CTkLabel(ws_row, text="переключение: win+<номер>")
        self.lbl_ws_apply.pack(side="left", padx=8)

        fps_frame = ctk.CTkFrame(tab)
        fps_frame.pack(fill="x", padx=12, pady=8)
        ctk.CTkLabel(
            fps_frame, text="Режим FPS (авто-настройка параметров):",
            font=("Arial", 14, "bold"),
        ).pack(anchor="w", padx=12, pady=(10, 2))
        self.opt_mode = ctk.CTkOptionMenu(
            fps_frame, values=list(MODE_LABELS.values()), width=240,
            command=self._on_mode_change,
        )
        self.opt_mode.pack(anchor="w", padx=12, pady=(2, 8))

        self.var_fps = tk.DoubleVar(value=24)
        self.var_quality = tk.DoubleVar(value=75)
        self.var_scale = tk.DoubleVar(value=0.75)
        self.sld_fps = self._make_slider(fps_frame, "FPS", self.var_fps, 5, 60)
        self.sld_quality = self._make_slider(fps_frame, "Качество JPEG", self.var_quality, 30, 95)
        self.sld_scale = self._make_slider(fps_frame, "Масштаб кадра", self.var_scale, 0.4, 1.0)

        # --- разрешение -----------------------------------------------------
        res_frame = ctk.CTkFrame(tab)
        res_frame.pack(fill="x", padx=12, pady=8)
        ctk.CTkLabel(
            res_frame, text="Разрешение экрана телефона:",
            font=("Arial", 14, "bold"),
        ).pack(anchor="w", padx=12, pady=(10, 2))
        res_row = ctk.CTkFrame(res_frame, fg_color="transparent")
        res_row.pack(fill="x", padx=12, pady=(2, 4))
        self.opt_res = ctk.CTkOptionMenu(
            res_row, values=[*RES_PRESETS.keys(), RES_CUSTOM], width=270,
            command=self._on_res_preset,
        )
        self.opt_res.pack(side="left", padx=(0, 12))
        ctk.CTkLabel(res_row, text="ШxВ:").pack(side="left", padx=(0, 6))
        self.ent_resolution = ctk.CTkEntry(res_row, width=110, justify="center")
        self.ent_resolution.pack(side="left")
        ctk.CTkLabel(
            res_frame, text="Портрет заполняет экран телефона целиком; «Своё…» — правьте ШxВ вручную.",
            text_color="#9CA3AF", justify="left", anchor="w",
        ).pack(anchor="w", padx=12, pady=(0, 10))

        scr_row = ctk.CTkFrame(res_frame, fg_color="transparent")
        scr_row.pack(fill="x", padx=12, pady=(0, 10))
        ctk.CTkLabel(scr_row, text="Экранов:").pack(side="left", padx=(0, 6))
        self.opt_screens = ctk.CTkOptionMenu(
            scr_row, values=["1", "2", "3", "4"], width=70,
        )
        self.opt_screens.set("1")
        self.opt_screens.pack(side="left")

        # --- обои телефона ---------------------------------------------------
        wp_frame = ctk.CTkFrame(tab)
        wp_frame.pack(fill="x", padx=12, pady=8)
        ctk.CTkLabel(
            wp_frame, text="Обои экрана телефона (swww, только headless):",
            font=("Arial", 14, "bold"),
        ).pack(anchor="w", padx=12, pady=(10, 2))
        dir_row = ctk.CTkFrame(wp_frame, fg_color="transparent")
        dir_row.pack(fill="x", padx=12, pady=(2, 4))
        ctk.CTkLabel(dir_row, text="Каталог:").pack(side="left", padx=(0, 6))
        self.ent_wp_dir = ctk.CTkEntry(dir_row, width=280)
        self.ent_wp_dir.pack(side="left", padx=(0, 8))
        ctk.CTkButton(dir_row, text="Обновить список", width=140,
                      command=self._refresh_wallpapers).pack(side="left")
        wp_row = ctk.CTkFrame(wp_frame, fg_color="transparent")
        wp_row.pack(fill="x", padx=12, pady=(2, 4))
        self.opt_wallpaper = ctk.CTkOptionMenu(
            wp_row, values=[wallpaper.NO_WALLPAPER], width=340,
        )
        self.opt_wallpaper.pack(side="left", padx=(0, 8))
        ctk.CTkButton(wp_row, text="Применить обои", width=150,
                      command=self._on_apply_wallpaper).pack(side="left")
        self.lbl_wp_msg = ctk.CTkLabel(
            wp_frame, text="", justify="left", anchor="w", text_color="#9CA3AF",
        )
        self.lbl_wp_msg.pack(fill="x", padx=12, pady=(2, 10))

        btn_row = ctk.CTkFrame(tab, fg_color="transparent")
        btn_row.pack(fill="x", padx=12, pady=10)
        ctk.CTkButton(btn_row, text="Сохранить настройки", width=180,
                      command=self._on_save_config).pack(side="left")
        self.lbl_screen_msg = ctk.CTkLabel(btn_row, text="", text_color=ACCENT)
        self.lbl_screen_msg.pack(side="left", padx=10)

    def _make_slider(self, parent: ctk.CTkFrame, title: str, var: tk.DoubleVar,
                     frm: float, to: float) -> ctk.CTkSlider:
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=2)
        lbl = ctk.CTkLabel(row, text=f"{title}: {var.get():g}", width=150, anchor="w")
        lbl.pack(side="left")

        # trace_add передаёт в колбэк 3 аргумента (имя переменной, index,
        # mode) — сигнатура со строгой одним параметром падала с TypeError
        # при каждом изменении слайдера (3 падения уже на старте GUI).
        def _on_val(*_args: str) -> None:
            lbl.configure(text=f"{title}: {var.get():g}")

        var.trace_add("write", _on_val)
        sld = ctk.CTkSlider(row, from_=frm, to=to, variable=var, width=280)
        sld.pack(side="left", padx=8)
        return sld

    # --- вкладка «Телефон» --------------------------------------------------

    def _build_tab_phone(self, tab: ctk.CTkFrame) -> None:
        top = ctk.CTkFrame(tab, fg_color="transparent")
        top.pack(fill="x", padx=12, pady=(14, 8))
        big = ctk.CTkFrame(top)
        big.pack(side="left", fill="both", expand=True)
        ctk.CTkLabel(
            big, text="Что показывается на телефоне:",
            font=("Arial", 14, "bold"),
        ).pack(anchor="w", padx=12, pady=(10, 2))
        self.lbl_phone_desktop = ctk.CTkLabel(
            big, text="—", font=("Arial", 26, "bold"), text_color=ACCENT,
        )
        self.lbl_phone_desktop.pack(anchor="w", padx=12, pady=(0, 10))
        self.btn_view = ctk.CTkButton(
            top, text="👁  Посмотреть экран телефона", width=230,
            command=self._toggle_preview,
        )
        self.btn_view.pack(side="right", padx=(8, 0), pady=(30, 0))

        info = ctk.CTkFrame(tab)
        info.pack(fill="x", padx=12, pady=8)
        self.lbl_phone_lines = ctk.CTkLabel(
            info, text="ждём сервер…", justify="left", anchor="w",
            font=("Arial", 13),
        )
        self.lbl_phone_lines.pack(fill="x", padx=12, pady=10)

        # --- живой предпросмотр (вся статистика — здесь, не на телефоне) ---
        self.frame_preview = ctk.CTkFrame(tab)
        self.lbl_preview = ctk.CTkLabel(
            self.frame_preview, text="", height=470,
        )
        self.lbl_preview.pack(fill="x", padx=12, pady=(10, 2))
        self.lbl_preview_caption = ctk.CTkLabel(
            self.frame_preview, text="", justify="center", text_color="#9CA3AF",
        )
        self.lbl_preview_caption.pack(fill="x", padx=12, pady=(0, 10))

        note = ctk.CTkLabel(
            tab, justify="left", anchor="w", text_color="#9CA3AF",
            text=(
                "Экран телефона — чистый: FPS/статус показываются только здесь "
                "и в предпросмотре.\nЕсли на телефоне всё ещё видна старая "
                "надпись — нажмите в APK кнопку «Оверлей» (один раз, запоминается)."
            ),
        )
        note.pack(fill="x", padx=12, pady=8)
        self._note_widget = note

    # --- вкладка «Лог» -------------------------------------------------------

    def _build_tab_log(self, tab: ctk.CTkFrame) -> None:
        btn_row = ctk.CTkFrame(tab, fg_color="transparent")
        btn_row.pack(fill="x", padx=12, pady=(12, 4))
        ctk.CTkButton(btn_row, text="Обновить", width=120,
                      command=self._refresh_log).pack(side="left")
        ctk.CTkLabel(btn_row, text=f"хвост {SERVER_LOG}").pack(side="left", padx=10)
        self.txt_log = ctk.CTkTextbox(tab, font=("Monospace", 11))
        self.txt_log.pack(fill="both", expand=True, padx=12, pady=(4, 12))

    # ------------------------------------------------------------- значения

    def _load_initial_values(self) -> None:
        ws = settings_store.get_workspace()
        mode = settings_store.get_fps_mode("auto")
        # Сохранённый config.toml — источник порта/токена/разрешения/экранов
        # (раньше GUI сбрасывал их на дефолты при каждом открытии и перезаписывал
        # config.toml этими дефолтами при первом же старте сервера).
        port, token, res_text, screens_n = "8765", "", "2340x1080", 1
        custom_vals: Optional[tuple[int, int, float]] = None
        cfg_path = os.path.join(BASE_DIR, "config.toml")
        if os.path.exists(cfg_path):
            try:
                saved = Config.from_file(cfg_path)
                s0 = saved.screens[0]
                port = str(saved.port)
                token = saved.auth_token or ""
                res_text = f"{s0.width}x{s0.height}"
                screens_n = max(1, min(4, len(saved.screens)))
                if mode == "auto" and s0.fps_mode in FPS_MODES:
                    mode = s0.fps_mode
                if mode == "custom":
                    custom_vals = (s0.fps, s0.jpeg_quality, s0.scale)
            except Exception:
                pass  # битый toml — работаем на дефолтах
        self.ent_workspace.delete(0, "end")
        self.ent_workspace.insert(0, str(ws))
        if custom_vals is not None:
            self.var_fps.set(float(custom_vals[0]))
            self.var_quality.set(float(custom_vals[1]))
            self.var_scale.set(float(custom_vals[2]))
        self.opt_mode.set(MODE_LABELS.get(mode, MODE_LABELS["auto"]))
        self._on_mode_change(self.opt_mode.get())
        self.ent_port.delete(0, "end")
        self.ent_port.insert(0, port)
        self.ent_token.delete(0, "end")
        if token:
            self.ent_token.insert(0, token)
        self.ent_resolution.delete(0, "end")
        self.ent_resolution.insert(0, res_text)
        # Пресет в меню должен совпадать с реально загруженным разрешением
        # (раньше меню всегда показывало дефолт, даже когда в config.toml
        # было другое).
        res_to_label = {v: k for k, v in RES_PRESETS.items()}
        self.opt_res.set(res_to_label.get(res_text, "Телефон · альбом 2340×1080"))
        self.opt_screens.set(str(screens_n))
        # Обои: каталог из настроек (дефолт ~/Обои) + сохранённый выбор.
        self.ent_wp_dir.delete(0, "end")
        self.ent_wp_dir.insert(0, settings_store.get_wallpaper_dir())
        self._refresh_wallpapers()
        saved_wp = settings_store.get_wallpaper()
        if saved_wp:
            for name, path in self._wp_map.items():
                if os.path.expanduser(path) == os.path.expanduser(saved_wp):
                    self.opt_wallpaper.set(name)
                    break
        if self._migrate_actions:
            self.lbl_screen_msg.configure(
                text="настройки обновлены: " + "; ".join(self._migrate_actions),
                text_color="#FCA5A5",
            )

    def _collect_config(self) -> Config:
        cfg = Config.default()
        try:
            cfg.workspace = max(1, min(99, int(self.ent_workspace.get().strip() or DEFAULT_WORKSPACE)))
        except ValueError:
            cfg.workspace = DEFAULT_WORKSPACE
        try:
            cfg.port = int(self.ent_port.get().strip() or "8765")
        except ValueError:
            cfg.port = 8765
        token = self.ent_token.get().strip()
        cfg.auth_token = token or None
        mode = LABEL_TO_MODE.get(self.opt_mode.get(), "auto")
        res_text = self.ent_resolution.get().strip() or "2340x1080"
        for s in cfg.screens:
            s.fps_mode = mode
            s.apply_fps_mode()
            try:
                w_str, h_str = res_text.lower().split("x", 1)
                s.resolution = (max(320, int(w_str)), max(240, int(h_str)))
            except ValueError:
                pass
            if mode == "custom":
                s.fps = int(self.var_fps.get())
                s.jpeg_quality = int(self.var_quality.get())
                s.scale = float(self.var_scale.get())
        try:
            n = max(1, min(4, int(self.opt_screens.get())))
        except ValueError:
            n = 1
        # Независимые копии: `screens * n` дублировал ССЫЛКИ на один объект —
        # все экраны писали разрешение в один и тот же ScreenConfig.
        cfg.screens = [copy.deepcopy(cfg.screens[0]) for _ in range(n)]
        return cfg

    # ------------------------------------------------------------- действия

    def _on_start(self) -> None:
        cfg = self._collect_config()
        settings_store.set_workspace(cfg.workspace)
        settings_store.set_fps_mode(cfg.screens[0].fps_mode)
        ok, msg = self.server.start(cfg)
        self.lbl_server_msg.configure(
            text=msg, text_color=ACCENT if ok else "#FCA5A5"
        )
        self._tick_status(False)
        self._tick_phone(False)

    def _on_stop(self) -> None:
        ok, msg = self.server.stop()
        self.lbl_server_msg.configure(text=msg, text_color=ACCENT if ok else "#FCA5A5")
        self._tick_status(False)

    def _on_mode_change(self, label: str) -> None:
        """Пресет лочит слайдеры к своим значениям; «Своё» — разрешает правку."""
        mode = LABEL_TO_MODE.get(label, "auto")
        preset = FPS_MODE_PRESETS.get(mode)
        readonly = preset is not None or mode == "auto"
        if preset is not None:
            self.var_fps.set(int(preset["fps"]))
            self.var_quality.set(int(preset["jpeg_quality"]))
            self.var_scale.set(float(preset["scale"]))
        for sld in (self.sld_fps, self.sld_quality, self.sld_scale):
            sld.configure(state="disabled" if readonly else "normal")

    def _on_res_preset(self, label: str) -> None:
        """Пресет разрешения заполняет поле ШxВ («Своё…» оставляет как есть)."""
        value = RES_PRESETS.get(label)
        if value:
            self.ent_resolution.delete(0, "end")
            self.ent_resolution.insert(0, value)

    def _on_apply_workspace(self) -> None:
        """Перепривязать воркспейс на лету (сервер должен работать)."""
        try:
            ws = max(1, min(99, int(self.ent_workspace.get().strip())))
        except ValueError:
            self.lbl_ws_apply.configure(text="нужно число", text_color="#FCA5A5")
            return
        settings_store.set_workspace(ws)
        python_bin = sys.executable
        venv_python = os.path.join(BASE_DIR, ".venv", "bin", "python")
        if os.path.exists(venv_python):
            python_bin = venv_python
        try:
            proc = subprocess.run(
                [python_bin, os.path.join(BASE_DIR, "main.py"), "workspace", str(ws)],
                capture_output=True, text=True, timeout=30,
                cwd=BASE_DIR, env={**os.environ, "PYTHONPATH": BASE_DIR},
            )
            lines = (proc.stdout + proc.stderr).strip().splitlines()
            msg = lines[-1] if lines else f"exit {proc.returncode}"
            color = ACCENT if proc.returncode == 0 else "#FCA5A5"
        except Exception as exc:
            msg = f"ошибка: {exc}"
            color = "#FCA5A5"
        self.lbl_ws_apply.configure(text=msg, text_color=color)
        self._tick_phone()

    # --- обои ---------------------------------------------------------------

    def _refresh_wallpapers(self) -> None:
        """Перечитать список картинок из каталога в поле «Каталог»."""
        directory = self.ent_wp_dir.get().strip() or wallpaper.default_dir()
        previous = self.opt_wallpaper.get()
        files = wallpaper.list_wallpapers(directory)
        expanded = os.path.expanduser(directory)
        self._wp_map = {}
        for p in files:
            try:
                name = os.path.relpath(p, expanded)
            except ValueError:
                name = os.path.basename(p)
            self._wp_map[name] = p
        values = [wallpaper.NO_WALLPAPER, *self._wp_map.keys()]
        self.opt_wallpaper.configure(values=values)
        if previous in values:
            self.opt_wallpaper.set(previous)
        else:
            self.opt_wallpaper.set(wallpaper.NO_WALLPAPER)
        count = len(files)
        self.lbl_wp_msg.configure(
            text=f"найдено изображений: {count}" if count
            else f"в каталоге нет изображений (jpg/png/webp/bmp/gif)"
        )

    def _on_apply_wallpaper(self) -> None:
        """Применить выбранные обои к headless-выводам и запомнить выбор."""
        name = self.opt_wallpaper.get()
        path = self._wp_map.get(name)
        directory = self.ent_wp_dir.get().strip()
        if directory:
            settings_store.set_wallpaper_dir(directory)
        outputs = self._headless_outputs()
        ok, msg = wallpaper.apply(path, outputs)
        if ok:
            settings_store.set_wallpaper(path)
            self.lbl_wp_msg.configure(text=msg, text_color=ACCENT)
        else:
            self.lbl_wp_msg.configure(text=msg, text_color="#FCA5A5")

    @staticmethod
    def _headless_outputs() -> list[str]:
        """Текущие headless-выводы: из state-файла, затем из Hyprland."""
        state = state_file.read_state() or {}
        names: list[str] = []
        for s in state.get("screens") or []:
            mon = s.get("monitor")
            if isinstance(mon, str) and mon.startswith("HEADLESS"):
                names.append(mon)
        if not names:
            names = hyprctl.find_headless_monitors()
        return names

    def _on_save_config(self) -> None:
        cfg = self._collect_config()
        settings_store.set_workspace(cfg.workspace)
        settings_store.set_fps_mode(cfg.screens[0].fps_mode)
        settings_store.set_wallpaper_dir(self.ent_wp_dir.get().strip())
        cfg.save(os.path.join(BASE_DIR, "config.toml"))
        self.lbl_screen_msg.configure(
            text=f"сохранено (воркспейс {cfg.workspace}, режим {cfg.screens[0].fps_mode})",
            text_color=ACCENT,
        )

    def _refresh_log(self) -> None:
        self.txt_log.configure(state="normal")
        self.txt_log.delete("1.0", "end")
        try:
            with open(SERVER_LOG, "r", encoding="utf-8", errors="replace") as fh:
                lines = fh.readlines()[-200:]
            self.txt_log.insert("1.0", "".join(lines) or "(лог пуст)")
        except OSError:
            self.txt_log.insert("1.0", "(лог ещё не создавался)")
        self.txt_log.configure(state="disabled")

    @staticmethod
    def _last_error_line(max_lines: int = 80) -> str:
        """Последняя ERROR/фатальная строка из лога сервера ('' если нет).

        Причина «остановлен (код 1)» показывается прямо в статусе —
        раньше пользователю приходилось самому искать её во вкладке «Лог».
        """
        try:
            with open(SERVER_LOG, "r", encoding="utf-8", errors="replace") as fh:
                lines = fh.readlines()[-max_lines:]
        except OSError:
            return ""
        for raw in reversed(lines):
            line = raw.rstrip()
            if "ERROR" in line or "фатальная" in line or "не удалось" in line:
                # Срезаем префикс «HH:MM:SS LEVEL logger: ».
                parts = line.split(": ", 1)
                text = parts[1] if len(parts) == 2 else line
                return text if len(text) <= 160 else text[:157] + "…"
        return ""

    # --- живой предпросмотр телефона ---------------------------------------

    def _toggle_preview(self) -> None:
        if self._preview_on:
            self._stop_preview()
        else:
            self._preview_on = True
            self.btn_view.configure(text="⏹  Остановить просмотр")
            self.frame_preview.pack(
                fill="x", padx=12, pady=8, before=self._note_widget
            )
            self._preview_tick()

    def _stop_preview(self) -> None:
        self._preview_on = False
        if self._preview_job is not None:
            try:
                self.after_cancel(self._preview_job)
            except Exception:
                pass
            self._preview_job = None
        self.lbl_preview.configure(image=None, text="")
        self.lbl_preview_caption.configure(text="")
        self.frame_preview.pack_forget()
        self.btn_view.configure(text="👁  Посмотреть экран телефона")
        self._preview_photo = None

    def _preview_tick(self) -> None:
        """Раз в 1.5 с: снять headless-вывод и показать картинку."""
        if not self._preview_on:
            return
        if not self._preview_busy:
            self._preview_busy = True
            threading.Thread(target=self._preview_grab, daemon=True).start()
        self._preview_job = self.after(1500, self._preview_tick)

    def _preview_grab(self) -> None:
        """Захват кадра с headless-вывода (в фоне) → обновление UI."""
        png = b""
        err = ""
        state = state_file.read_state() or {}
        monitor: Optional[str] = None
        for s in state.get("screens") or []:
            mon = s.get("monitor")
            if isinstance(mon, str) and mon.startswith("HEADLESS"):
                monitor = mon
                break
        if monitor:
            grim = shutil.which("grim")
            if grim:
                try:
                    proc = subprocess.run(
                        [grim, "-o", monitor, "-t", "png", "-"],
                        check=False, stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE, timeout=10,
                    )
                    if proc.returncode == 0:
                        png = proc.stdout
                    else:
                        err = (proc.stderr or b"").decode(
                            "utf-8", "replace"
                        ).strip() or f"код {proc.returncode}"
                except Exception as exc:  # noqa: BLE001
                    err = str(exc)
        self.after(
            0, lambda: self._set_preview_image(png, state, monitor, err)
        )

    def _set_preview_image(
        self,
        png: bytes,
        state: dict,
        monitor: Optional[str],
        err: str = "",
    ) -> None:
        self._preview_busy = False
        if not self._preview_on:
            return
        if png:
            try:
                img = tk.PhotoImage(data=base64.b64encode(png))
                factor = max(
                    1,
                    -(-img.width() // 320),
                    -(-img.height() // 470),
                )
                if factor > 1:
                    img = img.subsample(factor, factor)
                self._preview_photo = img  # держим ссылку, иначе GC удалит
                self.lbl_preview.configure(image=img, text="")
            except (tk.TclError, binascii.Error):
                self.lbl_preview.configure(image="", text="кадр не декодирован")
        else:
            no_frame = "нет кадра — сервер не запущен или headless-вывод недоступен"
            if err:
                err_short = err if len(err) <= 140 else err[:137] + "…"
                no_frame = f"нет кадра: grim: {err_short}"
            self.lbl_preview.configure(image="", text=no_frame)
        ws = state.get("workspace", DEFAULT_WORKSPACE)
        runtime = (state.get("runtime") or {})
        screens = runtime.get("screens") or []
        parts = [f"{monitor or 'HEADLESS-?'}", f"Рабочий стол {ws}"]
        if screens:
            s0 = screens[0]
            parts.append(f"{s0.get('eff_fps', s0.get('fps', '?'))} FPS")
            parts.append(f"режим {s0.get('fps_mode', '?')}")
        parts.append(f"клиентов: {runtime.get('clients', 0)}")
        self.lbl_preview_caption.configure(text=" · ".join(parts))

    # ------------------------------------------------------------- таймеры

    def _tick_status(self, reschedule: bool = True) -> None:
        """Статус сервера и адрес; раз в секунду (reschedule=False — разово)."""
        if self.server.running():
            self.status_badge.configure(text="● работает", text_color="#34D399")
            pid = self.server.proc.pid if self.server.proc else "?"
            self.lbl_server_line.configure(text=f"Статус: работает (pid {pid})")
            self.btn_start.configure(state="disabled")
            self.btn_stop.configure(state="normal")
        else:
            code = self.server.exit_code()
            text = "● остановлен"
            if code is not None and code not in (0, 130):
                text = f"● остановлен (код {code})"
            self.status_badge.configure(text=text, text_color="#F87171")
            reason = self._last_error_line() if code not in (None, 0, 130) else ""
            self.lbl_server_line.configure(
                text="Статус: остановлен"
                + (f" (код {code})" if code not in (None, 0, 130) else "")
            )
            # Причина падения — сразу в статус (0.13.2), а не только в «Лог».
            if reason:
                self.lbl_server_msg.configure(
                    text=f"Причина: {reason}", text_color="#FCA5A5"
                )
            self.btn_start.configure(state="normal")
            self.btn_stop.configure(state="disabled")
        state = state_file.read_state() or {}
        port = state.get("port", self.ent_port.get() or "8765")
        ip = state.get("ip", "?")
        ws = state.get("workspace", self.ent_workspace.get() or DEFAULT_WORKSPACE)
        self.lbl_addr.configure(text=f"Адрес: {ip}:{port}  (ws://{ip}:{port})")
        self.lbl_ws_hint.configure(text=f"Воркспейс: {ws} — переключение win+{ws}")
        if reschedule:
            self.after(1000, self._tick_status)

    def _tick_phone(self, reschedule: bool = True) -> None:
        """Обновить блок «Телефон»; раз в 2 с (reschedule=False — разово)."""
        state = state_file.read_state()
        if not state:
            self.lbl_phone_desktop.configure(text="—")
            self.lbl_phone_lines.configure(text="сервер не запущен")
        else:
            ws = state.get("workspace", DEFAULT_WORKSPACE)
            self.lbl_phone_desktop.configure(text=f"Рабочий стол {ws}")
            runtime = state.get("runtime") or {}
            screens = runtime.get("screens") or []
            clients = runtime.get("clients", 0)
            lines = [f"Подключение: {'активно' if clients else 'нет клиентов'} "
                     f"({clients} шт.)"]
            if screens:
                s0 = screens[0]
                eff = s0.get("eff_fps", s0.get("fps", "?"))
                mode = s0.get("fps_mode", "?")
                q = s0.get("quality", "?")
                out = s0.get("output", "?")
                lines.append(
                    f"Стрим: {eff} FPS (цель {s0.get('fps', '?')}), "
                    f"режим «{mode}», качество {q}, вывод {out}"
                )
                det = s0.get("clients_detail") or []
                if det:
                    c0 = det[0]
                    lines.append(
                        f"Клиент {c0.get('address', '?')}: "
                        f"{c0.get('fps', 0):.1f} FPS, задержка ~"
                        f"{c0.get('latency_ms_estimate', 0):.0f} мс"
                    )
            lines.append(f"Порт: {state.get('port', '?')} · версия {state.get('version', '?')}")
            self.lbl_phone_lines.configure(text="\n".join(lines))
        if reschedule:
            self.after(2000, self._tick_phone)

    def _on_close(self) -> None:
        self._preview_on = False
        if self._preview_job is not None:
            try:
                self.after_cancel(self._preview_job)
            except Exception:
                pass
        try:
            self.server.stop()
        except Exception:
            pass
        self.destroy()


def main() -> int:
    app = GuiApp()
    app.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
