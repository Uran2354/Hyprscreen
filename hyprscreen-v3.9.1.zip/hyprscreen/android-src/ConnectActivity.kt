@file:Suppress("SpellCheckingInspection") // HyprScreen — не опечатка

package com.example.hyprscreen

import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Экран подключения HyprScreen 3.9.1.
 *
 * Три способа подключиться к PC (как в 2.2.0):
 *  1. Discovery — PC, найденные по UDP-анонсам (:8766), обновляются живьём;
 *  2. Вручную   — IP, порт (по умолчанию 8080), токен (если задан на PC);
 *  3. История   — сохранённые хосты (тап — подключиться, долгий тап — удалить).
 *
 * «Подключиться» проверяет PC запросом GET /info (в 2.x был WebSocket+auth),
 * запоминает хост и передаёт сессию [ScreenStreamService] → [MainActivity].
 *
 * ВАЖНО (SETUP.md §7.8): стрим идёт по обычному http:// — Android 9+ МОЛЧА
 * блокирует такой трафик, если в манифесте нет
 * `android:usesCleartextTraffic="true"`. Симптом: doctor/GUI на ПК зелёные,
 * а здесь — «PC недоступен». [probeServer] распознаёт эту ошибку и показывает
 * подсказку с точным лечением вместо общего «PC недоступен».
 *
 * Дерево View построено в коде (без XML-лейаутов и ресурсов — «плоский
 * один пакет»), стиль — [UiTheme].
 *
 * База — [ComponentActivity], а НЕ AppCompatActivity: AppCompatActivity
 * требует AppCompat-тему и падал с платформенной темой из манифеста §4
 * (IllegalStateException: You need to use a Theme.AppCompat theme…,
 * SETUP.md §7.7). ComponentActivity работает с ЛЮБОЙ темой и без неё.
 */
class ConnectActivity : ComponentActivity() {

    private lateinit var prefs: Prefs
    private lateinit var discovery: Discovery

    private lateinit var statusLabel: TextView
    private lateinit var discoveredBox: LinearLayout
    private lateinit var historyBox: LinearLayout
    private lateinit var entHost: EditText
    private lateinit var entPort: EditText
    private lateinit var entToken: EditText
    private lateinit var btnConnect: Button

    @Volatile private var connecting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Экран подключения всегда ВЕРТИКАЛЬНЫЙ (запрос пользователя, 3.7.0);
        // крутить можно только экран показа (MainActivity, fullSensor с 3.8.0).
        // Код перекрывает манифест — работает и со старым шаблоном §4.
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        // Защита от манифеста без android:name=".HyprScreenApp" (SETUP.md §4):
        // раньше здесь был жёсткий cast, и приложение падало сразу после
        // запуска (ClassCastException). Теперь просто создаём свои Prefs.
        prefs = (application as? HyprScreenApp)?.prefs ?: Prefs(this)
        discovery = Discovery()
        setContentView(buildUi())
        refreshHistory()

        discovery.observeHosts()
        discovery.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        discovery.stop()
    }

    // ------------------------------------------------------------- discovery
    private fun Discovery.observeHosts() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                hosts.collect { list -> renderDiscovered(list) }
            }
        }
    }

    private fun renderDiscovered(list: List<DiscoveredHost>) {
        discoveredBox.removeAllViews()
        if (list.isEmpty()) {
            discoveredBox.addView(sectionNote(
                "PC не найден. Проверьте, что сервер запущен: hyprscreen on"
            ))
            return
        }
        for (host in list) {
            discoveredBox.addView(discoveredRow(host))
        }
    }

    // ------------------------------------------------------------- действия
    private fun connect(host: String, port: Int, token: String?) {
        if (connecting) return
        if (host.isBlank()) {
            setStatus("введите адрес ПК", UiTheme.RED)
            return
        }
        connecting = true
        btnConnect.isEnabled = false
        setStatus("подключение к $host:$port…", UiTheme.TEXT_DIM)

        lifecycleScope.launch {
            val probe = withContext(Dispatchers.IO) { probeServer(host, port, token) }
            connecting = false
            btnConnect.isEnabled = true
            when (probe) {
                ProbeResult.OK -> {
                    prefs.saveHost(host.trim(), port, name = host.trim(), token = token?.takeIf { it.isNotBlank() })
                    val svc = Intent(this@ConnectActivity, ScreenStreamService::class.java).apply {
                        putExtra(ScreenStreamService.EXTRA_HOST, host.trim())
                        putExtra(ScreenStreamService.EXTRA_PORT, port)
                        putExtra(ScreenStreamService.EXTRA_TOKEN, token)
                    }
                    ContextCompat.startForegroundService(this@ConnectActivity, svc)
                    startActivity(Intent(this@ConnectActivity, MainActivity::class.java))
                    finish()
                }
                ProbeResult.FORBIDDEN -> setStatus(
                    "сервер требует токен — введите его из config.toml на ПК", UiTheme.RED)
                ProbeResult.CLEARTEXT -> setStatus(
                    "Android блокирует HTTP (cleartext): добавьте в AndroidManifest.xml "
                        + "к <application> атрибут android:usesCleartextTraffic=\"true\" "
                        + "— SETUP.md §7.8", UiTheme.RED)
                ProbeResult.UNREACHABLE -> setStatus(
                    "PC недоступен: проверьте адрес, сеть и что сервер запущен (hyprscreen on)", UiTheme.RED)
            }
        }
    }

    private enum class ProbeResult { OK, FORBIDDEN, UNREACHABLE, CLEARTEXT }

    /** GET /info — проверка живости и токена (заменяет WebSocket+auth 2.x). */
    private fun probeServer(host: String, port: Int, token: String?): ProbeResult {
        return try {
            val query = token?.takeIf { it.isNotBlank() }
                ?.let { "?t=" + URLEncoder.encode(it, "UTF-8") } ?: ""
            val conn = URL("http://$host:$port/info$query").openConnection()
                as HttpURLConnection
            try {
                conn.connectTimeout = 2500
                conn.readTimeout = 2500
                conn.useCaches = false
                conn.setRequestProperty("Connection", "close")
                val code = conn.responseCode
                try { conn.inputStream?.close() } catch (_: Exception) {}
                when (code) {
                    200 -> ProbeResult.OK
                    401, 403 -> ProbeResult.FORBIDDEN
                    else -> ProbeResult.UNREACHABLE
                }
            } finally {
                conn.disconnect()   // ресурсы соединения не переживают probe
            }
        } catch (e: Exception) {
            android.util.Log.w(TAG, "probe $host:$port не удался: ${e.message}")
            // «Cleartext HTTP traffic to … not permitted» = в манифесте нет
            // usesCleartextTraffic (Android 9+ блокирует http по умолчанию).
            // Раньше это глоталось в общий UNREACHABLE — пользователь видел
            // «PC недоступен» при полностью исправном ПК (SETUP.md §7.8).
            if (e.message.orEmpty().contains("Cleartext", ignoreCase = true)) {
                return ProbeResult.CLEARTEXT
            }
            ProbeResult.UNREACHABLE
        }
    }

    private fun setStatus(text: String, color: Int) {
        statusLabel.text = text
        statusLabel.setTextColor(color)
    }

    private fun refreshHistory() {
        historyBox.removeAllViews()
        val hosts = prefs.savedHosts
        if (hosts.isEmpty()) {
            historyBox.addView(sectionNote("история пуста"))
            return
        }
        for (saved in hosts) {
            historyBox.addView(historyRow(saved))
        }
    }

    // ------------------------------------------------------------------- UI
    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(UiTheme.BG)
            setPadding(dp(18), dp(20), dp(18), dp(20))
        }

        // Шапка: точка + название + описание.
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(titleRow)
        TextView(this).apply {
            text = "●"
            setTextColor(UiTheme.EMERALD)
            textSize = 18f
            gravity = Gravity.CENTER_VERTICAL
            titleRow.addView(this)
        }
        TextView(this).apply {
            text = " HyprScreen"
            setTextColor(UiTheme.TEXT)
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            titleRow.addView(this)
        }
        TextView(this).apply {
            text = "  зеркало экрана ПК"
            setTextColor(UiTheme.TEXT_DIM)
            textSize = 12f
            gravity = Gravity.CENTER_VERTICAL
            titleRow.addView(this)
        }

        statusLabel = TextView(this).apply {
            setTextColor(UiTheme.TEXT_DIM)
            textSize = 13f
            setPadding(0, dp(6), 0, dp(2))
        }
        root.addView(statusLabel)

        // ── «Найдено в сети» ────────────────────────────────────────────
        root.addView(sectionCard("Найдено в сети"))
        discoveredBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = UiTheme.card(resources.displayMetrics.density)
            setPadding(dp(6), dp(4), dp(6), dp(8))
        }
        root.addView(discoveredBox)

        // ── «Вручную» ───────────────────────────────────────────────────
        root.addView(sectionCard("Подключиться вручную"))
        val manual = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = UiTheme.card(resources.displayMetrics.density)
            setPadding(dp(12), dp(10), dp(12), dp(12))
        }
        root.addView(manual)

        entHost = EditText(this).apply {
            hint = "IP компьютера, например 192.168.1.42"
            setSingleLine(true)
            textSize = 14f
            setTextColor(UiTheme.TEXT)
            setHintTextColor(UiTheme.TEXT_HINT)
            background = UiTheme.input(resources.displayMetrics.density)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            manual.addView(this, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) })
        }
        val portTokenRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        manual.addView(portTokenRow)
        entPort = EditText(this).apply {
            hint = "порт"
            setText(ServerInfo.DEFAULT_PORT.toString())
            setSingleLine(true)
            textSize = 14f
            setTextColor(UiTheme.TEXT)
            setHintTextColor(UiTheme.TEXT_HINT)
            background = UiTheme.input(resources.displayMetrics.density)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            portTokenRow.addView(this, LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            ).apply { rightMargin = dp(8) })
        }
        entToken = EditText(this).apply {
            hint = "токен (если есть)"
            setSingleLine(true)
            textSize = 14f
            setTextColor(UiTheme.TEXT)
            setHintTextColor(UiTheme.TEXT_HINT)
            background = UiTheme.input(resources.displayMetrics.density)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            portTokenRow.addView(this, LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f
            ))
        }
        btnConnect = Button(this).apply {
            text = "Подключиться"
            isAllCaps = false
            textSize = 15f
            setTextColor(UiTheme.ON_EMERALD)
            stateListAnimator = null
            background = UiTheme.buttonAccent(resources.displayMetrics.density)
            setOnClickListener {
                connect(
                    entHost.text.toString().trim(),
                    entPort.text.toString().trim().toIntOrNull()
                        ?: ServerInfo.DEFAULT_PORT,
                    entToken.text.toString().trim()
                )
            }
            manual.addView(this, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46)
            ).apply { topMargin = dp(10) })
        }

        // ── «История» ───────────────────────────────────────────────────
        root.addView(sectionCard("История"))
        historyBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = UiTheme.card(resources.displayMetrics.density)
            setPadding(dp(6), dp(4), dp(6), dp(8))
        }
        root.addView(historyBox)

        root.addView(sectionNote(
            "На ПК: hyprscreen on  — сервер найдёт себя сам (discovery).\n" +
            "В стриме: тап по экрану — клавиатура, круглая кнопка вверху — выход.\n" +
            "Телефон в стриме можно повернуть горизонтально — картинка развернётся."
        ))

        // Корневой LinearLayout внутри ScrollView, чтобы всё влезало на малых экранах:
        return android.widget.ScrollView(this).apply {
            setBackgroundColor(UiTheme.BG)
            addView(root)
        }
    }

    private fun sectionCard(title: String): TextView = TextView(this).apply {
        text = title.uppercase()
        UiTheme.styleSectionLabel(this)
        setPadding(dp(2), dp(14), 0, dp(6))
    }

    private fun sectionNote(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextColor(UiTheme.TEXT_HINT)
        textSize = 12f
        setPadding(dp(8), dp(8), dp(8), dp(8))
    }

    private fun discoveredRow(host: DiscoveredHost): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = UiTheme.buttonDark(resources.displayMetrics.density, UiTheme.INPUT)
            setOnClickListener {
                entHost.setText(host.host)
                entPort.setText(host.port.toString())
                connect(host.host, host.port, entToken.text.toString().trim())
            }
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        TextView(this).apply {
            text = host.name.ifBlank { host.host }
            setTextColor(UiTheme.TEXT)
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            texts.addView(this)
        }
        TextView(this).apply {
            text = buildString {
                append("${host.host}:${host.port}")
                if (host.monitor.isNotBlank()) append(" · экран ${host.monitor}")
            }
            setTextColor(UiTheme.TEXT_DIM)
            textSize = 12f
            texts.addView(this)
        }
        row.addView(texts, LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
        ))
        TextView(this).apply {
            text = "▸"
            setTextColor(UiTheme.EMERALD)
            textSize = 18f
            row.addView(this)
        }
        return row
    }

    private fun historyRow(saved: SavedHost): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = UiTheme.buttonDark(resources.displayMetrics.density, UiTheme.INPUT)
            setOnClickListener {
                connect(saved.host, saved.port, saved.token)
            }
            setOnLongClickListener {
                prefs.removeHost(saved.host, saved.port)
                Toast.makeText(context, "удалено", Toast.LENGTH_SHORT).show()
                refreshHistory()
                true
            }
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        TextView(this).apply {
            text = saved.host
            setTextColor(UiTheme.TEXT)
            textSize = 15f
            texts.addView(this)
        }
        TextView(this).apply {
            text = ":${saved.port}" + if (saved.token.isNullOrBlank()) "" else " · с токеном"
            setTextColor(UiTheme.TEXT_DIM)
            textSize = 12f
            texts.addView(this)
        }
        row.addView(texts, LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
        ))
        return row
    }

    companion object {
        private const val TAG = "HyprScreen/Connect"
    }
}
