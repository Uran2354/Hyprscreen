"""State-файл для межзапусковой координации PC-стороны HyprScreen.

Сервер (``run``) пишет сюда актуальные имена виртуальных выводов при старте,
удаляет при остановке. Команда ``workspace`` читает этот файл, чтобы знать,
на какой HEADLESS переносить воркспейс.
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


def state_path() -> Path:
    """Вернуть путь к state-файлу."""
    cache = os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache"))
    return Path(cache) / "hyprscreen" / "state.json"


def write_state(screens: list[dict[str, Any]], port: int = 8765, pid: int | None = None) -> None:
    """Записать текущее состояние сервера."""
    path = state_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "pid": pid if pid is not None else os.getpid(),
            "port": port,
            "screens": screens,
        }
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except OSError as exc:
        log.warning("не удалось записать state-файл %s: %s", path, exc)


def read_state() -> dict[str, Any] | None:
    """Прочитать state-файл."""
    path = state_path()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except (OSError, json.JSONDecodeError) as exc:
        log.warning("не удалось прочитать state-файл %s: %s", path, exc)
    return None


def clear_state() -> None:
    """Удалить state-файл."""
    path = state_path()
    try:
        if path.exists():
            path.unlink()
    except OSError as exc:
        log.warning("не удалось удалить state-файл %s: %s", path, exc)


def monitor_for_screen(screen_index: int) -> str | None:
    """Вернуть имя монитора для экрана из state-файла (или fallback на HEADLESS-*)."""
    state = read_state()
    if state and isinstance(state.get("screens"), list):
        for s in state["screens"]:
            if int(s.get("index", -1)) == screen_index:
                mon = s.get("monitor")
                if isinstance(mon, str) and mon:
                    return mon
    # Fallback: ищем HEADLESS-* в Hyprland.
    try:
        import hyprctl
        headless = hyprctl.find_headless_monitors()
        if headless:
            def _idx(name: str) -> int:
                try:
                    return int(name.split("-", 1)[1])
                except (ValueError, IndexError):
                    return 0
            headless_sorted = sorted(headless, key=_idx)
            if screen_index < len(headless_sorted):
                return headless_sorted[screen_index]
            return headless_sorted[0]
    except Exception:
        pass
    return None
