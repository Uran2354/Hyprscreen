#!/usr/bin/env bash
#
# Одноразовая настройка HyprScreen на CachyOS / Hyprland 0.55+ (Arch-based).
#
# Что делает:
#  - ставит системные пакеты (grim, wtype, python-evdev, swww, openssl);
#  - проверяет группу input (права на /dev/uinput для evdev);
#  - создаёт Python-venv в ./.venv и ставит Python-зависимости (websockets, evdev);
#  - копирует config.toml.example → config.toml, если ещё нет;
#  - опционально (--install) создаёт симлинк ~/.local/bin/hyprscreen
#    на ./run.sh (для exec-once = hyprscreen в hyprland.conf).
#
# Повторный запуск безопасен — скрипт идемпотентен.
#
# Использование:
#   ./setup.sh                # сделать всё
#   ./setup.sh --install      # + создать симлинк ~/.local/bin/hyprscreen
#   ./setup.sh --dry-run      # показать, что было бы сделано, без изменений

set -euo pipefail

DRY_RUN=0
DO_INSTALL=0
for arg in "$@"; do
    case "$arg" in
        --dry-run|-n)
            DRY_RUN=1
            ;;
        --install)
            DO_INSTALL=1
            ;;
        -h|--help)
            sed -n '2,21p' "$0"
            exit 0
            ;;
        *)
            echo "!! неизвестный аргумент: $arg" >&2
            exit 2
            ;;
    esac
done

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
cd "$SCRIPT_DIR"

VENV_DIR="${VENV_DIR:-$SCRIPT_DIR/.venv}"
PYTHON="${PYTHON:-python}"

echo "=== Настройка HyprScreen (CachyOS / Hyprland) ==="
if [[ "$DRY_RUN" -eq 1 ]]; then
    echo "(dry-run: установка пакетов / venv / pip / systemctl будут пропущены)"
fi
echo "  каталог скрипта : $SCRIPT_DIR"
echo "  venv            : $VENV_DIR"
echo "  python          : $PYTHON"
echo ""

# ------------------------------------------------------------------
# 1. Системные пакеты
# ------------------------------------------------------------------
need_pkgs=()
command -v grim     >/dev/null 2>&1 || need_pkgs+=(grim)
command -v wtype    >/dev/null 2>&1 || need_pkgs+=(wtype)
command -v swww     >/dev/null 2>&1 || need_pkgs+=(swww)
command -v openssl  >/dev/null 2>&1 || need_pkgs+=(openssl)
command -v "$PYTHON" >/dev/null 2>&1 || need_pkgs+=(python python-pip)
command -v pip      >/dev/null 2>&1 || need_pkgs+=(python-pip)
# python-evdev — для UInput (виртуальное устройство ввода).
pacman -Qi python-evdev >/dev/null 2>&1 || need_pkgs+=(python-evdev)

if [[ ${#need_pkgs[@]} -gt 0 ]]; then
    echo ">> Устанавливаю системные пакеты: ${need_pkgs[*]}"
    if [[ "$DRY_RUN" -eq 1 ]]; then
        echo "   (dry-run) было бы: sudo pacman -S --needed ${need_pkgs[*]}"
    else
        sudo pacman -S --needed --noconfirm "${need_pkgs[@]}"
    fi
else
    echo ">> Все нужные системные пакеты уже установлены."
fi

# ------------------------------------------------------------------
# 2. Опционально: portal-бэкенд захвата (xdg-desktop-portal-hyprland + pipewire)
#    Ставим если доступно, но не падаем если пропущено — grim работает и без.
# ------------------------------------------------------------------
portal_pkgs=()
pacman -Qi xdg-desktop-portal-hyprland >/dev/null 2>&1 || portal_pkgs+=(xdg-desktop-portal-hyprland)
pacman -Qi pipewire                    >/dev/null 2>&1 || portal_pkgs+=(pipewire)

if [[ ${#portal_pkgs[@]} -gt 0 ]]; then
    echo ""
    echo ">> Опционально: portal-бэкенду нужны: ${portal_pkgs[*]}"
    echo "   (только если поставите capture_backend = \"portal\" в config.toml; grim работает и без.)"
    if [[ "$DRY_RUN" -eq 1 ]]; then
        echo "   (dry-run) было бы: sudo pacman -S --needed ${portal_pkgs[*]}"
    else
        # Без --noconfirm: pacman может потребовать выбор провайдера.
        # Ошибка — не критична.
        sudo pacman -S --needed "${portal_pkgs[@]}" || \
            echo "   !! portal-пакеты не установлены; продолжаем (будет grim)."
    fi
fi

# ------------------------------------------------------------------
# 3. User-сервис ydotoold
#    Arch / CachyOS поставляют 'ydotoothy' как systemd user-юнит. В старых
#    сборках он назывался 'ydotoold'; пробуем оба.
# ------------------------------------------------------------------
echo ""
echo ">> Включаю user-сервис ydotoold (для инъекции ввода через ydotool)"

enable_unit=""
if systemctl --user list-unit-files --plain --no-legend 2>/dev/null | grep -q '^ydotoothy\.service'; then
    enable_unit="ydotoothy"
elif systemctl --user list-unit-files --plain --no-legend 2>/dev/null | grep -q '^ydotoold\.service'; then
    enable_unit="ydotoold"
else
    # Запасной вариант: пробуем сначала ydotoothy, потом ydotoold.
    enable_unit="ydotoothy"
fi

if [[ "$DRY_RUN" -eq 1 ]]; then
    echo "   (dry-run) было бы: systemctl --user enable --now ${enable_unit}"
else
    if ! systemctl --user enable --now "${enable_unit}" 2>/dev/null; then
        if [[ "$enable_unit" != "ydotoold" ]]; then
            echo "   ydotoothy не найден; пробую ydotoold..."
            if ! systemctl --user enable --now ydotoold 2>/dev/null; then
                echo "   !! Не удалось включить ydotoothy или ydotoold."
                echo "      Установите ydotool вручную: sudo pacman -S ydotool"
                echo "      Затем: systemctl --user enable --now ydotoothy"
            else
                enable_unit="ydotoold"
            fi
        else
            echo "   !! Не удалось включить ${enable_unit}."
            echo "      Убедитесь, что ydotool установлен: sudo pacman -S ydotool"
        fi
    fi
fi
echo "   сервис ydotoold : ${enable_unit}"

# Если ydotool не может открыть /dev/uinput, может понадобиться группа input.
if ! id -nG | tr ' ' '\n' | grep -qx input; then
    echo "   заметка: пользователь '$USER' не в группе 'input'."
    echo "   если позже будет 'ydotool: Permission denied', выполните:"
    echo "       sudo usermod -aG input \"\$USER\"   # затем выйдите и войдите снова"
fi

# ------------------------------------------------------------------
# 4. Python-venv + pip install
# ------------------------------------------------------------------
echo ""
echo ">> Python-venv в $VENV_DIR"
if [[ "$DRY_RUN" -eq 1 ]]; then
    echo "   (dry-run) было бы: создать venv (если нет) и pip install -r requirements.txt"
else
    if [[ ! -d "$VENV_DIR" ]]; then
        "$PYTHON" -m venv "$VENV_DIR"
    fi
    # shellcheck disable=SC1091
    source "$VENV_DIR/bin/activate"
    python -m pip install --quiet --upgrade pip
    python -m pip install --quiet -r requirements.txt
fi

# ------------------------------------------------------------------
# 5. config.toml из примера
# ------------------------------------------------------------------
echo ""
echo ">> Локальный config.toml"
if [[ -f "$SCRIPT_DIR/config.toml" ]]; then
    echo "   $SCRIPT_DIR/config.toml уже существует — не трогаю."
else
    if [[ "$DRY_RUN" -eq 1 ]]; then
        echo "   (dry-run) было бы: cp config.toml.example → config.toml"
    else
        cp "$SCRIPT_DIR/config.toml.example" "$SCRIPT_DIR/config.toml"
        echo "   создан: $SCRIPT_DIR/config.toml (отредактируйте под себя)"
    fi
fi

# ------------------------------------------------------------------
# 6. Опционально: симлинк hyprscreen → run.sh
# ------------------------------------------------------------------
if [[ "$DO_INSTALL" -eq 1 ]]; then
    echo ""
    echo ">> Установка команды 'hyprscreen' в PATH"
    BINDIR="${HOME}/.local/bin"
    TARGET="$SCRIPT_DIR/run.sh"
    LINK="$BINDIR/hyprscreen"
    if [[ "$DRY_RUN" -eq 1 ]]; then
        echo "   (dry-run) было бы: mkdir -p $BINDIR && ln -sf $TARGET $LINK"
    else
        mkdir -p "$BINDIR"
        ln -sfn "$TARGET" "$LINK"
        # Если ~/.local/bin не в PATH — подсказываем.
        case ":${PATH}:" in
            *":${BINDIR}:"*) ;;
            *)
                echo "   заметка: $BINDIR не найден в PATH."
                echo "   добавьте в ~/.bashrc / ~/.zshrc:"
                echo "       export PATH=\"\$HOME/.local/bin:\$PATH\""
                ;;
        esac
    fi
    echo "   теперь можно запускать: hyprscreen --screens 2"
    echo "   и добавить в hyprland.conf: exec-once = hyprscreen"
fi

# ------------------------------------------------------------------
# 7. Сводка / следующие шаги
# ------------------------------------------------------------------
echo ""
echo "=== Настройка завершена ==="
echo ""
echo "Следующие шаги:"
echo "  1. cd \"$(dirname "$0")\""
echo "  2. Отредактируйте config.toml (auth_token, resolution, fps)"
if [[ "$DRY_RUN" -ne 1 ]]; then
    echo "  3. ./run.sh                       # интерактивное меню"
else
    echo "  3. ./run.sh                       # (dry-run пропустил создание venv)"
fi
echo ""
echo "Подкоманды:"
echo "  ./run.sh                           # интерактивное меню (по умолчанию)"
echo "  ./run.sh run                       # только сервер"
echo "  ./run.sh kill                      # найти и убить сервер + очистить HEADLESS"
echo "  ./run.sh reset                     # удалить все HEADLESS-*"
echo "  ./run.sh list                      # показать мониторы/воркспейсы"
echo "  ./run.sh workspace 6               # перенести воркспейс на телефон"
echo "  ./run.sh diagnose                  # диагностика IPC Hyprland"
echo "  ./run.sh grimtest                  # тест захвата grim"
echo ""
echo "Дополнительные флаги:"
echo "  ./run.sh --auth-token secret       # токен авторизации"
echo "  ./run.sh --screens 2               # два виртуальных экрана"
echo "  ./run.sh --wallpaper ~/Pictures/wp.jpg  # обои swww"
echo "  ./run.sh --image-format webp       # WebP вместо JPEG"
echo "  ./run.sh --tls                     # TLS (wss://)"
echo "  ./run.sh --input-rate-limit 100    # rate-limit ввода"
echo ""
echo "Файрвол (открыть порт WebSocket + UDP discovery):"
echo "  sudo firewall-cmd --permanent --add-port=8765/tcp"
echo "  sudo firewall-cmd --permanent --add-port=8766/udp"
echo "  sudo firewall-cmd --reload"
echo ""
echo "На телефоне: введите IP PC, порт 8765, токен из config.toml"
