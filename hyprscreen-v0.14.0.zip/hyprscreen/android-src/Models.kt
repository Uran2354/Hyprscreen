package com.example.hyprscreen

import kotlinx.serialization.Serializable

/**
 * Классы данных и алгебра [InputEvent], общие для всего Android-клиента HyprScreen.
 *
 * Здесь живёт всё, что нужно wire-протоколу:
 *  - [ServerInfo] / [FrameStats] / [SavedHost] / [DiscoveredHost] для UI.
 *  - Запечатанный класс [InputEvent] для событий касания/клавиатуры, которые
 *    активность пересылает в [ScreenClient.sendInput].
 *  - `@Serializable`-объекты, повторяющие JSON-форматы, ожидаемые Python-сервером
 *    (по одному на каждый вариант InputEvent + hello + discovery-анонс + error).
 *
 * Мульти-экранность: hello-сообщение теперь несёт поля `screen` и `total_screens`,
 * discovery-анонс — `screens`, [ServerInfo]/[SavedHost]/[DiscoveredHost] хранят
 * индекс выбранного экрана. WS-URL формируется как `ws://<host>:<port>/<index>`.
 */

/**
 * Информация о PC-сервере, к которому мы подключены (или вот-вот подключимся).
 *
 * `width`, `height`, `fps` приходят в JSON-сообщении hello сразу после открытия
 * WebSocket. `screen`/`totalScreens` там же — индекс этого экрана и сколько всего
 * экранов отдаёт PC (мульти-экранный режим, см. PROTOCOL.md §3.1).
 */
data class ServerInfo(
    val host: String,
    val port: Int = 8765,
    val name: String? = null,
    val width: Int = 1920,
    val height: Int = 1080,
    val fps: Int = 30,
    val screen: Int = 0,
    val totalScreens: Int = 1,
    /** 0.11.0: сервер разрешает/запрещает служебную надпись (hello overlay). */
    val serverOverlay: Boolean = true
)

/**
 * Статистика соединения/рендеринга для оверлея. Мутится на месте декодером;
 * копируется при отправке листенерам.
 */
data class FrameStats(
    var framesDecoded: Long = 0,
    var framesDropped: Long = 0,
    var lastDecodeMs: Long = 0,
    var fps: Double = 0.0,
    var latencyMs: Long = 0,
    var connectedForMs: Long = 0
)

/**
 * Сохранённый хост из истории экрана подключения.
 * Поле [screen] запоминает, к какому экрану PC подключались в последний раз.
 */
data class SavedHost(
    val host: String,
    val port: Int,
    val name: String? = null,
    val screen: Int = 0,
    val lastUsed: Long = System.currentTimeMillis(),
    val token: String? = null
)

/**
 * Хост, обнаруженный через UDP-broadcast (см. [Discovery]).
 * Поле [screens] сообщает, сколько экранов отдаёт PC (1, 2, …) — UI показывает
 * выбор экрана для подключения.
 */
data class DiscoveredHost(
    val host: String,
    val port: Int,
    val name: String,
    val screens: Int = 1
)

/**
 * События ввода, порождаемые UI и пересылаемые в [ScreenClient.sendInput].
 * Клиент сериализует их в JSON-формат, ожидаемый Python-сервером.
 */
sealed class InputEvent {
    /** Абсолютное перемещение указателя, координаты в пикселях источника. */
    data class PointerMove(val x: Float, val y: Float) : InputEvent()
    /** Нажатие кнопки указателя в заданной пиксельной координате источника. */
    data class PointerDown(val x: Float, val y: Float, val button: String) : InputEvent()
    /** Отпускание кнопки указателя. */
    data class PointerUp(val button: String) : InputEvent()
    /** Дельта колеса прокрутки (положительное значение = вниз/вправо). */
    data class Scroll(val dx: Float, val dy: Float) : InputEvent()
    /** Нажатие клавиши с опциональными модификаторами (ctrl/shift/alt/meta). */
    data class Key(val keysym: String, val modifiers: List<String> = emptyList()) : InputEvent()
    /** Порция текста для инъекции (например, с мягкой клавиатуры). */
    data class Text(val text: String) : InputEvent()
}

// ---- Сериализуемые wire-объекты (внутренние для клиента) ----

/**
 * Конверт с дискриминатором `type` для текстовых сообщений сервера.
 * Используется, чтобы отличить `hello` от `error` ДО полного декодирования
 * (см. PROTOCOL.md §3.1, §3.3 и критический баг #7 аудита).
 * Поле сделано nullable: при отсутствии `type` считаем сообщение hello
 * (обратная совместимость со старыми серверами).
 */
@Serializable
internal data class WireEnvelope(
    val type: String? = null
)

/**
 * Hello-сообщение от сервера (PROTOCOL.md §3.1).
 *
 * Поля `width`/`height` — это размер ЭТОГО экрана в пикселях (источник истины
 * для масштабирования касаний). Поле `type` по умолчанию `"hello"` позволяет
 * отличить его от [ErrorMessage]. Все «лишние» поля (`server`, `version`,
 * `jpeg_quality`, `capture_backend`, `output`, `server_time` и т. д.) молча
 * игнорируются, т.к. Json-инстанция сконфигурирована с `ignoreUnknownKeys=true`.
 */
@Serializable
internal data class HelloMessage(
    val type: String = "hello",
    val width: Int = 1920,
    val height: Int = 1080,
    val fps: Int = 30,
    val screen: Int = 0,
    val total_screens: Int = 1,
    /** 0.11.0: сервер просит не рисовать служебную надпись (статус — в PC GUI). */
    val overlay: Boolean = true
)

/**
 * Сообщение об ошибке от сервера (PROTOCOL.md §3.3).
 * Сервер шлёт его, например, при malformed-input или неизвестном индексе экрана.
 */
@Serializable
internal data class ErrorMessage(
    val type: String = "error",
    val error: String = ""
)

/**
 * Discovery-анонс, рассылаемый PC по UDP (PROTOCOL.md §5).
 * Поле `screens` — сколько экранов отдаёт этот PC.
 */
@Serializable
internal data class DiscoveryAnnouncement(
    val hyprscreen: Boolean = false,
    val host: String,
    val port: Int = 8765,
    val screens: Int = 1,
    val name: String = "PC"
)

@Serializable
internal data class PointerMovePayload(
    val type: String = "pointer_move",
    val x: Float,
    val y: Float
)

@Serializable
internal data class PointerDownPayload(
    val type: String = "pointer_down",
    val x: Float,
    val y: Float,
    val button: String
)

@Serializable
internal data class PointerUpPayload(
    val type: String = "pointer_up",
    val button: String
)

@Serializable
internal data class ScrollPayload(
    val type: String = "scroll",
    val dx: Float,
    val dy: Float
)

@Serializable
internal data class KeyPayload(
    val type: String = "key",
    val keysym: String,
    val modifiers: List<String> = emptyList()
)

@Serializable
internal data class TextPayload(
    val type: String = "text",
    val text: String
)

/**
 * Auth-сообщение: клиент отправляет его ПЕРВЫМ после onOpen, если сервер
 * требует авторизацию (config.auth_token на PC). Сервер отвечает hello
 * после успешной auth, либо закрывает соединение с кодом 1008.
 */
@Serializable
internal data class AuthPayload(
    val type: String = "auth",
    val token: String
)
