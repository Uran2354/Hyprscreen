"""Persistent user settings for HyprScreen interactive mode.

Хранит выбранные обои и привязки воркспейсов между запусками:
  ~/.config/hyprscreen/settings.json
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


def _settings_path() -> Path:
    config_home = os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config"))
    return Path(config_home) / "hyprscreen" / "settings.json"


def load_settings() -> dict[str, Any]:
    path = _settings_path()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except (OSError, json.JSONDecodeError) as exc:
        log.warning("settings: %s", exc)
    return {}


def save_settings(settings: dict[str, Any]) -> None:
    path = _settings_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(settings, indent=2, ensure_ascii=False), encoding="utf-8")
    except OSError as exc:
        log.warning("settings save: %s", exc)


def get_wallpaper() -> str | None:
    return load_settings().get("wallpaper")


def set_wallpaper(path: str) -> None:
    s = load_settings()
    s["wallpaper"] = path
    save_settings(s)


def get_workspace_bindings() -> dict[str, int]:
    b = load_settings().get("workspaces", {})
    if isinstance(b, dict):
        return {str(k): int(v) for k, v in b.items() if isinstance(v, (int, str))}
    return {}


def set_workspace_binding(workspace: str, screen_index: int) -> None:
    s = load_settings()
    s.setdefault("workspaces", {})[workspace] = screen_index
    save_settings(s)
