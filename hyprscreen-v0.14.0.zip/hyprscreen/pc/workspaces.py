"""Привязка рабочих столов к виртуальным headless-выводам HyprScreen.

ЕДИНЫЙ источник истины по воркспейсам — раньше такая логика была
размазана по main/server/interactive и накапливала правила
(``hl.workspace_rule`` добавлял правило при каждом вызове и никогда не
удалял: за несколько запусков набирались правила 3, 4, 5 — и «телефонный
экран» открывался на всех свободных номерах).

Как теперь (0.11.0)
-------------------
* Номер воркспейса выбирает пользователь (по умолчанию **6**),
  дрейфа «следующего свободного» больше нет.
* Правила ставятся через ``hyprctl keyword workspace
  "<N>,monitor:<M>,default:true"`` и снимаются через
  ``hyprctl unkeyword workspace`` — накопление невозможно по
  построению. ``default:true`` — как в 0.10.0: headless «рождается»
  сразу с нужным воркспейсом (без него после создания вывода активным
  оставался пустой авто-воркспейс, и на телефоне вместо выбранного
  номера был пустой стол — «на 6 воркспейсе не показывает что
  должно»).
* Перед привязкой и после неё с headless-монитора эвакуируются все
  «посторонние» воркспейсы (в т.ч. авто-созданный при ``output create``)
  — на телефоне живёт ровно один номер.
* Пустые HEADLESS-выводы прошлых запусков убираются при старте
  (:func:`hyprctl.cleanup_phantom_outputs`).

Окна пользователя не страдают: если выбранный номер занят на физическом
мониторе, воркспейс вместе с окнами переносится на телефон, а при
остановке сервера — возвращается обратно.
"""

from __future__ import annotations

import logging
from typing import Any

import hyprctl
from config import Config

log = logging.getLogger(__name__)


def _ws_id(w: dict[str, Any]) -> str | None:
    """Идентификатор воркспейса из записи ``hyprctl -j workspaces``."""
    wid = w.get("id", w.get("name"))
    if wid is None:
        return None
    return str(wid)


def workspaces_on_monitor(monitor: str) -> list[str]:
    """Список id воркспейсов, живущих на данном мониторе (best-effort)."""
    try:
        data = hyprctl.list_workspaces()
    except hyprctl.HyprctlError as exc:
        log.warning("не удалось получить workspaces: %s", exc)
        return []
    out = []
    for w in data:
        if str(w.get("monitor", "")) == monitor:
            wid = _ws_id(w)
            if wid:
                out.append(wid)
    return out


def _focus_real_monitor() -> None:
    """Вернуть фокус на физический монитор (headless не должен его отбирать)."""
    real = hyprctl.real_monitors()
    if not real:
        return
    try:
        hyprctl.dispatch("focusmonitor", real[0])
    except hyprctl.HyprctlError as exc:
        log.debug("focusmonitor %s: %s", real[0], exc)


def _evacuate_stray(monitor: str, keep: set[str]) -> None:
    """Перенести все воркспейсы monitor (кроме keep) на физический монитор."""
    target = hyprctl.real_monitors()[:1]
    if not target:
        return
    for wid in workspaces_on_monitor(monitor):
        if wid in keep:
            continue
        try:
            log.info("эвакуация постороннего воркспейса %s с %s → %s", wid, monitor, target[0])
            hyprctl.move_workspace_to_monitor(wid, target[0])
        except hyprctl.HyprctlError as exc:
            log.warning("эвакуация %s: %s", wid, exc)


def _active_workspace_on(monitor: str) -> str | None:
    """Активный воркспейс монитора (поле ``activeWorkspace``) или None.

    Полностью defensive: любая ошибка — «неизвестно», активация ниже
    просто сработает (она best-effort и не должна ломать bind).
    """
    try:
        mons = hyprctl.monitors()
    except Exception as exc:  # noqa: BLE001 - defensive
        log.warning("не удалось получить monitors: %s", exc)
        return None
    for m in mons:
        if str(m.get("name", "")) != monitor:
            continue
        aw = m.get("activeWorkspace") or {}
        wid = aw.get("id", aw.get("name"))
        return str(wid) if wid is not None else None
    return None


def _activate(monitor: str, ws: int) -> None:
    """Сделать воркспейс ``ws`` активным на headless-мониторе (best-effort).

    После ``output create headless`` активным на выводе остаётся пустой
    авто-воркспейс — телефон показывает пустой стол, хотя привязка уже
    стоит. ``dispatch workspace N`` открывает воркспейс на СВОЁМ мониторе
    (правило ``monitor:...``), фокус возвращается физическому монитору
    в конце :func:`bind` (как в 0.10.0).
    """
    if _active_workspace_on(monitor) == str(ws):
        return
    try:
        hyprctl.dispatch("workspace", str(ws))
        log.info("воркспейс %d активирован на %s", ws, monitor)
    except hyprctl.HyprctlError as exc:
        log.warning("активация воркспейса %d на %s: %s", ws, monitor, exc)


def bind(cfg: Config, output_names: list[str]) -> list[dict[str, Any]]:
    """Привязать воркспейсы к headless-выводам. Возвращает список привязок.

    Для экрана i привязывается воркспейс ``cfg.workspace + i`` к выводу
    ``output_names[i]`` (1 экран → ровно один номер). Перед привязкой
    снимаются накопленные runtime-правила (``unkeyword workspace``).

    Каждая привязка: ``{"workspace": N, "monitor": "HEADLESS-1"}``.
    После привязки воркспейс ЯВНО активируется на своём headless-выводе
    (иначе телефон показывает пустой авто-воркспейс).
    """
    # 1. Снять ВСЕ runtime-правила воркспейсов, поставленные раньше
    #    (в т.ч. накопленные прошлыми запусками 3-5).
    reply = hyprctl.unkeyword("workspace")
    log.info("unkeyword workspace: %s", (reply or "ok").strip()[:80])

    bindings: list[dict[str, Any]] = []
    for i, output_name in enumerate(output_names):
        ws = min(99, cfg.workspace + i)
        # 2. Правило: этот номер живёт на этом headless-выводе и является
        #    для него стартовым (default:true — headless «рождается» с ним,
        #    как в 0.10.0).
        try:
            hyprctl.keyword("workspace", f"{ws},monitor:{output_name},default:true")
        except hyprctl.HyprctlError as exc:
            log.error("keyword workspace %d -> %s: %s", ws, output_name, exc)
        # 3. Если номер уже существует НЕ на headless — переносим его туда
        #    (окна переезжают вместе с ним).
        try:
            hyprctl.move_workspace_to_monitor_checked(str(ws), output_name)
        except hyprctl.HyprctlError as exc:
            log.debug("workspace %s пока не существует (нормально): %s", ws, exc)
        # 4. Посторонние воркспейсы (например, авто-созданный при output
        #    create) выселяем с телефона — там живёт только выбранный номер.
        _evacuate_stray(output_name, keep={str(ws)})
        # 5. Телефон должен показывать ИМЕННО этот номер: если активным
        #    остался пустой авто-воркспейс — активируем наш.
        _activate(output_name, ws)
        bindings.append({"workspace": ws, "monitor": output_name})
        log.info("воркспейс %d привязан к %s", ws, output_name)

    # 6. Фокус — на физический монитор, чтобы headless «не мигал» при старте.
    _focus_real_monitor()
    return bindings


def unbind(output_names: list[str]) -> None:
    """Отвязать воркспейсы перед удалением headless-выводов.

    Воркспейсы (вместе с окнами) возвращаются на физический монитор,
    runtime-правила снимаются, фокус возвращается пользователю.
    """
    for output_name in output_names:
        _evacuate_stray(output_name, keep=set())
    hyprctl.unkeyword("workspace")
    _focus_real_monitor()
