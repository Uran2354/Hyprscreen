package com.example.hyprscreen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.View

/**
 * Custom View, рисующий последний JPEG-кадр, полученный от PC.
 *
 * Отрисовка — «fit-center»: исходный bitmap масштабируется равномерно (с
 * сохранением соотношения сторон) и центрируется внутри View, оставляя
 * letterbox-полосы там, где соотношения сторон не совпадают.
 *
 * Кадры публикуются [ScreenClient] через [updateBitmap], который атомарно
 * меняет ссылку [currentBitmap] и зовёт [invalidate]. Отрисовка читает
 * последний bitmap без дальнейшей синхронизации — `@Volatile` даёт нам
 * безопасную публикацию. Размер источника берётся из САМОГО битмапа
 * (фикс «картинки на пол-экрана» из 2.1.7) и дополнительно из /info.
 *
 * [StatusOverlay] рисуется поверх в левом-нижнем углу, поэтому активности
 * не нужен отдельный overlay-View.
 *
 * В 3.x касания НИКУДА не отправляются (телефон — не тачпад): на View нет
 * touch-листенера, а `viewToSource` удалён за ненадобностью.
 */
class ScreenView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    @Volatile private var currentBitmap: Bitmap? = null

    private val srcRect = RectF()
    private val dstRect = RectF()
    private val drawMatrix = Matrix()

    private var srcWidth = 1920
    private var srcHeight = 1080
    private var matrixDirty = true

    private val bgPaint = Paint().apply { color = Color.BLACK }
    private val bmpPaint = Paint().apply {
        isFilterBitmap = true
        isDither = true
    }

    // Фикс «чёрного экрана без объяснений» (2.0.0): если соединение живо,
    // но кадры не приходят дольше [noSignalAfterMs], рисуем плашку
    // «НЕТ СИГНАЛА» вместо немого чёрного экрана.
    private val warnPaint = Paint().apply {
        color = 0xE6141414.toInt()          // #141414 на 90%
        isAntiAlias = true
    }
    private val warnStrokePaint = Paint().apply {
        color = 0xFF7F1D1D.toInt()          // рамка red-800
        style = Paint.Style.STROKE
        strokeWidth = 4f
        isAntiAlias = true
    }
    private val warnTextPaint = Paint().apply {
        color = 0xFFF87171.toInt()          // red-400
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
        textSize = 42f
    }
    private val warnSubTextPaint = Paint().apply {
        color = 0xFFA3A3A3.toInt()          // neutral-400
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
        textSize = 26f
    }
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile private var connected: Boolean = false
    @Volatile private var lastFrameAtMs: Long = 0
    private val noSignalAfterMs: Long = 5000

    private val stalenessTicker = object : Runnable {
        override fun run() {
            if (!connected || !isAttachedToWindow) return  // не перезапускаемся вечно
            invalidate()
            mainHandler.postDelayed(this, 1000)
        }
    }

    private val overlay = StatusOverlay()

    /** Установить размер источника из /info (уточняется первым битмапом). */
    fun setSourceSize(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        if (w == srcWidth && h == srcHeight) return
        srcWidth = w
        srcHeight = h
        matrixDirty = true
        invalidate()
    }

    /** Атомарно подменить последний декодированный bitmap и перерисовать. */
    fun updateBitmap(bitmap: Bitmap) {
        val bw = bitmap.width
        val bh = bitmap.height
        if (bw > 0 && bh > 0 && (bw != srcWidth || bh != srcHeight)) {
            srcWidth = bw
            srcHeight = bh
            matrixDirty = true
        }
        currentBitmap = bitmap
        lastFrameAtMs = System.currentTimeMillis()
        invalidate()
    }

    /** Соединение установлено/разорвано. */
    fun setConnected(value: Boolean) {
        connected = value
        if (value) {
            if (lastFrameAtMs == 0L) lastFrameAtMs = System.currentTimeMillis()
            mainHandler.removeCallbacks(stalenessTicker)
            mainHandler.post(stalenessTicker)
        } else {
            mainHandler.removeCallbacks(stalenessTicker)
        }
        invalidate()
    }

    private fun isSignalStale(): Boolean {
        if (!connected) return false
        if (lastFrameAtMs == 0L) return true
        return System.currentTimeMillis() - lastFrameAtMs > noSignalAfterMs
    }

    /** Обновить текст оверлея в углу («подключение…»). */
    fun setOverlayText(text: String) {
        overlay.setText(text)
        invalidate()
    }

    /** Показать или скрыть оверлей. */
    fun setOverlayVisible(visible: Boolean) {
        overlay.setVisible(visible)
        invalidate()
    }

    private fun ensureMatrix() {
        if (!matrixDirty) return
        if (width == 0 || height == 0) return
        srcRect.set(0f, 0f, srcWidth.toFloat(), srcHeight.toFloat())
        dstRect.set(0f, 0f, width.toFloat(), height.toFloat())
        drawMatrix.setRectToRect(srcRect, dstRect, Matrix.ScaleToFit.CENTER)
        matrixDirty = false
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        matrixDirty = true
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        val bmp = currentBitmap
        if (bmp != null) {
            ensureMatrix()
            canvas.drawBitmap(bmp, drawMatrix, bmpPaint)
        }
        if (isSignalStale()) {
            // Кадры не идут: «мёртвый чёрный» больше не молчит.
            val w = width.toFloat()
            val h = height.toFloat()
            val boxW = w * 0.86f
            val boxH = h * 0.22f
            val left = (w - boxW) / 2f
            val top = (h - boxH) / 2f
            canvas.drawRoundRect(left, top, left + boxW, top + boxH, 24f, 24f, warnPaint)
            canvas.drawRoundRect(left, top, left + boxW, top + boxH, 24f, 24f, warnStrokePaint)
            warnTextPaint.textSize = h * 0.045f
            warnSubTextPaint.textSize = h * 0.028f
            val cy = top + boxH / 2f
            canvas.drawText("НЕТ СИГНАЛА", w / 2f, cy - warnSubTextPaint.textSize, warnTextPaint)
            canvas.drawText(
                "кадры от ПК не приходят — на ПК: hyprscreen grimtest",
                w / 2f, cy + warnTextPaint.textSize, warnSubTextPaint
            )
        }
        overlay.draw(canvas, width, height)
    }

    /** Возобновить тикер после re-attach (иначе «НЕТ СИГНАЛА» не обновится). */
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (connected) {
            mainHandler.removeCallbacks(stalenessTicker)
            mainHandler.post(stalenessTicker)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        // Снимаем тикер — иначе он вечно живёт в main-handler, удерживая
        // View → Activity (утечка при фоновом стриме).
        mainHandler.removeCallbacks(stalenessTicker)
        currentBitmap = null
    }
}
