package com.example.hyprscreen

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.IBinder
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

/**
 * Полноэкранный режим стриминга. Биндится к [ScreenStreamService], чтобы
 * получить доступ к [ScreenClient], подключает сенсорный + клавиатурный ввод
 * и рисует оверлей FPS/latency/экран.
 *
 * Активность зафиксирована в landscape-ориентации (см. манифест) и использует
 * иммерсивные системные бары, пока имеет фокус.
 *
 * Мульти-экранность: из intent-экстра берётся индекс выбранного экрана
 * [EXTRA_SCREEN] и (опционально) общее число [EXTRA_TOTAL_SCREENS]. Когда
 * приходит hello, эти значения обновляются из [ServerInfo] и показываются
 * в оверлее как «Экран N/M» (1-based для пользователя).
 *
 * Дерево View строится целиком в коде в [buildUi] — никакого XML-лейаута,
 * ViewBinding и app-resource-ссылок. Скрытый [EditText] владеет InputConnection
 * мягкой клавиатуры; [ScreenView] хостит и кадры, и оверлей статуса (см.
 * [StatusOverlay]).
 *
 * Все строковые литералы — русские (требование «плоского одного пакета»:
 * приложение не поставляет строковых ресурсов платформы Android).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var rootView: FrameLayout
    private lateinit var screenView: ScreenView
    private lateinit var hiddenInput: EditText
    private lateinit var keyboardButton: Button
    private lateinit var overlayToggle: Button
    private lateinit var disconnectButton: Button

    private lateinit var prefs: Prefs
    private lateinit var keyboardHelper: KeyboardHelper

    /** Выбранный индекс экрана (0-based) — из intent-экстра, обновляется из hello. */
    private var screenIndex: Int = 0
    /** Всего экранов PC — из intent-экстра, обновляется из hello. */
    private var totalScreens: Int = 1

    private var service: ScreenStreamService? = null
    private var bound = false
    private var stateCollectionStarted = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val s = (binder as ScreenStreamService.LocalBinder).service
            service = s
            bound = true
            attachClient(s.client)
        }

        override fun onServiceDisconnected(name: ComponentName) {
            bound = false
            service = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        prefs = Prefs(this)

        // Читаем индекс экрана из intent (передаётся ConnectActivity).
        screenIndex = intent?.getIntExtra(EXTRA_SCREEN, 0) ?: 0
        totalScreens = intent?.getIntExtra(EXTRA_TOTAL_SCREENS, 1) ?: 1
        refreshOverlayHeader()

        // Держим экран включённым во время стриминга.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableImmersive()

        // Касания → события ввода
        screenView.setOnTouchListener(
            TouchHandler(screenView) { event ->
                service?.client?.sendInput(event)
            }
        )

        // Оверлей по умолчанию
        screenView.setOverlayVisible(prefs.showOverlay)
        refreshOverlayHeader()

        // Помощник мягкой клавиатуры, привязанный к скрытому EditText
        keyboardHelper = KeyboardHelper(this, hiddenInput) { event ->
            service?.client?.sendInput(event)
        }

        keyboardButton.setOnClickListener {
            keyboardHelper.toggle()
        }
        overlayToggle.setOnClickListener {
            prefs.showOverlay = !prefs.showOverlay
            screenView.setOverlayVisible(prefs.showOverlay)
            if (!prefs.showOverlay) screenView.setOverlayText("") else refreshOverlayHeader()
        }
        disconnectButton.setOnClickListener {
            service?.disconnect()
            finish()
        }
    }

    override fun onStart() {
        super.onStart()
        bindService(
            Intent(this, ScreenStreamService::class.java),
            connection,
            Context.BIND_AUTO_CREATE
        )
    }

    override fun onStop() {
        super.onStop()
        if (bound) {
            unbindService(connection)
            bound = false
            service?.client?.frameListener = null
        }
    }

    override fun onResume() {
        super.onResume()
        enableImmersive()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enableImmersive()
    }

    /** Сначала отправляем события клавиш в помощник клавиатуры. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (keyboardHelper.dispatchKey(event)) return true
        return super.dispatchKeyEvent(event)
    }

    /** Спрятать системные бары для иммерсивного полноэкранного режима. */
    private fun enableImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, rootView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    /**
     * Обновить оверлей в верхней части экрана, показывающий «Экран N/M».
     * Вызывается при создании и при приходе hello. Если оверлей FPS выключен,
     * текст всё равно задаётся (станет виден, когда пользователь включит
     * оверлей).
     */
    private fun refreshOverlayHeader() {
        if (!prefs.showOverlay) return
        val header = if (totalScreens > 1) {
            "Экран ${screenIndex + 1}/$totalScreens"
        } else {
            "Экран ${screenIndex + 1}"
        }
        screenView.setOverlayText(header)
    }

    private fun attachClient(client: ScreenClient) {
        client.frameListener = object : ScreenClient.FrameListener {
            override fun onHello(info: ServerInfo) {
                runOnUiThread {
                    // Истинная размерность и индекс/общее число приходят из hello
                    // (баг аудита #1: ранее брался дефолт 1920×1080 → касания мажутся
                    // при любом другом разрешении). Теперь ScreenClient строит
                    // ServerInfo из полей hello.width/height/fps/screen/total_screens.
                    screenView.setSourceSize(info.width, info.height)
                    screenIndex = info.screen
                    totalScreens = info.totalScreens
                    refreshOverlayHeader()
                }
            }

            override fun onFrame(bitmap: Bitmap, decodeMs: Long) {
                runOnUiThread { screenView.updateBitmap(bitmap) }
            }

            override fun onStats(stats: FrameStats) {
                runOnUiThread {
                    if (prefs.showOverlay) {
                        // Инлайн-формат строки — исходный код использовал
                        // string-ресурс; эта версия их не поставляет.
                        // К оверлею FPS/latency добавляем заголовок «Экран N/M»,
                        // чтобы пользователь видел текущий экран PC.
                        val screenHeader = if (totalScreens > 1)
                            "Экран ${screenIndex + 1}/$totalScreens  ·  "
                        else
                            "Экран ${screenIndex + 1}  ·  "
                        val text = screenHeader +
                            "FPS %.1f  ·  Пинг %dмс  ·  Декод %dмс".format(
                                stats.fps,
                                stats.latencyMs,
                                stats.lastDecodeMs
                            )
                        screenView.setOverlayText(text)
                    }
                }
            }

            override fun onError(message: String) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Ошибка сервера: $message", Toast.LENGTH_LONG).show()
                }
            }
        }

        // Если сервер уже прислал hello до того, как мы забиндились (сервис
        // стартует раньше активности), достаём актуальный ServerInfo сейчас,
        // чтобы мэппинг координат касаний был корректен с первого кадра.
        client.currentServerInfo?.let { info ->
            screenView.setSourceSize(info.width, info.height)
            screenIndex = info.screen
            totalScreens = info.totalScreens
            refreshOverlayHeader()
        }

        // Наблюдаем состояние — выходим при disconnect. Стартуем коллектор
        // один раз на экземпляр активности, чтобы не дублировать коллекторы
        // при ре-биндингах.
        if (stateCollectionStarted) return
        stateCollectionStarted = true
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                client.state.collect { state ->
                    when (state) {
                        is ScreenClient.State.Disconnected,
                        is ScreenClient.State.Error -> {
                            // Сносим foreground-сервис тоже, чтобы он не пережил
                            // стриминговую сессию. Сообщение об ошибке (если есть)
                            // покажем тостом.
                            if (state is ScreenClient.State.Error) {
                                Toast.makeText(
                                    this@MainActivity,
                                    "Соединение разорвано: ${state.message}",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                            service?.disconnect()
                            finish()
                        }
                        else -> Unit
                    }
                }
            }
        }
    }

    // ----- UI построен целиком в коде (без XML-лейаутов) -----------------

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        rootView = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        // ScreenView заполняет всё окно.
        screenView = ScreenView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        rootView.addView(screenView)

        // Тулбар сверху-справа: Клавиатура | Оверлей | Отключиться
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = ColorDrawable(Color.parseColor("#CC000000"))
            val lp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
            lp.gravity = android.view.Gravity.TOP or android.view.Gravity.END
            lp.setMargins(dp(8), dp(8), dp(8), dp(8))
            layoutParams = lp
        }

        keyboardButton = makeToolbarButton("Клавиатура")
        overlayToggle = makeToolbarButton("Оверлей")
        disconnectButton = makeToolbarButton("Отключиться")
        toolbar.addView(keyboardButton)
        toolbar.addView(overlayToggle)
        toolbar.addView(disconnectButton)
        rootView.addView(toolbar)

        // Скрытый 1dp EditText, владеющий InputConnection мягкой клавиатуры.
        // Размер 1×1dp и alpha=0, чтобы пользователь его не видел, но
        // InputMethodManager показывал клавиатуру при фокусе.
        hiddenInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            alpha = 0f
            isSingleLine = false
            isFocusable = true
            isFocusableInTouchMode = true
            layoutParams = FrameLayout.LayoutParams(dp(1), dp(1))
        }
        rootView.addView(hiddenInput)

        return rootView
    }

    private fun makeToolbarButton(text: String): Button = Button(this).apply {
        this.text = text
        minWidth = 0
        setPadding(dp(12), dp(8), dp(12), dp(8))
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.marginStart = dp(4)
        layoutParams = lp
        // Дефолтная Material-кнопка — без кастомного атрибута темы.
    }

    companion object {
        /** Экстра intent: выбранный индекс экрана (0-based). */
        const val EXTRA_SCREEN = "screen"
        /** Экстра intent: общее число экранов PC (заполняется из hello). */
        const val EXTRA_TOTAL_SCREENS = "total_screens"
    }
}
