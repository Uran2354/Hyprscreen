#!/usr/bin/env bash
# =============================================================================
#  HyprScreen 3.9.1 — установщик (CachyOS / Arch / Hyprland)
#
#  Делает:
#    1) копирует программу в ~/.local/share/hyprscreen (или /usr/local/share)
#    2) запускает pc/setup.sh (пакеты, venv, config.toml)
#    3) ставит CLI ~/.local/bin/hyprscreen (GUI — `hyprscreen gui`)
#    4) ставит quickshell-виджеты (тикер) в ~/.config/quickshell/hyprscreen
#
#  Хоткеи Hyprland НЕ ставятся (их нет в 3.x — по решению пользователя).
#
#  Использование:  ./install.sh            — в ~/.local (без root)
#                  ./install.sh --system   — в /usr/local (нужен sudo)
# =============================================================================
set -euo pipefail

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODE="user"
[[ "${1:-}" == "--system" ]] && MODE="system"

if [[ "$MODE" == "system" ]]; then
  BIN_DIR="/usr/local/bin"
  DEST_DIR="/usr/local/share/hyprscreen"
  SUDO="sudo"
else
  BIN_DIR="$HOME/.local/bin"
  DEST_DIR="$HOME/.local/share/hyprscreen"
  SUDO=""
fi

ok()   { printf '✅ %s\n' "$*"; }
warn() { printf '⚠️  %s\n' "$*"; }
err()  { printf '❌ %s\n' "$*"; }

[[ -f "$SRC_DIR/pc/main.py" ]] || { err "запускайте install.sh из корня распакованного HyprScreen"; exit 1; }

# Исходник должен быть ПОЛНЫМ до копирования. Локальные *.py — файлы
# проекта (их НЕТ в requirements.txt, pip их не ставит): если модуль
# не докопировался в распаковку, установленная копия упадёт в рантайме.
missing_src=()
for mod in main server capture input config hyprctl discovery \
           settings_store state_file logging_setup gui; do
    [[ -f "$SRC_DIR/pc/$mod.py" ]] || missing_src+=("pc/$mod.py")
done
[[ -f "$SRC_DIR/pc/run.sh" ]]        || missing_src+=("pc/run.sh")
[[ -f "$SRC_DIR/pc/setup.sh" ]]      || missing_src+=("pc/setup.sh")
[[ -f "$SRC_DIR/pc/requirements.txt" ]] || missing_src+=("pc/requirements.txt")
[[ -f "$SRC_DIR/pc/config.toml.example" ]] || missing_src+=("pc/config.toml.example")
[[ -f "$SRC_DIR/bin/hyprscreen" ]]   || missing_src+=("bin/hyprscreen")
[[ -f "$SRC_DIR/android-src/MainActivity.kt" ]] || missing_src+=("android-src/MainActivity.kt")
[[ -f "$SRC_DIR/android-src/SETUP.md" ]] || missing_src+=("android-src/SETUP.md")
if ((${#missing_src[@]})); then
    err "исходник неполный — нет файлов: ${missing_src[*]}"
    err "лечение: заново распакуйте полный архив hyprscreen и запустите ./install.sh"
    exit 1
fi

echo "— HyprScreen 3.9.1: установка ($MODE) —"

# 1. Копирование программы ------------------------------------------------------
# Перед удалением старой копии сохраняем пользовательский pc/config.toml
# (там токен!) и pc/.venv (чтобы переустановка не пересобирала окружение).
BACKUP_DIR=""
if [[ "$SRC_DIR" != "$DEST_DIR" ]]; then
  if [[ -d "$DEST_DIR" ]]; then
    BACKUP_DIR="$(mktemp -d)"
    [[ -f "$DEST_DIR/pc/config.toml" ]] && cp "$DEST_DIR/pc/config.toml" "$BACKUP_DIR/config.toml"
    [[ -d "$DEST_DIR/pc/.venv" ]]       && mv "$DEST_DIR/pc/.venv" "$BACKUP_DIR/venv"
  fi
  mkdir -p "$(dirname "$DEST_DIR")"
  $SUDO rm -rf "$DEST_DIR"
  $SUDO mkdir -p "$DEST_DIR"
  $SUDO cp -r "$SRC_DIR/." "$DEST_DIR/"
  $SUDO rm -rf "$DEST_DIR/.git"
  if [[ -n "$BACKUP_DIR" ]]; then
    mkdir -p "$DEST_DIR/pc"
    [[ -f "$BACKUP_DIR/config.toml" ]] && cp "$BACKUP_DIR/config.toml" "$DEST_DIR/pc/config.toml" \
      && ok "config.toml сохранён (токен/настройки не потеряны)"
    [[ -d "$BACKUP_DIR/venv" ]] && mv "$BACKUP_DIR/venv" "$DEST_DIR/pc/.venv" \
      && ok ".venv перенесён (без пересборки окружения)"
    rm -rf "$BACKUP_DIR"
  fi
fi
ok "программа: $DEST_DIR"

# 2. Зависимости + venv + config.toml --------------------------------------------
if [[ -x "$DEST_DIR/pc/setup.sh" ]]; then
  "$DEST_DIR/pc/setup.sh" || warn "setup.sh завершился с предупреждениями — проверьте вывод выше"
fi

# 3. CLI ---------------------------------------------------------------------------
mkdir -p "$BIN_DIR"
sed "s|__INSTALL_DIR__|$DEST_DIR|g" "$DEST_DIR/bin/hyprscreen" | $SUDO tee "$BIN_DIR/hyprscreen" >/dev/null
$SUDO chmod +x "$BIN_DIR/hyprscreen"
ok "CLI: $BIN_DIR/hyprscreen (on|off|toggle|status|monitors|qr|grimtest|cleanup|doctor|gui|menu)"

# 4. Quickshell-виджеты (тикер) ------------------------------------------------------
QS_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/quickshell/hyprscreen"
if [[ -d "$DEST_DIR/quickshell" ]]; then
  mkdir -p "$QS_DIR"
  install -m 644 "$DEST_DIR/quickshell/Service.qml"          "$QS_DIR/Service.qml"
  install -m 644 "$DEST_DIR/quickshell/HyprScreenTicker.qml" "$QS_DIR/HyprScreenTicker.qml"
  install -m 644 "$DEST_DIR/quickshell/shell.qml"            "$QS_DIR/shell.qml"
  ok "quickshell-виджеты: $QS_DIR"
fi

# 5. Остатки старых версий ------------------------------------------------------------
# v2.x оставляла виртуальные HEADLESS-мониторы и бинды Win+N; в 3.x их нет.
if command -v hyprscreen >/dev/null 2>&1; then
  hyprscreen cleanup >/dev/null 2>&1 || true
  ok "очищены остатки предыдущих запусков"
fi

# 6. PATH ------------------------------------------------------------------------------
case ":$PATH:" in
  *":$HOME/.local/bin:"*) ;;
  *) warn "~/.local/bin не в PATH — добавьте в ~/.zshenv: export PATH=\"\$HOME/.local/bin:\$PATH\"" ;;
esac

echo ""
echo "Готово. Быстрый старт:"
echo "  1) hyprscreen monitors        — номера экранов"
echo "  2) hyprscreen on              — транслировать воркспейс №6 (по умолчанию)"
echo "  3) телефон: приложение HyprScreen (android-src/, SETUP.md) или браузер"
echo "     http://IP:8080 — адрес покажет команда"
echo "  Окно управления: hyprscreen gui"
echo "  Тикер в quickshell: см. README, раздел Quickshell"
echo ""
echo "Хоткеев в 3.x нет — управление: CLI / GUI / тикер."
