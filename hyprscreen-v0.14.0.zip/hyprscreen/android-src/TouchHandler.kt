package com.example.hyprscreen

import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/**
 * Переводит события касания на [ScreenView] в события ввода HyprScreen.
 *
 * Поддерживаемые жесты:
 *  - **Тап** → `pointer_down(left)` + `pointer_up(left)` в точке тапа.
 *  - **Перетаскивание** → `pointer_down(left)` при первом значимом движении,
 *    поток `pointer_move`, затем `pointer_up(left)` при отпускании.
 *  - **Долгое нажатие** → `pointer_down(right)` + `pointer_up(right)`
 *    (правый клик).
 *  - **Двухпальцевое перетаскивание** → поток событий `scroll`, чьи `dx`/`dy`
 *    — дельта средней точки между последовательными MOVE.
 *
 * Мэппинг координат view→source делегирован в [ScreenView.viewToSource],
 * который использует инверсию той же fit-center матрицы, что и для отрисовки.
 * Поэтому куда упал палец на экране телефона — ровно тот пиксель источника
 * и уходит на PC. Размер источника [ScreenView] получает из hello-полей
 * `ServerInfo.width`/`height` (исправление бага аудита #1).
 */
class TouchHandler(
    private val screenView: ScreenView,
    private val sender: (InputEvent) -> Unit
) : View.OnTouchListener {

    private var dragButtonSent = false
    private var dragging = false
    /** Долгий тап уже отработал как правый клик — палец ещё держится, но
     *  дальнейшее движение НЕ должно запускать левый drag. */
    private var longPressed = false

    private var scrolling = false
    private var scrollLastX = 0f
    private var scrollLastY = 0f

    private val gestureDetector = GestureDetector(screenView.context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            if (dragging || scrolling || dragButtonSent || longPressed) return false
            val (x, y) = map(e)
            sender(InputEvent.PointerDown(x, y, "left"))
            sender(InputEvent.PointerUp("left"))
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            if (dragging || scrolling || dragButtonSent || longPressed) return
            val (x, y) = map(e)
            sender(InputEvent.PointerDown(x, y, "right"))
            sender(InputEvent.PointerUp("right"))
            longPressed = true
        }
    })

    override fun onTouch(v: View, event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragButtonSent = false
                dragging = false
                scrolling = false
                longPressed = false
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount == 2) {
                    // Переходим в режим скролла; сначала отменим летящий drag.
                    if (dragButtonSent) {
                        sender(InputEvent.PointerUp("left"))
                        dragButtonSent = false
                    }
                    scrolling = true
                    val mid = midpoint(event)
                    scrollLastX = mid[0]
                    scrollLastY = mid[1]
                }
            }

            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2) {
                    val mid = midpoint(event)
                    val dx = mid[0] - scrollLastX
                    val dy = mid[1] - scrollLastY
                    if (abs(dx) > MIN_SCROLL_DELTA || abs(dy) > MIN_SCROLL_DELTA) {
                        sender(InputEvent.Scroll(dx, dy))
                        scrollLastX = mid[0]
                        scrollLastY = mid[1]
                    }
                    scrolling = true
                } else if (event.pointerCount == 1 && !longPressed) {
                    if (!dragButtonSent) {
                        val (x, y) = map(event)
                        sender(InputEvent.PointerDown(x, y, "left"))
                        dragButtonSent = true
                    }
                    val (x, y) = map(event)
                    sender(InputEvent.PointerMove(x, y))
                    dragging = true
                }
            }

            MotionEvent.ACTION_POINTER_UP -> {
                if (event.pointerCount <= 2) scrolling = false
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragButtonSent) sender(InputEvent.PointerUp("left"))
                dragButtonSent = false
                dragging = false
                scrolling = false
            }
        }
        return true
    }

    private fun map(e: MotionEvent): Pair<Float, Float> {
        val src = screenView.viewToSource(e.x, e.y)
        return src[0] to src[1]
    }

    private fun midpoint(event: MotionEvent): FloatArray {
        var sx = 0f
        var sy = 0f
        val n = event.pointerCount.coerceAtLeast(1)
        for (i in 0 until event.pointerCount) {
            sx += event.getX(i)
            sy += event.getY(i)
        }
        return floatArrayOf(sx / n, sy / n)
    }

    companion object {
        private const val MIN_SCROLL_DELTA = 0.75f
    }
}
