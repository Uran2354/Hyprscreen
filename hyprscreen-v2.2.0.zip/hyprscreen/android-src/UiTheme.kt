package com.example.hyprscreen

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.TextView

/**
 * Единая палитра приложения — «чёрный + изумруд» (та же, что у док-страницы
 * и GUI на ПК): глубокий чёрный фон нейтральный (#0A0A0A), изумрудный акцент
 * (#10B981), карточки #141414 с тонкой рамкой #262626.
 *
 * Всё в коде — приложение сознательно не поставляет ресурсов (R.*) и строк:
 * «плоский один пакет» (см. ConnectActivity). [UiTheme] только раздаёт цвета
 * и программно скруглённые drawable — никакого XML.
 *
 * 2.1.0: раньше каждый экран красил элементы сам (teal #5EEAD4, сланец
 * #1E293B, дефолтные Material-кнопки) — стиль был разнородным. Теперь весь
 * UI берёт цвета отсюда, а кнопки/поля/карточки — скруглённые [pill]/[card].
 */
object UiTheme {

    // ── Фоны ────────────────────────────────────────────────────────────
    /** Фон окон (neutral-950). */
    val BG = Color.parseColor("#0A0A0A")
    /** Фон карточек/строк списков (neutral-900). */
    val CARD = Color.parseColor("#141414")
    /** Фон полей ввода. */
    val INPUT = Color.parseColor("#1C1C1C")
    /** Рамки карточек и полей (neutral-800). */
    val BORDER = Color.parseColor("#262626")

    // ── Текст ───────────────────────────────────────────────────────────
    val TEXT = Color.parseColor("#F5F5F5")
    val TEXT_DIM = Color.parseColor("#A3A3A3")
    val TEXT_HINT = Color.parseColor("#6B6B6B")

    // ── Акцент (emerald) ────────────────────────────────────────────────
    val EMERALD = Color.parseColor("#10B981")
    val EMERALD_BRIGHT = Color.parseColor("#34D399")
    val EMERALD_PALE = Color.parseColor("#6EE7B7")
    /** Тёмная изумрудная плашка (фон индикаторов/выбранных чипов). */
    val EMERALD_DIM = Color.parseColor("#0B2E23")
    /** Почти чёрный текст на изумрудной заливке. */
    val ON_EMERALD = Color.parseColor("#04150F")

    // ── Опасность/ошибка ────────────────────────────────────────────────
    val RED = Color.parseColor("#F87171")
    val RED_BRIGHT = Color.parseColor("#EF4444")
    /** Тёмно-красная плашка (фон предупреждений). */
    val RED_DIM = Color.parseColor("#2A1212")
    val RED_BORDER = Color.parseColor("#7F1D1D")

    /** Полупрозрачный фон тулбара поверх стрима. */
    val SCRIM = Color.parseColor("#CC141414")

    // ── Хелперы drawable ────────────────────────────────────────────────

    /**
     * Скруглённый прямоугольник: заливка [fill], опциональная рамка
     * [stroke] толщиной [strokeDp] dp.
     */
    fun rounded(
        fill: Int,
        radiusDp: Float,
        density: Float,
        stroke: Int = 0,
        strokeDp: Float = 1f,
    ): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radiusDp * density
        if (stroke != 0) {
            setStroke((strokeDp * density).toInt().coerceAtLeast(1), stroke)
        }
    }

    /** Карточка: фон [CARD], рамка [BORDER], радиус [radiusDp] dp. */
    fun card(density: Float, radiusDp: Float = 14f): GradientDrawable =
        rounded(CARD, radiusDp, density, BORDER, 1f)

    /** Поле ввода: фон [INPUT], рамка [BORDER], радиус 12 dp. */
    fun input(density: Float): GradientDrawable =
        rounded(INPUT, 12f, density, BORDER, 1f)

    /** Изумрудная кнопка-пилюля. */
    fun buttonAccent(density: Float): GradientDrawable =
        rounded(EMERALD, 12f, density)

    /** Тёмная кнопка-пилюля (тулбар поверх стрима, вторичные кнопки). */
    fun buttonDark(density: Float, fill: Int = SCRIM): GradientDrawable =
        rounded(fill, 12f, density, BORDER, 1f)

    /** Красная кнопка-пилюля («Отключиться»). */
    fun buttonDanger(density: Float): GradientDrawable =
        rounded(RED_DIM, 12f, density, RED_BORDER, 1f)

    /**
     * Заголовок секции: мелкий, разреженный, приглушённый — как eyebrow
     * на док-странице.
     */
    fun styleSectionLabel(label: TextView) {
        label.setTextColor(TEXT_DIM)
        label.textSize = 13f
        label.letterSpacing = 0.08f
        label.setTypeface(label.typeface, Typeface.BOLD)
    }
}
