# HyprScreen 3.9.1 — сборка Android-приложения

Приложение — «плоский один пакет» `com.example.hyprscreen`: **12 .kt-файлов
без XML-лейаутов и ресурсов** (OkHttp и kotlinx.serialization из 2.x больше
не нужны — сеть на `HttpURLConnection`, JSON на платформенном `org.json`).
Внешние библиотеки — kotlinx-coroutines (StateFlow) и три ЛЁГКИЕ androidx
(`activity`, `core`, `lifecycle`) — Material/ConstraintLayout/appcompat
НЕ нужны.

## Содержание

1. Обзор
2. Создание проекта в Android Studio
3. Копирование 12 .kt и ЧИСТКА ШАБЛОНА (activity_main.xml, themes.xml)
4. AndroidManifest.xml
5. build.gradle.kts — зависимости (и чего там быть НЕ должно)
6. Сборка APK
7. Заметки и решение проблем:
   7.1. ошибка AAPT `Theme.Material3.DayNight.NoActionBar`;
   7.2. ошибка AAPT `attribute layout_constraint* not found` (activity_main.xml);
   7.3. телефон не ставит APK: `INSTALL_FAILED_USER_RESTRICTED`;
   7.4. установилось, но не запускается (падает при старте);
   7.5. своя картинка/иконка приложения (и ошибки AAPT после неё);
   7.6. Gradle-файлы: где лежат и чего в них быть не должно;
   7.7. падает при старте: `You need to use a Theme.AppCompat theme`;
   7.8. «PC недоступен» при зелёных doctor/GUI: cleartext-блокировка Android и сеть

## 1. Обзор

Приложение подключается к HTTP-серверу HyprScreen (`hyprscreen on`, по
умолчанию порт **8080**):

* `GET /info` — JSON о сервере (монитор/fps/размер кадра);
* `GET /stream.mjpeg?t=ТОКЕН` — поток JPEG-кадров;
* `POST /key`, `POST /text` — клавиатура с телефона (на PC это wtype);
* UDP `:8766` — discovery (PC находит себя сам).

Тача-ввода НЕТ (телефон — не тачпад). Оверлей-кнопок и бургер-меню НЕТ
(бургер удалён в 3.3.0): экран телефона чистый. Управление — ровно два
жеста:

* **тап по видео** — поднять/спрятать мягкую клавиатуру;
* **кнопка «⏻»** в правом верхнем углу (полупрозрачная) — отключиться.

## 2. Создание проекта

1. Android Studio → **New Project → Empty Views Activity**;
2. Name: `HyprScreen`, Package: `com.example.hyprscreen`,
   Language: **Kotlin**, Min SDK: **24** (Android 7.0);
3. Build configuration language — можно Groovy или Kotlin DSL.

## 3. Копирование 12 .kt и чистка шаблона

Скопируйте ВСЕ файлы из `android-src/` в
`app/src/main/java/com/example/hyprscreen/`:

| Файл | Что делает |
|---|---|
| `HyprScreenApp.kt` | Application: ленивые Prefs |
| `ConnectActivity.kt` | Экран подключения: discovery + вручную + история |
| `MainActivity.kt` | Полноэкранный стрим; тап — клавиатура, «⏻» — отключиться |
| `ScreenStreamService.kt` | Foreground-сервис: держит поток, wake lock, нотификация |
| `ScreenClient.kt` | MJPEG-клиент: /info + поток + декод + POST клавиатуры |
| `ScreenView.kt` | View с «fit-center» отрисовкой и «НЕТ СИГНАЛА» |
| `StatusOverlay.kt` | Изумрудная пилюля статуса («подключение…») |
| `KeyboardHelper.kt` | Мягкая клавиатура → `key`/`text` события (без дублей букв, с BackSpace) |
| `Discovery.kt` | UDP-слушатель :8766 |
| `Models.kt` | Data-классы + JSON-тела запросов |
| `Prefs.kt` | SharedPreferences (история хостов) |
| `UiTheme.kt` | Палитра «чёрный + изумруд», скруглённые drawable |

`android:name=".HyprScreenApp"` в манифесте обязателен (см. ниже).

**Сразу же удалите мусор шаблона** — весь интерфейс HyprScreen строится в
Kotlin-коде, XML-лейауты и Material-темы НЕ используются, а шаблонные
файлы ломают сборку (см. §7):

```text
app/src/main/res/layout/activity_main.xml   ← УДАЛИТЬ (файл и папку layout/)
app/src/main/res/values-night/themes.xml    ← удалить, если существует
```

Шаблонный `res/values/values.xml`… `themes.xml` либо замените по §7.1,
либо удалите (тема берётся из манифеста, §4).

## 4. AndroidManifest.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <!-- Обязательно при targetSdk 34 + foregroundServiceType="dataSync":
         без него startForeground() на Android 14 падает SecurityException -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <!-- ОБЯЗАТЕЛЬНО: android:usesCleartextTraffic="true" — стрим ходит по
         обычному http://, а Android 9+ МОЛЧА блокирует такой трафик, если
         атрибута нет. Симптом: doctor и GUI на ПК зелёные, а приложение
         вечно пишет «PC недоступен» (см. §7.8). Комментарий сюда копировать
         НЕ нужно — только сам атрибут. -->
    <application
        android:name=".HyprScreenApp"
        android:label="HyprScreen"
        android:icon="@android:drawable/ic_menu_compass"
        android:supportsRtl="true"
        android:usesCleartextTraffic="true"
        android:theme="@android:style/Theme.Material.NoActionBar">

        <activity
            android:name=".ConnectActivity"
            android:exported="true"
            android:screenOrientation="portrait"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Экран ПОКАЗА можно вращать (с 3.8.0): fullSensor следует
             датчику, и ландшафтный кадр ПК разворачивается на весь экран,
             когда телефон лежит горизонтально. Код MainActivity.kt 3.8.0
             ставит то же самое сам — атрибут для явности. Хотите жёсткую
             вертикаль в стриме — замените на "portrait". -->
        <activity
            android:name=".MainActivity"
            android:exported="false"
            android:screenOrientation="fullSensor"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:launchMode="singleTop" />

        <service
            android:name=".ScreenStreamService"
            android:exported="false"
            android:foregroundServiceType="dataSync" />
    </application>
</manifest>
```

Примечания:

* `usesCleartextTraffic="true"` — ОБЯЗАТЕЛЬНЫЙ атрибут с 3.7.1: без него
  Android 9+ блокирует весь `http://`, приложение показывает «PC недоступен»,
  хотя `doctor` и GUI на ПК зелёные (§7.8). Если ваш манифест собран по
  документации ≤ 3.7.0 — добавьте строку и пересоберите;
* тема `@android:style/Theme.Material.NoActionBar` — ПЛАТФОРМЕННАЯ, она
  есть в любом SDK без библиотек. Если в вашем проекте остался шаблонный
  `res/values/themes.xml` с `Theme.Material3.*` и сборка падает ошибкой
  AAPT — см. раздел 7.1 (решение в одну строку);
* иконка `@android:drawable/ic_menu_compass` — платформенная (своих
  ресурсов приложение не ставит); свою картинку можно подключить по
  §7.5 (тогда её же покажет и уведомление в шторке);
* `foregroundServiceType="dataSync"` — для API 34+; на старых SDK
  атрибут игнорируется (если targetSdk < 34 — просто оставьте).
  При targetSdk 34 ОБЯЗАТЕЛЬНА разрешение `FOREGROUND_SERVICE_DATA_SYNC`
  (см. манифест выше), иначе `startForegroundService` уронит приложение
  на Android 14; учтите также лимит ~6 ч работы dataSync-сервиса в сутки;
* `ConnectActivity` зафиксирована в ПОРТРЕТНОЙ (вертикальной) ориентации —
  с 3.7.0 по запросу пользователя. `MainActivity` (экран показа) с 3.8.0
  — `fullSensor` + то же в коде: телефон МОЖНО поворачивать во время
  трансляции — ландшафтный кадр ПК развернётся на весь экран, в
  вертикальном положении он вписывается fit-center (поля по бокам).
  `configChanges` не даёт активности пересоздаться при повороте — поток
  не рвётся. Хотите жёсткую вертикаль в стриме — верните `portrait`
  (и уберите requestedOrientation из MainActivity.kt);
* `MainActivity` без системных баров (иммерсивный режим) — управляет
  только приложенный код.

## 5. build.gradle.kts — зависимости

В `app/build.gradle.kts` (Module):

```kotlin
android {
    namespace = "com.example.hyprscreen"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.hyprscreen"
        minSdk = 24
        targetSdk = 34
        compileOptions {
            sourceCompatibility = JavaVersion.VERSION_17
            targetCompatibility = JavaVersion.VERSION_17
        }
        kotlinOptions { jvmTarget = "17" }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    packaging {
        resources.excludes += "META-INF/*"
    }
}

dependencies {
    implementation("androidx.activity:activity:1.9.3")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
```

Больше НИЧЕГО: сеть — `HttpURLConnection`, JSON — `org.json`,
UI — стандартные View (все скругления рисуются `GradientDrawable` в `UiTheme`).
С 3.7.0 обе активити наследуют `androidx.activity.ComponentActivity`, поэтому
**`androidx.appcompat:appcompat` БОЛЬШЕ НЕ НУЖЕН** (остался от шаблона —
можно удалить, строка в dependencies не помешает, но APK будет на ~1,5 МБ
больше). **`com.google.android.material` НЕ нужен** — приложение не использует
Material-виджеты и Material-темы. **`androidx.constraintlayout` НЕ нужен** —
XML-лейаутов в приложении нет (§3, §7.2). **Плагин
`kotlin.serialization` НЕ нужен** — @Serializable в коде нет, JSON на
платформенном org.json; строку `alias(libs.plugins.kotlin.serialization)`
из `plugins { … }` удалите (см. §7.6 — иначе возможна ошибка
несовпадения версий Kotlin-плагинов).

Если в проекте есть каталог версий, он лежит в `gradle/libs.versions.toml`
(НЕ в корне проекта). Неиспользуемые записи в нём безвредны; критично
только не ПОДКЛЮЧАТЬ лишние плагины. Содержимое §5 (dependency-блок) при
этом одинаково: координаты можно писать строками, как выше, — catalog
для них не обязателен.

## 6. Сборка APK

```bash
# из корня проекта Android Studio
./gradlew assembleRelease
# результат: app/build/outputs/apk/release/app-release-unsigned.apk
# подписать или собрать Debug: ./gradlew assembleDebug
```

Телефон и PC должны быть в одной Wi-Fi сети. На PC: `hyprscreen on`.
В приложении PC появится в «Найдено в сети» сам (discovery :8766), либо
введите IP вручную; порт — 8080; токен — из `config.toml` (если задан).

## 7. Заметки и решение проблем

### 7.1. Ошибка AAPT: `resource style/Theme.Material3.DayNight.NoActionBar ... not found`

Шаблон Android Studio кладёт в `app/src/main/res/values/themes.xml` (и
иногда в `values-night/themes.xml`) тему-наследника `Theme.Material3.*`.
Эта тема живёт в библиотеке `com.google.android.material`, которой в
проекте HyprScreen НЕТ — линковщик ресурсов (AAPT) падает:

```
ERROR: AAPT: error: resource style/Theme.Material3.DayNight.NoActionBar
(aka com.example.hyprscreen:style/Theme.Material3.DayNight.NoActionBar)
not found.
error: failed linking references.
```

**Решение (рекомендуется)** — используйте платформенную тему, библиотека
не потребуется. Замените СОДЕРЖИМОЕ `app/src/main/res/values/themes.xml`
на:

```xml
<resources>
    <style name="Theme.HyprScreen" parent="android:Theme.Material.NoActionBar" />
</resources>
```

…и убедитесь, что в `AndroidManifest.xml` у `<application>` стоит
`android:theme="@style/Theme.HyprScreen"`
(или сразу `android:theme="@android:style/Theme.Material.NoActionBar"` —
тогда themes.xml можно удалить вовсе).

* Если существует `app/src/main/res/values-night/themes.xml` — сделайте
  то же самое в нём (или удалите этот файл).
* После правки: **File → Sync Project with Gradle Files**, затем
  **Build → Clean Project** и пересборка.

**Альтернатива** — оставить `Theme.Material3.DayNight.NoActionBar` и
добавить библиотеку в `app/build.gradle.kts`:

```kotlin
dependencies {
    implementation("com.google.android.material:material:1.12.0")
    // …остальные зависимости
}
```

Но приложению Material-виджеты не нужны (весь UI — платформенные View),
поэтому первый вариант чище: APK меньше на ~2 МБ и без лишних
зависимостей.

### 7.2. Ошибка AAPT: `attribute layout_constraintTop_toTopOf ... not found` (activity_main.xml)

```
ERROR: .../app/src/main/res/layout/activity_main.xml:17: AAPT: error:
attribute layout_constraintTop_toTopOf
(aka com.example.hyprscreen:layout_constraintTop_toTopOf) not found.
ERROR: ... attribute layout_constraintStart_toStartOf ... not found.
ERROR: ... attribute layout_constraintEnd_toEndOf ... not found.
ERROR: ... attribute layout_constraintBottom_toBottomOf ... not found.
```

**Причина.** В проекте остался шаблонный лейаут Android Studio
`app/src/main/res/layout/activity_main.xml` («Empty Views Activity»
кладёт туда `TextView` в `ConstraintLayout`, строки 17–20 — это его
`app:layout_constraint*`). Код HyprScreen этот файл НЕ использует и
вообще не имеет XML-лейаутов (§3), а библиотека
`androidx.constraintlayout` в минимальном наборе зависимостей (§5)
отсутствует — AAPT не может разрешить атрибуты `layout_constraint*`.

**Решение 1 (рекомендуется)** — удалить шаблонный лейаут целиком:

```bash
rm app/src/main/res/layout/activity_main.xml
rmdir app/src/main/res/layout 2>/dev/null
```

(в Android Studio: Project → app → res → layout → ПКМ по
activity_main.xml → Delete). Больше ничего править не нужно — интерфейс
строится в `ConnectActivity`/`MainActivity` кодом.

**Решение 2 (если хотите оставить шаблонный файл)** — вернуть библиотеку
в `app/build.gradle.kts`:

```kotlin
dependencies {
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    // …остальные зависимости
}
```

…после чего **File → Sync Project with Gradle Files** → **Build →
Clean Project** → пересборка. Но приложению ConstraintLayout не нужен:
чище — Решение 1 (минус зависимость, минус файл-мусор).

### 7.3. Телефон не принимает APK: `INSTALL_FAILED_USER_RESTRICTED` («Installation via USB is disabled»)

```
The application could not be installed: INSTALL_FAILED_USER_RESTRICTED
Installation via USB is disabled.
List of apks: [0] '.../app/build/intermediates/apk/debug/app-debug.apk'
```

**Причина.** Это ЗАПРЕТ НА СТОРОНЕ ТЕЛЕФОНА, а не ошибка проекта и не
последствие нажатия «Debug» вместо «Run» — обе кнопки собирают и ставят
ОДИН И ТОТ ЖЕ app-debug.apk, «Run» просто ещё и запускает его. Телефон
(чаще всего Xiaomi/Redmi/Poco — MIUI/HyperOS) блокирует установку
приложений по USB, пока не разрешить это явно.

**Решение (Xiaomi / Redmi / Poco — MIUI, HyperOS):**

1. Настройки → Расширенные настройки → **Для разработчиков** →
   включите **«Установка через USB»** (Install via USB);
2. Фокус MIUI: переключатель часто ОТКАЗЫВАЕТСЯ включаться при активном
   интернете — **выключите Wi-Fi и мобильные данные**, передёрните
   тумблер, затем включите сеть обратно (может потребоваться вход в
   Mi-аккаунт и/или SIM-карта в слоте);
3. Там же включите **«Установка через USB (настройки безопасности)»** /
   «Отладка по USB (Security settings)», если пункт есть;
4. Если не помогло — **«Отзыв разрешений отладки по USB»** (Revoke USB
   debugging authorizations), отключите/включите «Отладку по USB»,
   перезапустите Android Studio и подключите телефон заново (на экране
   телефона подтвердите отпечаток ключа);
5. Следите за ЭКРАНОМ телефона во время установки — MIUI может
   показывать запрос-подтверждение, который легко пропустить.

**Другие производители:** Huawei/Honor — «Для разработчиков» →
«Разрешить установку АПК по USB»; Vivo/Oppo — «Установка по USB» в том
же меню.

**Обходной путь без Android Studio** — поставить APK вручную:

```bash
# вариант А: через adb (запрет действует и тут, если не разрешить п.1)
adb install -r app/build/outputs/apk/debug/app-debug.apk

# вариант Б: скопировать файл на телефон и тапнуть по нему
adb push app/build/outputs/apk/debug/app-debug.apk /sdcard/Download/
# → на телефоне: Файлы → Download → app-debug.apk → установить
#   (разрешите «установка из неизвестных источников» для проводника)
```

### 7.4. Установилось, но не запускается (падает при старте)

Иконка есть, APK встал, но при тапе приложение гаснет («остановлено»)
или не открывается. Причину нужно СНЯТЬ С ЛОГА (угадывать бесполезно):

**Как снять ошибку (30 секунд):**

* Android Studio → внизу **Logcat** → в фильтре:
  `package:com.example.hyprscreen level:ERROR` → тапните по иконке
  приложения на телефоне → пришлите блок, начинающийся с
  `FATAL EXCEPTION:`;
* либо из терминала:

```bash
adb logcat -c && adb logcat AndroidRuntime:E *:S
# → тапните по иконке HyprScreen; скопируйте блок FATAL EXCEPTION
```

**Самые частые причины (в порядке вероятности):**

1. `java.lang.ClassCastException: android.app.Application cannot be cast
   to com.example.hyprscreen.HyprScreenApp` — в манифесте НЕТ
   `android:name=".HyprScreenApp"` внутри `<application>` (шаблонный
   манифест не заменён, §4). С 3.6.2 код больше не падает и без этого
   атрибута, но манифест всё равно поставьте по §4 целиком.
2. `ClassNotFoundException: com.example.hyprscreen.MainActivity` или
   `Unable to find explicit activity class` при тапе — в манифесте
   остался шаблонный LAUNCHER `.MainActivity` (или шаблонный
   `MainActivity.kt` из чужого пакета), а нашего класса по этому пути
   нет. Лечение: заменить манифест ЦЕЛИКОМ по §4 — launcher там
   `.ConnectActivity`, а `.MainActivity` — НЕ exported.
3. Открывается чёрный экран (не падает, но и не экран подключения) —
   тот же случай: launcher = `.MainActivity` вместо
   `.ConnectActivity`. Манифест §4.
4. «Приложение установлено» поверх старой версии с другой подписью
   (например, собирали на другом ПК) — удалите приложение на телефоне
   и поставьте заново.
5. MIUI/HyperOS: «Безопасность» → «Автозапуск» → разрешите HyprScreen
   (без этого фоновый сервис может гаситься, а запуск — тормозить).
6. `IllegalStateException: You need to use a Theme.AppCompat theme (or
   descendant) with this activity` — .kt-файлы ДО 3.7.0 наследовали
   AppCompatActivity (требует AppCompat-тему), а манифест §4 задаёт
   платформенную тему. Лечение — §7.7.

Если в логе другая ошибка — пришлите блок `FATAL EXCEPTION` целиком:
по нему фикс делается за один шаг.

### 7.5. Своя картинка/иконка приложения (и ошибки AAPT после неё)

Приложение по умолчанию НЕ содержит ни одного ресурса-картинки — в
манифесте стоит платформенная иконка
`android:icon="@android:drawable/ic_menu_compass"`. Свою картинку
поставить МОЖНО — но соблюдайте правила ресурсов Android, иначе сломается
СБОРКА (AAPT), а не запуск:

**Как правильно добавить свою иконку (2 шага):**

1. Положите PNG в `app/src/main/res/drawable/` под именем из СТРОЧНЫХ
   латинских букв, цифр и подчёркиваний, например:
   `app/src/main/res/drawable/hyprscreen_icon.png`;
2. В манифесте замените у `<application>`:
   `android:icon="@drawable/hyprscreen_icon"`.

Иконка уведомления в шторке с 3.6.3 — это иконка приложения, так что
больше ничего менять не нужно. Весь остальной UI строится кодом и
ресурсов не касается.

**Иконка осталась СТАНДАРТНОЙ (компас), а не ваша картинка — чек-лист:**

Приложение показывает ТОЛЬКО то, на что ссылается манифест. Сам по себе
PNG, положенный в проект, ни на что не влияет. Проверяйте по порядку:

| # | Проверка | Как исправить |
|---|---|---|
| 1 | Манифест ссылается на ВАШ файл? | у `<application>` должно быть `android:icon="@drawable/hyprscreen_icon"`. Если там `@android:drawable/ic_menu_compass` (дефолт §4) или `@mipmap/ic_launcher` (от шаблона) — показывается то, что написано, а не ваш PNG. Замените строку. |
| 2 | В проекте остались шаблонные adaptive-иконки? | wizard кладёт `res/mipmap-*/ic_launcher.xml` — если манифест смотрит на `@mipmap/ic_launcher`, рисуется ЭТОТ XML, а ваш PNG в drawable он не трогает. Лечится п.1 (ссылка на `@drawable/...`). |
| 3 | Лаунчер закэшировал старую иконку | после смены иконки СНАЧАЛА удалите приложение на телефоне, потом поставьте заново — обновление APK «поверх» часто оставляет в лаунчере старую иконку. Если не помогло — перезагрузите телефон (лаунчер перечитает иконку). |
| 4 | Имя совпадает байт в байт? | файл `res/drawable/hyprscreen_icon.png` ↔ в манифесте `@drawable/hyprscreen_icon` (БЕЗ расширения .png; регистр важен). |

Если все 4 пункта в порядке, а иконка всё равно старая — **Build → Clean
Project**, пересборка, удаление приложения и чистая установка.

**Если после добавления картинки сборка сломалась — типовые ошибки:**

| Ошибка AAPT/Gradle | Причина | Лечение |
|---|---|---|
| `Invalid resource file name` / `File name must contain only lowercase…` | имя файла с заглавными/дефисом/пробелом (`MyIcon.png`, `hypr-screen.png`) | переименуйте в `hyprscreen_icon.png` |
| `resource mipmap/ic_launcher not found` | манифест ссылается на `@mipmap/ic_launcher`, а файлов mipmap в проекте нет (мы их не создаём) | положите PNG в `res/mipmap-xxxhdpi/ic_launcher.png` или верните `@android:drawable/ic_menu_compass` |
| `resource drawable/myicon not found` | файл не в `res/drawable/` (например, лежит в корне `res/` или имя не совпадает) | перенесите в `res/drawable/`, сверьте имя с манифестом |
| сборка ломается «на ровном месте», кэши | испорченные intermediates | **Build → Clean Project**, затем Rebuild; жёстче: `./gradlew clean` и **File → Invalidate Caches → Invalidate and Restart** |

Важно: картинка НЕ может ломать ЗАПУСК приложения — если APK собрался и
установился, ресурсы уже слинкованы. Слом «после картинки» — всегда
ошибка сборки (см. таблицу выше), а не причина падения при старте (§7.4).

### 7.6. Gradle-файлы: где лежат и чего в них быть не должно

Три Gradle-файла проекта имеют РАЗНОЕ назначение — перепутать их
местами = сломать сборку:

| Файл | Где лежит | Что внутри |
|---|---|---|
| `build.gradle.kts` (Module) | `app/build.gradle.kts` | блоки `android { … }` и `dependencies { … }` из §5 |
| `build.gradle.kts` (Project) | корень проекта | ТОЛЬКО `plugins { alias(…) apply false }` — НЕ вставляйте сюда содержимое из §5 |
| каталог версий | `gradle/libs.versions.toml` | версии/алиасы плагинов (НЕ в корне!) |

**Частая ошибка после вставки зависимостей из §5 — лишний плагин
serialization.** Шаблон Android Studio с version catalog содержит строку:

```kotlin
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.serialization)   // ← УДАЛИТЬ
}
```

HyprScreen НЕ использует kotlinx.serialization (JSON — платформенный
`org.json`, §5), а плагин тянет свою версию Kotlin и ломает сборку
(типичные ошибки: `Failed to apply plugin
'org.jetbrains.kotlin.plugin.serialization'`, `Kotlin plugin was applied
with different versions`, несовпадение `serialization = "1.6.3"` с
`kotlin = "1.9.24"`). Удалите строку — и сборка пройдёт.

**Ещё две типовые ошибки Gradle:**

| Ошибка | Причина | Лечение |
|---|---|---|
| `Could not get unknown property 'libs'` / `libs.plugins… not found` | каталог `libs.versions.toml` лежит не в `gradle/` (или отсутствует) | положите его в `gradle/libs.versions.toml`; при желании зависимости можно писать СОВСЕМ без catalog — строками, как в §5 |
| `Unable to find method…` / старый Gradle под AGP 8.5.x | AGP 8.5.2 требует Gradle 8.7+ и JDK 17 | Android Studio обновит wrapper сам (Sync); проверьте JDK 17 в Settings → Build Tools → Gradle |

После правок: **File → Sync Project with Gradle Files**, затем сборка.

### 7.7. Падает при старте: `IllegalStateException: You need to use a Theme.AppCompat theme (or descendant) with this activity`

APK собрался и установился, но приложение гаснет сразу при запуске, а в
Logcat (§7.4) — вот такой FATAL EXCEPTION:

```
java.lang.RuntimeException: Unable to start activity ComponentInfo
  {com.example.hyprscreen/com.example.hyprscreen.ConnectActivity}:
  java.lang.IllegalStateException: You need to use a Theme.AppCompat theme
  (or descendant) with this activity.
  at androidx.appcompat.app.AppCompatActivity.setContentView(…)
  at com.example.hyprscreen.ConnectActivity.onCreate(ConnectActivity.kt:…)
```

**Причина.** .kt-файлы HyprScreen ДО 3.7.0 наследовали
`androidx.appcompat.app.AppCompatActivity`, а этот класс ЖЁСТКО требует
тему-наследника `Theme.AppCompat` — при любом `setContentView` он
проверяет тему и падает. Манифест же §4 задаёт платформенную
`@android:style/Theme.Material.NoActionBar` (Material-библиотек в проекте
нет — §7.1), то есть именно НЕ-AppCompat тему. Конфликт наш, а не ваш:
проект собран точно по документации, но падал на любом телефоне.

**Решение 1 (рекомендуется) — обновите .kt до 3.7.0.** Начиная с 3.7.0
`ConnectActivity` и `MainActivity` наследуют
`androidx.activity.ComponentActivity`, которому тема не нужна ВООБЩЕ
(работает с платформенной, Material3, любой и даже без `android:theme`).
Скопируйте оба файла из архива 3.7.0 в
`app/src/main/java/com/example/hyprscreen/` с заменой:

* `ConnectActivity.kt`
* `MainActivity.kt`

…и приведите зависимости к §5: строку `appcompat` замените на
`implementation("androidx.activity:activity:1.9.3")` (сам appcompat
оставлять можно — не помешает, но APK будет больше). Затем
**File → Sync Project with Gradle Files** → **Build → Clean Project** →
пересборка.

**Решение 2 (быстрое, без замены .kt)** — если хотите остаться на старых
файлах, дайте AppCompatActivity ту тему, которую он требует: в
`AndroidManifest.xml` у `<application>` замените

```xml
android:theme="@android:style/Theme.Material.NoActionBar"
```

на

```xml
android:theme="@style/Theme.AppCompat.DayNight.NoActionBar"
```

`Theme.AppCompat.DayNight.NoActionBar` живёт в `androidx.appcompat`
(в §5 ≤3.6.4 он уже был в зависимостях), так что больше ничего менять
не нужно. Минусы: остаётся тяжёлая библиотека, а ошибка §7.1
(`Theme.Material3` из шаблона themes.xml) может вернуться — тогда themes.xml
по §7.1 всё равно придётся править.

Проверка после фикса: приложение открывает тёмный экран «HyprScreen ·
зеркало экрана ПК» со списком «Найдено в сети». Если снова падает —
снимите свежий FATAL EXCEPTION (§7.4) и сверьтесь с таблицей ниже.

### 7.8. Приложение пишет «PC недоступен», хотя `doctor` и GUI на ПК — зелёные

Сервер запущен (`hyprscreen on`), `hyprscreen doctor` — «Всё в порядке»,
GUI показывает «● работает», а приложение упорно отвечает
«PC недоступен: проверьте адрес, сеть и что сервер запущен» — и по
discovery, и при ручном вводе адреса.

**Причина №1 (самая частая) — Android блокирует HTTP без шифрования.**
Стрим ходит по обычному `http://` (не https). Начиная с Android 9 (API 28)
система МОЛЧА режет весь cleartext-трафик, если в манифесте нет явного
разрешения. Симптом — ровно ваш: ПК полностью исправен (doctor/GUI
зелёные), а телефон не подключается НИКАК.

Лечение — одна строка в `AndroidManifest.xml`. У `<application …>`
должен быть атрибут (шаблон §4 содержит его с версии 3.7.1):

```xml
android:usesCleartextTraffic="true"
```

После правки — **Build → Clean Project** → пересборка → переустановка.
С 3.7.1 приложение само распознаёт эту ошибку: на экране подключения
появится «Android блокирует HTTP (cleartext)…» вместо «PC недоступен».
Если видите именно эту подсказку — атрибута в вашем манифесте нет.

**Причина №2 — сеть/файрвол.** Если атрибут есть, а подключения нет:

1. телефон и ПК в ОДНОЙ Wi-Fi сети (гостевая сеть и мобильный интернет
   не считаются);
2. файрвол на ПК: `hyprscreen doctor` с 3.7.1 сам показывает подсказки
   для ufw/firewalld/nftables/iptables. Открыть нужно **8080/tcp**
   (стрим) И **8766/udp** (discovery — без него ПК не появится в
   «Найдено в сети»);
3. «AP isolation» на роутере (клиенты Wi-Fi не видят друг друга):
   проверка — откройте в БРАУЗЕРЕ телефона `http://<IP-ПК>:8080`.
   Если браузер тоже не открывает, а на ПК всё зелёное — это изоляция
   точек доступа или файрвол; приложение тут ни при чём;
4. у ПК несколько адресов (VPN, вторая сетевая карта): с 3.7.1 discovery
   анонсирует ВСЕ адреса, а `hyprscreen doctor` их перечисляет — в
   приложении выбирайте адрес вашей Wi-Fi подсети (`192.168.*` и т.п.);
5. bind: если в `config.toml` было `bind_address = "127.0.0.1"` —
   `hyprscreen` с 3.7.1 сам заменяет его на `0.0.0.0` с предупреждением,
   а `doctor` показывает, на каком адресе сервер слушает РЕАЛЬНО
   (раньше при loopback-bind телефон не подключался при зелёных
   doctor/GUI).

### Остальные проблемы

| Симптом | Причина | Лечение |
|---|---|---|
| лишний плагин `kotlin.serialization` в app/build.gradle.kts | шаблон с version catalog | удалите `alias(libs.plugins.kotlin.serialization)` (§7.6) |
| `Could not get unknown property 'libs'` | libs.versions.toml не в gradle/ | перенесите в `gradle/` или пишите координаты строками (§7.6) |
| не запускается / падает при старте | чаще манифест (§4): нет `.HyprScreenApp` или launcher не `.ConnectActivity` | снимите FATAL из Logcat (§7.4) |
| падает при старте: `You need to use a Theme.AppCompat theme` | .kt ≤3.6.4 (AppCompatActivity) + платформенная тема §4 | замените оба .kt из 3.7.0 или тему в манифесте (§7.7) |
| AAPT: Invalid resource file name / mipmap not found (после своей картинки) | имя/папка ресурса | правила §7.5: строчные, res/drawable/, сверить манифест |
| INSTALL_FAILED_USER_RESTRICTED (не ставится по USB) | телефон запрещает установку по USB | «Установка через USB» в «Для разработчиков» (§7.3) |
| AAPT `attribute layout_constraint* not found` | шаблонный activity_main.xml | удалите `res/layout/` (§7.2) |
| AAPT `Theme.Material3.* not found` | шаблонный themes.xml | платформенная тема (§7.1) |
| «PC недоступен» при зелёных doctor/GUI | Android блокирует http (cleartext) или сеть/файрвол | `android:usesCleartextTraffic="true"` в манифесте, затем сеть — §7.8 |
| при показе экран НЕ поворачивается в горизонтальный | .kt ≤3.7.1: MainActivity была зафиксирована portrait | обновите MainActivity.kt из 3.8.0 (fullSensor в коде) или поставьте `android:screenOrientation="fullSensor"` в манифесте (§4) |
| вместо кнопки питания — прямоугольник с крестом (tofu) | в шрифте телефона нет глифа «⏻» (U+23FB) | обновите MainActivity.kt из 3.8.0 — значок теперь рисуется кодом (Canvas) |
| на телефоне НЕ тот воркспейс (показывает текущий ПК) | PC ≤3.7.1 не переключал монитор | обновите pc/ из 3.8.0+: при старте сервер сам откроет выбранный воркспейс (и GUI больше не отказывается стартовать) |
| при переключении воркспейса НА ПК картинка на телефоне «едет» за ним ИЛИ замирает | PC ≤3.8.0 зеркалил текущий воркспейс; 3.8.1 ставил поток на паузу | обновите pc/ из 3.9.1: закреплённый воркспейс живёт на ВИРТУАЛЬНОМ мониторе (headless) и рендерится всегда — кадры живые, экраны ПК свободны; при остановке воркспейс возвращается на место. На Hyprland 0.55+ с Lua-конфигом (CachyOS) нужна именно 3.9.1 — там исправлен dispatch под новый Lua-движок |
| «сервер требует токен (403)» | на PC задан auth_token | введите токен в поле на экране подключения |
| «НЕТ СИГНАЛА» | grim не может захватить экран | на PC: `hyprscreen grimtest`; чаще всего `yay -S grim-git` |
| PC не появляется в «Найдено» | UDP заблокирован / разные сети | разрешите 8766/udp, проверьте Wi-Fi AP isolation |
| Клавиатура: «wtype не установлен» | нет пакета на PC | `sudo pacman -S wtype` |
| Тост «Соединение разорвано» | сервер выключен (`hyprscreen off`) | включите снова: `hyprscreen on` |

* Экран телефона чистый: FPS/статус — в GUI на PC (вкладка «Телефон»).
* Клавиатура: тап по видео поднимает мягкую клавиатуру; текст и
  BackSpace/Enter/Tab уходят на PC через wtype. Специальные клавиши
  (стрелки, F1–F12, Ctrl+…) работают и с аппаратной клавиатуры телефона
  (dispatchKeyEvent).
* Если клавиатура на вашем устройстве/IME работает некорректно — сообщите:
  по решению пользователя её можно вовсе убрать (останется только «⏻»).
* Long-tap по хосту в «Истории» — удалить запись.
