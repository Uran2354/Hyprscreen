"""Конфигурация HyprScreen.

Здесь живёт :class:`Config` (верхнеуровневые настройки) и
:class:`ScreenConfig` (настройки одного виртуального экрана). Конфиг
читается из TOML-файла (Python 3.11+: стандартный :mod:`tomllib`).

Ключевые гарантии текущей версии:

* кадр на телефоне занимает ВЕСЬ экран: hello шлёт ФАКТИЧЕСКИЙ размер
  JPEG-кадра (с учётом ``grim -s scale``), координаты касаний приходят
  в пространстве кадра, и PC пересчитывает их в пиксели монитора;
* старт сервера не «дёргает» рабочий стол: после создания headless-вывода
  и на всех прочих шагах фокус и курсор возвращаются на физический
  монитор, при остановке пользователю возвращается его воркспейс;
* preflight-тест захвата grim: если захват не работает, причина сразу
  видна в логе/уведомлении/GUI, а не по чёрному экрану на телефоне;
* дефолтное разрешение — АЛЬБОМНОЕ ``2340x1080``: приложение на
  телефоне зафиксировано в landscape, кадр совпадает с экраном по
  соотношению сторон и занимает весь экран;
* runtime-правила воркспейсов не накапливаются: bind() переуказывает,
  а не добавляет их.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Mapping

__version__ = "2.2.0"

log = logging.getLogger(__name__)

try:
    import tomllib as _toml  # type: ignore[import-not-found]
except ModuleNotFoundError:  # pragma: no cover - только Python < 3.11
    try:
        import tomli as _toml  # type: ignore[import-not-found]
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "Нет TOML-парсера. На Python <3.11 установите 'tomli': pip install tomli"
        ) from exc

#: Пресеты FPS-режимов: fps / качество JPEG / масштаб кадра.
#: ``auto`` берёт balance как базу и дополнительно адаптирует FPS вниз.
FPS_MODE_PRESETS: dict[str, dict[str, float]] = {
    "eco":     {"fps": 12, "jpeg_quality": 60, "scale": 0.60},
    "balance": {"fps": 24, "jpeg_quality": 75, "scale": 0.75},
    "smooth":  {"fps": 30, "jpeg_quality": 80, "scale": 1.00},
    "max":     {"fps": 60, "jpeg_quality": 85, "scale": 1.00},
    "auto":    {"fps": 24, "jpeg_quality": 75, "scale": 0.75},
}

FPS_MODES: tuple[str, ...] = ("auto", "eco", "balance", "smooth", "max", "custom")

#: Рабочий стол по умолчанию (выбор воркспейса, дефолт 6).
DEFAULT_WORKSPACE = 6


def _parse_resolution(value: str | tuple[int, int]) -> tuple[int, int]:
    """Разобрать ``"1920x1080"`` или ``(1920, 1080)`` в ``(width, height)``."""
    if isinstance(value, tuple):
        if len(value) != 2:
            raise ValueError(f"кортеж разрешения должен быть (W, H), получено {value!r}")
        w, h = int(value[0]), int(value[1])
        if w <= 0 or h <= 0:
            raise ValueError(f"разрешение должно быть положительным: {(w, h)!r}")
        return w, h
    if not isinstance(value, str):
        raise TypeError("разрешение должно быть строкой 'WxH' или (W,H)")
    text = value.strip().lower()
    if "x" not in text:
        raise ValueError(f"разрешение должно выглядеть как '1920x1080', получено {value!r}")
    w_str, h_str = text.split("x", 1)
    w, h = int(w_str), int(h_str)
    if w <= 0 or h <= 0:
        raise ValueError(f"разрешение должно быть положительным: {value!r}")
    return w, h


def clamp_workspace(value: int) -> int:
    """Привести номер воркспейса к допустимому диапазону 1..99."""
    return max(1, min(99, int(value)))


def clamp_fps(value: int) -> int:
    """Привести FPS к допустимому диапазону 1..120."""
    return max(1, min(120, int(value)))


def clamp_quality(value: int) -> int:
    """Привести качество JPEG к допустимому диапазону 1..100."""
    return max(1, min(100, int(value)))


@dataclass
class ScreenConfig:
    """Настройки одного виртуального экрана.

    Атрибуты
    --------
    resolution:
        ``(width, height)`` headless-вывода в пикселях. Дефолт — альбом
        2340x1080: приложение на телефоне зафиксировано в landscape, и
        альбомный кадр с тем же соотношением сторон занимает весь экран
        (портрет 1080x2340 давал «маленькую» картинку).
    refresh_rate:
        Частота обновления (Гц) headless-вывода (``WxH@rate``).
    fps:
        Целевая частота кадров стрима.
    jpeg_quality:
        Качество JPEG 1-100 (``grim -q``).
    scale:
        Масштаб кадра 0.2-1.0 (``grim -s``); меньше кадр — выше FPS.
    output_name:
        Имя headless-вывода (обычно авто: ``HEADLESS-1``).
    fps_mode:
        Один из :data:`FPS_MODES`. Пресет лочит fps/quality/scale к своим
        значениям (:meth:`apply_fps_mode`), ``custom`` — значения как заданы,
        ``auto`` — как balance + адаптация FPS в capture-лупе.
    """

    resolution: tuple[int, int] = (2340, 1080)
    refresh_rate: float = 60.0
    fps: int = 24
    jpeg_quality: int = 75
    scale: float = 0.75
    output_name: str | None = None
    fps_mode: str = "auto"

    def __post_init__(self) -> None:
        if self.fps_mode not in FPS_MODES:
            raise ValueError(
                f"fps_mode должен быть одним из {FPS_MODES}, получено {self.fps_mode!r}"
            )
        self.scale = max(0.2, min(1.0, float(self.scale)))
        # Клампы против мусора из TOML/CLI: fps=1000 превращал capture-луп
        # в busy-cycle (sleep_for всегда <= 0), quality=0 ломал grim -q.
        self.fps = clamp_fps(self.fps)
        self.jpeg_quality = clamp_quality(self.jpeg_quality)

    @property
    def width(self) -> int:
        return self.resolution[0]

    @property
    def height(self) -> int:
        return self.resolution[1]

    @property
    def mode_string(self) -> str:
        """Hyprland-строка режима ``WxH@rate``."""
        rate = int(self.refresh_rate) if self.refresh_rate.is_integer() else self.refresh_rate
        return f"{self.width}x{self.height}@{rate}"

    # Фактический размер JPEG-кадра. grim при ``-s scale`` выдаёт
    # кадр width*scale x height*scale — именно его получает телефон.
    # hello обязан нести ЭТИ размеры (PROTOCOL.md: «ширина/высота в hello
    # всегда равны реальному размеру захвата»), иначе клиент рисует кадр
    # меньшей площади (масштаб 0.75 → 56% экрана) и касания съезжают.
    @property
    def frame_width(self) -> int:
        """Ширина фактического кадра стрима (пиксели)."""
        return max(1, round(self.width * self.scale))

    @property
    def frame_height(self) -> int:
        """Высота фактического кадра стрима (пиксели)."""
        return max(1, round(self.height * self.scale))

    def apply_fps_mode(self) -> None:
        """Применить пресет fps_mode к fps/jpeg_quality/scale.

        ``custom`` и ``auto`` (после применения базы) значения не трогают.
        """
        preset = FPS_MODE_PRESETS.get(self.fps_mode)
        if preset is None:
            return
        self.fps = int(preset["fps"])
        self.jpeg_quality = int(preset["jpeg_quality"])
        self.scale = float(preset["scale"])

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["resolution"] = list(self.resolution)
        return d


@dataclass
class Config:
    """Верхнеуровневая конфигурация HyprScreen.

    Атрибуты
    --------
    port:
        TCP-порт WebSocket-сервера (по умолчанию 8765).
    bind_address:
        Адрес привязки; ``0.0.0.0`` — чтобы телефон в LAN подключился.
    workspace:
        Номер рабочего стола, который живёт на телефоне (по умолчанию 6).
        Именно он открывается по ``win+<N>``; другие воркспейсы на
        headless-мониторе не создаются.
    phone_overlay:
        ``False`` (по умолчанию) — сервер просит клиента НЕ рисовать
        служебную надпись (hello ``overlay:false``); данные статуса
        вместо этого видны в блоке «Телефон» GUI.
    screens:
        Список :class:`ScreenConfig` (по умолчанию один экран).
    discovery_port / discovery_enabled / host_name:
        UDP-discovery для авто-поиска PC из приложения.
    extra:
        Неструктурированные поля из TOML (например, ключи старых версий).
    """

    port: int = 8765
    bind_address: str = "0.0.0.0"
    screens: list[ScreenConfig] = field(default_factory=lambda: [ScreenConfig()])
    discovery_port: int = 8766
    discovery_enabled: bool = True
    host_name: str | None = None
    workspace: int = DEFAULT_WORKSPACE
    phone_overlay: bool = False
    extra: dict[str, Any] = field(default_factory=dict)
    auth_token: str | None = None
    input_rate_limit: int = 0
    tls_enabled: bool = False
    tls_cert: str | None = None
    tls_key: str | None = None
    log_to_file: bool = True
    log_file: str | None = None

    def __post_init__(self) -> None:
        self.workspace = clamp_workspace(self.workspace)

    # -- backward-compat свойства (делегируют к screens[0]) ----------------

    @property
    def width(self) -> int:
        return self.screens[0].width

    @property
    def height(self) -> int:
        return self.screens[0].height

    @property
    def resolution(self) -> tuple[int, int]:
        return self.screens[0].resolution

    @resolution.setter
    def resolution(self, value: tuple[int, int]) -> None:
        for s in self.screens:
            s.resolution = value

    @property
    def refresh_rate(self) -> float:
        return self.screens[0].refresh_rate

    @refresh_rate.setter
    def refresh_rate(self, value: float) -> None:
        for s in self.screens:
            s.refresh_rate = value

    @property
    def fps(self) -> int:
        return self.screens[0].fps

    @fps.setter
    def fps(self, value: int) -> None:
        for s in self.screens:
            s.fps = clamp_fps(value)

    @property
    def jpeg_quality(self) -> int:
        return self.screens[0].jpeg_quality

    @jpeg_quality.setter
    def jpeg_quality(self, value: int) -> None:
        for s in self.screens:
            s.jpeg_quality = clamp_quality(value)

    @property
    def fps_mode(self) -> str:
        return self.screens[0].fps_mode

    @fps_mode.setter
    def fps_mode(self, value: str) -> None:
        for s in self.screens:
            s.fps_mode = value

    @property
    def mode_string(self) -> str:
        return self.screens[0].mode_string

    @property
    def virtual_output_name(self) -> str | None:
        return self.screens[0].output_name

    @virtual_output_name.setter
    def virtual_output_name(self, value: str | None) -> None:
        self.screens[0].output_name = value

    # -- сериализация ------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Плоский словарь для логов; auth_token маскируется."""
        return {
            "port": self.port,
            "bind_address": self.bind_address,
            "workspace": self.workspace,
            "phone_overlay": self.phone_overlay,
            "screens": [s.to_dict() for s in self.screens],
            "discovery_port": self.discovery_port,
            "discovery_enabled": self.discovery_enabled,
            "host_name": self.host_name,
            "auth_token": "***" if self.auth_token else None,
            "input_rate_limit": self.input_rate_limit,
            "tls_enabled": self.tls_enabled,
            "log_to_file": self.log_to_file,
        }

    def to_toml_string(self) -> str:
        """Сериализация в TOML (для сохранения из GUI).

        Нестандартные настройки пользователя (TLS, rate-limit, файл лога)
        сохраняются вместе с остальными — раньше запись из GUI молча
        стирала их из config.toml.
        """
        s0 = self.screens[0]
        lines = [
            "# HyprScreen config — сгенерировано автоматически",
            "[hyprscreen]",
            f"port = {int(self.port)}",
            f'bind_address = "{self.bind_address}"',
            f"workspace = {int(self.workspace)}",
            f"phone_overlay = {'true' if self.phone_overlay else 'false'}",
            f"resolution = \"{s0.width}x{s0.height}\"",
            f"refresh_rate = {float(s0.refresh_rate)}",
            f'fps_mode = "{s0.fps_mode}"',
            f"fps = {int(s0.fps)}",
            f"jpeg_quality = {int(s0.jpeg_quality)}",
            f"scale = {float(s0.scale)}",
            f"screen_count = {len(self.screens)}",
            f"discovery_enabled = {'true' if self.discovery_enabled else 'false'}",
            f"discovery_port = {int(self.discovery_port)}",
        ]
        if self.host_name:
            lines.append(f'host_name = "{self.host_name}"')
        if self.auth_token:
            lines.append(f'auth_token = "{self.auth_token}"')
        if self.input_rate_limit:
            lines.append(f"input_rate_limit = {int(self.input_rate_limit)}")
        if self.tls_enabled:
            lines.append("tls_enabled = true")
            if self.tls_cert:
                lines.append(f'tls_cert = "{self.tls_cert}"')
            if self.tls_key:
                lines.append(f'tls_key = "{self.tls_key}"')
        if self.log_file:
            lines.append(f'log_file = "{self.log_file}"')
        if not self.log_to_file:
            lines.append("log_to_file = false")
        return "\n".join(lines) + "\n"

    def save(self, path: str | os.PathLike[str]) -> None:
        """Сохранить конфиг в TOML-файл."""
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(self.to_toml_string(), encoding="utf-8")
        log.info("конфиг сохранён: %s", p)

    # -- конструкторы ------------------------------------------------------

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any]) -> "Config":
        """Построить :class:`Config` из маппинга (разобранного TOML).

        Экраны: ``screen_count = N`` (N одинаковых из общих полей) либо
        массив таблиц ``[[screens]]``. Неизвестные ключи (в т.ч. от старых
        версий) уходят в ``extra``.
        """
        screen_field_names = set(ScreenConfig.__dataclass_fields__.keys())
        cfg_field_names = set(cls.__dataclass_fields__.keys()) - {"screens", "extra"}

        known: dict[str, Any] = {}
        extra: dict[str, Any] = {}
        for key, value in data.items():
            if key in cfg_field_names:
                known[key] = value
            elif key in ("screen_count", "screens"):
                continue  # обработаем ниже
            else:
                extra[key] = value

        screens: list[ScreenConfig] = []
        raw_screens = data.get("screens")
        if isinstance(raw_screens, list):
            for entry in raw_screens:
                if not isinstance(entry, Mapping):
                    raise ValueError(
                        f"каждый [[screens]] должен быть таблицей, получено {type(entry)}"
                    )
                fields = {k: v for k, v in entry.items() if k in screen_field_names}
                for k in entry:
                    if k not in screen_field_names:
                        extra[f"screen.{k}"] = entry[k]
                if "resolution" in fields:
                    fields["resolution"] = _parse_resolution(fields["resolution"])
                screens.append(ScreenConfig(**fields))
        else:
            shared: dict[str, Any] = {}
            for k in screen_field_names:
                if k in data:
                    v = data[k]
                    if k == "resolution":
                        v = _parse_resolution(v)
                    shared[k] = v
            count = int(data.get("screen_count", 1))
            if count < 1 or count > 4:
                raise ValueError(f"screen_count должен быть 1..4, получено {count}")
            screens = [ScreenConfig(**dict(shared)) for _ in range(count)]

        if not screens:
            screens = [ScreenConfig()]

        cfg = cls(**known)
        cfg.screens = screens
        cfg.extra = extra
        # Пресеты применяются сразу: fps_mode="balance" => fps/q/scale пресета,
        # если пользователь не задал явные fps/jpeg_quality/scale в TOML.
        explicit_stream_keys = {"fps", "jpeg_quality", "scale"} & set(data.keys())
        for s in cfg.screens:
            s.apply_fps_mode()
        if explicit_stream_keys and cfg.fps_mode != "custom":
            # Пользователь смешал пресет и явные значения: явные сильнее.
            if "fps" in data:
                cfg.fps = clamp_fps(data["fps"])
            if "jpeg_quality" in data:
                cfg.jpeg_quality = clamp_quality(data["jpeg_quality"])
            if "scale" in data:
                for s in cfg.screens:
                    s.scale = max(0.2, min(1.0, float(data["scale"])))
        return cfg

    @classmethod
    def from_file(cls, path: str | os.PathLike[str]) -> "Config":
        """Загрузить конфиг из TOML-файла (таблица ``[hyprscreen]`` или плоский)."""
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"конфиг не найден: {p}")
        with p.open("rb") as fh:
            data = _toml.load(fh)
        section = data.get("hyprscreen", data) if isinstance(data, dict) else data
        if not isinstance(section, dict):
            raise ValueError(f"некорректная структура конфига в {p}")
        cfg = cls.from_mapping(section)
        log.info("конфиг загружен из %s: %s", p, cfg.to_dict())
        return cfg

    @classmethod
    def default(cls, screen_count: int = 1) -> "Config":
        """Встроенная конфигурация по умолчанию с N экранами."""
        if screen_count < 1 or screen_count > 4:
            raise ValueError(f"screen_count должен быть 1..4, получено {screen_count}")
        return cls(screens=[ScreenConfig() for _ in range(screen_count)])
