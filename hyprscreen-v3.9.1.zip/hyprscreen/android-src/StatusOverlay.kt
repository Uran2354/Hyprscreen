package com.example.hyprscreen

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect

/**
 * Маленький помощник, рисующий текстовый оверлей статуса («подключение…»)
 * в левом-нижнем углу [ScreenView]. Включается/выключается в рантайме.
 *
 * Единый стиль «чёрный + изумруд» ([UiTheme]) — изумрудный текст на
 * скруглённой полупрозрачной тёмной пилюле с тонкой рамкой.
 *
 * В 3.x оверлей-КНОПКИ на телефоне нет (решение пользователя): пилюля
 * используется только для служебных сообщений («подключение…»).
 *
 * Намеренно крошечный — без ресурсов, без ветвления по версии платформы.
 */
class StatusOverlay {

    private val textPaint = Paint().apply {
        color = UiTheme.EMERALD_BRIGHT
        textSize = 26f
        isAntiAlias = true
        setShadowLayer(5f, 1f, 1f, Color.BLACK)
    }
    private val bgPaint = Paint().apply { color = UiTheme.SCRIM }
    private val strokePaint = Paint().apply {
        color = UiTheme.BORDER
        style = Paint.Style.STROKE
        strokeWidth = 2f
        isAntiAlias = true
    }
    private val bounds = Rect()

    private var text: String = ""
    private var visible: Boolean = true

    fun setText(t: String) {
        if (t != text) text = t
    }

    fun setVisible(v: Boolean) {
        visible = v
    }

    fun draw(canvas: Canvas, w: Int, h: Int) {
        if (!visible || text.isBlank()) return
        textPaint.getTextBounds(text, 0, text.length, bounds)
        val pad = 14f
        val left = 16f
        val bottom = h - 16f
        val top = bottom - bounds.height() - pad
        val rLeft = left - pad
        val rTop = top - pad
        val rRight = left + bounds.width() + pad
        val rBottom = bottom + pad
        canvas.drawRoundRect(rLeft, rTop, rRight, rBottom, 12f, 12f, bgPaint)
        canvas.drawRoundRect(rLeft, rTop, rRight, rBottom, 12f, 12f, strokePaint)
        canvas.drawText(text, left, bottom, textPaint)
    }
}
