// shell.qml — автономный запуск hyprscreen-тикера (если у вас нет бара
// с местом под виджет, или хотите плавающую «пилюлю» в углу).
//
//   qs -p ~/.config/quickshell/hyprscreen
//
// Если же вы встраиваете HyprScreenTicker в свой бар — этот файл не нужен.
// =============================================================================
import QtQuick
import Quickshell

Scope {
    PanelWindow {
        id: win

        anchors {
            right: true
            bottom: true
        }
        margins {
            right: 14
            bottom: 14
        }
        // Не резервируем место на экране и не мешаем окнам:
        exclusiveZone: -1
        aboveWindows: true
        color: "transparent"

        implicitWidth: pill.implicitWidth + 4
        implicitHeight: pill.implicitHeight + 4

        HyprScreenTicker {
            id: pill
            anchors.centerIn: parent
        }
    }
}
