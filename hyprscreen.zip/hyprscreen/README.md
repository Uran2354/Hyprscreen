# HyprScreen

Превратите Android-телефон или планшет во **второй беспроводной монитор** для ПК
на Linux (CachyOS / Hyprland 0.55+). ПК создаёт виртуальный Wayland-вывод
(`HEADLESS-N`), захватывает его через `grim` и стримит кадры по WebSocket на
устройство. Ввод инъектируется через **evdev UInput** (абсолютные координаты —
курсор двигается мгновенно, без дрейфа и без ydotool).

## Особенности

- **Hyprland 0.55+ (Lua)** — поддержка нового Lua-синтаксиса `hyprctl dispatch`
- **evdev UInput** — абсолютное позиционирование курсора, без subprocess на
  каждое движение, без демона ydotoold
- **Интерактивное меню** — `./run.sh` без аргументов: выбор обоев, воркспейсов,
  просмотр лога, перезапуск
- **Auth токен** — защита от несанкционированного подключения
- **Автопереподключение** — Android автоматически переподключается при обрыве Wi-Fi
- **Сохранение настроек** — обои, воркспейсы и токен восстанавливаются при запуске
- **Multi-screen** — 1–4 виртуальных экрана (телефон + планшет одновременно)
- **Логирование в файл** — с ротацией (5 МБ × 3)
- **Rate-limit** — защита от flood input-сообщений

## Структура проекта

```
hyprscreen/
├── README.md
├── PROTOCOL.md                 ← спецификация wire-протокола
├── android-src/                # Kotlin (один пакет com.example.hyprscreen)
│   ├── SETUP.md                # интеграция в Android Studio
│   ├── Models.kt               # data-классы + AuthPayload
│   ├── ScreenClient.kt         # OkHttp WebSocket + auth + auto-reconnect
│   ├── ScreenView.kt           # fit/crop рендеринг
│   ├── TouchHandler.kt         # жесты → JSON
│   ├── KeyboardHelper.kt       # софт-клавиатура
│   ├── ScreenStreamService.kt  # foreground service
│   ├── ConnectActivity.kt      # экран подключения (IP, порт, токен, экран)
│   ├── MainActivity.kt         # полноэкранный стрим + бургер-меню
│   ├── Prefs.kt                # сохранение хостов с токеном
│   └── Discovery.kt            # UDP-обнаружение
└── pc/                         # Python (CachyOS / Hyprland 0.55+)
    ├── main.py                 # точка входа, подкоманды, интерактивное меню
    ├── config.py               # Config + ScreenConfig (auth, TLS, rate-limit)
    ├── hyprctl.py              # IPC через hyprctl CLI + Lua 0.55 dispatch
    ├── virtual_output.py       # создание/удаление HEADLESS-*
    ├── capture.py              # grim захват (jpeg/webp)
    ├── server.py               # WebSocket сервер, auth, rate-limit, cleanup
    ├── input.py                # evdev UInput (абсолютные координаты)
    ├── discovery.py            # UDP-бродкастер
    ├── logging_setup.py        # лог в stderr + файл с ротацией
    ├── state_file.py           # state.json (имена HEADLESS)
    ├── settings_store.py       # сохранение обоев/воркспейсов
    ├── config.toml.example     # пример конфига с auth_token
    ├── requirements.txt        # websockets, evdev
    ├── setup.sh                # настройка CachyOS
    └── run.sh                  # запускатор
```

## Быстрый старт

### 1. Настройка PC (CachyOS / Hyprland 0.55+)

```bash
cd pc/
./setup.sh              # pacman: grim, wtype, python-evdev + venv + config.toml
```

`setup.sh` проверит:
- `grim`, `wtype` — захват и клавиатура
- `python-evdev` — виртуальное устройство ввода (UInput)
- группа `input` — права на `/dev/uinput`
- venv + `pip install -r requirements.txt`
- `config.toml` из примера

### 2. Конфигурация

```bash
cp config.toml.example config.toml
```

Отредактируйте `config.toml`:
```toml
[hyprscreen]
auth_token = "mysecret"       # токен для телефона
screen_count = 1              # 1-4 виртуальных экрана
resolution = "1920x1080"
fps = 30
```

### 3. Запуск

```bash
./run.sh                      # интерактивное меню (без аргументов)
```

Меню покажет:
```
==================================================
  HyprScreen — интерактивное меню
==================================================
  IP:     192.168.0.189
  Порт:   8765
  Токен:  mysecret

  ✓ Сервер активен, HEADLESS: HEADLESS-1

  1) Выбрать обои
  2) Перенести воркспейс на телефон
  3) Показать статус (list)
  4) Показать лог сервера
  5) Перезапустить сервер
  0) Выход (остановить сервер)
```

### 4. Подкоманды

```bash
./run.sh                      # интерактивное меню (по умолчанию)
./run.sh run                  # только сервер (без меню)
./run.sh kill                 # найти и убить сервер + очистить HEADLESS
./run.sh reset                # удалить все HEADLESS-* и state-файл
./run.sh list                 # показать мониторы/воркспейсы
./run.sh workspace 6          # перенести воркспейс 6 на телефон
./run.sh diagnose             # диагностика IPC Hyprland
./run.sh grimtest             # тест захвата grim
```

### 5. Дополнительные флаги

```bash
./run.sh --auth-token secret       # токен авторизации
./run.sh --screens 2               # два виртуальных экрана
./run.sh --wallpaper ~/Pictures/wp.jpg  # обои swww
./run.sh --image-format webp       # WebP вместо JPEG
./run.sh --tls                     # TLS (wss://)
./run.sh --input-rate-limit 100    # rate-limit ввода
./run.sh --no-log-to-file          # лог только в stderr
./run.sh --log-level DEBUG         # уровень логирования
```

### 6. Android

Откройте Android Studio → New Project → Empty Views Activity, пакет
`com.example.hyprscreen`, minSdk 24. Скопируйте `.kt` из `android-src/`,
добавьте разрешения в манифест и зависимости в `build.gradle.kts` (см.
`android-src/SETUP.md`). Введите IP, порт, токен — подключитесь.

### 7. Автозапуск с Hyprland

В `hyprland.conf`:
```ini
exec-once = /путь/к/hyprscreen/pc/run.sh run
```

Или с токеном через config.toml:
```ini
exec-once = /путь/к/hyprscreen/pc/run.sh run -c /путь/к/config.toml
```

## Wire-протокол

Полная спецификация — в `PROTOCOL.md`. Кратко:

| Направление | Сообщение | Формат |
|---|---|---|
| PC → телефон | `hello` (text) | `{"type":"hello","width":1920,"height":1080,"fps":30,"image_format":"jpeg"}` |
| PC → телефон | кадр (binary) | один JPEG/WebP на сообщение |
| телефон → PC | `auth` (text) | `{"type":"auth","token":"mysecret"}` (первым сообщением) |
| телефон → PC | `pointer_move` | `{"type":"pointer_move","x":842.0,"y":510.0}` |
| телефон → PC | `pointer_down/up` | `{"type":"pointer_down","x":842,"y":510,"button":"left"}` |
| телефон → PC | `scroll` | `{"type":"scroll","dx":0.0,"dy":-3.0}` |
| телефон → PC | `key` | `{"type":"key","keysym":"c","modifiers":["ctrl","shift"]}` |
| телефон → PC | `text` | `{"type":"text","text":"neofetch\n"}` |

## Требования

- **PC**: CachyOS (или Arch), Hyprland 0.55+, `grim`, `wtype`, `python-evdev`,
  Python 3.10+, группа `input` (права `/dev/uinput`)
- **Android**: API 24+, Android Studio, OkHttp, kotlinx-serialization
- **Сеть**: порты `8765/tcp` (стрим) и `8766/udp` (обнаружение)

## Устранение неполадок

```bash
./run.sh diagnose              # проверить IPC Hyprland
./run.sh grimtest              # проверить захват grim
./run.sh kill                  # убить зависший сервер
./run.sh reset                 # очистить фантомные HEADLESS
cat /tmp/hyprscreen-server.log # лог сервера (из интерактивного меню)
```

| Проблема | Решение |
|---|---|
| Сервер не запускается | `./run.sh kill && ./run.sh reset` |
| Курсор не двигается | Проверьте группу `input`: `groups \| grep input`, `sudo usermod -aG input $USER` |
| HEADLESS не удаляется | `./run.sh kill && ./run.sh reset` |
| Телефон не подключается | Проверьте токен, IP, порт, firewall (`8765/tcp`, `8766/udp`) |
| Нет изображения | `./run.sh grimtest` — проверит захват |
| Auth failed | Токен на телефоне должен совпадать с `auth_token` в `config.toml` |
