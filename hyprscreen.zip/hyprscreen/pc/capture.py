"""Бэкенды захвата экрана для HyprScreen.

Предусмотрено два бэкенда:

* :class:`GrimCapture` — использует ``grim -o <output> -t jpeg -q <q> -``
  чтобы выгрузить JPEG названного вывода Hyprland в stdout. Это бэкенд по
  умолчанию, всегда доступен на CachyOS после установки пакета ``grim``.
* :class:`PortalPipeWireCapture` — должен использовать FreeDesktop ScreenCast
  portal (предоставляется ``xdg-desktop-portal-hyprland``) через D-Bus для
  получения PipeWire-потока виртуального вывода и вытягивать кадры через
  GStreamer. Это эффективнее (zero-copy dmabuf там, где поддерживается),
  **НО в этой версии D-Bus-флоу не дописан**: методы ``_create_session``,
  ``_select_sources``, ``_start`` поднимают :class:`NotImplementedError`.
  Бэкенд честно задокументирован как экспериментальный — при отсутствии
  библиотек автоматически откатывается на grim (см. :func:`make_backend`).

Оба бэкенда реализуют ABC :class:`CaptureBackend`, чей async-генератор
:meth:`CaptureBackend.frames` выдаёт ``bytes`` JPEG-кадры.

Утиная типизация для make_backend
--------------------------------
:func:`make_backend` принимает объект с атрибутами ``fps``, ``jpeg_quality``,
``capture_backend`` — это может быть как :class:`ScreenConfig`, так и
старый :class:`Config` (для обратной совместимости).
"""

from __future__ import annotations

import asyncio
import logging
import shutil
import subprocess
import time
from abc import ABC, abstractmethod
from typing import AsyncIterator, Optional

from config import ScreenConfig

log = logging.getLogger(__name__)


class CaptureError(RuntimeError):
    """Поднимается, когда бэкенд захвата упал без возможности восстановления."""


class CaptureBackend(ABC):
    """Абстрактный базовый класс для бэкендов захвата.

    Подклассы обязаны реализовать :meth:`frames` (асинхронный генератор,
    выдающий JPEG ``bytes``) и :meth:`close` (освобождение ресурсов).
    """

    def __init__(self, config: ScreenConfig, output_name: str) -> None:
        self.config = config
        self.output_name = output_name

    @abstractmethod
    async def frames(self) -> AsyncIterator[bytes]:
        """Выдавать JPEG-кадры как ``bytes`` бесконечно, пока не :meth:`close`."""
        if False:  # pragma: no cover - typing only
            yield b""

    @abstractmethod
    async def close(self) -> None:
        """Освободить ресурсы бэкенда."""


# ---------------------------------------------------------------------------


class GrimCapture(CaptureBackend):
    """Захват вывода Hyprland через внешний вызов ``grim``.

    ``grim`` — стандартный wlroots-инструмент для снимков экрана, работает на
    Hyprland. Мы вызываем ``grim -o <output> -t jpeg -q <quality> -`` — это
    пишет один JPEG в stdout; читаем его в память и выдаём.

    Каждый вызов создаёт новый процесс ``grim``. Это намеренно просто и
    совпадает с тем, как экосистема wlroots снимает экраны; для более
    высокой производительности используйте portal-бэкенд (когда он будет
    дописан).
    """

    def __init__(self, config: ScreenConfig, output_name: str) -> None:
        super().__init__(config, output_name)
        self._grim_path: Optional[str] = shutil.which("grim")
        if self._grim_path is None:
            raise CaptureError(
                "grim не найден в PATH. На CachyOS установите: "
                "sudo pacman -S grim"
            )
        self._closed = False

    async def _grab(self) -> bytes:
        """Запустить один ``grim`` и вернуть JPEG-байты."""
        cmd = [
            self._grim_path,  # type: ignore[list-item]
            "-o", self.output_name,
            "-t", getattr(self.config, "image_format", "jpeg"),
            "-q", str(self.config.jpeg_quality),
            "-",  # писать в stdout
        ]
        log.debug("grim команда: %s", " ".join(cmd))
        # Запуск в рабочем потоке, чтобы не блокировать event loop.
        proc = await asyncio.to_thread(
            subprocess.run,
            cmd,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=10,
        )
        if proc.returncode != 0:
            stderr = proc.stderr.decode("utf-8", "replace").strip() if proc.stderr else ""
            raise CaptureError(f"grim завершился с кодом {proc.returncode}: {stderr}")
        return proc.stdout or b""

    async def frames(self) -> AsyncIterator[bytes]:
        """Выдавать JPEG-кадры с целевым FPS, бесконечно."""
        interval = 1.0 / max(1, self.config.fps)
        next_t = time.monotonic()
        while not self._closed:
            try:
                data = await self._grab()
            except CaptureError as exc:
                log.warning("grim-захват не удался: %s", exc)
                await asyncio.sleep(0.2)
                next_t = time.monotonic() + interval
                continue
            except subprocess.TimeoutExpired as exc:
                log.warning("grim таймаут: %s", exc)
                next_t = time.monotonic() + interval
                continue
            if data:
                yield data
            # Темп до целевого FPS: спим до next_t (если уже опоздали —
            # пересинхронизируемся к «сейчас»).
            next_t += interval
            now = time.monotonic()
            if next_t > now:
                await asyncio.sleep(next_t - now)
            else:
                # Просроченный/медленный кадр: пересинхронизация к now + interval.
                next_t = now + interval

    async def close(self) -> None:
        self._closed = True


# ---------------------------------------------------------------------------


class PortalPipeWireCapture(CaptureBackend):
    """ЭКСПЕРИМЕНТАЛЬНЫЙ бэкенд через FreeDesktop ScreenCast portal + PipeWire.

    D-Bus-флоу не дописан — при инициализации поднимает NotImplementedError.
    Фабрика make_backend автоматически откатывается на GrimCapture.
    Для рабочей реализации нужно дописать: CreateSession → SelectSources →
    Start → обработка сигнала Prepare с PipeWire fd → GStreamer pipeline.
    """
    def __init__(self, config, output_name):
        super().__init__(config, output_name)
        raise NotImplementedError("portal-бэкенд не дописан — откат на grim")

    async def frames(self):
        yield b""

    async def close(self):
        pass


def make_backend(config: any, output_name: str) -> CaptureBackend:
    """Фабрика: выбрать настроенный бэкенд захвата.

    ``config`` может быть :class:`ScreenConfig` или старым :class:`Config`
    (утиная типизация по атрибутам ``capture_backend``, ``fps``,
    ``jpeg_quality``). При запросе ``"portal"`` и отсутствии зависимостей
    (или при :class:`NotImplementedError`) — авто-откат на :class:`GrimCapture`.
    """
    backend_name = (getattr(config, "capture_backend", "grim") or "grim").lower()
    if backend_name == "grim":
        return GrimCapture(_as_screen_config(config), output_name)
    if backend_name == "portal":
        try:
            return PortalPipeWireCapture(_as_screen_config(config), output_name)
        except NotImplementedError as exc:
            log.warning(
                "portal-бэкенд недоступен (%s); откатываемся на grim", exc
            )
            return GrimCapture(_as_screen_config(config), output_name)
    raise CaptureError(f"неизвестный capture_backend: {backend_name!r}")


def _as_screen_config(config) -> ScreenConfig:
    """Привести ``config`` (ScreenConfig или Config) к ScreenConfig."""
    if isinstance(config, ScreenConfig):
        return config
    screens = getattr(config, "screens", None)
    if screens:
        return screens[0]
    return ScreenConfig(
        resolution=getattr(config, "resolution", (1920, 1080)),
        refresh_rate=getattr(config, "refresh_rate", 60.0),
        fps=getattr(config, "fps", 30),
        jpeg_quality=getattr(config, "jpeg_quality", 80),
        capture_backend=getattr(config, "capture_backend", "grim"),
        output_name=getattr(config, "virtual_output_name", None),
        wallpaper=getattr(config, "wallpaper", None),
        image_format=getattr(config, "image_format", "jpeg"),
    )
