"""Захват кадров для HyprScreen — ``grim`` с адаптивным FPS.

Единственный бэкенд — :class:`GrimCapture`: ``grim -o <output> -t jpeg
-q <q> [-s <scale>] -`` выдаёт один JPEG в stdout. Экспериментальный
portal/PipeWire-бэкенд удалён (никогда не работал — D-Bus-флоу не был
дописан), webp удалён (grim его не поддерживает).

Режимы FPS (:data:`config.FPS_MODE_PRESETS`) задают fps/качество/масштаб;
в режиме ``auto`` контроллер :class:`AdaptiveFps` следит за реальной
длительностью захвата и снижает FPS (пол 8), когда grim не успевает,
возвращая скорость при первой возможности.
"""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import subprocess
import time
from typing import AsyncIterator, Optional

from config import ScreenConfig

log = logging.getLogger(__name__)

#: Минимальный интервал между полными диагностическими блоками в логе
#: (секунды). Большой интервал глушил диагностику на 5 минут,
#: и пользователь видел на телефоне ЧЁРНЫЙ ЭКРАН без единой подсказки.
#: 30 c — по-прежнему без спама, но сбой заметен сразу.
DIAG_MIN_INTERVAL = 30.0

#: Пока рабочий стол не меняется, одинаковые JPEG-кадры клиенту не
#: отправляются — экономия канала Wi-Fi в разы (сравнение байт: grim
#: кодирует одинаковый кадр в одинаковые байты). Раз в этот интервал
#: кадр всё же уходит — страховка от потери пакетов и «оживления»
#: после reconnect. Малое значение = быстрый первый кадр у нового клиента.
STATIC_KEEPALIVE_SEC = 0.5


class CaptureError(RuntimeError):
    """Поднимается, когда захват упал без возможности восстановления."""


#: Подсказки по типовым причинам сбоя grim — «чёрный экран» без
#: объяснений недопустим: причина всегда попадает в лог/GUI.
def capture_hints(stderr: str) -> list[str]:
    """Вернуть человекочитаемые подсказки по stderr grim."""
    s = (stderr or "").lower()
    hints: list[str] = []
    if "screencopy" in s or "zwlr" in s or "unsupported" in s or "manager" in s:
        hints.append(
            "Протокол захвата недоступен: новый Hyprland (>= 0.53) убрал "
            "wlr-screencopy, а grim 1.4.1 из репо умеет только его. "
            "Лечение: установите grim-git из AUR (поддержка "
            "ext-image-copy-capture): yay -S grim-git, и проверьте: "
            "./run.sh grimtest"
        )
    if "no such output" in s or "output.*not found" in s or "не найден вывод" in s:
        hints.append(
            "Вывод не найден: выполните ./run.sh reset и перезапустите сервер "
            "(fanтомный HEADLESS-* мог быть удалён)"
        )
    if "wayland" in s and ("display" in s or "connect" in s):
        hints.append(
            "grim не видит композитор: запускайте сервер внутри сессии "
            "Hyprland (exec-once) либо задайте WAYLAND_DISPLAY"
        )
    if not hints:
        hints.append(
            "Причина нестандартная — см. stderr выше; проверка: ./run.sh grimtest"
        )
    return hints


def preflight_output(output_name: str) -> tuple[bool, str]:
    """Тестовый захват указанного вывода (защита от «чёрного экрана»)."""
    grim = shutil.which("grim")
    if grim is None:
        return False, "grim не найден в PATH (pacman -S grim)"
    cmd = [grim, "-o", output_name, "-t", "jpeg", "-q", "60", "-"]
    try:
        proc = subprocess.run(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=8
        )
    except subprocess.TimeoutExpired:
        return False, f"grim завис (>8 c) на выводе {output_name} — убит по таймауту"
    except OSError as exc:
        return False, f"не удалось запустить grim: {exc}"
    if proc.returncode != 0:
        err = (proc.stderr or b"").decode("utf-8", "replace").strip()
        hint = "; ".join(capture_hints(err))
        return False, f"grim код {proc.returncode}: {err or 'без stderr'}. {hint}"
    if not proc.stdout:
        return False, "grim вернул пустой кадр"
    return True, ""



class AdaptiveFps:
    """Адаптер FPS для режима ``auto``.

    EMA длительности раунда захвата сравнивается с бюджетом ТЕКУЩЕГО FPS
    (``1 / текущий fps``): превышение на 15% → FPS вниз шагом 2 (пол
    ``min_fps``), запас более чем в ~2 раза → FPS вверх шагом 1 (потолок
    ``target``). Разные пороги вверх/вниз — анти-осцилляция; контроллер
    сходится к реальной ёмкости захвата, а не падает в пол.
    """

    def __init__(self, target_fps: int, min_fps: int = 8) -> None:
        self.target = max(1, int(target_fps))
        self.min_fps = max(1, int(min_fps))
        self.fps = float(self.target)
        self._ema: float | None = None

    def update(self, round_dt: float) -> float:
        """Учесть длительность раунда и вернуть текущий FPS."""
        if self._ema is None:
            self._ema = round_dt
        else:
            self._ema = 0.9 * self._ema + 0.1 * round_dt
        budget = 1.0 / self.fps  # что можем себе позволить при текущем FPS
        if self._ema > budget * 1.15:
            self.fps = max(float(self.min_fps), self.fps - 2.0)
        elif self._ema < budget * 0.55:
            self.fps = min(float(self.target), self.fps + 1.0)
        return self.fps

    @property
    def current(self) -> int:
        return int(round(self.fps))


class GrimCapture:
    """Захват headless-вывода через внешний ``grim``.

    Каждый кадр — отдельный процесс ``grim`` (просто и надёжно; так
    работает вся экосистема wlroots-скриншотов). ``scale < 1.0`` включает
    ``grim -s`` — кадр меньшего размера кодируется и передаётся быстрее.
    """

    #: Предупреждение про WAYLAND_DISPLAY логируется один раз на процесс,
    #: а не на каждый пересозданный бэкенд (иначе — спам в логе).
    _env_warned = False
    #: Полный диагностический блок печатается НЕ ЧАЩЕ раза в
    #: :data:`DIAG_MIN_INTERVAL` секунд на процесс.
    #:
    #: Раньше это было флагом «один раз на процесс, сбрасывается при
    #: успехе» — и ЭТО была дыра: при неустойчивом сбое (3 неудачи →
    #: успех → снова 3 неудачи…) флаг сбрасывался КАЖДЫМ успешным
    #: кадром, и блок печатался бесконечно (57 блоков за 40 c на
    #: стенде). Время-гейт не зависит от паттерна успехов/неудач.
    _diag_last_ts = 0.0

    def __init__(self, config: ScreenConfig, output_name: str) -> None:
        self.config = config
        self.output_name = output_name
        self._grim_path: Optional[str] = shutil.which("grim")
        if self._grim_path is None:
            raise CaptureError(
                "grim не найден в PATH. На CachyOS установите: sudo pacman -S grim"
            )
        if not (
            os.environ.get("WAYLAND_DISPLAY")
            or os.environ.get("HYPRLAND_INSTANCE_SIGNATURE")
        ):
            if not GrimCapture._env_warned:
                GrimCapture._env_warned = True
                log.warning(
                    "в окружении нет WAYLAND_DISPLAY/HYPRLAND_INSTANCE_SIGNATURE — "
                    "grim не сможет подключиться к композитору (сервер запущен "
                    "вне сессии Hyprland?)"
                )
        self._fail_streak = 0
        self._last_cmd: list[str] = []
        self._closed = False
        self._adaptive = AdaptiveFps(config.fps) if config.fps_mode == "auto" else None
        #: Последний отправленный кадр — для пропуска неизменных.
        self._last_frame: Optional[bytes] = None
        self._last_yield_ts: float = 0.0
        #: Сколько одинаковых кадров не отправлено (статистика).
        self.frames_skipped: int = 0
        #: Последняя ошибка захвата — видна в GUI/state.
        self.last_error: str | None = None

    # -- свойства для статуса/GUI ----------------------------------------

    @property
    def effective_fps(self) -> int:
        """Фактический FPS: адаптивный (auto) или целевой."""
        if self._adaptive is not None:
            return self._adaptive.current
        return self.config.fps

    @property
    def effective_quality(self) -> int:
        return self.config.jpeg_quality

    # -- захват -----------------------------------------------------------

    async def _grab(self) -> bytes:
        """Запустить один ``grim`` и вернуть JPEG-байты.

        Процесс запускается через :func:`asyncio.create_subprocess_exec` —
        без рабочего потока на каждый кадр; зависший grim убивается по
        таймауту (10 с).
        """
        cmd = [self._grim_path, "-o", self.output_name, "-t", "jpeg",
               "-q", str(self.config.jpeg_quality)]
        if self.config.scale < 1.0:
            cmd += ["-s", f"{self.config.scale:.2f}"]
        cmd.append("-")
        self._last_cmd = cmd
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
        except (OSError, FileNotFoundError) as exc:
            raise CaptureError(f"не удалось запустить grim: {exc}") from exc
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=10)
        except asyncio.TimeoutError:
            try:
                proc.kill()
                await proc.communicate()
            except Exception:  # noqa: BLE001
                pass
            raise CaptureError("grim не ответил за 10 c (убит по таймауту)") from None
        if proc.returncode != 0:
            stderr_text = stderr.decode("utf-8", "replace").strip() if stderr else ""
            self.last_error = f"grim код {proc.returncode}: {stderr_text}"
            raise CaptureError(
                f"grim завершился с кодом {proc.returncode}: {stderr_text}"
            )
        return stdout or b""

    async def frames(self) -> AsyncIterator[bytes]:
        """Выдавать JPEG-кадры, удерживая целевой (или адаптивный) FPS.

        Единичные сбои захвата глотаются (0.2 с и повтор). Диагностический
        блок (:meth:`_log_diagnostics`) пишется после 3 подряд ошибок,
        но НЕ ЧАЩЕ раза в :data:`DIAG_MIN_INTERVAL` секунд —
        флаг «один раз на процесс» сбрасывался каждым успешным
        кадром, и при неустойчивом сбое блок печатался бесконечно.
        После 10 подряд — ``CaptureError`` отдаётся наверх, чтобы сервер
        пересоздал бэкенд (см. ``StreamScreen._capture_loop``).
        """
        while not self._closed:
            t0 = time.monotonic()
            try:
                data = await self._grab()
            except CaptureError as exc:
                self._fail_streak += 1
                self.last_error = str(exc)
                now = time.monotonic()
                if (
                    self._fail_streak >= 3
                    and now - GrimCapture._diag_last_ts >= DIAG_MIN_INTERVAL
                ):
                    GrimCapture._diag_last_ts = now
                    self._log_diagnostics(exc)
                if self._fail_streak >= 10:
                    self._fail_streak = 0
                    raise
                await asyncio.sleep(0.2)
                continue
            # Успех: счётчик ПОДРЯД идущих неудач в ноль. Сам диагностический
            # блок теперь гейтится ТОЛЬКО временем (см. выше) — успех его
            # больше не сбрасывает.
            self._fail_streak = 0
            self.last_error = None
            round_dt = time.monotonic() - t0
            if self._adaptive is not None:
                fps = int(round(self._adaptive.update(round_dt)))
            else:
                fps = self.config.fps
            if not data:
                # Пустой кадр (grim rc=0, stdout пуст) раньше глотался
                # молча — «healthy» в GUI при мёртвой картинке. Трактуем как
                # сбой: last_error виден в GUI/тикере, CaptureError уходит в
                # capture-луп, который пересоздаст бэкенд.
                self.last_error = "grim вернул пустой кадр (rc=0, stdout пуст)"
                raise CaptureError(self.last_error)
            # Пропуск НЕИЗМЕННЫХ кадров: пока стол статичен, один и тот же
            # JPEG не отправляется (Wi-Fi не забивается миллионами байт).
            # Раз в STATIC_KEEPALIVE_SEC кадр всё же уходит.
            now = time.monotonic()
            if (
                data == self._last_frame
                and (now - self._last_yield_ts) < STATIC_KEEPALIVE_SEC
            ):
                self.frames_skipped += 1
            else:
                self._last_frame = data
                self._last_yield_ts = now
                yield data
            # Пауза до следующего кадра; если grim уже съел бюджет — без паузы.
            interval = 1.0 / max(1, fps)
            sleep_for = interval - round_dt
            if sleep_for > 0:
                await asyncio.sleep(sleep_for)

    def _log_diagnostics(self, exc: CaptureError) -> None:
        """Подробный блок диагностики в лог (после 3 подряд ошибок)."""
        env = os.environ
        lines = [
            "grim-захват не удался 3 раза подряд — диагностика:",
            f"  ошибка: {exc}",
            f"  команда: {' '.join(self._last_cmd)}",
            "  окружение: WAYLAND_DISPLAY={!r}, HYPRLAND_INSTANCE_SIGNATURE={!r}, "
            "XDG_RUNTIME_DIR={!r}".format(
                env.get("WAYLAND_DISPLAY"),
                env.get("HYPRLAND_INSTANCE_SIGNATURE"),
                env.get("XDG_RUNTIME_DIR"),
            ),
        ]
        # Подсказки по типовым причинам — сразу в лог, а не тишина.
        for h in capture_hints(str(exc)):
            lines.append(f"  подсказка: {h}")
        try:
            ver = subprocess.run(
                [self._grim_path, "--version"],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, timeout=5,
            ).stdout.strip()
            if ver:
                lines.append(f"  {ver}")
        except Exception:  # noqa: BLE001
            pass
        try:
            import hyprctl  # локальный импорт — тот же каталог
            mons = hyprctl.monitors()
            heads = [str(m.get("name")) for m in mons
                     if str(m.get("name", "")).startswith("HEADLESS")]
            ours = [m for m in mons if str(m.get("name")) == self.output_name]
            if ours:
                m = ours[0]
                lines.append(
                    f"  вывод {self.output_name}: есть, "
                    f"{m.get('width')}x{m.get('height')}, "
                    f"disabled={m.get('disabled')}"
                )
            else:
                lines.append(
                    f"  вывод {self.output_name}: ОТСУТСТВУЕТ в hyprctl "
                    f"monitors (headless всего: {', '.join(heads) or 'нет'}) — "
                    f"запустите ./run.sh reset и перезапустите сервер"
                )
        except Exception as exc2:  # noqa: BLE001
            lines.append(f"  hyprctl monitors: не удалось ({exc2})")
        log.error("\n".join(lines))

    async def close(self) -> None:
        self._closed = True


def make_backend(config: ScreenConfig, output_name: str) -> GrimCapture:
    """Фабрика захвата (grim). Оставлена для совместимости с server.py."""
    return GrimCapture(config, output_name)
