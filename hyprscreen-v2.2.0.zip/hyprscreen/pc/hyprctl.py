"""Маленькая обёртка над командой ``hyprctl`` для Hyprland.

Hyprland открывает IPC-сокет через ``hyprctl``. Большинство команд
принимает флаг ``-j`` для вывода JSON — его гораздо проще парсить, чем
человекочитаемую форму.

Этот модуль намеренно stateless; это тонкая, строго-типизированная обёртка,
чтобы остальная кодовая база не повторяла ``subprocess.run`` бойлерплейт.

Все вызовы идут с ``timeout=10`` — если hyprctl зависнет, тред не
заблокируется навсегда (а с ``asyncio.to_thread`` это была бы утечка треда).

Ссылки
------
* ``man hyprctl`` (пакет CachyOS / Arch ``hyprland``)
* https://wiki.hyprland.org/Configuring/Using-hyprctl/
"""

from __future__ import annotations

import json
import logging
import re
import shutil
import subprocess
from typing import Any, Iterable, Optional, Sequence

log = logging.getLogger(__name__)

# Hyprland 0.55 перевёл конфиг на Lua: классический «dispatch name args»
# теперь разворачивается в невалидный Lua-код, а keyword/unkeyword исчезли
# из IPC (0.56+). Все пути ниже делятся на «lua» (>= 0.55) и «classic».
_LUA_MIN_VERSION = (0, 55)

_version_cache: Optional[tuple[int, int]] = None
_version_loaded = False


class HyprctlError(RuntimeError):
    """Поднимается, когда ``hyprctl`` завершается с non-zero или не найден."""


def _find_binary() -> str:
    """Вернуть абсолютный путь к ``hyprctl`` или поднять исключение."""
    path = shutil.which("hyprctl")
    if path is None:
        raise HyprctlError(
            "hyprctl не найден в PATH. На CachyOS установите: "
            "sudo pacman -S hyprland"
        )
    return path


def hyprland_version() -> Optional[tuple[int, int]]:
    """Версия Hyprland как ``(major, minor)`` или None, если не распознали.

    Результат кешируется: ``hyprctl version`` не меняется в рамках сессии.
    """
    global _version_cache, _version_loaded
    if _version_loaded:
        return _version_cache
    _version_loaded = True
    try:
        raw = run_raw(["version"], check=False)
    except HyprctlError:
        return None
    match = re.search(r"(\d+)\.(\d+)", raw)
    if match:
        _version_cache = (int(match.group(1)), int(match.group(2)))
    return _version_cache


def uses_lua_config() -> bool:
    """True для Hyprland >= 0.55 (Lua-конфиг, hl.dsp.* вместо dispatch)."""
    ver = hyprland_version()
    return ver is not None and ver >= _LUA_MIN_VERSION


def run_raw(args: Sequence[str], *, json_output: bool = False, check: bool = True) -> str:
    """Вызвать ``hyprctl <args...>`` и вернуть stdout как строку.

    Параметры
    ---------
    args:
        Аргументы после ``hyprctl`` (например ``["monitors"]``).
    json_output:
        Если True — добавить ``-j``, чтобы hyprctl выдал JSON.
    check:
        Если True — поднять :class:`HyprctlError` на non-zero exit.

    Возвращает
    ----------
    str
        Декодированный stdout (trailing whitespace обрезан).
    """
    binary = _find_binary()
    cmd: list[str] = [binary]
    if json_output:
        cmd.append("-j")
    cmd.extend(args)
    log.debug("hyprctl запуск: %s", " ".join(cmd))
    try:
        proc = subprocess.run(
            cmd,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=10,
        )
    except subprocess.TimeoutExpired as exc:
        msg = f"hyprctl {' '.join(args)} таймаут ({exc.timeout}s)"
        if check:
            raise HyprctlError(msg) from exc
        log.warning(msg)
        return ""
    if proc.returncode != 0:
        msg = (
            f"hyprctl {' '.join(args)} упал (exit {proc.returncode}): "
            f"{proc.stderr.strip() or proc.stdout.strip()}"
        )
        if check:
            raise HyprctlError(msg)
        log.warning(msg)
    return proc.stdout.strip()


def run_json(args: Sequence[str], *, check: bool = True) -> Any:
    """Вызвать ``hyprctl -j <args...>`` и разобрать JSON-вывод.

    Возвращает декодированный JSON-объект (обычно list или dict).
    """
    raw = run_raw(args, json_output=True, check=check)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise HyprctlError(f"hyprctl вернул некорректный JSON: {exc}: {raw!r}") from exc


def keyword(option: str, value: str) -> None:
    """Установить keyword конфига Hyprland в рантайме: ``hyprctl keyword <opt> <val>``.

    Пример: ``keyword("monitor", "HEADLESS-1,1920x1080@60,2560x0,1")``
    """
    run_raw(["keyword", option, value])


def unkeyword(option: str) -> str:
    """Снять runtime-keyword(ы): ``hyprctl unkeyword <opt>``.

    HyprScreen ставит правила воркспейсов через ``keyword workspace``;
    эта команда снимает их все (правила из hyprland.conf пользователя
    не затрагиваются). Возвращает ответ hyprctl.
    """
    return run_raw(["unkeyword", option], check=False)


def dispatch(rule: str, *args: str) -> None:
    """Вызвать ``hyprctl dispatch <rule> [args...]`` (ТОЛЬКО Hyprland <= 0.54).

    Пример: ``dispatch("output", "remove", "HEADLESS-1")``

    На Hyprland >= 0.55 этот вызов ломается композитором (аргументы
    вставляются в Lua-код как есть). Для диспетчеров используйте хелперы
    ниже — :func:`focus_workspace`, :func:`focus_monitor` и т. д., — они
    сами выбирают синтаксис по версии. ``dispatch()`` остаётся для
    вызовов без аргументов и низкоуровневых нужд.
    """
    run_raw(["dispatch", rule, *args])


# ---- Lua-эра (Hyprland >= 0.55) ---------------------------------------

def eval_lua(lua_expr: str) -> str:
    """``hyprctl eval '<lua>'`` — выполнить Lua-выражение (0.55+).

    Возвращает ответ hyprctl. Отличие от :func:`run_raw`: композитор
    отвечает ``ok`` и на успех, и строкой ошибки в теле ответа, поэтому
    проверяем содержимое, а не только exit-код.
    """
    reply = run_raw(["eval", lua_expr])
    if not reply.startswith("ok"):
        raise HyprctlError(f"hyprctl eval {lua_expr[:60]}…: {reply[:200]}")
    return reply


def dispatch_lua_expr(lua_expr: str) -> str:
    """``hyprctl dispatch 'hl.dsp.…(…)'`` — Lua-диспетчер (0.55+)."""
    reply = run_raw(["dispatch", lua_expr])
    low = reply.lower()
    if "error" in low or "expected" in low or "unknown" in low:
        raise HyprctlError(f"dispatch lua {lua_expr[:60]}…: {reply[:200]}")
    return reply


def focus_workspace(ws: str | int) -> None:
    """Сделать воркспейс ``ws`` активным (на своём мониторе по правилу).

    0.55+: ``hl.dsp.focus({ workspace = ... })``; старее: ``dispatch workspace N``.
    """
    if uses_lua_config():
        try:
            dispatch_lua_expr(f'hl.dsp.focus({{ workspace = "{ws}" }})')
            return
        except HyprctlError as exc:
            log.debug("lua focus workspace %s не удался, пробую классику: %s", ws, exc)
    run_raw(["dispatch", "workspace", str(ws)])


def focus_monitor(name: str) -> None:
    """Перевести фокус на монитор ``name`` (0.55+: ``hl.dsp.focus({ monitor = ... })``)."""
    if uses_lua_config():
        try:
            dispatch_lua_expr(f'hl.dsp.focus({{ monitor = "{_lua_escape(name)}" }})')
            return
        except HyprctlError as exc:
            log.debug("lua focusmonitor %s не удался, пробую классику: %s", name, exc)
    run_raw(["dispatch", "focusmonitor", name])


def move_cursor_to_monitor(name: str) -> None:
    """Перенести курсор на монитор ``name`` (best-effort).

    0.55+: прямого аналога ``movecursortomonitor`` нет — двигаем курсор
    в центр монитора через ``hl.dsp.cursor.move`` по координатам из
    ``hyprctl monitors``.
    """
    if uses_lua_config():
        try:
            target = next(
                (m for m in monitors() if str(m.get("name", "")) == name), None
            )
            if target is not None:
                cx = int(target.get("x", 0)) + int(target.get("width", 0)) // 2
                cy = int(target.get("y", 0)) + int(target.get("height", 0)) // 2
                dispatch_lua_expr(f"hl.dsp.cursor.move({{ x = {cx}, y = {cy} }})")
                return
        except (HyprctlError, TypeError, ValueError) as exc:
            log.debug("lua cursor->%s не удался, пробую классику: %s", name, exc)
    run_raw(["dispatch", "movecursortomonitor", name], check=False)


def move_window_to_monitor(name: str) -> None:
    """Перенести активное окно на монитор ``name`` (win+shift+N)."""
    if uses_lua_config():
        try:
            dispatch_lua_expr(f'hl.dsp.window.move({{ monitor = "{_lua_escape(name)}" }})')
            return
        except HyprctlError as exc:
            log.debug("lua movewindow->%s не удался, пробую классику: %s", name, exc)
    run_raw(["dispatch", "movewindow", f"mon:{name}"])


def set_workspace_rule(ws: str | int, monitor: str, default: bool = True) -> None:
    """Правило «воркспейс живёт на мониторе» для текущей эры Hyprland.

    0.55+: ``hl.workspace_rule({ workspace = ..., monitor = ..., default = true })``
    (replaceOrAdd — повторный вызов ЗАМЕНЯЕТ правило, накопления нет);
    старее: ``hyprctl keyword workspace "N,monitor:M,default:true"``.
    """
    if uses_lua_config():
        eval_lua(
            f'hl.workspace_rule({{ workspace = "{_lua_escape(str(ws))}", '
            f'monitor = "{_lua_escape(monitor)}", default = {"true" if default else "false"} }})'
        )
        return
    value = f"{ws},monitor:{monitor}"
    if default:
        value += ",default:true"
    run_raw(["keyword", "workspace", value])


def set_monitor_config(name: str, mode: str, x: int, y: int, scale: float = 1.0) -> None:
    """Режим/позиция/масштаб вывода для текущей эры Hyprland.

    0.55+: ``hl.monitor({ output = ..., mode = ..., position = "XxY", scale = S })``
    (правило для вывода ЗАМЕНЯЕТСЯ, применяется сразу —
    ``REFRESH_MONITOR_STATES``); старее: ``hyprctl keyword monitor ...``.
    """
    scale_str = str(int(scale)) if float(scale).is_integer() else str(scale)
    if uses_lua_config():
        eval_lua(
            f'hl.monitor({{ output = "{_lua_escape(name)}", mode = "{mode}", '
            f'position = "{x}x{y}", scale = {scale_str} }})'
        )
        return
    run_raw(["keyword", "monitor", f"{name},{mode},{x}x{y},{scale_str}"])


def remove_workspace_rules(
    keep_monitors: Optional[Iterable[str]] = None,
) -> str | None:
    """Снять runtime-правила воркспейсов (best-effort). Возвращает ответ или None.

    Hyprland <= 0.54: ``hyprctl unkeyword workspace`` — снимает все
    keyword-правила.

    0.55+: ``unkeyword`` НЕ существует (в IPC его больше нет — отсюда
    «unknown request» в логах). Вместо снятия перечитываем
    ``hyprctl -j workspacerules`` и переуказываем правила, целящиеся в
    headless-выводы, на первый физический монитор: ``hl.workspace_rule``
    для того же воркспейса заменяет правило (replaceOrAdd), накопления
    нет. Именно накопленные правила «воркспейс → HEADLESS-N» давали
    фантомные столы на телефоне при повторных запусках.

    ``keep_monitors`` — правила для этих мониторов НЕ трогаются.
    Используется при старте: правила, только что закреплённые за
    будущими headless-выводами (pin до ``output create``), нельзя
    переуказывать на физмонитор — иначе пропадает весь смысл закрепления.
    """
    keep = {str(m) for m in keep_monitors} if keep_monitors is not None else set()

    if not uses_lua_config():
        if keep:
            # Классический unkeyword снимает ВСЕ правила разом и выборочность
            # не поддерживает. Вызывающий код сам решает: либо правил с keep
            # ещё нет (закрепление позже), либо он готов к полному снятию.
            log.debug("unkeyword не поддерживает keep_monitors — снимаю все")
        return run_raw(["unkeyword", "workspace"], check=False)

    real = real_monitors()[:1]
    try:
        rules = run_json(["workspacerules"], check=False)
    except HyprctlError:
        rules = None
    if not isinstance(rules, list):
        rules = []
    repointed = 0
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        ws = str(rule.get("workspaceString", "") or "")
        mon = str(rule.get("monitor", "") or "")
        if not ws or not mon:
            continue
        targets_headless = mon.startswith("HEADLESS") or ("x" in mon and "@" in mon)
        if not targets_headless:
            continue
        if mon in keep:
            continue
        if not real:
            log.warning(
                "правило воркспейса %s → %s осталось: нет физических мониторов",
                ws, mon,
            )
            continue
        try:
            eval_lua(
                f'hl.workspace_rule({{ workspace = "{_lua_escape(ws)}", '
                f'monitor = "{_lua_escape(real[0])}" }})'
            )
            repointed += 1
        except HyprctlError as exc:
            log.warning("не удалось переуказать правило %s (%s): %s", ws, mon, exc)
    if repointed:
        log.info(
            "правила %d воркспейсов переуказаны с headless на %s "
            "(unkeyword в Hyprland 0.55+ отсутствует)", repointed, real[0],
        )
    else:
        log.info("headless-правил воркспейсов не найдено — чисто")
    return None


def monitors() -> list[dict[str, Any]]:
    """Вернуть текущий список мониторов как разобранный JSON.

    Каждая запись имеет поля ``name``, ``x``, ``y``, ``width``, ``height``,
    ``transform``, ``scale``, ``refreshRate``. См. ``hyprctl monitors -j``.
    """
    data = run_json(["monitors"])
    if data is None:
        return []
    if not isinstance(data, list):
        raise HyprctlError(f"неожиданный вывод monitors: {data!r}")
    return data


def output_create_headless() -> str:
    """Создать headless (виртуальный) вывод: ``hyprctl output create headless``.

    БЕЗ аргумента режима! В Hyprland 0.55 второй аргумент ``output create`` —
    это ИМЯ вывода, а не режим. Передача ``1920x1080@60`` создаёт вывод с
    именем ``1920x1080@60`` вместо ``HEADLESS-N``. Режим задаётся отдельной
    командой ``keyword monitor`` после создания.
    """
    return run_raw(["output", "create", "headless"])


def output_remove(name: str) -> None:
    """Удалить виртуальный вывод: ``hyprctl output remove <name>``."""
    run_raw(["output", "remove", name])


def list_workspaces() -> list[dict[str, Any]]:
    """Список воркспейсов (``hyprctl -j workspaces``)."""
    data = run_json(["workspaces"])
    if data is None:
        return []
    if not isinstance(data, list):
        raise HyprctlError(f"неожиданный вывод workspaces: {data!r}")
    return data


def dispatch_lua(lua_expr: str) -> str:
    """Вызвать ``hyprctl dispatch '<lua_expr>'`` (Hyprland 0.55+ Lua-синтаксис)."""
    return run_raw(["dispatch", lua_expr])


def _lua_escape(s: str) -> str:
    """Экранировать строку для Lua-литерала."""
    return s.replace("\\", "\\\\").replace('"', '\\"')


def move_workspace_to_monitor(workspace: str | int, monitor: str) -> None:
    """Перенести воркспейс на монитор.

    0.55+: ``hl.dsp.workspace.move({ workspace, monitor })``;
    старее: ``dispatch moveworkspacetomonitor <ws> <monitor>``.
    """
    ws = _lua_escape(str(workspace))
    mon = _lua_escape(monitor)
    if uses_lua_config():
        try:
            reply = dispatch_lua(
                f'hl.dsp.workspace.move({{ workspace = "{ws}", monitor = "{mon}" }})'
            )
            if reply and ("error" in reply.lower() or "not found" in reply.lower()):
                raise HyprctlError(f"workspace.move: {reply}")
            return
        except HyprctlError as exc:
            log.debug(
                "lua workspace.move(%s→%s) не удался, пробую классику: %s",
                workspace, monitor, exc,
            )
    run_raw(["dispatch", "moveworkspacetomonitor", str(workspace), monitor])


def move_workspace_to_monitor_checked(workspace: str | int, monitor: str) -> str:
    """Как move_workspace_to_monitor, но возвращает ответ (не валидирует)."""
    ws = _lua_escape(str(workspace))
    mon = _lua_escape(monitor)
    if uses_lua_config():
        return dispatch_lua(
            f'hl.dsp.workspace.move({{ workspace = "{ws}", monitor = "{mon}" }})'
        )
    return run_raw(
        ["dispatch", "moveworkspacetomonitor", str(workspace), monitor], check=False
    )


def find_headless_monitors() -> list[str]:
    """Имена всех HEADLESS-* мониторов."""
    try:
        return [
            str(m.get("name", ""))
            for m in monitors()
            if str(m.get("name", "")).startswith("HEADLESS")
        ]
    except HyprctlError:
        return []


def _evacuate_workspaces_from_monitor(monitor: str, target: str | None = None) -> None:
    """Перенести все воркспейсы с monitor на target (best-effort).

    Правила воркспейсов НЕ регистрируются (старая версия делала здесь
    workspace_rule — из-за этого правила накапливались).
    """
    if target is None:
        target = (real_monitors()[:1] or [None])[0]
        if target is None:
            try:
                mons = monitors()
            except HyprctlError:
                mons = []
            target = next(
                (str(m.get("name", "")) for m in mons
                 if str(m.get("name", "")).startswith("HEADLESS")
                 and str(m.get("name", "")) != monitor),
                None,
            )
    if target is None:
        return
    try:
        workspaces = list_workspaces()
    except HyprctlError as exc:
        log.warning("эвакуация: не удалось получить workspaces: %s", exc)
        return
    for w in workspaces:
        if str(w.get("monitor", "")) != monitor:
            continue
        ws_id = w.get("id", w.get("name", ""))
        if ws_id == "" or ws_id is None:
            continue
        try:
            log.info("эвакуация воркспейса %s с %s → %s", ws_id, monitor, target)
            move_workspace_to_monitor(ws_id, target)
        except HyprctlError as exc:
            log.warning("эвакуация: %s: %s", ws_id, exc)


def cleanup_phantom_outputs(
    owned_names: Optional[Iterable[str]] = None,
) -> list[str]:
    """Удалить фантомные HEADLESS-* выводы. Возвращает список удалённых.

    Если передан ``owned_names`` (имена выводов из state.json прошлых
    запусков) — удаляются ТОЛЬКО они. Это защищает чужие headless-выводы
    (например, собственный wayvnc-стек пользователя) от сноса при старте/kill.
    Агрессивное поведение по всем HEADLESS-*/mode-подобным остаётся только
    для ``reset`` (вызов без аргумента).
    """
    removed: list[str] = []
    try:
        mons = monitors()
    except HyprctlError as exc:
        log.warning("cleanup: не удалось получить monitors: %s", exc)
        return removed

    if owned_names is not None:
        owned = {str(n) for n in owned_names if str(n)}
        present_owned = [str(m.get("name", "")) for m in mons if str(m.get("name", "")) in owned]
        fallback = next(
            (str(m.get("name", "")) for m in mons if str(m.get("name", "")) not in owned),
            None,
        )
        for name in present_owned:
            _evacuate_workspaces_from_monitor(name, fallback)
            try:
                log.info("cleanup: удаляем вывод прошлых запусков %s", name)
                output_remove(name)
                removed.append(name)
            except HyprctlError as exc:
                log.warning("cleanup: не удалось удалить %s: %s", name, exc)
        if removed:
            log.info("cleanup: удалено своих выводов: %d %s", len(removed), removed)
        return removed

    real_monitors = [
        str(m.get("name", "")) for m in mons
        if not str(m.get("name", "")).startswith("HEADLESS")
        and not ("x" in str(m.get("name", "")) and "@" in str(m.get("name", "")))
    ]
    fallback = real_monitors[0] if real_monitors else None
    for m in mons:
        name = str(m.get("name", ""))
        if not name:
            continue
        is_headless = name.startswith("HEADLESS")
        is_mode_like = "x" in name and "@" in name
        if not (is_headless or is_mode_like):
            continue
        target = fallback
        if target is None:
            target = next(
                (str(x.get("name", "")) for x in mons
                 if str(x.get("name", "")).startswith("HEADLESS")
                 and str(x.get("name", "")) != name),
                None,
            )
        _evacuate_workspaces_from_monitor(name, target)
        try:
            log.info("cleanup: удаляем фантомный вывод %s", name)
            output_remove(name)
            removed.append(name)
        except HyprctlError as exc:
            log.warning("cleanup: не удалось удалить %s: %s", name, exc)
    if removed:
        log.info("cleanup: удалено %d фантомных выводов: %s", len(removed), removed)
    return removed


def real_monitors() -> list[str]:
    """Имена физических мониторов (всё, что не HEADLESS-* и не режим-подобное)."""
    names: list[str] = []
    try:
        mons = monitors()
    except HyprctlError:
        return names
    for m in mons:
        name = str(m.get("name", ""))
        if not name or name.startswith("HEADLESS"):
            continue
        if "x" in name and "@" in name:  # выводы, созданные со случайным именем-режимом
            continue
        names.append(name)
    return names


def diagnose() -> None:
    """Диагностика IPC-протокола Hyprland (мониторы определяются динамически)."""
    import os
    print("=== Диагностика IPC Hyprland ===")
    sign = os.environ.get("HYPRLAND_INSTANCE_SIGNATURE", "")
    print(f"  HYPRLAND_INSTANCE_SIGNATURE = {sign!r}")
    try:
        ver = run_raw(["version"], check=False)
        print(f"  hyprctl version: {ver[:120]}")
    except HyprctlError as e:
        print(f"  hyprctl version: ОШИБКА: {e}")
    ver_tuple = hyprland_version()
    lua_mode = uses_lua_config()
    print(
        f"  эра конфига: {'Lua (0.55+)' if lua_mode else 'hyprlang (классика)'}"
        f"{f' (распознано {ver_tuple[0]}.{ver_tuple[1]})' if ver_tuple else ' (версия не распознана)'}"
    )
    mon_names: list[str] = []
    try:
        mons = monitors()
        mon_names = [str(m.get("name", "")) for m in mons]
        print(f"  мониторы: {', '.join(mon_names) if mon_names else '(нет)'}")
        print(f"  физические: {', '.join(real_monitors()) or '(нет)'}")
        headless = [n for n in mon_names if n.startswith("HEADLESS")]
        print(f"  headless: {', '.join(headless) if headless else '(нет)'}")
    except HyprctlError as e:
        print(f"  hyprctl monitors: ОШИБКА: {e}")
    try:
        raw = run_raw(["-j", "workspaces"])
        print(f"  hyprctl -j workspaces: OK ({len(raw)} байт)")
    except HyprctlError as e:
        print(f"  hyprctl -j workspaces: ОШИБКА: {e}")
    try:
        raw = unkeyword("__hyprscreen_probe__")
        print(f"  hyprctl unkeyword: OK ({raw[:60]!r})")
    except HyprctlError as e:
        print(f"  hyprctl unkeyword: ОШИБКА: {e}")
    if lua_mode:
        try:
            raw = eval_lua("hl.monitor({ output = \"__hyprscreen_probe__\", disabled = true })")
            print(f"  hyprctl eval hl.monitor: OK ({raw[:60]!r})")
        except HyprctlError as e:
            print(f"  hyprctl eval hl.monitor: ОШИБКА: {e}")
    print()
    print("--- dispatch ---")
    target = real_monitors()[:1]
    move_target = target[0] if target else (mon_names[0] if mon_names else None)
    probes = [('hl.dsp.focus({ workspace = "1" })', "focus workspace 1")]
    if move_target:
        probes.append(
            (
                f'hl.dsp.workspace.move({{ workspace = "1", monitor = "{move_target}" }})',
                f"workspace.move 1→{move_target}",
            )
        )
    for expr, desc in probes:
        try:
            raw = run_raw(["dispatch", expr], check=False)
            print(f"  [{desc:35s}] → {raw[:80]!r}")
        except HyprctlError as e:
            print(f"  [{desc:35s}] → ОШИБКА: {e}")
    if not lua_mode:
        try:
            raw = run_raw(["dispatch", "workspace", "1"], check=False)
            print(f"  [{'classic workspace 1':35s}] → {raw[:80]!r}")
        except HyprctlError as e:
            print(f"  [{'classic workspace 1':35s}] → ОШИБКА: {e}")
