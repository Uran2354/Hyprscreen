#!/usr/bin/env bash
# Запускатор HyprScreen 2.2.0.
#
# Без аргументов:  ./run.sh
#   → GUI (customtkinter); если он не установлен — интерактивное меню.
#
# Подкоманды:
#   ./run.sh gui          — графический интерфейс (customtkinter)
#   ./run.sh interactive  — консольное меню
#   ./run.sh workspace 6  — перепривязать воркспейс 6 к телефону (сервер должен работать)
#   ./run.sh list | reset | diagnose | grimtest | kill
#   ./run.sh run --workspace 6 --fps-mode auto   — прямой запуск сервера

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
cd "$SCRIPT_DIR"

# Если PYTHON не задан — python3, затем python (в части дистрибутивов
# бинарника `python` нет, и запуск падал с «command not found» вместо внятного
# сообщения).
PYTHON="${PYTHON:-}"
if [[ -z "$PYTHON" ]]; then
    if command -v python3 >/dev/null 2>&1; then
        PYTHON="python3"
    else
        PYTHON="python"
    fi
fi
VENV_DIR="${VENV_DIR:-$SCRIPT_DIR/.venv}"
if [[ -x "$VENV_DIR/bin/python" ]]; then
    PYTHON="$VENV_DIR/bin/python"
fi

export PYTHONPATH="$SCRIPT_DIR${PYTHONPATH:+:$PYTHONPATH}"

# Проверка целостности ЛОКАЛЬНЫХ модулей проекта до запуска Python.
# settings_store.py и прочие *.py — файлы ПРОЕКТА: их НЕТ в requirements.txt
# и pip их не ставит. Если копия неполная (файл не докопировался), python
# падает с невнятным «ModuleNotFoundError: No module named 'settings_store'»
# на 39-й строке main.py — падаем сразу, с точным списком и лечением.
missing_files=()
for mod in config hyprctl settings_store state_file wallpaper \
           capture logging_setup server virtual_output workspaces \
           discovery input; do
    [[ -f "$SCRIPT_DIR/$mod.py" ]] || missing_files+=("$mod.py")
done
if ((${#missing_files[@]})); then
    echo "ОШИБКА: копия HyprScreen неполная — в pc/ нет файлов:"
    printf '    pc/%s\n' "${missing_files[@]}"
    echo "Это ЛОКАЛЬНЫЕ модули проекта (не pip-пакеты, в requirements.txt их нет)."
    echo "Лечение:"
    echo "  1) скопируйте перечисленные файлы из полной поставки 2.2.0 в pc/; ИЛИ"
    echo "  2) заново распакуйте полный архив hyprscreen-v2.2.0.zip и запустите"
    echo "     из него ./install.sh."
    exit 1
fi

cmd="${1:-}"
case "$cmd" in
    gui)
        exec "$PYTHON" gui.py
        ;;
    menu)
        # `hyprscreen menu` документирован (README/бинды), но сабкоманды
        # menu в main.py нет — раньше падало с «invalid choice». Мапим на меню.
        exec "$PYTHON" main.py interactive
        ;;
    "")
        if "$PYTHON" -c 'import customtkinter' >/dev/null 2>&1; then
            exec "$PYTHON" gui.py
        fi
        echo "customtkinter не установлен — открываю консольное меню."
        echo "  GUI:  pip install customtkinter   (или ./setup.sh)"
        exec "$PYTHON" main.py interactive
        ;;
    *)
        exec "$PYTHON" main.py "$@"
        ;;
esac
