package com.example.hyprscreen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.View

/**
 * Custom View, рисующий последний JPEG-кадр, полученный от PC.
 *
 * Отрисовка — «fit-center»: исходный bitmap масштабируется равномерно (с
 * сохранением соотношения сторон) и центрируется внутри View, оставляя
 * letterbox-полосы там, где соотношения сторон не совпадают. Та же самая
 * [drawMatrix] инвертируется и даёт [viewToSource], который [TouchHandler]
 * использует для перевода координат пальца обратно в пиксели источника.
 *
 * Кадры публикуются [ScreenClient] через [updateBitmap], который атомарно
 * меняет ссылку [currentBitmap] и зовёт [invalidate]. Отрисовка читает
 * последний bitmap без дальнейшей синхронизации — `@Volatile` даёт нам
 * безопасную публикацию.
 *
 * [StatusOverlay] рисуется поверх в левом-нижнем углу, поэтому активности
 * не нужен отдельный overlay-View.
 *
 * Размер источника (`srcWidth`/`srcHeight`) устанавливается из hello-полей
 * `width`/`height` [ServerInfo] (см. [MainActivity.onHello]). Это устраняет
 * баг аудита #1: при любом non-1080p разрешении инверсная матрица корректна.
 */
class ScreenView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    @Volatile private var currentBitmap: Bitmap? = null

    private val srcRect = RectF()
    private val dstRect = RectF()
    private val drawMatrix = Matrix()
    private val inverseMatrix = Matrix()

    private var srcWidth = 1920
    private var srcHeight = 1080
    private var matrixDirty = true

    private val bgPaint = Paint().apply { color = Color.BLACK }
    private val bmpPaint = Paint().apply {
        isFilterBitmap = true
        isDither = true
    }

    // 2.0.0 (фикс «чёрного экрана без объяснений»): если соединение живо,
    // но кадры не приходят дольше [NO_SIGNAL_AFTER_MS], рисуем плашку
    // «НЕТ СИГНАЛА» вместо немого чёрного экрана.
    // 2.1.0: стиль единой темы ([UiTheme]) — тёмная карточка с красной
    // рамкой вместо плоской тёмно-красной заливки.
    private val warnPaint = Paint().apply {
        color = 0xE6141414.toInt()          // #141414 на 90%
        isAntiAlias = true
    }
    private val warnStrokePaint = Paint().apply {
        color = 0xFF7F1D1D.toInt()          // рамка red-800
        style = Paint.Style.STROKE
        strokeWidth = 4f
        isAntiAlias = true
    }
    private val warnTextPaint = Paint().apply {
        color = 0xFFF87171.toInt()          // red-400 — как RED на док-странице
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
        textSize = 42f
    }
    private val warnSubTextPaint = Paint().apply {
        color = 0xFFA3A3A3.toInt()          // neutral-400
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
        textSize = 26f
    }
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile private var connected: Boolean = false
    @Volatile private var lastFrameAtMs: Long = 0
    private val noSignalAfterMs: Long = 5000

    private val stalenessTicker = object : Runnable {
        override fun run() {
            if (!connected || !isAttachedToWindow) return  // 2.1.2: не перезапускаемся вечно
            invalidate()
            mainHandler.postDelayed(this, 1000)
        }
    }

    private val overlay = StatusOverlay()

    /** Установить размер источника из hello-сообщения. */
    fun setSourceSize(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        if (w == srcWidth && h == srcHeight) return
        srcWidth = w
        srcHeight = h
        matrixDirty = true
        invalidate()
    }

    /**
     * Атомарно подменить последний декодированный bitmap и попросить перерисовку.
     *
     * 2.1.7: размер источника берётся из САМОГО битмапа. Раньше матрица
     * строилась только по hello (настроенный режим монитора), а кадр приходил
     * меньше (grim -s scale) — картинка рисовалась в 0.75² ≈ 56% экрана
     * («на пол-экрана»). Теперь отрисовка и viewToSource всегда точны, даже
     * если hello не совпал с фактическим кадром.
     */
    fun updateBitmap(bitmap: Bitmap) {
        val bw = bitmap.width
        val bh = bitmap.height
        if (bw > 0 && bh > 0 && (bw != srcWidth || bh != srcHeight)) {
            srcWidth = bw
            srcHeight = bh
            matrixDirty = true
        }
        currentBitmap = bitmap
        lastFrameAtMs = System.currentTimeMillis()
        invalidate()
    }

    /** Соединение установлено/разорвано (2.0.0). */
    fun setConnected(value: Boolean) {
        connected = value
        if (value) {
            if (lastFrameAtMs == 0L) lastFrameAtMs = System.currentTimeMillis()
            mainHandler.removeCallbacks(stalenessTicker)
            mainHandler.post(stalenessTicker)
        } else {
            mainHandler.removeCallbacks(stalenessTicker)
        }
        invalidate()
    }

    private fun isSignalStale(): Boolean {
        if (!connected) return false
        if (lastFrameAtMs == 0L) return true
        return System.currentTimeMillis() - lastFrameAtMs > noSignalAfterMs
    }

    /** Обновить текст оверлея FPS/latency в углу. */
    fun setOverlayText(text: String) {
        overlay.setText(text)
        invalidate()
    }

    /** Показать или скрыть оверлей. */
    fun setOverlayVisible(visible: Boolean) {
        overlay.setVisible(visible)
        invalidate()
    }

    /**
     * Перевести точку из координат View в пиксели источника.
     * Возвращает массив из двух float: [x, y] в пикселях источника.
     */
    fun viewToSource(x: Float, y: Float): FloatArray {
        ensureMatrix()
        val pts = floatArrayOf(x, y)
        inverseMatrix.mapPoints(pts)
        // Ограничиваем границами источника, чтобы касания вне letterbox
        // оставались корректными.
        pts[0] = pts[0].coerceIn(0f, srcWidth.toFloat())
        pts[1] = pts[1].coerceIn(0f, srcHeight.toFloat())
        return pts
    }

    private fun ensureMatrix() {
        if (!matrixDirty) return
        if (width == 0 || height == 0) return
        srcRect.set(0f, 0f, srcWidth.toFloat(), srcHeight.toFloat())
        dstRect.set(0f, 0f, width.toFloat(), height.toFloat())
        drawMatrix.setRectToRect(srcRect, dstRect, Matrix.ScaleToFit.CENTER)
        drawMatrix.invert(inverseMatrix)
        matrixDirty = false
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        matrixDirty = true
    }

    /**
     * 2.1.1: кастомный View, на котором висит setOnTouchListener (касания →
     * ввод ПК), обязан переопределять performClick — иначе lint/accessibility
     * ругается «does not override performClick». Реальную обработку жестов
     * делает TouchHandler в onTouch; здесь только корректный «клик».
     */
    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        val bmp = currentBitmap
        if (bmp != null) {
            ensureMatrix()
            canvas.drawBitmap(bmp, drawMatrix, bmpPaint)
        }
        if (isSignalStale()) {
            // Кадры не идут: «мёртвый чёрный» больше не молчит (2.0.0).
            val w = width.toFloat()
            val h = height.toFloat()
            val boxW = w * 0.86f
            val boxH = h * 0.22f
            val left = (w - boxW) / 2f
            val top = (h - boxH) / 2f
            canvas.drawRoundRect(left, top, left + boxW, top + boxH, 24f, 24f, warnPaint)
            canvas.drawRoundRect(left, top, left + boxW, top + boxH, 24f, 24f, warnStrokePaint)
            warnTextPaint.textSize = h * 0.045f
            warnSubTextPaint.textSize = h * 0.028f
            val cy = top + boxH / 2f
            canvas.drawText("НЕТ СИГНАЛА", w / 2f, cy - warnSubTextPaint.textSize, warnTextPaint)
            canvas.drawText(
                "кадры от ПК не приходят — на ПК: ./run.sh grimtest",
                w / 2f, cy + warnTextPaint.textSize, warnSubTextPaint
            )
        }
        overlay.draw(canvas, width, height)
    }

    /** 2.1.2: возобновить тикер после re-attach (иначе «НЕТ СИГНАЛА» не обновится). */
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (connected) {
            mainHandler.removeCallbacks(stalenessTicker)
            mainHandler.post(stalenessTicker)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        // 2.1.2: снимаем тикер — иначе он вечно живёт в main-handler,
        // удерживая View → Activity (утечка при фоновом стриме), и будит
        // главный loop каждую секунду.
        mainHandler.removeCallbacks(stalenessTicker)
        currentBitmap = null
    }
}
