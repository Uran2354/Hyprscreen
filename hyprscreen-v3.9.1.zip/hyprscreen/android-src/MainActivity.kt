package com.example.hyprscreen

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.os.IBinder
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

/**
 * Полноэкранный режим стриминга. Биндится к [ScreenStreamService], чтобы
 * получить доступ к [ScreenClient], и рисует служебную пилюлю
 * («подключение…»).
 *
 * Экран ПОДКЛЮЧЕНИЯ вертикальный (портрет), а ЭКРАН ПОКАЗА можно СВОБОДНО
 * вращать (SCREEN_ORIENTATION_FULL_SENSOR, с 3.8.0): повернули телефон
 * горизонтально — ландшафтный кадр ПК разворачивается на весь экран, в
 * вертикальном положении он вписывается fit-center с полями. Код-сторонняя
 * установка перекрывает манифест, поэтому работает и со старым шаблоном
 * §4, где MainActivity зафиксирована portrait (SETUP.md §4/§7.9).
 * configChanges в манифесте §4 не даёт активности пересоздаться при
 * повороте — MJPEG-поток не прерывается ([ScreenView] сам пересчитывает
 * fit-center по новым размерам).
 *
 * Дерево View строится целиком в коде в [buildUi] — никакого XML-лейаута.
 *
 * UI сознательно минимален (решение пользователя, 3.3.0):
 *   - бургер-меню «☰» из 3.2.0 УДАЛЕН;
 *   - в правом верхнем углу — ЕДИНСТВЕННАЯ полупрозрачная круглая кнопка
 *     питания ([PowerButtonView], значок рисуется Canvas-ом — глиф «⏻»
 *     U+23FB отсутствует в шрифтах многих телефонов и показывался
 *     квадратиком с крестом): завершить сессию (disconnect + выход);
 *   - ОДНОТАП по видео поднимает/прячет мягкую клавиатуру (ввод на PC
 *     через wtype, см. [KeyboardHelper]);
 *   - тач-ввода указателя НЕТ (телефон — НЕ тачпад), оверлей-кнопок НЕТ:
 *     экран телефона чистый.
 *
 * Скрытый [WedgeEditText] владеет InputConnection мягкой клавиатуры;
 * [ScreenView] хостит и кадры, и оверлей статуса (см. [StatusOverlay]).
 *
 * Все строковые литералы — русские (приложение не поставляет строковых
 * ресурсов платформы Android).
 *
 * База — [ComponentActivity] (SETUP.md §7.7): AppCompatActivity требовал
 * AppCompat-тему и падал с платформенной темой манифеста §4.
 */
class MainActivity : ComponentActivity() {

    private lateinit var rootView: FrameLayout
    private lateinit var screenView: ScreenView
    private lateinit var hiddenInput: WedgeEditText
    private lateinit var powerButton: View

    private lateinit var keyboardHelper: KeyboardHelper

    private var service: ScreenStreamService? = null
    private var bound = false
    private var stateCollectionStarted = false

    /** Антиспам тостов onError: тот же текст в течение 3 с не показываем. */
    private var lastErrorMessage: String? = null
    private var lastErrorAtMs: Long = 0L

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val s = (binder as ScreenStreamService.LocalBinder).service
            service = s
            bound = true
            attachClient(s.client)
        }

        override fun onServiceDisconnected(name: ComponentName) {
            bound = false
            service = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Экран показа можно ВРАЩАТЬ (запрос пользователя, 3.8.0):
        // fullSensor следует датчику независимо от системного «автоповорота»,
        // поэтому поворот работает всегда. Код перекрывает манифест —
        // действует и на старый шаблон §4 с жёстким portrait.
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        setContentView(buildUi())

        // Держим экран включённым во время стриминга.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableImmersive()

        // Помощник мягкой клавиатуры, привязанный к скрытому полю.
        keyboardHelper = KeyboardHelper(this, hiddenInput) { event ->
            service?.client?.sendInput(event)
        }
        // Все текстовые события IME перехватываются ДО вставки в поле.
        hiddenInput.wrap = { base -> keyboardHelper.wrapInputConnection(base) }

        // ОДНОТАП по видео — поднять/спрятать клавиатуру.
        screenView.setOnClickListener { keyboardHelper.toggle() }

        // Единственная кнопка на экране: «⏻» — завершить сессию.
        powerButton.setOnClickListener {
            service?.disconnect()
            finish()
        }

        Toast.makeText(
            this,
            "Тап по экрану — клавиатура · круглая кнопка вверху — выход",
            Toast.LENGTH_SHORT
        ).show()
    }

    override fun onStart() {
        super.onStart()
        bindService(
            Intent(this, ScreenStreamService::class.java),
            connection,
            Context.BIND_AUTO_CREATE
        )
    }

    override fun onStop() {
        super.onStop()
        if (bound) {
            unbindService(connection)
            bound = false
            service?.client?.frameListener = null
        }
    }

    override fun onResume() {
        super.onResume()
        enableImmersive()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enableImmersive()
    }

    /** Сначала отправляем события клавиш в помощник клавиатуры. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (keyboardHelper.dispatchKey(event)) return true
        return super.dispatchKeyEvent(event)
    }

    /** Спрятать системные бары для иммерсивного полноэкранного режима. */
    private fun enableImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, rootView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun attachClient(client: ScreenClient) {
        client.frameListener = object : ScreenClient.FrameListener {
            override fun onInfo(info: ServerInfo) {
                runOnUiThread {
                    // Размер кадра — из /info (уточнится первым битмапом).
                    if (info.width > 0 && info.height > 0) {
                        screenView.setSourceSize(info.width, info.height)
                    }
                    screenView.setOverlayVisible(false)
                }
            }

            override fun onFrame(bitmap: Bitmap, decodeMs: Long) {
                runOnUiThread {
                    screenView.updateBitmap(bitmap)
                }
            }

            override fun onStats(stats: FrameStats) {
                runOnUiThread { /* FPS-оверлей не рисуем: экран чистый */ }
            }

            override fun onError(message: String) {
                runOnUiThread {
                    // Сервер может ругаться на каждое событие ввода
                    // (например, «wtype не установлен») — глушим повторы
                    // одинакового текста в течение 3 секунд.
                    val now = System.currentTimeMillis()
                    if (message == lastErrorMessage && now - lastErrorAtMs < 3000) return@runOnUiThread
                    lastErrorMessage = message
                    lastErrorAtMs = now
                    Toast.makeText(this@MainActivity, "Ошибка сервера: $message", Toast.LENGTH_LONG).show()
                }
            }
        }

        // Если сервер уже прислал /info до того, как мы забиндились (сервис
        // стартует раньше активности), достаём актуальный ServerInfo сейчас.
        client.currentServerInfo?.let { info ->
            if (info.width > 0 && info.height > 0) {
                screenView.setSourceSize(info.width, info.height)
            }
        }

        // Наблюдаем состояние — выходим при disconnect. Стартуем коллектор
        // один раз на экземпляр активности, чтобы не дублировать коллекторы
        // при ре-биндингах.
        if (stateCollectionStarted) return
        stateCollectionStarted = true
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                client.state.collect { state ->
                    when (state) {
                        is ScreenClient.State.Connected -> {
                            screenView.setConnected(true)
                            screenView.setOverlayVisible(false)
                        }
                        is ScreenClient.State.Connecting,
                        is ScreenClient.State.Reconnecting -> {
                            screenView.setConnected(false)
                            screenView.setOverlayText("подключение…")
                            screenView.setOverlayVisible(true)
                        }
                        is ScreenClient.State.Error -> {
                            screenView.setConnected(false)
                            // Сносим foreground-сервис тоже, чтобы он не пережил
                            // стриминговую сессию. Сообщение покажем тостом.
                            Toast.makeText(
                                this@MainActivity,
                                "Соединение разорвано: ${state.message}",
                                Toast.LENGTH_LONG
                            ).show()
                            service?.disconnect()
                            finish()
                        }
                        is ScreenClient.State.Disconnected -> {
                            screenView.setConnected(false)
                        }
                        else -> Unit
                    }
                }
            }
        }
    }

    // ----- UI построен целиком в коде (без XML-лейаутов) -----------------

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        rootView = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        // ScreenView заполняет всё окно; одиночный тап — клавиатура.
        screenView = ScreenView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        rootView.addView(screenView)

        // Полупрозрачная круглая кнопка питания — завершить сессию.
        // Единственный постоянный элемент поверх видео. Значок РИСУЕТСЯ
        // кодом ([PowerButtonView]): шрифтовый глиф «⏻» (U+23FB) отсутствует
        // в системных шрифтах многих телефонов и показывался прямоугольником
        // с крестом (tofu) — фик 3.8.0.
        powerButton = PowerButtonView(this).apply {
            contentDescription = "Отключиться"
            alpha = 0.6f
            val lp = FrameLayout.LayoutParams(dp(46), dp(46))
            lp.gravity = Gravity.TOP or Gravity.END
            lp.setMargins(dp(10), dp(10), dp(10), dp(10))
            layoutParams = lp
        }
        rootView.addView(powerButton)

        // Скрытый 1dp EditText, владеющий InputConnection мягкой клавиатуры.
        // Размер 1×1dp и alpha=0, чтобы пользователь его не видел, но
        // InputMethodManager показывал клавиатуру при фокусе.
        // TYPE_TEXT_FLAG_MULTI_LINE: у IME Enter — перевод строки (шлётся
        // нам как key Return), а не «Готово»-экшен.
        hiddenInput = WedgeEditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            alpha = 0f
            isFocusable = true
            isFocusableInTouchMode = true
            layoutParams = FrameLayout.LayoutParams(dp(1), dp(1))
        }
        rootView.addView(hiddenInput)

        return rootView
    }

    /**
     * Кнопка питания со ЗНАЧКОМ, нарисованным в [onDraw] (дуга с разрывом
     * сверху + вертикальная линия): глиф U+23FB POWER SYMBOL есть не во
     * всех прошивочных шрифтах, и вместо него рисовался прямоугольник
     * с крестом (tofu). Canvas даёт одинаковый вид на любом телефоне.
     * Полупрозрачный круг — [UiTheme.buttonPower].
     */
    private class PowerButtonView(context: Context) : View(context) {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            color = UiTheme.RED
        }

        init {
            background = UiTheme.buttonPower(resources.displayMetrics.density)
            isClickable = true
            isFocusable = true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val d = resources.displayMetrics.density
            val stroke = 2.4f * d
            paint.strokeWidth = stroke
            val cx = width / 2f
            val cy = height / 2f + 1.5f * d          // круг чуть ниже центра кнопки
            val r = width / 2f - stroke - 3f * d      // радиус окружности
            // окружность с разрывом сверху (72°, центр разрыва — 12 часов):
            canvas.drawArc(cx - r, cy - r, cx + r, cy + r, 306f, 288f, false, paint)
            // вертикальная линия: выступает над кругом и уходит к центру
            canvas.drawLine(
                cx, cy - r - 2.2f * d,
                cx, cy - r * 0.35f,
                paint
            )
        }
    }

    /**
     * EditText, чья InputConnection оборачивается перехватчиком
     * [KeyboardHelper.wrapInputConnection]: текст уходит на PC, а не в поле.
     */
    private class WedgeEditText(context: Context) : EditText(context) {
        var wrap: ((InputConnection?) -> InputConnection?)? = null

        override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
            val base = super.onCreateInputConnection(outAttrs)
            // Клавиатура не должна разворачиваться на весь экран и не должна
            // подменять Enter на «Далее/Готово».
            outAttrs.imeOptions = outAttrs.imeOptions or
                EditorInfo.IME_FLAG_NO_FULLSCREEN or
                EditorInfo.IME_FLAG_NO_ENTER_ACTION
            return wrap?.invoke(base) ?: base
        }
    }
}
