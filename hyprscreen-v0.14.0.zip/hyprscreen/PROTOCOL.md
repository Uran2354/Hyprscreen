# HyprScreen — спецификация wire-протокола

Версия: **0.14.0**. Единый источник истины для PC (Python) и Android (Kotlin).

## 1. Топология

Один PC отдаёт **N независимых экранов** (1–4). Каждый — отдельный
виртуальный Wayland-вывод `HEADLESS-<i>`, стримится на
`ws://<host>:<port>/<index>` (index = 0..N-1).

Воркспейс: экран i живёт в рабочем столе `workspace + i` (PC выбирает
номер, по умолчанию **6**; привязка — `hyprctl keyword workspace
"<N>,monitor:HEADLESS-<i>,default:true"`, старые runtime-правила
снимаются `hyprctl unkeyword workspace`). На протокол это не влияет —
информация для пользователя.

Разрешение: PC задаёт headless-выводу режим (по умолчанию альбом
`2340x1080` под landscape-приложение телефона — кадр занимает весь
экран) и сверяет его с фактическим — `width`/`height` в hello всегда
равны реальному размеру захвата.

Привязка воркспейса: правило
`workspace = <N>,monitor:HEADLESS-<i>,default:true` — headless
«рождается» сразу с нужным воркспейсом, а bind() дополнительно ЯВНО
активирует его на выводе (пустой авто-воркспейс после `output create`
на телефон не попадает).

## 2. WebSocket

- TCP-сервер на `bind_address:port` (по умолчанию `0.0.0.0:8765`).
- Путь `/` и пустой → экран **0**; вне диапазона → `close(1008, "unknown screen index")`.
- При `tls_enabled = true` — `wss://` (self-signed сертификат).

## 3. Auth (опционально)

Если на PC задан `auth_token`:

1. Клиент подключается и **первым сообщением** шлёт
   `{"type":"auth","token":"<значение>"}` (timeout 10 сек).
2. Успех → `hello`; неудача → `close(1008, "auth required")`.

Если `auth_token` не задан — auth-шаг пропускается.

## 4. Сообщения PC → телефон

### 4.1. hello (text, один раз после auth)

```json
{
  "type": "hello",
  "server": "hyprscreen",
  "version": "0.14.0",
  "width": 2340,
  "height": 1080,
  "fps": 24,
  "jpeg_quality": 75,
  "overlay": false,
  "screen": 0,
  "total_screens": 1,
  "output": "HEADLESS-1",
  "server_time": 1719480000.123
}
```

Обязательные поля: `width`, `height`, `fps`, `screen`, `total_screens`.
`width`/`height` — фактический режим headless-вывода (источник истины
для масштабирования касаний). `fps` — **фактический** (в режиме `auto`
может быть ниже целевого). `overlay` — просьба сервера НЕ рисовать
служебную надпись на телефоне (статус вместо этого пишется в state-файл
и показывается в PC GUI). Устаревшие поля `image_format`/
`capture_backend` удалены (клиенты с `ignoreUnknownKeys=true` принимают
оба варианта).

### 4.2. frame (binary)

Одно бинарное сообщение = один JPEG-кадр. Частота ≈ `fps`.

### 4.3. error (text, опционально)

```json
{"type": "error", "error": "описание ошибки"}
```

## 5. Сообщения телефон → PC

Все — text JSON. Координаты — в пикселях источника (0..width, 0..height).

```json
{"type":"pointer_move","x":842.0,"y":510.0}
{"type":"pointer_down","x":842.0,"y":510.0,"button":"left"}
{"type":"pointer_up","button":"left"}
{"type":"scroll","dx":0.0,"dy":-3.0}
{"type":"key","keysym":"c","modifiers":["ctrl","shift"]}
{"type":"text","text":"neofetch\n"}
{"type":"auth","token":"mysecret"}
```

`button` ∈ `"left" | "right" | "middle"`. `dy > 0` = вниз.

## 6. UDP discovery (PC → широковещательно)

PC каждые 2 секунды шлёт на порт `8766`:

```json
{"hyprscreen":true,"host":"192.168.1.42","port":8765,"screens":1,"name":"cachyos-pc"}
```

## 7. Ввод (поведение PC)

- **evdev UInput** — виртуальное устройство с абсолютными осями
  ABS_X/ABS_Y; курсор ставится мгновенно, без дрейфа.
- Координаты: глобальные = `(x_offset + x, y)`.
- Скролл: `REL_WHEEL` / `REL_HWHEEL`; текст/клавиши: `wtype`.
  Протокол: положительный `dy` = прокрутка вниз, `dx` = вправо.
  В evdev знак вертикали инвертируется (REL_WHEEL +1 = «вверх»);
  пиксели делятся на 10 (минимум 1 щелчок на событие).
- Rate-limit: если `input_rate_limit > 0` — не более N сообщений/сек.

## 8. Захват кадров (поведение PC)

- `grim -o HEADLESS-<i> -t jpeg -q <quality> [-s <scale>] -`.
- `scale < 1.0` уменьшает кадр (быстрее кодирование и передача).
- Режимы FPS (`fps_mode`): пресеты `eco|balance|smooth|max` задают
  fps/качество/масштаб; `auto` = balance + адаптивный FPS (EMA
  длительности захвата, пол 8 FPS, возврат к цели при запасе).
- Обои телефона: `swww img -o HEADLESS-<i>` (только headless-вывод),
  выбор — GUI (`~/Обои`), авто-применение на старте сервера.
- Нет клиентов — capture-луп спит; устаревшие кадры отбрасываются.

## 9. Жизненный цикл воркспейсов (PC)

1. Старт: миграция настроек (v3: возврат альбомного разрешения 2340x1080),
   `hyprctl unkeyword workspace` (снять накопленное),
   `cleanup_phantom_outputs()` (эвакуировать и удалить старые HEADLESS-*),
   создать выводы, сверить фактический режим,
   `keyword workspace "<N+i>,monitor:<HEADLESS-i>,default:true"`,
   выселить посторонние воркспейсы с headless, активировать телефонный
   воркспейс на выводе, поставить обои,
   вернуть фокус на физический монитор.
2. Остановка: воркспейс (с окнами) возвращается на физический монитор,
   `unkeyword workspace`, выводы удаляются, state-файл очищается.

## 10. Завершение работы

- SIGINT/SIGTERM: сервер отменяет задачи, закрывает клиентов и evdev
  UInput, отвязывает воркспейсы, удаляет HEADLESS-выводы, останавливает
  discovery, чистит state-файл.
- `./run.sh kill`: останавливает процесс сервера, освобождает порт,
  чистит HEADLESS и runtime-правила воркспейсов.
