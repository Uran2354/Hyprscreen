"""``python main.py`` — точка входа PC-стороны HyprScreen.

Разбирает аргументы CLI, загружает конфигурацию (TOML + CLI-переопределения),
убирает мусор прошлых запусков (фантомные HEADLESS-*, накопленные правила
воркспейсов), создаёт ровно N headless-выводов, привязывает ВЫБРАННЫЙ
воркспейс (по умолчанию 6; только один — дрейфа по «свободным номерам»
больше нет), сверяет разрешение с фактическим режимом вывода, ставит
выбранные обои и запускает WebSocket-сервер до SIGINT/SIGTERM.

Примеры::

    python main.py -c config.toml
    python main.py --workspace 6 --fps-mode auto
    python main.py --resolution 2340x1080 --fps 24 --fps-mode custom
    python main.py --screens 2                # два экрана: воркспейсы 6 и 7

Подкоманды: run | list | reset | diagnose | grimtest | workspace N |
interactive | kill
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import signal
import subprocess
import sys
from typing import Optional, Sequence

from capture import preflight_output
from config import (Config, ScreenConfig, FPS_MODES, _parse_resolution,
                    clamp_workspace, __version__)
from logging_setup import setup_logging
from server import HyprScreenServer
from virtual_output import VirtualOutputManager
import hyprctl
import settings_store
import state_file
import wallpaper
import workspaces

log = logging.getLogger("hyprscreen.main")


def _missing_runtime_deps() -> list[str]:
    """Python-модули, без которых сервер не заведётся.

    Раньше headless-выводы создавались, обои применялись и ПОТОМ
    падали в конструкторе сервера без ``websockets`` — с откатом, но зря.
    Теперь проверяем всё ДО первого касания Hyprland.
    """
    import importlib.util

    missing: list[str] = []
    for module, purpose in (
        ("websockets", "WebSocket-сервер"),
        ("evdev", "ввод с телефона (UInput)"),
    ):
        if importlib.util.find_spec(module) is None:
            missing.append(f"{module} ({purpose})")
    return missing


def _report_missing_deps(logger) -> bool:
    """Если зависимости отсутствуют — написать чёткую инструкцию. True = есть чего-то.

    ``logger`` — logging.Logger (пишет в лог) ИЛИ print-подобная функция
    (так передают из интерактивного меню). Раньше print-callable
    падал с «AttributeError: 'function' object has no attribute 'error'» —
    интерактивное меню без websockets/evdev не открывалось вовсе.
    """
    missing = _missing_runtime_deps()
    if not missing:
        return False

    if callable(logger) and not hasattr(logger, "error"):
        def emit(msg: str) -> None:
            logger(msg)
    else:
        def emit(msg: str) -> None:
            logger.error(msg)

    emit("не хватает Python-зависимостей: " + "; ".join(missing))
    emit(
        "установите одним из способов и запустите снова:\n"
        "  1) ./setup.sh                       (создаст .venv и поставит всё)\n"
        "  2) pip install -r requirements.txt  (в текущее окружение)\n"
        "  3) sudo pacman -S python-websockets python-evdev python-customtkinter"
    )
    return True


def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="main.py",
        description=(
            "HyprScreen — превратите Android-устройство в беспроводной второй "
            "экран для PC на CachyOS + Hyprland."
        ),
    )
    p.add_argument("--version", action="version", version=f"hyprscreen {__version__}")
    p.add_argument(
        "-c", "--config",
        default=None,
        help="Путь к config.toml. Если не задан — встроенные дефолты + settings.json.",
    )
    p.add_argument(
        "--screens",
        type=int,
        default=None,
        help="Количество виртуальных экранов (1..4). По умолчанию 1. "
             "Воркспейсы: N, N+1, ... (по числу экранов).",
    )
    p.add_argument(
        "--resolution", "-r",
        default=None,
        help="Разрешение виртуального вывода, например 1920x1080.",
    )
    p.add_argument(
        "--refresh-rate",
        type=float,
        default=None,
        help="Частота обновления в Гц (по умолчанию 60).",
    )
    p.add_argument(
        "--workspace", "-w",
        type=int,
        default=None,
        help="Номер рабочего стола, который живёт на телефоне (по умолчанию 6).",
    )
    p.add_argument(
        "--fps-mode",
        choices=FPS_MODES,
        default=None,
        help="Режим FPS: auto (адаптивный), eco, balance, smooth, max, custom. "
             "По умолчанию auto.",
    )
    p.add_argument(
        "--fps",
        type=int,
        default=None,
        help="Явный FPS (переводит fps_mode в custom, если --fps-mode не задан).",
    )
    p.add_argument(
        "--jpeg-quality",
        type=int,
        default=None,
        help="Качество JPEG 1-100 (тоже переключает в custom без --fps-mode).",
    )
    p.add_argument(
        "--port",
        type=int,
        default=None,
        help="TCP-порт WebSocket-сервера (по умолчанию 8765).",
    )
    p.add_argument(
        "--bind",
        default=None,
        help="Адрес привязки (по умолчанию 0.0.0.0). 127.0.0.1 — для SSH-туннеля.",
    )
    p.add_argument(
        "--output-name",
        default=None,
        help="Задать имя headless-вывода (например HEADLESS-1). По умолчанию авто.",
    )
    p.add_argument(
        "--discovery",
        dest="discovery",
        default=None,
        action=argparse.BooleanOptionalAction,
        help="Включить/выключить UDP discovery (--no-discovery).",
    )
    p.add_argument(
        "--log-level",
        default="INFO",
        help="Уровень логирования (DEBUG, INFO, WARNING, ERROR).",
    )
    p.add_argument(
        "--auth-token",
        default=None,
        help="Токен авторизации (клиент обязан прислать auth первым сообщением).",
    )
    p.add_argument(
        "--input-rate-limit",
        type=int,
        default=None,
        help="Max input-сообщений/сек на клиент (0 = без лимита).",
    )
    p.add_argument(
        "--tls",
        dest="tls",
        default=None,
        action=argparse.BooleanOptionalAction,
        help="Включить TLS (wss://).",
    )
    p.add_argument(
        "--tls-cert",
        default=None,
        help="Путь к PEM-сертификату (иначе self-signed авто).",
    )
    p.add_argument(
        "--tls-key",
        default=None,
        help="Путь к PEM-ключу.",
    )
    p.add_argument(
        "--log-to-file",
        dest="log_to_file",
        default=None,
        action=argparse.BooleanOptionalAction,
        help="Писать лог в файл с ротацией (по умолчанию вкл).",
    )
    p.add_argument(
        "--no-virtual-output",
        action="store_true",
        help="Не создавать виртуальный вывод; захватить вывод из --output-name "
             "(отладка на реальном мониторе).",
    )
    # Подкоманды.
    sub = p.add_subparsers(dest="command")
    sub.add_parser("run", help="Запустить сервер (по умолчанию).")
    sub.add_parser("list", help="Показать мониторы/воркспейсы.")
    sub.add_parser("reset", help="Удалить все HEADLESS-*, правила воркспейсов и state.")
    sub.add_parser("diagnose", help="Диагностика IPC Hyprland.")
    sub.add_parser("grimtest", help="Тест захвата grim для HEADLESS-*.")
    p_ws = sub.add_parser(
        "workspace",
        help="Перепривязать воркспейс к телефону (сервер должен быть запущен).",
    )
    p_ws.add_argument("workspace", help="Номер воркспейса (например 6).")
    sub.add_parser("interactive", help="Интерактивное меню (сервер в фоне).")
    sub.add_parser("kill", help="Остановить сервер + очистить HEADLESS и правила.")
    # Бинды Win+N — работают при запущенном сервере (читают state.json).
    sub.add_parser(
        "focus",
        help="Фокус на экран телефона (= Win+N; если сервер выключен — уведомит).",
    )
    sub.add_parser(
        "movewin",
        help="Перенести активное окно на экран телефона (= Win+Shift+N).",
    )
    return p


def _apply_cli_overrides(cfg: Config, args: argparse.Namespace) -> Config:
    """Применить CLI-переопределения поверх загруженного конфига.

    Семантика FPS: ``--fps-mode`` задаёт пресет; явные ``--fps`` /
    ``--jpeg-quality`` без ``--fps-mode`` переводят режим в ``custom``
    (значения пользователя приоритетнее пресета). Явные значения вместе
    с ``--fps-mode`` применяются ПОВЕРХ пресета.
    """
    if args.screens is not None:
        if args.screens < 1 or args.screens > 4:
            raise ValueError(f"--screens должен быть 1..4, получено {args.screens}")
        if len(cfg.screens) != args.screens:
            base = cfg.screens[0]
            cfg.screens = [
                ScreenConfig(
                    resolution=base.resolution,
                    refresh_rate=base.refresh_rate,
                    fps=base.fps,
                    jpeg_quality=base.jpeg_quality,
                    scale=base.scale,
                    output_name=None,
                    fps_mode=base.fps_mode,
                )
                for _ in range(args.screens)
            ]
    if args.resolution:
        res = _parse_resolution(args.resolution)
        for s in cfg.screens:
            s.resolution = res
    if args.refresh_rate is not None:
        for s in cfg.screens:
            s.refresh_rate = args.refresh_rate

    explicit_stream = args.fps is not None or args.jpeg_quality is not None
    if args.fps_mode is not None:
        for s in cfg.screens:
            s.fps_mode = args.fps_mode
            s.apply_fps_mode()
    elif explicit_stream:
        for s in cfg.screens:
            s.fps_mode = "custom"
    if args.fps is not None:
        for s in cfg.screens:
            s.fps = args.fps
    if args.jpeg_quality is not None:
        for s in cfg.screens:
            s.jpeg_quality = args.jpeg_quality

    if args.output_name is not None:
        cfg.screens[0].output_name = args.output_name
    if args.workspace is not None:
        cfg.workspace = clamp_workspace(args.workspace)
    if args.port is not None:
        cfg.port = args.port
    if args.bind is not None:
        cfg.bind_address = args.bind
    if args.discovery is not None:
        cfg.discovery_enabled = args.discovery
    if args.auth_token is not None:
        cfg.auth_token = args.auth_token
    if args.input_rate_limit is not None:
        cfg.input_rate_limit = args.input_rate_limit
    if args.tls is not None:
        cfg.tls_enabled = args.tls
    if args.tls_cert is not None:
        cfg.tls_cert = args.tls_cert
    if args.tls_key is not None:
        cfg.tls_key = args.tls_key
    if args.log_to_file is not None:
        cfg.log_to_file = args.log_to_file
    return cfg


def _load_config(args: argparse.Namespace) -> Config:
    """Загрузить конфиг (TOML → settings.json → дефолты) и применить CLI."""
    if args.config:
        cfg = Config.from_file(args.config)
        source = f"config.toml ({args.config})"
    else:
        cfg = Config.default()
        # Без config.toml берём сохранённый в settings.json выбор.
        cfg.workspace = settings_store.get_workspace()
        saved_mode = settings_store.get_fps_mode()
        if saved_mode and saved_mode in FPS_MODES and cfg.screens[0].fps_mode != saved_mode:
            for s in cfg.screens:
                s.fps_mode = saved_mode
        for s in cfg.screens:
            s.apply_fps_mode()
        source = "settings.json / дефолт"
    if args.workspace is not None:
        source = "CLI --workspace"
    log.info("воркспейс телефона: %d (источник: %s)", cfg.workspace, source)
    return _apply_cli_overrides(cfg, args)


def _sync_actual_resolutions(cfg: Config, output_names: list[str]) -> None:
    """Сверить разрешения экранов с фактическим режимом headless-выводов.

    Если Hyprland не принял запрошенный режим (например, нестандартный
    альбом 2340x1080), вывод остаётся в дефолтном — тогда hello,
    захват grim и инъекция ввода обязаны исходить из ФАКТИЧЕСКОГО
    размера, иначе касания промахиваются мимо целей.
    """
    try:
        mons = {
            str(m.get("name")): (int(m.get("width", 0)), int(m.get("height", 0)))
            for m in hyprctl.monitors()
        }
    except hyprctl.HyprctlError as exc:
        log.warning("не удалось сверить разрешения: %s", exc)
        return
    for i, name in enumerate(output_names):
        actual = mons.get(name)
        if (
            actual
            and actual[0] > 0
            and actual[1] > 0
            and actual != cfg.screens[i].resolution
        ):
            log.info(
                "экран %d: фактический режим %dx%d (запрашивали %dx%d) — используем его",
                i, actual[0], actual[1], *cfg.screens[i].resolution,
            )
            cfg.screens[i].resolution = actual


def _owned_headless_outputs() -> list[str]:
    """Имена HEADLESS-выводов из state.json прошлых запусков (только наши).

    Cleanup старта/kill не сносит ВСЕ HEADLESS-* подряд —
    только записанные в state (иначе погибал, например, собственный
    wayvnc-стек пользователя на headless-выводе).
    """
    state = state_file.read_state() or {}
    screens = state.get("screens")
    if not isinstance(screens, list):
        return []
    return [
        str(s.get("monitor"))
        for s in screens
        if isinstance(s, dict) and s.get("monitor")
    ]


def _focus_real_monitor_safe() -> None:
    """Вернуть фокус И курсор на физический монитор (best-effort).

    После отката/ошибки старта фокус мог остаться на headless-выводе —
    без явного возврата пользователь получает «клавиатура ничего не
    делает, окна открываются неведомо куда» (жалоба реального запуска).
    Вызывается на ВСЕХ путях выхода из _run — и на ошибках,
    и после УСПЕШНОГО старта.

    Вместе с фокусом переносится и курсор (как в Win+N):
    ``hyprctl dispatch focusmonitor`` меняет фокус, но не курсор —
    без этого ок под курсором оставался на физмониторе, а focused
    окно — на headless: первый же клик возвращал фокус обратно.
    """
    try:
        real = hyprctl.real_monitors()
        if real:
            hyprctl.focus_monitor(real[0])
            hyprctl.move_cursor_to_monitor(real[0])
    except Exception as exc:  # noqa: BLE001 - best-effort
        log.debug("возврат фокуса на физический монитор: %s", exc)


async def _run(cfg: Config, create_outputs: bool) -> int:
    """Создать виртуальные выводы, привязать воркспейс, запустить сервер."""
    # Зависимости проверяем ПЕРВЫМ делом — раньше без websockets
    # мы успевали создать/удалить headless-выводы и обои, и только потом
    # падали в конструкторе сервера.
    if _report_missing_deps(log):
        return 1
    mgr: Optional[VirtualOutputManager] = None
    if create_outputs:
        # 0. Мусор прошлых запусков: фантомные HEADLESS-* (их воркспейсы —
        #    источник «экран на 3-5») эвакуируются и удаляются.
        #    Только СВОИ выводы из state — чужие headless не трогаем.
        try:
            owned = _owned_headless_outputs()
            if owned:
                removed = hyprctl.cleanup_phantom_outputs(owned_names=owned)
                if removed:
                    log.info("удалены выводы прошлых запусков: %s", removed)
            else:
                log.info(
                    "state прошлых запусков отсутствует — чужие HEADLESS-* не трогаю "
                    "(полная очистка: hyprscreen reset)"
                )
        except hyprctl.HyprctlError as exc:
            log.warning("cleanup_phantom_outputs: %s", exc)
        # 0.5. Правила воркспейсов — ДО создания выводов: headless рождается
        #      сразу с телефонным воркспейсом (default:true), и bind'у не
        #      нужно ничего активировать — рабочий стол не дёргается.
        try:
            planned = workspaces.pin_rules_planned(cfg, len(cfg.screens))
        except Exception as exc:  # noqa: BLE001 - не критично, есть запасной путь
            log.warning("закрепление правил до создания не удалось: %s", exc)
            planned = {}
        # 1. Создаём ровно N выводов.
        try:
            mgr = VirtualOutputManager(cfg.screens)
            await mgr.__aenter__()
        except Exception as exc:
            log.error(
                "не удалось создать виртуальные выводы: %s — рабочий стол "
                "восстановлен (выводы откатаны). Если на столе остался чужой "
                "фантомный HEADLESS — полная очистка: ./run.sh reset",
                exc,
            )
            _notify("HyprScreen: не удалось запуститься", str(exc)[:180])
            _focus_real_monitor_safe()
            return 1
        placement = mgr.placement()
        if len(placement) != len(cfg.screens):
            log.error("создано %d выводов, ожидалось %d — откат",
                      len(placement), len(cfg.screens))
            await mgr.__aexit__(None, None, None)
            _focus_real_monitor_safe()
            return 1
        output_names = [p[0] for p in placement]
        # 1.5. Фактический режим вывода — источник истины (hello/ввод/захват).
        _sync_actual_resolutions(cfg, output_names)
        # 1.6 (фикс чёрного экрана): тест захвата ДО старта сервера.
        # Если grim не работает — пользователь узнаёт об этом СРАЗУ
        # (лог + уведомление), а не по чёрному экрану на телефоне.
        _preflight_capture_or_warn(output_names)
        screen_specs = [
            (placement[i][0], placement[i][1], cfg.screens[i])
            for i in range(len(placement))
        ]
        # 2-3. Привязка воркспейса + обои. Любая ошибка здесь — сносим уже
        #      созданные выводы (иначе остаются фантомные HEADLESS-*).
        try:
            bindings = workspaces.bind(cfg, output_names, planned=planned or None)
            # Выбранные обои — только на телефонные выводы (swww -o).
            wp = settings_store.get_wallpaper()
            if wp:
                ok, msg = wallpaper.apply(wp, output_names)
                (log.info if ok else log.warning)("обои телефона: %s", msg)
        except Exception as exc:  # noqa: BLE001
            log.error("привязка воркспейса не удалась: %s — откат", exc)
            try:
                workspaces.unbind(output_names)
            except Exception:  # noqa: BLE001
                pass
            await mgr.__aexit__(None, None, None)
            _notify("HyprScreen: не удалось привязать воркспейс", str(exc)[:180])
            _focus_real_monitor_safe()
            return 1
    else:
        if not cfg.screens[0].output_name:
            log.error("--no-virtual-output требует --output-name")
            return 2
        mgr = None
        output_names = [cfg.screens[0].output_name]
        screen_specs = [(cfg.screens[0].output_name, 0, cfg.screens[0])]
        bindings = []

    state_file.write_state(
        screens=[
            {
                "index": i,
                "monitor": output_names[i],
                "workspace": cfg.workspace + i,
                "resolution": list(cfg.screens[i].resolution),
            }
            for i in range(len(output_names))
        ],
        port=cfg.port,
    )

    # Конструктор создаёт UInput/проверяет websockets/evdev — может упасть
    # (раньше падение оставляло фантомные HEADLESS-* и правила
    # воркспейсов без очистки — “код 1” и мусор в Hyprland).
    try:
        server = HyprScreenServer(cfg, screen_specs)
    except Exception as exc:  # noqa: BLE001
        log.error("не удалось инициализировать сервер: %s", exc)
        if mgr is not None:
            try:
                workspaces.unbind(output_names)
            except Exception:  # noqa: BLE001
                pass
            await mgr.__aexit__(None, None, None)
        state_file.clear_state()
        _notify("HyprScreen: не удалось инициализировать сервер", str(exc)[:180])
        _focus_real_monitor_safe()
        return 1
    try:
        await server.start()
    except Exception as exc:  # noqa: BLE001
        msg = str(exc)
        if "address already in use" in msg.lower() or "errno 98" in msg.lower():
            log.error(
                "не удалось запустить сервер: %s — порт %d занят. Возможно, "
                "HyprScreen уже запущен (проверьте: ./run.sh kill) или порт "
                "взяла другая программа",
                exc, cfg.port,
            )
        else:
            log.error("не удалось запустить сервер: %s", exc)
        if mgr is not None:
            workspaces.unbind(output_names)
            await mgr.__aexit__(None, None, None)
        state_file.clear_state()
        _notify("HyprScreen: не удалось запустить сервер", msg[:180])
        _focus_real_monitor_safe()
        return 1

    # ПРИЯТНЫЙ СТАРТ. Hyprland отдаёт фокус только что созданному
    # headless-выводу, а bind() активирует на нём телефонный воркспейс —
    # рабочий стол пользователя «прыгал» на новый пустой экран
    # («при запуске сервера открывается какой-то экран»). Не Lua-особенность,
    # а поведение вывода create на любых версиях. Явно возвращаем фокус и
    # курсор на физический монитор: телефонный стол никуда не денется
    # (правило воркспейса + win+N), а десктоп не дёргается.
    _focus_real_monitor_safe()

    log.info(
        "телефонный экран: воркспейс %s (%s); переключение win+<номер>",
        [b["workspace"] for b in bindings] or [cfg.workspace],
        ", ".join(output_names),
    )

    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()

    def _on_signal() -> None:
        log.info("получен сигнал, останавливаемся")
        stop_event.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _on_signal)
        except NotImplementedError:
            signal.signal(sig, lambda *_: stop_event.set())

    serve_task = asyncio.create_task(server.serve(), name="server-serve")
    stop_task = asyncio.create_task(stop_event.wait(), name="stop-event")
    try:
        await asyncio.wait({serve_task, stop_task}, return_when=asyncio.FIRST_COMPLETED)
    finally:
        await server.stop()
        if not serve_task.done():
            try:
                await serve_task
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                log.warning("serve-задача завершена с ошибкой: %s", exc)
        else:
            exc = serve_task.exception()
            if exc is not None:
                log.error("serve-задача упала: %s", exc)
        if not stop_task.done():
            stop_task.cancel()
            try:
                await stop_task
            except asyncio.CancelledError:
                pass
        # Чистый выход: воркспейс с окнами возвращается на физический
        # монитор, правила снимаются, выводы удаляются.
        if mgr is not None:
            try:
                workspaces.unbind(output_names)
            except Exception as exc:  # noqa: BLE001
                log.warning("unbind воркспейсов: %s", exc)
            await mgr.__aexit__(None, None, None)
        _focus_real_monitor_safe()
        state_file.clear_state()
    return 0


def _cmd_list() -> int:
    """Показать мониторы и воркспейсы."""
    print("=== Мониторы ===")
    try:
        for m in hyprctl.monitors():
            name = m.get("name", "?")
            mark = " ← виртуальный" if str(name).startswith("HEADLESS") else ""
            print(f"  {name:16s} {m.get('width', '?')}x{m.get('height', '?')} "
                  f"@ ({m.get('x', 0)},{m.get('y', 0)}){mark}")
    except hyprctl.HyprctlError as exc:
        print(f"  ошибка: {exc}", file=sys.stderr)
    print("\n=== Воркспейсы ===")
    try:
        for w in hyprctl.list_workspaces():
            ws_id = w.get("id", "?")
            mon = w.get("monitor", "?")
            mark = " ← на телефоне" if str(mon).startswith("HEADLESS") else ""
            print(f"  {ws_id:4s} монитор: {mon}{mark}")
    except hyprctl.HyprctlError as exc:
        print(f"  ошибка: {exc}", file=sys.stderr)
    return 0


def _cmd_reset() -> int:
    """Удалить все HEADLESS-*, runtime-правила воркспейсов и state-файл."""
    print("=== Сброс HyprScreen ===")
    removed = hyprctl.cleanup_phantom_outputs()
    if removed:
        for n in removed:
            print(f"  — вывод {n}")
    else:
        print("  headless уже чисто")
    reply = hyprctl.remove_workspace_rules()
    print(f"  правила воркспейсов сняты ({(reply or 'ok').strip()[:40]})")
    state_file.clear_state()
    print("  state-файл очищен")
    return 0


def _current_headless_outputs() -> list[str]:
    """Имена headless-выводов: сначала из state-файла, потом из Hyprland."""
    state = state_file.read_state()
    names: list[str] = []
    if state and isinstance(state.get("screens"), list):
        for s in state["screens"]:
            mon = s.get("monitor")
            if isinstance(mon, str) and mon.startswith("HEADLESS"):
                names.append(mon)
    if not names:
        names = hyprctl.find_headless_monitors()
    return names


def _cmd_workspace(args) -> int:
    """Перепривязать воркспейс к телефону (на лету, без перезапуска)."""
    ws_text = str(args.workspace).strip()
    outputs = _current_headless_outputs()
    if not outputs:
        print("HEADLESS не найден. Запустите сервер: ./run.sh", file=sys.stderr)
        return 1
    cfg = Config.default(screen_count=len(outputs))
    try:
        cfg.workspace = clamp_workspace(int(ws_text))
    except ValueError:
        print(f"Номер воркспейса должен быть числом: {ws_text!r}", file=sys.stderr)
        return 1
    try:
        bindings = workspaces.bind(cfg, outputs)
    except hyprctl.HyprctlError as exc:
        print(f"Ошибка: {exc}", file=sys.stderr)
        return 1
    settings_store.set_workspace(cfg.workspace)
    state_file.update_state(
        workspace=cfg.workspace,
        screens=[
            {"index": i, "monitor": outputs[i], "workspace": cfg.workspace + i}
            for i in range(len(outputs))
        ],
    )
    for b in bindings:
        print(f"✓ Воркспейс {b['workspace']} → {b['monitor']}")
    print("  Переключение: win+<номер>")
    return 0


def _cmd_grimtest() -> int:
    """Тест захвата grim для HEADLESS-* (с подсказками по сбоям)."""
    import shutil
    import time
    try:
        mons = hyprctl.monitors()
    except hyprctl.HyprctlError as exc:
        print(f"  ошибка: {exc}", file=sys.stderr)
        return 1
    headless = [m for m in mons if str(m.get("name", "")).startswith("HEADLESS")]
    if not headless:
        print("  HEADLESS не найден. Запустите сервер.")
        return 1
    grim_path = shutil.which("grim")
    if not grim_path:
        print("  grim не установлен: sudo pacman -S grim", file=sys.stderr)
        return 1
    failed = False
    for m in headless:
        name = m.get("name", "?")
        t0 = time.monotonic()
        ok, msg = preflight_output(str(name))
        dt = time.monotonic() - t0
        if ok:
            print(f"  {name}: ✓ захват работает ({dt:.2f}s)")
        else:
            failed = True
            print(f"  {name}: ✗ {msg}")
    if failed:
        print("")
        print("  Если на телефоне ЧЁРНЫЙ ЭКРАН — вот причина (см. выше).")
        print("  После устранения перезапустите сервер: ./run.sh kill && ./run.sh run")
    return 0


def _notify(title: str, body: str = "") -> None:
    """Уведомление через notify-send (best-effort)."""
    try:
        cmd = ["notify-send", "-a", "HyprScreen", "-t", "6000", title]
        if body:
            cmd.append(body)
        subprocess.run(cmd, check=False, timeout=5,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:  # noqa: BLE001
        pass


def _phone_monitor_from_state() -> Optional[str]:
    """Имя монитора телефона из state-файла; None если сервер не запущен."""
    state = state_file.read_state()
    if not state:
        return None
    screens = state.get("screens") or []
    if screens and isinstance(screens[0].get("monitor"), str):
        return str(screens[0]["monitor"])
    try:
        heads = hyprctl.find_headless_monitors()
        return heads[0] if heads else None
    except hyprctl.HyprctlError:
        return None


def _cmd_focus() -> int:
    """Win+N: перевести фокус и курсор на экран телефона.

    Фикс «win+n не переходит на телефон»: бинд целился в
    статическое имя монитора. Здесь имя берётся из state.json (динамическое
    HEADLESS-N), фокус + курсор переводятся вместе.
    """
    mon = _phone_monitor_from_state()
    if not mon:
        _notify("HyprScreen выключен", "Запустите: ./run.sh (сервер не отвечает)")
        print("сервер не запущен (state.json нет) — нечего фокусировать")
        return 1
    try:
        hyprctl.focus_monitor(mon)
        hyprctl.move_cursor_to_monitor(mon)
        log.info("focus -> %s", mon)
        return 0
    except hyprctl.HyprctlError as exc:
        _notify("HyprScreen: не удалось переключиться", str(exc))
        print(f"ошибка: {exc}", file=sys.stderr)
        return 1


def _cmd_movewin() -> int:
    """Win+Shift+N: активное окно — на экран телефона."""
    mon = _phone_monitor_from_state()
    if not mon:
        _notify("HyprScreen выключен", "Запустите: ./run.sh")
        print("сервер не запущен (state.json нет)")
        return 1
    try:
        hyprctl.move_window_to_monitor(mon)
        hyprctl.focus_monitor(mon)
        hyprctl.move_cursor_to_monitor(mon)
        log.info("окно -> %s", mon)
        return 0
    except hyprctl.HyprctlError as exc:
        _notify("HyprScreen: не удалось перенести окно", str(exc))
        print(f"ошибка: {exc}", file=sys.stderr)
        return 1


def _preflight_capture_or_warn(output_names: list[str]) -> bool:
    """Тест захвата каждого вывода ДО старта сервера (фикс чёрного экрана).

    Раньше сбой захвата обнаруживался только через ~минуту тишины в логе,
    и пользователь видел на телефоне чёрный экран без объяснений. Теперь
    если grim не может снять вывод — сервер всё равно стартует (GUI/тикер
    покажут статус), но причина КРИЧИТСЯ в лог и в уведомление немедленно.

    Возвращает True, если все выводы захватываются.
    """
    all_ok = True
    for name in output_names:
        ok, msg = preflight_output(name)
        if ok:
            log.info("preflight захват %s: OK", name)
            continue
        all_ok = False
        log.error(
            "preflight захват %s: НЕ РАБОТАЕТ — на телефоне будет чёрный экран. "
            "Причина: %s",
            name, msg,
        )
        _notify(
            "HyprScreen: захват НЕ работает",
            f"{name}: {msg[:180]} — телефон покажет чёрный экран",
        )
    if not all_ok:
        log.error(
            "захват сломан — типовое лечение: yay -S grim-git (новый Hyprland "
            "убрал wlr-screencopy из grim 1.4.1); затем: ./run.sh kill && ./run.sh run"
        )
    return all_ok


def _interactive_wallpaper() -> None:
    """Выбор обоев из каталога (settings → ~/Обои). Выбор сохраняется."""
    import os

    wp_dir = settings_store.get_wallpaper_dir()
    files = wallpaper.list_wallpapers(wp_dir)
    if not files:
        print(f"В каталоге {os.path.expanduser(wp_dir)} нет изображений "
              f"(jpg/png/webp/bmp/gif).")
        return
    saved_wp = settings_store.get_wallpaper()
    print(f"\n--- Обои в {os.path.expanduser(wp_dir)} ---")
    for i, f in enumerate(files, 1):
        mark = " ✓" if saved_wp and os.path.expanduser(saved_wp) == f else ""
        print(f"  {i}) {os.path.relpath(f, os.path.expanduser(wp_dir))}{mark}")
    print("  b) без обоев (чёрный)")
    print("  0) назад")
    try:
        choice = input("Выбор: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return
    if choice == "0" or not choice:
        return
    outputs = hyprctl.find_headless_monitors()
    if choice == "b":
        ok, msg = wallpaper.clear(outputs)
        print(f"  {'✓' if ok else '⚠'} {msg}")
        if ok:
            settings_store.set_wallpaper(None)
        return
    try:
        idx = int(choice) - 1
        if idx < 0 or idx >= len(files):
            print("Неверный индекс")
            return
    except ValueError:
        print("Нужно число")
        return
    ok, msg = wallpaper.apply(files[idx], outputs)
    print(f"  {'✓' if ok else '⚠'} {msg}")
    if ok:
        settings_store.set_wallpaper(files[idx])
        print("  ✓ Обои сохранены — применятся и при следующем запуске сервера")


def _interactive_workspace() -> None:
    """Выбор воркспейса для телефона (по умолчанию — сохранённый, обычно 6)."""
    try:
        workspaces_list = hyprctl.list_workspaces()
    except hyprctl.HyprctlError as exc:
        print(f"Ошибка: {exc}")
        return
    saved_ws = settings_store.get_workspace()
    print("\n--- Воркспейсы ---")
    for w in workspaces_list:
        ws_id = w.get("id", "?")
        mon = w.get("monitor", "?")
        mark = " ← на телефоне" if str(mon).startswith("HEADLESS") else ""
        print(f"  {ws_id} (монитор: {mon}){mark}")
    print(f"  Сохранённый номер: {saved_ws}")
    print("  Введите НОВЫЙ номер (Enter — оставить текущий):")
    try:
        choice = input("Воркспейс: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return
    if not choice:
        return
    outputs = _current_headless_outputs()
    if not outputs:
        print("HEADLESS не найден. Запустите сервер.")
        return
    cfg = Config.default(screen_count=len(outputs))
    try:
        cfg.workspace = clamp_workspace(int(choice))
    except ValueError:
        print("Нужно число")
        return
    try:
        bindings = workspaces.bind(cfg, outputs)
        settings_store.set_workspace(cfg.workspace)
        state_file.update_state(
            workspace=cfg.workspace,
            screens=[
                {"index": i, "monitor": outputs[i], "workspace": cfg.workspace + i}
                for i in range(len(outputs))
            ],
        )
        for b in bindings:
            print(f"✓ Воркспейс {b['workspace']} → {b['monitor']}")
    except hyprctl.HyprctlError as exc:
        print(f"Ошибка: {exc}")


def _cmd_interactive() -> int:
    """Интерактивное меню: сервер в фоне + обои/воркспейс/лог/рестарт."""
    import subprocess
    import os
    import time
    from collections import deque

    # Раньше без websockets сервер рождался и тут же умирал,
    # а пользователь видел только «Сервер остановлен (код N)».
    _report_missing_deps(lambda *a, **k: print(*a, file=sys.stderr))
    log_file = "/tmp/hyprscreen-server.log"
    script_dir = os.path.dirname(os.path.abspath(__file__))
    venv_python = os.path.join(script_dir, ".venv", "bin", "python")
    python_bin = venv_python if os.path.exists(venv_python) else sys.executable

    config_path = os.path.join(script_dir, "config.toml")
    if os.path.exists(config_path):
        try:
            cfg = Config.from_file(config_path)
        except Exception:
            cfg = Config.default()
    else:
        cfg = Config.default()
        cfg.workspace = settings_store.get_workspace()

    server_cmd = [python_bin, "main.py", "--log-level", "INFO", "--no-log-to-file"]
    if os.path.exists(config_path):
        server_cmd.extend(["-c", config_path])
    if cfg.auth_token:
        server_cmd.extend(["--auth-token", cfg.auth_token])

    def _spawn() -> tuple[subprocess.Popen, object]:
        fh = open(log_file, "w")
        proc = subprocess.Popen(
            server_cmd,
            stdout=fh,
            stderr=subprocess.STDOUT,
            cwd=script_dir,
            env={**os.environ, "PYTHONPATH": script_dir},
            start_new_session=True,
        )
        return proc, fh

    def _close(proc: subprocess.Popen, fh: object) -> None:
        try:
            proc.terminate()
            proc.wait(timeout=5)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
        try:
            fh.close()  # type: ignore[attr-defined]
        except Exception:
            pass

    print(f"Запускаю сервер в фоне: {' '.join(server_cmd)}")
    print(f"Лог сервера: {log_file}")
    try:
        server_proc, server_log_fh = _spawn()
    except Exception as exc:
        print(f"Не удалось запустить сервер: {exc}", file=sys.stderr)
        return 1
    print(f"Сервер запущен (pid={server_proc.pid}). Ожидание...")
    time.sleep(2)

    from server import lan_ip
    lan_ip_str = lan_ip()

    wp_dir = settings_store.get_wallpaper_dir()
    try:
        while True:
            print("\n" + "=" * 50)
            print("  HyprScreen — интерактивное меню")
            print("=" * 50)
            print(f"  IP:     {lan_ip_str}")
            print(f"  Порт:   {cfg.port}")
            print(f"  Токен:  {cfg.auth_token if cfg.auth_token else '(нет)'}")
            print(f"  Воркспейс телефона: {cfg.workspace} (win+{cfg.workspace})")
            print()
            if server_proc.poll() is not None:
                print(f"  ⚠ Сервер остановлен (код {server_proc.returncode})")
                print("    Подсказка: посмотрите лог (пункт 4); частые причины — "
                      "занятый порт или не установлен websockets/evdev.")
            else:
                try:
                    mons = hyprctl.monitors()
                    headless = [str(m.get("name", "")) for m in mons
                                if str(m.get("name", "")).startswith("HEADLESS")]
                    if headless:
                        print(f"  ✓ Сервер активен, HEADLESS: {', '.join(headless)}")
                    else:
                        print("  ✓ Сервер активен")
                except Exception:
                    print("  ✓ Сервер активен")
            print()
            print("  1) Выбрать обои")
            print("  2) Выбрать воркспейс телефона")
            print("  3) Показать статус (list)")
            print("  4) Показать лог сервера")
            print("  5) Перезапустить сервер")
            print("  0) Выход (остановить сервер)")
            print()
            try:
                choice = input("Выбор [0-5]: ").strip()
            except (EOFError, KeyboardInterrupt):
                choice = "0"
                print()
            if choice == "0":
                break
            elif choice == "1":
                _interactive_wallpaper()
            elif choice == "2":
                _interactive_workspace()
                cfg.workspace = settings_store.get_workspace()
            elif choice == "3":
                _cmd_list()
            elif choice == "4":
                try:
                    with open(log_file, "r") as f:
                        tail = deque(f, maxlen=20)
                    for line in tail:
                        print(line.rstrip())
                except Exception as exc:
                    print(f"Ошибка: {exc}")
            elif choice == "5":
                print("Перезапуск...")
                _close(server_proc, server_log_fh)
                try:
                    server_proc, server_log_fh = _spawn()
                    print(f"Перезапущен (pid={server_proc.pid})")
                    time.sleep(2)
                except Exception as exc:
                    print(f"Не удалось перезапустить сервер: {exc}", file=sys.stderr)
                    return 1
            else:
                print("Неверный выбор")
    finally:
        print("\nОстанавливаю сервер...")
        _close(server_proc, server_log_fh)
        print("Сервер остановлен.")
        try:
            owned = _owned_headless_outputs()
            if owned:
                hyprctl.cleanup_phantom_outputs(owned_names=owned)
            else:
                print("  state не найден — чужие HEADLESS-* не тронуты (полная очистка: reset)")
        except Exception:
            pass
        state_file.clear_state()
    return 0


def _cmd_kill() -> int:
    """Найти и остановить сервер HyprScreen + очистить HEADLESS и правила."""
    import subprocess
    import os
    import signal
    import time

    print("=== Поиск и остановка сервера HyprScreen ===")
    script_dir = os.path.realpath(os.path.dirname(os.path.abspath(__file__)))

    def _is_hyprscreen(pid: int) -> bool:
        """pgrep -f 'main.py' ловит и чужие процессы (редактор с открытым
        main.py и т.п.) — процесс наш, только если его cwd или cmdline
        указывают на каталог HyprScreen."""
        try:
            cwd = os.path.realpath(f"/proc/{pid}/cwd")
            with open(f"/proc/{pid}/cmdline", "rb") as fh:
                cmdline = fh.read().decode("utf-8", "replace").replace("\x00", " ").lower()
        except OSError:
            return False
        return cwd == script_dir or script_dir.lower() in cmdline

    killed: list[int] = []
    try:
        result = subprocess.run(["pgrep", "-f", "main.py"],
                                capture_output=True, text=True, timeout=5)
        pids = [int(p) for p in result.stdout.strip().split("\n") if p.strip()]
    except Exception:
        pids = []
    my_pid = os.getpid()
    pids = [p for p in pids if p != my_pid and _is_hyprscreen(p)]

    if pids:
        for pid in pids:
            try:
                os.kill(pid, signal.SIGTERM)
                print(f"  SIGTERM → pid {pid}")
                killed.append(pid)
            except ProcessLookupError:
                pass
            except PermissionError:
                print(f"  ⚠ Нет прав на pid {pid} (sudo kill {pid}?)")
        time.sleep(2)
        for pid in killed:
            try:
                os.kill(pid, 0)
                os.kill(pid, signal.SIGKILL)
                print(f"  SIGKILL → pid {pid} (не завершился по SIGTERM)")
            except ProcessLookupError:
                pass
        print(f"  Остановлено процессов: {len(killed)}")
    else:
        print("  Работающий сервер не найден.")

    # Порт берём из state-файла работающего сервера (8765 — только как
    # запасной): сервер может слушать другой порт, и SIGKILL по жёсткому
    # 8765 убивал чужой процесс.
    state = state_file.read_state()
    port = int(state.get("port", 8765)) if state and state.get("port") else 8765
    try:
        result = subprocess.run(["lsof", f"-ti:{port}"],
                                capture_output=True, text=True, timeout=5)
        port_pids = [int(p) for p in result.stdout.strip().split("\n") if p.strip()]
        for pid in port_pids:
            if pid not in killed and pid != my_pid:
                try:
                    os.kill(pid, signal.SIGTERM)
                    print(f"  Порт {port} освобождён (pid {pid})")
                except Exception:
                    pass
    except Exception:
        pass

    print("\n--- Очистка HEADLESS и правил воркспейсов ---")
    try:
        # Только СВОИ выводы из state; чужие headless-стеки не трогаем.
        owned = _owned_headless_outputs()
        if owned:
            removed = hyprctl.cleanup_phantom_outputs(owned_names=owned)
            if removed:
                for n in removed:
                    print(f"  — вывод {n}")
            else:
                print("  headless уже чисто")
        else:
            print("  state не найден — чужие HEADLESS-* не тронуты (полная очистка: reset)")
    except Exception as exc:
        print(f"  ⚠ {exc}")
    reply = hyprctl.remove_workspace_rules()
    print(f"  правила воркспейсов сняты ({(reply or 'ok').strip()[:40]})")
    state_file.clear_state()
    print("  state-файл очищен")
    print("\nГотово.")
    return 0


def main(argv: Optional[Sequence[str]] = None) -> int:
    """Точка входа. Возвращает код выхода процесса."""
    argv = list(sys.argv[1:] if argv is None else argv)
    # «main.py run --workspace 6» (так вызывает run.sh): опции после
    # подкоманды попадали в ПУСТОЙ sub-парсер run и падали с
    # «unrecognized arguments» (exit 2). Подкоманда run — то же самое,
    # что и запуск по умолчанию, поэтому просто снимаем лишний токен.
    if argv and argv[0] == "run":
        argv.pop(0)
    parser = _build_arg_parser()
    args = parser.parse_args(argv)
    cmd = args.command
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # Одноразовая миграция настроек: старые версии могли сохранить чужой
    # номер воркспейса (например 4) — сброс на дефолт 6.
    actions = settings_store.migrate(
        args.config or os.path.join(script_dir, "config.toml")
    )
    if actions:
        print("Миграция настроек:")
        for a in actions:
            print(f"  — {a}")
    if cmd == "list":
        setup_logging("WARNING")
        return _cmd_list()
    elif cmd == "reset":
        setup_logging("WARNING")
        return _cmd_reset()
    elif cmd == "diagnose":
        setup_logging("WARNING")
        hyprctl.diagnose()
        return 0
    elif cmd == "grimtest":
        setup_logging("WARNING")
        return _cmd_grimtest()
    elif cmd == "workspace":
        setup_logging("INFO")
        return _cmd_workspace(args)
    elif cmd == "interactive":
        setup_logging("WARNING")
        return _cmd_interactive()
    elif cmd == "kill":
        setup_logging("WARNING")
        return _cmd_kill()
    elif cmd == "focus":
        setup_logging("WARNING")
        return _cmd_focus()
    elif cmd == "movewin":
        setup_logging("WARNING")
        return _cmd_movewin()
    # По умолчанию (без подкоманды или run) — запускаем сервер.
    cfg = _load_config(args)
    setup_logging(args.log_level, log_to_file=cfg.log_to_file, log_file=cfg.log_file)
    log.info("HyprScreen %s запускается с конфигом: %s", __version__, cfg.to_dict())
    try:
        return asyncio.run(_run(cfg, create_outputs=not args.no_virtual_output))
    except KeyboardInterrupt:
        return 130
    except asyncio.CancelledError:
        return 130
    except Exception as exc:  # noqa: BLE001
        log.error("фатальная ошибка: %s", exc, exc_info=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
