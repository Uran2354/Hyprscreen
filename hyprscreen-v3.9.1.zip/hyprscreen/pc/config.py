"""Конфигурация HyprScreen 3.9.1 (TOML).

Логика: зеркало ЗАКРЕПЛЁННОГО ВОРКСПЕЙСА Hyprland (по умолчанию №6) на
телефон/планшет:

* видео — HTTP MJPEG-поток (только просмотр, без ввода указателя);
* клавиатура — POST /key и /text -> wtype (тап по экрану в приложении);
* discovery — UDP-анонсы :8766, чтобы приложение находило PC само.

Воркспейс — это воркспейс Hyprland (1..10), ЗАКРЕПЛЁННЫЙ за телефоном.
С 3.9.0 он переезжает на ВИРТУАЛЬНЫЙ монитор (`hyprctl output create
headless` — официальный рецепт Hyprland для стримов) и рендерится там
ВСЕГДА: кадры на телефоне живые всегда, физические экраны ПК свободно
переключаются, чужие воркспейсы в поток не попадают (пауз 3.8.1 больше
нет). Клавиатура с телефона перед вводом передаёт фокус на виртуальный
монитор и возвращает фокус обратно после ввода (экран ПК не трогается).
Можно выбрать и весь монитор по имени (monitor, workspace = 0, без
закрепления). Тачпада из экрана телефона НЕТ, хоткеев НЕТ.
На старых Hyprland (без `output create`) — автоматический fallback
в поведение 3.8.1 (пауза при переключении на ПК).
Конфиг лежит рядом с main.py (pc/config.toml); пример — config.toml.example.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field

__version__ = "3.9.1"

#: Пресеты FPS-режима (как в 2.2.0): fps / качество JPEG / масштаб кадра.
#: «auto» ведёт себя как balance, но луп захвата сам замедляется, если grim
#: не успевает (кадр просто не отправляется чаще, чем успевает захват).
FPS_MODE_PRESETS: dict[str, dict[str, float]] = {
    "eco":     {"fps": 12, "jpeg_quality": 60, "scale": 0.60},
    "balance": {"fps": 24, "jpeg_quality": 75, "scale": 0.75},
    "smooth":  {"fps": 30, "jpeg_quality": 80, "scale": 1.00},
    "max":     {"fps": 60, "jpeg_quality": 85, "scale": 1.00},
}

#: auto = balance + естественная адаптация под скорость захвата.
FPS_MODES: tuple[str, ...] = ("auto", "eco", "balance", "smooth", "max", "custom")

#: Номер воркспейса Hyprland по умолчанию (1..10).
DEFAULT_WORKSPACE = 6
#: Номер экрана из `hyprscreen monitors` — устаревший fallback (если
#: workspace = 0). Держим для совместимости старых config.toml.
DEFAULT_MONITOR_INDEX = 6
#: Порт HTTP MJPEG-сервера по умолчанию.
DEFAULT_PORT = 8080
#: Порт UDP-discovery (слушает Discovery.kt на телефоне).
DEFAULT_DISCOVERY_PORT = 8766


#: Ошибка ПОСЛЕДНЕГО чтения config.toml (не None — файл есть, но не читается).
#: CLI/GUI показывают её пользователю ВМЕСТО молчаливого сброса в дефолты
#: (раньше битый TOML «проглатывался», и все настройки молча игнорировались).
LAST_LOAD_ERROR: str | None = None


def clamp_workspace(value: int) -> int:
    """0 = показывать весь монитор (monitor/monitor_index); иначе воркспейс."""
    return max(0, min(99, int(value)))


def clamp_monitor_index(value: int) -> int:
    return max(1, min(64, int(value)))


def clamp_port(value: int) -> int:
    return max(1024, min(65535, int(value)))


def clamp_fps(value: int) -> int:
    return max(1, min(120, int(value)))


def clamp_quality(value: int) -> int:
    return max(10, min(100, int(value)))


def clamp_scale(value: float) -> float:
    return max(0.2, min(1.0, float(value)))


@dataclass
class Config:
    """Все настройки PC-стороны (config.toml + флаги CLI)."""

    workspace: int = DEFAULT_WORKSPACE  # воркспейс Hyprland (0 = весь монитор)
    monitor: str = ""                  # имя монитора (если workspace = 0)
    monitor_index: int = DEFAULT_MONITOR_INDEX
    port: int = DEFAULT_PORT
    bind_address: str = "0.0.0.0"

    fps_mode: str = "auto"             # auto|eco|balance|smooth|max|custom
    fps: int = 24
    jpeg_quality: int = 75
    scale: float = 0.75

    auth_token: str | None = None
    discovery_enabled: bool = True
    discovery_port: int = DEFAULT_DISCOVERY_PORT
    keyboard_enabled: bool = True      # POST /key и /text (wtype)
    input_rate_limit: int = 0          # событий клавиатуры/сек (0 = без лимита)

    notifications: bool = True
    log_to_file: bool = True
    log_file: str | None = None

    extra: dict = field(default_factory=dict)

    # --------------------------------------------------------------- пресеты
    def apply_fps_mode(self) -> None:
        """Пресет лочит fps/quality/scale; custom/auto оставляет значения."""
        preset = FPS_MODE_PRESETS.get(self.fps_mode)
        if preset:
            self.fps = int(preset["fps"])
            self.jpeg_quality = int(preset["jpeg_quality"])
            self.scale = float(preset["scale"])

    def effective(self) -> "Config":
        """Копия с применённым пресетом FPS (для запуска сервера)."""
        cfg = Config(**{k: v for k, v in self.__dict__.items() if k != "extra"})
        cfg.extra = dict(self.extra)
        cfg.apply_fps_mode()
        return cfg

    # ------------------------------------------------------------------ TOML
    def to_dict(self) -> dict:
        data = {
            "workspace": clamp_workspace(self.workspace),
            "monitor": self.monitor,
            "monitor_index": clamp_monitor_index(self.monitor_index),
            "port": clamp_port(self.port),
            "bind_address": self.bind_address,
            "fps_mode": self.fps_mode,
            "fps": clamp_fps(self.fps),
            "jpeg_quality": clamp_quality(self.jpeg_quality),
            "scale": clamp_scale(self.scale),
            "discovery_enabled": bool(self.discovery_enabled),
            "discovery_port": clamp_port(self.discovery_port),
            "keyboard_enabled": bool(self.keyboard_enabled),
            "input_rate_limit": max(0, int(self.input_rate_limit)),
            "notifications": bool(self.notifications),
            "log_to_file": bool(self.log_to_file),
        }
        if self.auth_token:
            data["auth_token"] = self.auth_token
        if self.log_file:
            data["log_file"] = self.log_file
        return data

    def to_toml_string(self) -> str:
        def q(v: str) -> str:
            return '"' + v.replace("\\", "\\\\").replace('"', '\\"') + '"'

        d = self.to_dict()
        lines = ["# HyprScreen 3.9.1 — сохранено GUI/CLI", ""]
        for key, value in d.items():
            if isinstance(value, bool):
                lines.append(f"{key} = {'true' if value else 'false'}")
            elif isinstance(value, str):
                lines.append(f"{key} = {q(value)}")
            elif isinstance(value, float):
                lines.append(f"{key} = {value}")
            else:
                lines.append(f"{key} = {value}")
        return "\n".join(lines) + "\n"

    def save(self, path: str | os.PathLike) -> None:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(self.to_toml_string())

    # ------------------------------------------------------------------ load
    @staticmethod
    def _load_toml(path: str | os.PathLike) -> dict:
        global LAST_LOAD_ERROR
        try:
            import tomllib  # Python 3.11+
        except ImportError:  # pragma: no cover
            try:
                import tomli as tomllib  # type: ignore
            except ImportError:
                return {}
        try:
            with open(path, "rb") as fh:
                return tomllib.load(fh)
        except FileNotFoundError:
            return {}
        except Exception as exc:
            # Битый TOML больше НЕ «молчит»: фиксируем текст ошибки —
            # CLI/GUI при старте сервера покажут её и НЕ будут использовать
            # полу-дефолтный конфиг вместо пользовательского.
            LAST_LOAD_ERROR = f"{exc}"
            return {}

    @classmethod
    def from_file(cls, path: str | os.PathLike) -> "Config":
        cfg = cls()
        raw = cls._load_toml(path)
        section = raw.get("hyprscreen") if isinstance(raw.get("hyprscreen"), dict) else raw
        if not isinstance(section, dict):
            section = {}
        g = section.get

        if isinstance(g("workspace"), int):
            cfg.workspace = clamp_workspace(g("workspace"))
        if isinstance(g("monitor"), str):
            cfg.monitor = g("monitor").strip()
        if isinstance(g("monitor_index"), int):
            cfg.monitor_index = clamp_monitor_index(g("monitor_index"))
        if isinstance(g("port"), int):
            cfg.port = clamp_port(g("port"))
        if isinstance(g("bind_address"), str) and g("bind_address").strip():
            cfg.bind_address = g("bind_address").strip()

        if isinstance(g("fps_mode"), str) and g("fps_mode") in FPS_MODES:
            cfg.fps_mode = g("fps_mode")
        if isinstance(g("fps"), int):
            cfg.fps = clamp_fps(g("fps"))
        if isinstance(g("jpeg_quality"), int):
            cfg.jpeg_quality = clamp_quality(g("jpeg_quality"))
        if isinstance(g("scale"), (int, float)):
            cfg.scale = clamp_scale(g("scale"))

        if isinstance(g("auth_token"), str) and g("auth_token").strip():
            cfg.auth_token = g("auth_token").strip()
        if isinstance(g("discovery_enabled"), bool):
            cfg.discovery_enabled = g("discovery_enabled")
        if isinstance(g("discovery_port"), int):
            cfg.discovery_port = clamp_port(g("discovery_port"))
        if isinstance(g("keyboard_enabled"), bool):
            cfg.keyboard_enabled = g("keyboard_enabled")
        if isinstance(g("input_rate_limit"), int):
            cfg.input_rate_limit = max(0, g("input_rate_limit"))
        if isinstance(g("notifications"), bool):
            cfg.notifications = g("notifications")
        if isinstance(g("log_to_file"), bool):
            cfg.log_to_file = g("log_to_file")
        if isinstance(g("log_file"), str) and g("log_file").strip():
            cfg.log_file = g("log_file").strip()

        cfg.extra = {k: v for k, v in section.items()
                     if k not in cfg.to_dict() and k != "auth_token"}
        return cfg
