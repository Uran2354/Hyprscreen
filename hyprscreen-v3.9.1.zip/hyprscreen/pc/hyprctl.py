"""Обёртка над hyprctl для HyprScreen.

С 3.9.0 закреплённый воркспейс переезжает на ВИРТУАЛЬНЫЙ монитор
(`hyprctl output create headless` — официальный рецепт для VNC/RDP/
Sunshine-стримов): там он рендерится ВСЕГДА, поэтому телефон показывает
живые кадры независимо от того, что происходит на экранах ПК.
Здесь и примитивы для этого: создание/удаление headless-вывода,
правило монитора (разрешение/частота), moveworkspacetomonitor.
Плюс базовое: список мониторов, разрешение, восстановление окружения
Wayland для systemd/ssh-запусков, поиск забытых HEADLESS-выводов.

С 3.9.1 dispatch работает в ОБОИХ мирах: классический .conf шлёт
`hyprctl dispatch NAME ARGS` как раньше, а Hyprland 0.55+ с Lua-конфигом
(configProvider: lua; CachyOS/Arch bleeding edge) исполняет payload
`dispatch` как LUA-код — там диспетчеры вызываются через
`hyprctl eval 'hl.dispatch(hl.dsp....)'` (официальный синтаксис вики
«Using hyprctl»). Детект — один раз по `hyprctl systeminfo`.
"""

from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess


def have(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def fix_env() -> None:
    """Восстановить окружение Wayland-сессии (systemd/ssh/tmux запуски).

    Если HYPRLAND_INSTANCE_SIGNATURE пуст — читаем его из /proc/<Hyprland>/environ;
    если WAYLAND_DISPLAY пуст — берём первый сокет wayland-* из XDG_RUNTIME_DIR.
    """
    uid = os.getuid()
    runtime_dir = os.environ.get("XDG_RUNTIME_DIR", f"/run/user/{uid}")

    if not os.environ.get("HYPRLAND_INSTANCE_SIGNATURE"):
        try:
            out = subprocess.run(
                ["pgrep", "-u", str(uid), "-x", "Hyprland"],
                capture_output=True, text=True, timeout=5,
            )
            pid = out.stdout.strip().splitlines()
            if pid and os.access(f"/proc/{pid[0]}/environ", os.R_OK):
                with open(f"/proc/{pid[0]}/environ", "rb") as fh:
                    for chunk in fh.read().split(b"\0"):
                        if chunk.startswith(b"HYPRLAND_INSTANCE_SIGNATURE="):
                            os.environ["HYPRLAND_INSTANCE_SIGNATURE"] = (
                                chunk.split(b"=", 1)[1].decode("utf-8", "replace")
                            )
                            break
        except Exception:  # noqa: BLE001 — best-effort
            pass

    if not os.environ.get("WAYLAND_DISPLAY"):
        try:
            for name in sorted(os.listdir(runtime_dir)):
                if name.startswith("wayland-") and os.path.isdir(
                    os.path.join(runtime_dir, name)
                ) is False:
                    os.environ["WAYLAND_DISPLAY"] = name
                    break
        except OSError:
            pass


def socket2_path() -> str:
    """Путь к IPC-сокету Hyprland ``.socket2.sock`` ('' — сессии нет).

    Сокет отдаёт события COMPOSITOR-а (``workspace>>``, ``focusedmon>>`` …) —
    WorkspaceWatch (capture.py) использует их для мгновенной реакции на
    переключение воркспейса на ПК (закрепление, 3.8.1).
    """
    his = os.environ.get("HYPRLAND_INSTANCE_SIGNATURE", "")
    if not his:
        fix_env()  # systemd/ssh/tmux-запуски — восстановим окружение
        his = os.environ.get("HYPRLAND_INSTANCE_SIGNATURE", "")
    if not his:
        return ""
    runtime = os.environ.get("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
    path = os.path.join(runtime, "hypr", his, ".socket2.sock")
    return path if os.path.exists(path) else ""


def hyprctl(args: list[str], timeout: float = 6.0) -> tuple[int, str, str]:
    """Запустить hyprctl; вернуть (rc, stdout, stderr). Пустой вывод при ошибке."""
    if not have("hyprctl"):
        return 127, "", "hyprctl не найден (pacman -S hyprland)"
    try:
        proc = subprocess.run(
            ["hyprctl", *args], capture_output=True, text=True, timeout=timeout
        )
        return proc.returncode, proc.stdout, proc.stderr
    except (OSError, subprocess.TimeoutExpired) as exc:
        return 1, "", str(exc)


# ---------------------------------------------------------------- dispatch --
#: True/False — конфигурация Hyprland (Lua или классика); None — не определена.
#: Определяется один раз (`hyprctl systeminfo`) и живёт до конца процесса:
#: конфиг не меняется БЕЗ перезапуска Hyprland, а после перезапуска
#: WorkspaceWatch всё равно пересоздаёт закрепление (ошибка детекта
#: самолечится через fallback-попытку в _dispatch).
_LUA_PROVIDER: bool | None = None


def _detect_lua_provider() -> bool:
    """True — Hyprland с Lua-конфигом (configProvider: lua, 0.55+).

    У такого Hyprland ЛЮБОЙ payload `hyprctl dispatch <строка>` оборачивается
    в `return hl.dispatch(<строка>)` и исполняется как Lua: старый синтаксис
    `dispatch workspace 5` даёт ошибку `')' expected near '5'` (CachyOS/
    Arch 0.55+, ломало ВСЁ закрепление — «сигнал не приходит на телефон»).
    `systeminfo` — безопасное чтение без побочных эффектов; на старых
    Hyprland команды нет (rc != 0) — значит, классика.
    """
    global _LUA_PROVIDER
    if _LUA_PROVIDER is None:
        rc, out, _err = hyprctl(["systeminfo"], timeout=6.0)
        _LUA_PROVIDER = rc == 0 and "configprovider: lua" in out.lower()
    return _LUA_PROVIDER


def _lua_str(value: str) -> str:
    """Строка в виде Lua-литерала (имена мониторов безопасны, но страхуемся)."""
    return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"') + '"'


def _dispatch(lua_expr: str, legacy_args: list[str]) -> tuple[bool, str]:
    """Выполнить dispatcher в синтаксисе ТЕКУЩЕЙ конфигурации Hyprland.

    Hyprland 0.55+ с Lua-конфигом (configProvider: lua) исполняет payload
    `dispatch` как Lua — работает только Lua-форма:
    `hyprctl eval 'hl.dispatch(hl.dsp.focus({ workspace = "5" }))'`
    (официальный синтаксис вики «Using hyprctl»). Классический .conf
    работает как раньше: `hyprctl dispatch workspace 5`.

    Порядок попыток определяется детектом (`systeminfo`); если детект
    ошибся, характерная Lua-ошибка «hl.dispatch» в stderr переключает
    кэш и выполняется вторая форма. Упавшая попытка боковых эффектов не
    имеет (ошибка разбора — ничего не выполнилось).

    Возвращает (успех, stderr-подробность при неудаче).
    """
    global _LUA_PROVIDER
    lua_args = ["eval", f"hl.dispatch({lua_expr})"]
    legacy = ["dispatch", *legacy_args]
    plan = ([lua_args, legacy] if _detect_lua_provider() else [legacy, lua_args])
    detail = ""
    for args in plan:
        is_lua = args[0] == "eval"
        rc, out, err = hyprctl(args)
        if rc == 0:
            _LUA_PROVIDER = is_lua
            return True, ""
        detail = (err or out or "").strip() or f"hyprctl вернул код {rc}"
        if not is_lua and "hl.dispatch" in detail:
            # legacy-форма упала с Lua-ошибкой — детект ошибся, кэш вправляем
            _LUA_PROVIDER = True
    return False, detail


def monitors_json() -> list[dict]:
    """Список мониторов из `hyprctl -j monitors` (пустой список при сбое)."""
    rc, out, _ = hyprctl(["-j", "monitors"])
    if rc != 0 or not out.strip():
        return []
    try:
        data = json.loads(out)
        return data if isinstance(data, list) else []
    except json.JSONDecodeError:
        return []


def monitor_names() -> list[str]:
    """Имена мониторов в порядке `hyprctl monitors` (1-based индексация CLI)."""
    data = monitors_json()
    if data:
        return [str(m.get("name", "")) for m in data if m.get("name")]
    # Fallback без JSON: строки "Monitor DP-3 (...)"
    _, out, _ = hyprctl(["monitors"])
    names = []
    for line in out.splitlines():
        if line.startswith("Monitor "):
            names.append(line.split()[1])
    return names


def monitor_at_index(n: int) -> str | None:
    """Имя монитора по номеру (1-based) или None."""
    names = monitor_names()
    if 1 <= n <= len(names):
        return names[n - 1]
    return None


def workspaces_json() -> list[dict]:
    """Открытые воркспейсы из `hyprctl -j workspaces` (пустой список при сбое)."""
    rc, out, _ = hyprctl(["-j", "workspaces"])
    if rc != 0 or not out.strip():
        return []
    try:
        data = json.loads(out)
        return data if isinstance(data, list) else []
    except json.JSONDecodeError:
        return []


def workspace_monitor(ws: int) -> str | None:
    """Монитор, на котором СЕЙЧАС открыт воркспейс ws, или None.

    Воркспейс в Hyprland всегда живёт на каком-то мониторе — зеркалим
    именно этот монитор (grim снимает монитор целиком).
    """
    for w in workspaces_json():
        try:
            if int(w.get("id", -1)) == int(ws):
                mon = str(w.get("monitor", "") or "")
                return mon or None
        except (TypeError, ValueError):
            continue
    return None


def open_workspace_numbers() -> list[int]:
    """Номера ОТКРЫТЫХ воркспейсов (для селекторов GUI/подсказок CLI)."""
    nums: set[int] = set()
    for w in workspaces_json():
        try:
            n = int(w.get("id", 0))
        except (TypeError, ValueError):
            continue
        if n > 0:
            nums.add(n)
    return sorted(nums)


def monitor_active_workspace(name: str) -> int:
    """Номер АКТИВНОГО воркспейса на мониторе name (0 — не удалось)."""
    for m in monitors_json():
        if str(m.get("name")) == name:
            try:
                return int((m.get("activeWorkspace") or {}).get("id", 0))
            except (TypeError, ValueError):
                return 0
    return 0


def monitor_active_workspaces() -> dict[str, int]:
    """{имя монитора: активный воркспейс} — ОДНА команда hyprctl.

    WorkspaceWatch опрашивает это несколько раз в секунду: один вызов
    вместо двух (monitors + workspaces) заметно дешевле.
    """
    result: dict[str, int] = {}
    for m in monitors_json():
        name = str(m.get("name") or "")
        if not name:
            continue
        try:
            result[name] = int((m.get("activeWorkspace") or {}).get("id", 0))
        except (TypeError, ValueError):
            result[name] = 0
    return result


def monitor_size(name: str) -> tuple[int, int, int, float]:
    """(ширина, высота, Гц, масштаб) монитора name (дефолты — если не найден)."""
    for m in monitors_json():
        if str(m.get("name")) == name:
            try:
                w = int(m.get("width") or 1920)
                h = int(m.get("height") or 1080)
            except (TypeError, ValueError):
                w, h = 1920, 1080
            try:
                hz = int(float(m.get("refreshRate") or 60))
            except (TypeError, ValueError):
                hz = 60
            try:
                scale = float(m.get("scale") or 1)
            except (TypeError, ValueError):
                scale = 1.0
            return w, h, hz, scale
    return 1920, 1080, 60, 1.0


def focused_monitor() -> str:
    """Имя монитора, где сейчас фокус (пустая строка — не удалось)."""
    for m in monitors_json():
        if m.get("focused"):
            name = str(m.get("name") or "")
            if name:
                return name
    names = monitor_names()
    return names[0] if names else ""


def switch_workspace(ws: int, monitor: str) -> tuple[bool, str]:
    """Сделать воркспейс ws АКТИВНЫМ на мониторе monitor (best effort).

    С 3.9.0 используется только в FALLBACK-режиме (старые Hyprland без
    `output create`) и перед переездом воркспейса на виртуальный монитор.
    Возвращает (успех, человекочитаемое сообщение). Ничего не ломает,
    если hyprctl недоступен (сервер всё равно начнёт трансляцию).
    """
    ws = int(ws or 0)
    monitor = (monitor or "").strip()
    if ws <= 0 or not monitor:
        return True, ""
    active = monitor_active_workspace(monitor)
    if active == ws:
        return True, f"воркспейс №{ws} уже активен на {monitor}"
    if monitor != focused_monitor():
        # dispatch workspace действует на монитор С ФОКУСОМ — наводим
        # фокус на целевой монитор (фокус возвращается пользователю
        # обычным кликом; сам кадр на ПК переключится на выбранный
        # воркспейс — это и есть смысл «Воркспейс для показа»).
        focus_monitor(monitor)
    ok, err = _dispatch(
        f'hl.dsp.focus({{ workspace = "{ws}" }})',
        ["workspace", str(ws)])
    ok = ok and monitor_active_workspace(monitor) == ws
    if ok:
        return True, f"монитор {monitor} переключён на воркспейс №{ws}"
    detail = (err or "").strip() or "hyprctl не подтвердил переключение"
    return False, (f"не удалось переключить {monitor} на воркспейс "
                   f"№{ws}: {detail}")


def monitor_resolution(name: str) -> str:
    """Строка 'WxH @ NHz' для монитора ('' если не найден)."""
    for m in monitors_json():
        if str(m.get("name")) == name:
            try:
                hz = int(float(m.get("refreshRate", 0)))
            except (TypeError, ValueError):
                hz = 0
            return f"{m.get('width', '?')}x{m.get('height', '?')} @ {hz}Hz"
    return ""


def monitors_display() -> list[str]:
    """Строки 'N: NAME — WxH @ Hz' для CLI/GUI."""
    lines = []
    for i, name in enumerate(monitor_names(), start=1):
        res = monitor_resolution(name)
        lines.append(f"{i}: {name}" + (f" — {res}" if res else ""))
    return lines


def create_headless(name: str) -> tuple[bool, str]:
    """Создать ВИРТУАЛЬНЫЙ монитор (headless output) с именем name.

    Официальный способ из вики Hyprland (`hyprctl output create headless
    test`), рекомендуется самим Hyprland для VNC/RDP/Sunshine-стримов.
    Пустой name → Hyprland сам придумает имя (HEADLESS-1 и т.п.).
    """
    args = ["output", "create", "headless"]
    if (name or "").strip():
        args.append(name.strip())
    rc, out, err = hyprctl(args)
    if rc == 0:
        return True, ""
    detail = (err or out or "").strip() or f"hyprctl вернул код {rc}"
    return False, detail


def keyword_monitor(name: str, mode: str, position: str,
                    scale: float) -> bool:
    """Правило монитора на лету: `hyprctl keyword monitor NAME,MODE,POS,SCALE`.

    Нужна для headless-вывода: без него Hyprland создаёт его с частотой
    ~0.06 Гц — клиенты (браузер, видео) троттлят отрисовку до слайдшоу.
    Runtime-правило, в конфиг НЕ записывается.
    """
    rule = f"{name},{mode},{position},{scale:g}"
    rc, _, _ = hyprctl(["keyword", "monitor", rule])
    return rc == 0


def move_workspace_to_monitor(ws: int, monitor: str) -> tuple[bool, str]:
    """Перегнать воркспейс ws на монитор monitor с верификацией (best effort).

    Lua-эквивалент (0.55+) — `hl.dsp.workspace.move({ workspace, monitor })`,
    классика — `dispatch moveworkspacetomonitor N MON`.
    ВНИМАНИЕ (исходники Hyprland): воркспейс становится АКТИВНЫМ на новом
    мониторе только если был активен на старом. Если был неактивен —
    просто переезжает. Возвращает (успех, сообщение).
    """
    ws = int(ws or 0)
    monitor = (monitor or "").strip()
    if ws <= 0 or not monitor:
        return False, "пустой воркспейс или монитор"
    ok, err = _dispatch(
        f"hl.dsp.workspace.move({{ workspace = \"{ws}\", "
        f"monitor = {_lua_str(monitor)} }})",
        ["moveworkspacetomonitor", f"{ws} {monitor}"])
    if not ok:
        return False, err
    if workspace_monitor(ws) == monitor:
        return True, ""
    return False, "воркспейс не переехал (проверьте, существует ли он)"


def focus_monitor(name: str) -> bool:
    """`focusmonitor NAME` (Lua: `hl.dsp.focus({ monitor = ... })`)."""
    if not (name or "").strip():
        return False
    ok, _err = _dispatch(
        f"hl.dsp.focus({{ monitor = {_lua_str(name.strip())} }})",
        ["focusmonitor", name.strip()])
    return ok


def dispatch_workspace(ws: int) -> bool:
    """`dispatch workspace N` — активировать воркспейс на его мониторе.

    Если воркспейс живёт на ДРУГОМ мониторе (например на headless),
    Hyprland НЕ крадёт его на фокусируемый экран, а активирует на
    мониторе-владельце (и передаёт туда фокус) — проверено по исходникам
    CKeybindManager::changeworkspace. Используется для создания нового
    воркспейса и повторной активации закреплённого.
    """
    ws = int(ws or 0)
    if ws <= 0:
        return False
    ok, _err = _dispatch(
        f'hl.dsp.focus({{ workspace = "{ws}" }})',
        ["workspace", str(ws)])
    return ok


def physical_monitors() -> list[str]:
    """Только ФИЗИЧЕСКИЕ мониторы (без HEADLESS-* виртуальных)."""
    return [n for n in monitor_names() if not n.startswith("HEADLESS-")]


def headless_monitors() -> list[str]:
    """HEADLESS-* выводы (наши + остатки старых версий) — для cleanup."""
    return [n for n in monitor_names() if n.startswith("HEADLESS-")]


def remove_output(name: str) -> bool:
    rc, _, _ = hyprctl(["output", "remove", name])
    return rc == 0


def lan_ip() -> str:
    """IPv4 этого PC в LAN (UDP-трюк, без реальной отправки пакетов)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.settimeout(0.5)
        s.connect(("8.8.8.8", 80))
        return str(s.getsockname()[0])
    except OSError:
        pass
    finally:
        s.close()
    # Fallback: ip route. ВАЖНО: берём адрес ПОСЛЕ ключа src — первый
    # токен строки это ЦЕЛЬ (1.1.1.1), он раньше мог вернуться как «IP ПК».
    try:
        out = subprocess.run(
            ["ip", "-4", "route", "get", "1.1.1.1"],
            capture_output=True, text=True, timeout=3,
        )
        tokens = out.stdout.split()
        if "src" in tokens:
            return tokens[tokens.index("src") + 1]
    except Exception:  # noqa: BLE001
        pass
    return ""
