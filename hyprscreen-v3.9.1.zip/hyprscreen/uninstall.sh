#!/usr/bin/env bash
# HyprScreen 3.9.1 — удаление
set -euo pipefail

echo "— Удаление hyprscreen —"

# 1. Выключить запущенный экземпляр и подчистить
if command -v hyprscreen >/dev/null 2>&1; then
  hyprscreen off >/dev/null 2>&1 || true
  hyprscreen cleanup >/dev/null 2>&1 || true
fi

# 2. Файлы
rm -f "$HOME/.local/bin/hyprscreen" 2>/dev/null || true
rm -f /usr/local/bin/hyprscreen    2>/dev/null || true
rm -rf "$HOME/.local/share/hyprscreen" && echo "✅ удалена программа (pc/, venv)" || true
rm -rf /usr/local/share/hyprscreen    2>/dev/null || true
rm -rf "${XDG_CONFIG_HOME:-$HOME/.config}/quickshell/hyprscreen" \
  && echo "✅ удалены quickshell-виджеты" || true
rm -rf "${XDG_CACHE_HOME:-$HOME/.cache}/hyprscreen" && echo "✅ удалены состояние и логи сервера" || true
rm -rf "$HOME/.local/state/hyprscreen" 2>/dev/null || true   # остатки 3.0/3.1

# 3. Бинды старых версий (v2.x) и конфиг
if [[ -f "$HOME/.config/hypr/hyprscreen.conf" ]]; then
  rm -f "$HOME/.config/hypr/hyprscreen.conf" && echo "✅ удалён файл биндов старой версии" || true
  HYPRLAND_CONF="$HOME/.config/hypr/hyprland.conf"
  if [[ -f "$HYPRLAND_CONF" ]] && grep -q "hypr/hyprscreen.conf" "$HYPRLAND_CONF"; then
    sed -i '/hypr\/hyprscreen\.conf/d' "$HYPRLAND_CONF"
    echo "✅ source биндов убран из hyprland.conf"
  fi
fi

if [[ "${1:-}" == "--purge" ]]; then
  rm -rf "${XDG_CONFIG_HOME:-$HOME/.config}/hyprscreen" \
    && echo "✅ удалён конфиг и настройки" || true
  rm -f "$HOME/.local/share/hyprscreen/pc/config.toml" 2>/dev/null || true
else
  echo "ℹ️  конфиг сохранён (~/.config/hyprscreen). Для полного удаления: ./uninstall.sh --purge"
fi

echo "Готово."
