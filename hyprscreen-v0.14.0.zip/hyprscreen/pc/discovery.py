"""UDP discovery-бродкастер для HyprScreen.

Android-клиент (:file:`Discovery.kt`) слушает UDP-порт 8766 и ожидает
датаграммы вида::

    {"hyprscreen":true,"host":"192.168.1.42","port":8765,"screens":2,"name":"cachyos-pc"}

Этот модуль реализует PC-сторону: :class:`DiscoveryBroadcaster` каждые 2
секунды отправляет такую датаграмму на адрес подсети broadcast (или на
``255.255.255.255``, если подсеть вычислить не удалось).

Сокет создаётся с ``SO_BROADCAST``, отправка идёт в рабочем потоке через
:func:`asyncio.to_thread`, чтобы не блокировать event loop.
"""

from __future__ import annotations

import asyncio
import json
import logging
import socket
import time
from typing import Any, Optional

from config import Config

log = logging.getLogger(__name__)

BROADCAST_INTERVAL_SEC: float = 2.0

#: Предупреждения о сбоях отправки пишутся не чаще раза в минуту
#: (0.13.2: при сбитой сети цикл шлёт раз в 2 с — предупреждение на
#: каждую попытку заполняло лог бесконечным спамом).
_WARN_MIN_INTERVAL: float = 60.0
_last_net_warn: float = 0.0


def _warn_throttled(msg: str, *args: Any) -> None:
    """log.warning, но не чаще раза в ``_WARN_MIN_INTERVAL`` секунд."""
    global _last_net_warn
    now = time.monotonic()
    if now - _last_net_warn >= _WARN_MIN_INTERVAL:
        _last_net_warn = now
        log.warning(msg, *args)


def _detect_lan_ip() -> str:
    """Определить IPv4-адрес этого PC в LAN.

    Трюк: открываем UDP-сокет и «подключаемся» к публичному IP — ядро
    выбирает src-адрес маршрута. Ничего реально не отправляется.
    Возвращает ``"127.0.0.1"`` в крайнем случае.
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        try:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
        except OSError:
            return "127.0.0.1"
    finally:
        s.close()


def _detect_broadcast_address() -> str:
    """Вычислить адрес подсети broadcast для первого non-loopback интерфейса.

    Если интерфейсов нет или не удалось вычислить маску, возвращаем
    ограниченный broadcast ``255.255.255.255``.
    """
    try:
        hostname = socket.gethostname()
        # gethostbyname_ex возвращает (hostname, aliases, list_of_ips)
        info = socket.gethostbyname_ex(hostname)
        ips = info[2] if info and len(info) > 2 else []
    except OSError:
        ips = []
    if not ips:
        # Запасной трюк: тот же UDP-connect.
        ip = _detect_lan_ip()
        ips = [ip]

    # Простой расчёт: берём первый non-loopback IP и считаем broadcast для /24.
    # (мёртвый блок опциональной библиотеки сетевых адаптеров удалён —
#  она никогда не ставилась requirements.txt).
    for ip in ips:
        if ip.startswith("127."):
            continue
        parts = ip.split(".")
        if len(parts) != 4:
            continue
        # Предполагаем /24 — типичный домашний роутер.
        # broadcast = network | ~mask = (ip & 0xFFFFFF00) | 0xFF
        return f"{parts[0]}.{parts[1]}.{parts[2]}.255"

    # Последний рубеж — ограниченный broadcast.
    return "255.255.255.255"


class DiscoveryBroadcaster:
    """UDP-бродкастер, рассылающий анонс HyprScreen каждые 2 секунды.

    Использование::

        bcast = DiscoveryBroadcaster(cfg, screens=2)
        await bcast.start()
        ...
        await bcast.stop()

    Запуск идёт в фоновой asyncio-задаче; отправка — в рабочем потоке,
    чтобы не блокировать event loop.
    """

    def __init__(self, config: Config, screens: int) -> None:
        self.config = config
        self.screens = int(screens)
        self._task: Optional[asyncio.Task[None]] = None
        self._sock: Optional[socket.socket] = None
        self._broadcast_addr: str = ""
        self._host_ip: str = ""
        self._host_name: str = config.host_name or _default_hostname()
        self._stopped = asyncio.Event()

    async def start(self) -> None:
        """Открыть сокет и запустить фоновую задачу рассылки."""
        if self._task is not None:
            return  # уже запущен
        # Вычисляем адреса в потоке — gethostbyname_ex может блокировать.
        self._host_ip = await asyncio.to_thread(_detect_lan_ip)
        self._broadcast_addr = await asyncio.to_thread(_detect_broadcast_address)
        self._sock = await asyncio.to_thread(self._open_socket)
        log.info(
            "UDP discovery: host=%s broadcast=%s port=%d screens=%d name=%s",
            self._host_ip, self._broadcast_addr, self.config.discovery_port,
            self.screens, self._host_name,
        )
        self._stopped.clear()
        self._task = asyncio.create_task(self._loop(), name="discovery-broadcast")

    def _open_socket(self) -> socket.socket:
        """Создать UDP-сокет с SO_BROADCAST. Запускается в потоке."""
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        return s

    def _send_once(self) -> None:
        """Сформировать датаграмму и отправить её. Запускается в потоке."""
        payload = {
            "hyprscreen": True,
            "host": self._host_ip,
            "port": int(self.config.port),
            "screens": int(self.screens),
            "name": self._host_name,
        }
        data = json.dumps(payload).encode("utf-8")
        try:
            if self._sock is not None:
                self._sock.sendto(
                    data, (self._broadcast_addr, int(self.config.discovery_port))
                )
        except OSError as exc:
            _warn_throttled("не удалось отправить discovery-датаграмму: %s", exc)

    async def _loop(self) -> None:
        """Цикл рассылки каждые BROADCAST_INTERVAL_SEC секунд."""
        try:
            while not self._stopped.is_set():
                try:
                    await asyncio.to_thread(self._send_once)
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # noqa: BLE001
                    _warn_throttled("ошибка в discovery-цикле: %s", exc)
                try:
                    await asyncio.wait_for(
                        self._stopped.wait(), timeout=BROADCAST_INTERVAL_SEC
                    )
                except asyncio.TimeoutError:
                    continue
                except asyncio.CancelledError:
                    raise
        except asyncio.CancelledError:
            log.info("discovery-бродкастер отменён")
            raise

    async def stop(self) -> None:
        """Остановить рассылку и закрыть сокет (идемпотентно)."""
        self._stopped.set()
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            except Exception as exc:  # noqa: BLE001
                log.warning("ошибка при остановке discovery-задачи: %s", exc)
            self._task = None
        if self._sock is not None:
            try:
                self._sock.close()
            except OSError:
                pass
            self._sock = None


def _default_hostname() -> str:
    """Получить имя хоста по умолчанию (для поля name в датаграмме)."""
    try:
        return socket.gethostname() or "hyprscreen-pc"
    except OSError:
        return "hyprscreen-pc"
