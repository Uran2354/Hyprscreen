"""Управление виртуальными headless-выходами Hyprland.

На CachyOS + Hyprland «вторым экраном» служит *headless*-вывод — виртуальный
монитор без физического дисплея. Телефон отображает захваченные кадры этого
вывода и отправляет ввод обратно в него.

Жизненный цикл одного вывода
----------------------------
1. ``hyprctl output create headless <WxH@rate>`` — создаёт вывод и возвращает
   его имя (например, ``HEADLESS-1``).
2. ``hyprctl monitors -j`` — подтверждает создание и читает координаты.
3. ``hyprctl keyword monitor <NAME>,<WxH@rate>,<x>x<y>,<scale>`` —
   позиционирует вывод справа от самого правого монитора, чтобы он не
   перекрывал реальные дисплеи.
4. При выходе: ``hyprctl output remove <NAME>``.

Этот модуль оборачивает всё это в :class:`VirtualOutput` (один вывод) и
:class:`VirtualOutputManager` (несколько выходов в ряд). Оба безопасно
используются через ``with`` и ``async with``.

Мультиэкранность
----------------
Менеджер создаёт N headless-выходов **последовательно**, после каждого
создания перевычитывает список мониторов — так выход N+1 позиционируется
справа от выхода N, а не от исходного снапшота (важный багфикс: старый
код считал ``x`` один раз по первому снапшоту и клал все выходы друг на
друга).
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

import hyprctl
from config import ScreenConfig

log = logging.getLogger(__name__)


class VirtualOutputError(RuntimeError):
    """Поднимается, когда виртуальный вывод не удалось создать/спозиционировать/удалить."""


def _compute_placement(monitors: list[dict[str, Any]]) -> tuple[int, int]:
    """Вычислить ``(x, y)`` для нового вывода так, чтобы он не перекрывал существующие.

    Стратегия: поместить новый вывод *справа* от самого правого существующего
    монитора на ``y=0``. ``x`` равен ``max(monitor.x + monitor.width)`` —
    новый вывод начинается ровно там, где заканчивается самый правый.
    """
    if not monitors:
        return (0, 0)
    rightmost_x = max(
        int(m.get("x", 0)) + int(m.get("width", 0)) for m in monitors
    )
    return (rightmost_x, 0)


def _find_headless_output(
    monitors: list[dict[str, Any]],
    expected_name: str | None,
    original_names: set[str],
) -> str:
    """Вернуть имя только что созданного headless-выхода.

    Hyprland называет headless-выходы ``HEADLESS-<N>`` (с 1). Если задано
    ``expected_name`` — ищем именно его. Иначе выбираем headless-выход,
    которого **не было** в ``original_names`` (снапшот до create).

    Это фикс прежнего бага: старая версия брала выход с максимальным
    trailing-номером, что ломалось при переиспользовании Hyprland'ом
    свободных индексов (например, создан ``HEADLESS-1``, а ``HEADLESS-2``
    остался от прошлой сессии — старый код возвращал существующий, а не
    новый).
    """
    candidates = [
        m for m in monitors if str(m.get("name", "")).startswith("HEADLESS")
    ]
    if expected_name:
        for m in candidates:
            if m.get("name") == expected_name:
                return str(m["name"])
        raise VirtualOutputError(
            f"ожидался headless-выход {expected_name!r}, но его нет в monitors: "
            f"{[m.get('name') for m in monitors]}"
        )
    # Предпочитаем тот, которого не было в original_names — это и есть новый.
    fresh = [m for m in candidates if str(m["name"]) not in original_names]
    if fresh:
        # Самый правый по X из свежих — обычно он один, но на всякий случай.
        fresh.sort(
            key=lambda m: (int(m.get("x", 0)), str(m.get("name", "")))
        )
        return str(fresh[-1]["name"])
    # Запасной вариант: самый большой индекс (последний созданный).
    if not candidates:
        raise VirtualOutputError(
            "нет ни одного HEADLESS-* вывода в `hyprctl monitors -j` после create"
        )

    def _idx(name: str) -> int:
        try:
            return int(str(name).split("-", 1)[1])
        except (ValueError, IndexError):
            return 0

    candidates.sort(key=lambda m: _idx(str(m["name"])))
    return str(candidates[-1]["name"])


class VirtualOutput:
    """Один виртуальный headless-вывод Hyprland: create/position/remove.

    Используется как контекстный менеджер::

        with VirtualOutput(screen_cfg) as vo:
            print(vo.name)  # например "HEADLESS-1"

    либо асинхронно::

        async with VirtualOutput(screen_cfg) as vo:
            ...
    """

    def __init__(self, config: ScreenConfig) -> None:
        self.config = config
        self.name: str | None = None
        self.x_offset: int = 0
        self._created: bool = False
        self._original_monitors: list[dict[str, Any]] = []
        self._original_names: set[str] = set()

    # -- создание / удаление --------------------------------------------

    def _refocus_real(self) -> None:
        """Вернуть фокус и курсор на физический монитор (best-effort).

        Compositor сам решает, кому отдать фокус после смены набора
        выводов (и при create, и при remove он часто выбирает наш
        headless). Без явного возврата пользователь видит пустой экран
        и «некликаемый» десктоп.
        """
        try:
            real = hyprctl.real_monitors()
            if not real:
                return
            hyprctl.focus_monitor(real[0])
            hyprctl.move_cursor_to_monitor(real[0])
        except Exception as exc:  # noqa: BLE001 - best-effort
            log.debug("возврат фокуса на физмонитор: %s", exc)

    def create(self, placement_monitors: list[dict[str, Any]] | None = None) -> str:
        """Создать headless-вывод и спозиционировать его. Возвращает имя.

        ``placement_monitors`` — опциональный список уже существующих
        мониторов, относительно которых считается позиция (используется
        менеджером, чтобы передавать обновлённый снапшот для каждого
        следующего вывода). Если ``None``, снимает снапшот сам.
        """
        # Снимаем снапшот существующих мониторов, чтобы: (а) найти новый
        # вывод после create, (б) знать, куда его положить.
        self._original_monitors = (
            placement_monitors if placement_monitors is not None else hyprctl.monitors()
        )
        self._original_names = {
            str(m.get("name", "")) for m in self._original_monitors
        }
        log.info(
            "существующие мониторы до create: %s",
            [m.get("name") for m in self._original_monitors],
        )

        mode = self.config.mode_string
        log.info("создаём headless-вывод (режим %s зададим через keyword)", mode)
        reply = hyprctl.output_create_headless()
        log.debug("ответ hyprctl output create headless: %s", reply)
        self._created = True
        # Hyprland отдаёт фокус только что созданному выводу — рабочий стол
        # пользователя «прыгает» на пустой экран. Возвращаем фокус и курсор
        # на физический монитор НЕМЕДЛЕННО (далее — позиционирование и
        # ожидание режима, всё это время десктоп должен оставаться своим).
        self._refocus_real()

        # АТОМАРНОСТЬ. Всё, что после ``output create``, идёт под
        # try/except: любая ошибка (в т.ч. NameError в
        # _wait_for_mode) теперь откатывает вывод — раньше исключение
        # уходило наверх, вывод ОСТАВАЛСЯ фантомным (не в mgr.outputs,
        # не в state.json — его не снимали ни повторный старт, ни kill),
        # отбирал фокус Hyprland и ломал рабочий стол до перезагрузки.
        try:
            # Считываем обновлённый список мониторов, чтобы найти имя нового.
            monitors = hyprctl.monitors()
            self.name = _find_headless_output(
                monitors, self.config.output_name, self._original_names
            )

            # Позиционируем справа от самого правого текущего монитора.
            # Берём именно обновлённый monitors (с уже созданным этим выводом),
            # но compute_placement смотрит на x+width всех, кроме самого нового —
            # это безопасно, т.к. новый без keyword'а лежит в (0,0) и его
            # ширина ещё не прибавляется к rightmost_x (Hyprland так не делает).
            # Для надёжности используем original_monitors — точно не заденем себя.
            x, y = _compute_placement(self._original_monitors)
            self.x_offset = x
            log.info(
                "позиционируем виртуальный вывод: %s → %s @ %s (%dx%d, scale 1)",
                self.name, mode, f"{x}x{y}", self.config.width, self.config.height,
            )
            try:
                # Dual-path (hl.monitor на 0.55+, keyword на старых).
                hyprctl.set_monitor_config(self.name, mode, x, y, 1.0)
            except hyprctl.HyprctlError as exc:
                # СБОЙ ПОЗИЦИОНИРОВАНИЯ — ФАТАЛЕН. Раньше писали
                # warning и «продолжали»: непозиционированный headless
                # оставался в (0,0) ПОВЕРХ физического монитора — перекрытие
                # выводов = «сломанный экран», некликабельный бар, фокус в
                # пустоте. Теперь откатываем вывод и роняем старт с ясной
                # ошибкой (сессия пользователя не страдает).
                raise VirtualOutputError(
                    f"не удалось спозиционировать {self.name} в {x}x{y} "
                    f"(режим {mode}): {exc}"
                ) from exc
            self._wait_for_mode()
        except Exception:
            self.remove()
            raise

        log.info(
            "виртуальный вывод готов: name=%s at (%d,%d) %s",
            self.name, x, y, mode,
        )
        return self.name

    def _wait_for_mode(self, timeout: float = 2.0) -> bool:
        """Дождаться применения запрошенного режима (best-effort).

        Раньше фактический режим читался сразу после keyword
        и на 0.55+ стабильно возвращались дефолтные 1920x1080 (keyword там
        не применяется). Теперь режим применяет ``hl.monitor``, а эта
        проверка подтверждает результат и пишет честный WARNING, если
        compositor его не принял.
        """
        want = (self.config.width, self.config.height)
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:
                mons = hyprctl.monitors()
            except hyprctl.HyprctlError as exc:
                log.debug("проверка режима %s: %s", self.name, exc)
                return False
            mon = next((m for m in mons if str(m.get("name", "")) == self.name), None)
            if mon is None:
                return False
            actual = (int(mon.get("width", 0)), int(mon.get("height", 0)))
            if actual == want:
                return True
            time.sleep(0.2)
        log.warning(
            "режим %s для %s не применился за %.1fs — будет использован фактический",
            f"{want[0]}x{want[1]}", self.name, timeout,
        )
        return False

    def remove(self) -> None:
        """Удалить headless-вывод. Безопасно вызывать несколько раз."""
        if not self._created:
            return
        name = self.name
        self.name = None
        self._created = False
        self.x_offset = 0
        if not name:
            return
        log.info("удаляем виртуальный вывод %s", name)
        try:
            hyprctl.output_remove(name)
        except hyprctl.HyprctlError as exc:
            log.error("не удалось удалить виртуальный вывод %s: %s", name, exc)
        # После remove compositor может отдать фокус не тому выводу —
        # возвращаем десктоп пользователю сразу, а не в конце остановки.
        self._refocus_real()

    # -- контекстные менеджеры ------------------------------------------

    def __enter__(self) -> "VirtualOutput":
        self.create()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:  # noqa: D401 - context mgr
        self.remove()

    async def __aenter__(self) -> "VirtualOutput":
        # hyprctl синхронный (subprocess); выполняем в потоке, чтобы не
        # блокировать event loop.
        await asyncio.to_thread(self.create)
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await asyncio.to_thread(self.remove)


class VirtualOutputManager:
    """Создаёт и удаляет N headless-выходов в ряд.

    После каждого create перевычитывает monitors — следующий вывод
    позиционируется относительно обновлённого списка (а не исходного
    снапшота), поэтому выходы выстраиваются в ряд, а не накладываются.

    Использование::

        async with VirtualOutputManager(screens) as mgr:
            for vo in mgr.outputs:
                print(vo.name, vo.x_offset)

    ``mgr.outputs`` — список :class:`VirtualOutput` (в порядке создания).
    ``mgr.placement()`` — список кортежей ``(name, x_offset)``.
    """

    def __init__(self, screens: list[ScreenConfig]) -> None:
        if not screens:
            raise ValueError("нужен хотя бы один ScreenConfig")
        self.screens = list(screens)
        self.outputs: list[VirtualOutput] = []

    def create_all(self) -> list[VirtualOutput]:
        """Создать все выводы последовательно. Возвращает список выводов."""
        self.outputs = []
        # Текущий снапшот мониторов; после каждого create обновляем.
        current_monitors: list[dict[str, Any]] = []
        try:
            current_monitors = hyprctl.monitors()
        except hyprctl.HyprctlError as exc:
            log.error("не удалось снять снапшот monitors: %s", exc)
            raise

        for i, sc in enumerate(self.screens):
            vo = VirtualOutput(sc)
            # Регистрируем вывод ДО create — если create упадёт после
            # ``output create`` (а self-cleanup внутри create не сработает,
            # например при kill -9), _cleanup_best_effort всё равно снимет
            # то, что успело создаться. vo.remove() идемпотентен.
            self.outputs.append(vo)
            try:
                # Передаём текущий снапшот, чтобы вывод i+1 лёг справа от i.
                vo.create(placement_monitors=current_monitors)
            except Exception as exc:
                # Если один вывод не создался — откатываем уже созданные.
                log.error("не удалось создать вывод %d: %s", i, exc)
                self._cleanup_best_effort()
                raise
            # Переснимаем снапшот, чтобы следующий вывод видел новый правый край.
            try:
                current_monitors = hyprctl.monitors()
            except hyprctl.HyprctlError as exc:
                log.warning(
                    "не удалось переснять monitors после создания вывода %d: %s",
                    i, exc,
                )
        log.info(
            "создано %d виртуальных выводов: %s",
            len(self.outputs),
            [(vo.name, vo.x_offset) for vo in self.outputs],
        )
        return self.outputs

    def remove_all(self) -> None:
        """Удалить все выводы (best-effort, даже если какие-то упали)."""
        self._cleanup_best_effort()

    def _cleanup_best_effort(self) -> None:
        """Откатить уже созданные выводы, логируя ошибки."""
        for vo in reversed(self.outputs):
            try:
                vo.remove()
            except Exception as exc:  # noqa: BLE001 - очистка, не глотаем CancelledError
                log.error("ошибка при удалении вывода %s: %s", vo.name, exc)
        self.outputs = []

    def placement(self) -> list[tuple[str, int]]:
        """Вернуть список ``(name, x_offset)`` для всех созданных выводов."""
        return [(vo.name, vo.x_offset) for vo in self.outputs if vo.name]

    # -- контекстные менеджеры ------------------------------------------

    def __enter__(self) -> "VirtualOutputManager":
        self.create_all()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.remove_all()

    async def __aenter__(self) -> "VirtualOutputManager":
        await asyncio.to_thread(self.create_all)
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await asyncio.to_thread(self.remove_all)
