"""``python main.py`` — точка входа PC-стороны HyprScreen.

Разбирает аргументы CLI, загружает конфигурацию (из ``--config`` TOML-файла
с переопределениями из CLI), создаёт виртуальные headless-выводы Hyprland
(1..4 шт., в ряд) и запускает WebSocket-стриминг-сервер до SIGINT/SIGTERM.

Пример
------
::

    python main.py --config config.toml
    python main.py --resolution 1280x720 --fps 24
    python main.py --screens 2                  # два экрана в ряд
    python main.py --capture-backend portal
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import signal
import sys
from typing import Optional, Sequence

from config import Config, ScreenConfig, _parse_resolution, __version__
from logging_setup import setup_logging
from server import HyprScreenServer
from virtual_output import VirtualOutputManager
import hyprctl
import state_file

log = logging.getLogger("hyprscreen.main")


def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="main.py",
        description=(
            "HyprScreen — превратите Android-устройство в беспроводной второй "
            "экран для PC на CachyOS + Hyprland."
        ),
    )
    p.add_argument("--version", action="version", version=f"hyprscreen {__version__}")
    p.add_argument(
        "-c", "--config",
        default=None,
        help="Путь к config.toml. Если не задан — используются встроенные дефолты.",
    )
    p.add_argument(
        "--screens",
        type=int,
        default=None,
        help="Количество виртуальных экранов (1..4). По умолчанию 1. "
             "Клонирует настройки экрана[0] N раз.",
    )
    p.add_argument(
        "--resolution", "-r",
        default=None,
        help="Разрешение виртуального вывода, например 1920x1080 "
             "(переопределяет config; применяется ко всем экранам).",
    )
    p.add_argument(
        "--refresh-rate",
        type=float,
        default=None,
        help="Частота обновления в Гц (по умолчанию 60). Применяется ко всем экранам.",
    )
    p.add_argument(
        "--fps",
        type=int,
        default=None,
        help="Кадров в секунду, отправляемых клиентам (по умолчанию 30). "
             "Применяется ко всем экранам.",
    )
    p.add_argument(
        "--jpeg-quality",
        type=int,
        default=None,
        help="Качество JPEG 1-100 (по умолчанию 80). Применяется ко всем экранам.",
    )
    p.add_argument(
        "--port",
        type=int,
        default=None,
        help="TCP-порт WebSocket-сервера (по умолчанию 8765).",
    )
    p.add_argument(
        "--bind",
        default=None,
        help="Адрес привязки (по умолчанию 0.0.0.0). 127.0.0.1 — для SSH-туннеля.",
    )
    p.add_argument(
        "--capture-backend",
        choices=("grim", "portal"),
        default=None,
        help="Бэкенд захвата: grim (по умолчанию) или portal (PipeWire, "
             "экспериментальный — авто-откат на grim).",
    )
    p.add_argument(
        "--output-name",
        default=None,
        help="Задать имя headless-вывода (например HEADLESS-1). "
             "По умолчанию авто-определение. Применяется к первому экрану.",
    )
    p.add_argument(
        "--discovery",
        dest="discovery",
        default=None,
        action=argparse.BooleanOptionalAction,
        help="Включить/выключить UDP discovery. --no-discovery для отключения.",
    )
    p.add_argument(
        "--log-level",
        default="INFO",
        help="Уровень логирования (DEBUG, INFO, WARNING, ERROR). По умолчанию INFO.",
    )
    p.add_argument(
        "--auth-token",
        default=None,
        help="Токен авторизации. Если задан — клиент обязан прислать "
             "{\"type\":\"auth\",\"token\":\"...\"} первым сообщением.",
    )
    p.add_argument(
        "--input-rate-limit",
        type=int,
        default=None,
        help="Max input-сообщений/сек на клиент (0 = без лимита). Защита от flood.",
    )
    p.add_argument(
        "--tls",
        dest="tls",
        default=None,
        action=argparse.BooleanOptionalAction,
        help="Включить TLS (wss://). --no-tls для отключения.",
    )
    p.add_argument(
        "--tls-cert",
        default=None,
        help="Путь к PEM-сертификату для TLS (иначе self-signed авто).",
    )
    p.add_argument(
        "--tls-key",
        default=None,
        help="Путь к PEM-ключу для TLS.",
    )
    p.add_argument(
        "--image-format",
        choices=("jpeg", "webp"),
        default=None,
        help="Формат кадров: jpeg (по умолчанию) или webp (лучше качество/размер).",
    )
    p.add_argument(
        "--log-to-file",
        dest="log_to_file",
        default=None,
        action=argparse.BooleanOptionalAction,
        help="Писать лог в файл с ротацией (по умолчанию вкл). "
             "Используйте --no-log-to-file для отключения.",
    )
    p.add_argument(
        "--no-virtual-output",
        action="store_true",
        help=(
            "Не создавать виртуальный вывод Hyprland; вместо этого захватить "
            "вывод с именем из --output-name (полезно для отладки на реальном "
            "мониторе). В этом режиме --screens игнорируется (1 экран)."
        ),
    )
    # Подкоманды.
    sub = p.add_subparsers(dest="command")
    sub.add_parser("run", help="Запустить сервер (по умолчанию).")
    sub.add_parser("list", help="Показать мониторы/воркспейсы.")
    sub.add_parser("reset", help="Удалить все HEADLESS-* и state-файл.")
    sub.add_parser("diagnose", help="Диагностика IPC Hyprland.")
    sub.add_parser("grimtest", help="Тест захвата grim для HEADLESS-*.")
    p_ws = sub.add_parser("workspace", help="Перенести воркспейс на HEADLESS.")
    p_ws.add_argument("workspace", help="Номер воркспейса (1-10).")
    p_ws.add_argument("--screen", "-s", type=int, default=0, help="Индекс экрана (0=HEADLESS-1).")
    p_ws.add_argument("--move", action="store_true", help="Одноразовый перенос вместо правила.")
    p_ws.add_argument("--no-focus", action="store_true", help="Не переключаться.")
    sub.add_parser("interactive", help="Интерактивное меню (сервер в фоне + обои/воркспейс).")
    sub.add_parser("kill", help="Найти и остановить работающий сервер + очистить HEADLESS.")
    return p


def _apply_cli_overrides(cfg: Config, args: argparse.Namespace) -> Config:
    """Применить CLI-переопределения поверх загруженного/дефолтного конфига.

    ``--resolution/--fps/--jpeg-quality/--refresh-rate/--capture-backend``
    применяются ко ВСЕМ экранам. ``--screens N`` клонирует экран[0] N раз
    (если N отличается от текущего числа экранов).
    """
    # Сначала обрабатываем --screens (клонирование screen[0]).
    if args.screens is not None:
        if args.screens < 1 or args.screens > 4:
            raise ValueError(f"--screens должен быть 1..4, получено {args.screens}")
        if len(cfg.screens) != args.screens:
            base = cfg.screens[0]
            cfg.screens = [
                ScreenConfig(
                    resolution=base.resolution,
                    refresh_rate=base.refresh_rate,
                    fps=base.fps,
                    jpeg_quality=base.jpeg_quality,
                    capture_backend=base.capture_backend,
                    output_name=None,  # имена авто-определятся
                )
                for _ in range(args.screens)
            ]
    # Общие переопределения применяем ко всем экранам.
    if args.resolution:
        res = _parse_resolution(args.resolution)
        for s in cfg.screens:
            s.resolution = res
    if args.refresh_rate is not None:
        for s in cfg.screens:
            s.refresh_rate = args.refresh_rate
    if args.fps is not None:
        for s in cfg.screens:
            s.fps = args.fps
    if args.jpeg_quality is not None:
        for s in cfg.screens:
            s.jpeg_quality = args.jpeg_quality
    if args.capture_backend is not None:
        for s in cfg.screens:
            s.capture_backend = args.capture_backend
    # --output-name применяем только к первому экрану.
    if args.output_name is not None:
        cfg.screens[0].output_name = args.output_name
    # Верхнеуровневые поля.
    if args.port is not None:
        cfg.port = args.port
    if args.bind is not None:
        cfg.bind_address = args.bind
    if args.discovery is not None:
        cfg.discovery_enabled = args.discovery
    # Новые opt-in поля.
    if args.auth_token is not None:
        cfg.auth_token = args.auth_token
    if args.input_rate_limit is not None:
        cfg.input_rate_limit = args.input_rate_limit
    if args.tls is not None:
        cfg.tls_enabled = args.tls
    if args.tls_cert is not None:
        cfg.tls_cert = args.tls_cert
    if args.tls_key is not None:
        cfg.tls_key = args.tls_key
    if args.image_format is not None:
        for s in cfg.screens:
            s.image_format = args.image_format
    if args.log_to_file is not None:
        cfg.log_to_file = args.log_to_file
    return cfg


def _load_config(args: argparse.Namespace) -> Config:
    """Загрузить конфиг из файла (если задан) и применить CLI-переопределения."""
    if args.config:
        cfg = Config.from_file(args.config)
    else:
        # Дефолт берём с одним экраном; --screens ниже добавит остальные.
        cfg = Config.default(screen_count=1)
    return _apply_cli_overrides(cfg, args)


async def _run(cfg: Config, create_outputs: bool) -> int:
    """Создать виртуальные выводы (если надо) и запустить сервер."""
    if create_outputs:
        # Мультиэкранный путь: VirtualOutputManager создаёт все выводы в ряд.
        try:
            mgr = VirtualOutputManager(cfg.screens)
            await mgr.__aenter__()
        except Exception as exc:
            log.error("не удалось создать виртуальные выводы: %s", exc)
            return 1
        placement = mgr.placement()
        if len(placement) != len(cfg.screens):
            log.error(
                "создано %d выводов, ожидалось %d — откат",
                len(placement), len(cfg.screens),
            )
            await mgr.__aexit__(None, None, None)
            return 1
        # Собираем список (name, x_offset, ScreenConfig) для сервера.
        screen_specs: list[tuple[str, int, ScreenConfig]] = [
            (placement[i][0], placement[i][1], cfg.screens[i])
            for i in range(len(placement))
        ]
    else:
        # Режим --no-virtual-output: один экран, берём существующий вывод.
        if not cfg.screens[0].output_name:
            log.error(
                "--no-virtual-output требует --output-name, чтобы знать, какой "
                "вывод Hyprland захватывать."
            )
            return 2
        mgr = None
        screen_specs = [
            (cfg.screens[0].output_name, 0, cfg.screens[0]),
        ]

    server = HyprScreenServer(cfg, screen_specs)
    try:
        await server.start()
    except OSError as exc:
        log.error("не удалось привязать сервер: %s", exc)
        if mgr is not None:
            await mgr.__aexit__(None, None, None)
        return 1

    # Подключаемgraceful shutdown на SIGINT/SIGTERM.
    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()

    def _on_signal() -> None:
        log.info("получен сигнал, останавливаемся")
        stop_event.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _on_signal)
        except NotImplementedError:
            # add_signal_handler доступен не на всех платформах (например,
            # ProactorEventLoop на Windows). CachyOS использует epoll, так
            # что эта ветка не должна срабатывать.
            signal.signal(sig, lambda *_: stop_event.set())

    serve_task = asyncio.create_task(server.serve(), name="server-serve")
    stop_task = asyncio.create_task(stop_event.wait(), name="stop-event")
    try:
        await asyncio.wait({serve_task, stop_task}, return_when=asyncio.FIRST_COMPLETED)
    finally:
        await server.stop()
        # Дождаться serve_task (без отмены), чтобы shutdown в его finally отработал.
        if not serve_task.done():
            try:
                await serve_task
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                log.warning("serve-задача завершена с ошибкой: %s", exc)
        else:
            # Если задача уже упала — достаём исключение, чтобы залогировать.
            exc = serve_task.exception()
            if exc is not None:
                log.error("serve-задача упала: %s", exc)
        if not stop_task.done():
            stop_task.cancel()
            try:
                await stop_task
            except asyncio.CancelledError:
                pass
        if mgr is not None:
            await mgr.__aexit__(None, None, None)
    return 0


def _cmd_list() -> int:
    """Показать мониторы и воркспейсы."""
    print("=== Мониторы ===")
    try:
        for m in hyprctl.monitors():
            name = m.get("name", "?")
            w = m.get("width", "?")
            h = m.get("height", "?")
            x = m.get("x", 0)
            y = m.get("y", 0)
            mark = " ← виртуальный" if str(name).startswith("HEADLESS") else ""
            print(f"  {name:16s} {w}x{h} @ ({x},{y}){mark}")
    except hyprctl.HyprctlError as exc:
        print(f"  ошибка: {exc}", file=sys.stderr)
    print("\n=== Воркспейсы ===")
    try:
        for w in hyprctl.list_workspaces():
            ws_id = w.get("id", "?")
            mon = w.get("monitor", "?")
            mark = " ← на виртуальном" if str(mon).startswith("HEADLESS") else ""
            print(f"  {ws_id:4s} монитор: {mon}{mark}")
    except hyprctl.HyprctlError as exc:
        print(f"  ошибка: {exc}", file=sys.stderr)
    return 0


def _cmd_reset() -> int:
    """Удалить все HEADLESS-* и state-файл."""
    print("=== Сброс HyprScreen ===")
    removed = hyprctl.cleanup_phantom_outputs()
    if removed:
        for n in removed:
            print(f"  — {n}")
    else:
        print("  уже чисто")
    state_file.clear_state()
    print("  state-файл очищен")
    return 0


def _cmd_workspace(args) -> int:
    """Перенести воркспейс на HEADLESS."""
    ws = args.workspace
    monitor = state_file.monitor_for_screen(args.screen)
    if not monitor:
        headless = hyprctl.find_headless_monitors()
        if headless:
            monitor = headless[0]
        else:
            print("HEADLESS не найден. Запустите сервер: ./run.sh", file=sys.stderr)
            return 1
    log.info("переносим воркспейс %s на %s", ws, monitor)
    try:
        if args.move:
            reply = hyprctl.move_workspace_to_monitor_checked(ws, monitor)
        else:
            reply = hyprctl.workspace_rule(ws, monitor, default=True)
        print(f"✓ Воркспейс {ws} → {monitor}")
    except hyprctl.HyprctlError as exc:
        print(f"Ошибка: {exc}", file=sys.stderr)
        return 1
    if not args.no_focus:
        try:
            hyprctl.focus_workspace(ws)
        except Exception:
            pass
    return 0


def _cmd_grimtest() -> int:
    """Тест захвата grim для HEADLESS-*."""
    import subprocess
    import shutil
    import time
    try:
        mons = hyprctl.monitors()
    except hyprctl.HyprctlError as exc:
        print(f"  ошибка: {exc}", file=sys.stderr)
        return 1
    headless = [m for m in mons if str(m.get("name", "")).startswith("HEADLESS")]
    if not headless:
        print("  HEADLESS не найден. Запустите сервер.")
        return 1
    grim_path = shutil.which("grim")
    if not grim_path:
        print("  grim не установлен.", file=sys.stderr)
        return 1
    for m in headless:
        name = m.get("name", "?")
        cmd = [grim_path, "-o", name, "-t", "jpeg", "-q", "80", "-"]
        t0 = time.monotonic()
        try:
            proc = subprocess.run(cmd, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10)
            dt = time.monotonic() - t0
            if proc.returncode != 0:
                err = proc.stderr.decode("utf-8", "replace").strip()
                print(f"  {name}: ✗ grim exit={proc.returncode}: {err}")
            else:
                size = len(proc.stdout)
                print(f"  {name}: ✓ {size} байт за {dt:.2f}s")
        except Exception as exc:
            print(f"  {name}: ✗ {exc}")
    return 0


def _cmd_interactive() -> int:
    """Интерактивное меню: сервер в фоне + выбор обоев/воркспейса."""
    import subprocess
    import os
    import signal
    import time

    log_file = "/tmp/hyprscreen-server.log"
    script_dir = os.path.dirname(os.path.abspath(__file__))
    venv_python = os.path.join(script_dir, ".venv", "bin", "python")
    python_bin = venv_python if os.path.exists(venv_python) else sys.executable

    # Загружаем конфиг из config.toml если есть, иначе дефолт.
    config_path = os.path.join(script_dir, "config.toml")
    if os.path.exists(config_path):
        try:
            cfg = Config.from_file(config_path)
        except Exception:
            cfg = Config.default()
    else:
        cfg = Config.default()

    # Команда запуска сервера. --no-log-to-file — чтобы весь лог шёл в stdout
    # (перенаправляется в /tmp/hyprscreen-server.log), а не в файл.
    server_cmd = [python_bin, "main.py", "--log-level", "INFO", "--no-log-to-file"]
    if os.path.exists(config_path):
        server_cmd.extend(["-c", config_path])
    if cfg.auth_token:
        server_cmd.extend(["--auth-token", cfg.auth_token])
    print(f"Запускаю сервер в фоне: {' '.join(server_cmd)}")
    print(f"Лог сервера: {log_file}")
    try:
        server_proc = subprocess.Popen(
            server_cmd,
            stdout=open(log_file, "w"),
            stderr=subprocess.STDOUT,
            cwd=script_dir,
            env={**os.environ, "PYTHONPATH": script_dir},
            start_new_session=True,
        )
    except Exception as exc:
        print(f"Не удалось запустить сервер: {exc}", file=sys.stderr)
        return 1
    print(f"Сервер запущен (pid={server_proc.pid}). Ожидание...")
    time.sleep(2)

    # Автоприменение сохранённых настроек.
    import settings_store
    saved = settings_store.load_settings()
    if saved:
        print("\n--- Восстановление настроек ---")
        saved_wp = saved.get("wallpaper")
        if saved_wp and os.path.exists(os.path.expanduser(saved_wp)):
            print(f"  Обои: {saved_wp}")
            _apply_wallpaper(saved_wp)
        bindings = saved.get("workspaces", {})
        if bindings and isinstance(bindings, dict):
            for ws_id, scr_idx in bindings.items():
                try:
                    monitor = state_file.monitor_for_screen(int(scr_idx))
                    if monitor:
                        hyprctl.workspace_rule(str(ws_id), monitor, default=True)
                        print(f"  Воркспейс {ws_id} → {monitor}")
                except Exception as exc:
                    print(f"  ⚠ Воркспейс {ws_id}: {exc}")
        print()

    # Определяем LAN IP.
    import socket as _socket
    try:
        s = _socket.socket(_socket.AF_INET, _socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        lan_ip = s.getsockname()[0]
        s.close()
    except Exception:
        lan_ip = "?"

    wp_dir = os.path.expanduser("~/Pictures")
    try:
        while True:
            print("\n" + "=" * 50)
            print("  HyprScreen — интерактивное меню")
            print("=" * 50)
            # Информация о подключении.
            port = cfg.port if cfg else 8765
            token = cfg.auth_token if cfg else None
            print(f"  IP:     {lan_ip}")
            print(f"  Порт:   {port}")
            print(f"  Токен:  {token if token else '(нет)'}")
            print()
            if server_proc.poll() is not None:
                print(f"  ⚠ Сервер остановлен (код {server_proc.returncode})")
            else:
                try:
                    mons = hyprctl.monitors()
                    headless = [str(m.get("name", "")) for m in mons if str(m.get("name", "")).startswith("HEADLESS")]
                    if headless:
                        print(f"  ✓ Сервер активен, HEADLESS: {', '.join(headless)}")
                    else:
                        print("  ✓ Сервер активен")
                except Exception:
                    print("  ✓ Сервер активен")
            print()
            print("  1) Выбрать обои")
            print("  2) Перенести воркспейс на телефон")
            print("  3) Показать статус (list)")
            print("  4) Показать лог сервера")
            print("  5) Перезапустить сервер")
            print("  0) Выход (остановить сервер)")
            print()
            try:
                choice = input("Выбор [0-5]: ").strip()
            except (EOFError, KeyboardInterrupt):
                choice = "0"
                print()
            if choice == "0":
                break
            elif choice == "1":
                _interactive_wallpaper(wp_dir)
            elif choice == "2":
                _interactive_workspace()
            elif choice == "3":
                _cmd_list()
            elif choice == "4":
                try:
                    with open(log_file, "r") as f:
                        for line in f.readlines()[-20:]:
                            print(line.rstrip())
                except Exception as exc:
                    print(f"Ошибка: {exc}")
            elif choice == "5":
                print("Перезапуск...")
                try:
                    os.killpg(os.getpgid(server_proc.pid), signal.SIGTERM)
                    server_proc.wait(timeout=5)
                except Exception:
                    pass
                server_proc = subprocess.Popen(
                    server_cmd,
                    stdout=open(log_file, "w"),
                    stderr=subprocess.STDOUT,
                    cwd=script_dir,
                    env={**os.environ, "PYTHONPATH": script_dir},
                    start_new_session=True,
                )
                print(f"Перезапущен (pid={server_proc.pid})")
                time.sleep(2)
            else:
                print("Неверный выбор")
    finally:
        print("\nОстанавливаю сервер...")
        try:
            os.killpg(os.getpgid(server_proc.pid), signal.SIGTERM)
            server_proc.wait(timeout=8)
            print("Сервер остановлен.")
        except Exception:
            try:
                server_proc.kill()
            except Exception:
                pass
        try:
            hyprctl.cleanup_phantom_outputs()
        except Exception:
            pass
        state_file.clear_state()
    return 0


def _apply_wallpaper(wp_path: str) -> bool:
    """Применить обои на все HEADLESS через swww."""
    import subprocess
    import shutil
    import os
    wp_path = os.path.expanduser(wp_path)
    if not os.path.exists(wp_path):
        print(f"  ⚠ Файл не найден: {wp_path}")
        return False
    swww = shutil.which("swww")
    if swww is None:
        print("  ⚠ swww не установлен: sudo pacman -S swww")
        return False
    try:
        mons = hyprctl.monitors()
        headless = [str(m.get("name", "")) for m in mons if str(m.get("name", "")).startswith("HEADLESS")]
    except Exception:
        headless = []
    if not headless:
        return False
    ok = True
    for name in headless:
        cmd = [swww, "img", "-o", name, "--resize", "crop", wp_path]
        try:
            proc = subprocess.run(cmd, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
            if proc.returncode != 0:
                print(f"  ⚠ {name}: {proc.stderr.strip()}")
                ok = False
        except Exception as exc:
            print(f"  ⚠ {name}: {exc}")
            ok = False
    return ok


def _interactive_wallpaper(wp_dir: str) -> None:
    """Выбор обоев из wp_dir. Выбор сохраняется в settings."""
    import glob
    import os
    import settings_store
    wp_dir = os.path.expanduser(wp_dir)
    if not os.path.isdir(wp_dir):
        print(f"Каталог {wp_dir} не существует.")
        return
    files: list[str] = []
    for ext in ("*.jpg", "*.jpeg", "*.png", "*.webp", "*.bmp"):
        files.extend(glob.glob(os.path.join(wp_dir, ext)))
        files.extend(glob.glob(os.path.join(wp_dir, "**", ext), recursive=True))
    files = sorted(set(files))
    if not files:
        print(f"В {wp_dir} нет изображений.")
        return
    saved_wp = settings_store.get_wallpaper()
    print(f"\n--- Обои в {wp_dir} ---")
    for i, f in enumerate(files, 1):
        mark = " ✓" if saved_wp and os.path.expanduser(saved_wp) == f else ""
        print(f"  {i}) {os.path.basename(f)}{mark}")
    print(f"  0) назад")
    try:
        choice = input("Выбор: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return
    if choice == "0" or not choice:
        return
    try:
        idx = int(choice) - 1
        if idx < 0 or idx >= len(files):
            print("Неверный индекс")
            return
    except ValueError:
        print("Нужно число")
        return
    wp_path = files[idx]
    if _apply_wallpaper(wp_path):
        settings_store.set_wallpaper(wp_path)
        print(f"  ✓ Обои сохранены: {wp_path}")


def _interactive_workspace() -> None:
    """Выбор воркспейса для переноса на телефон. Выбор сохраняется."""
    import settings_store
    try:
        workspaces = hyprctl.list_workspaces()
    except hyprctl.HyprctlError as exc:
        print(f"Ошибка: {exc}")
        return
    saved_bindings = settings_store.get_workspace_bindings()
    print("\n--- Воркспейсы ---")
    for w in workspaces:
        ws_id = w.get("id", "?")
        mon = w.get("monitor", "?")
        mark = " ← на телефоне" if str(mon).startswith("HEADLESS") else ""
        print(f"  {ws_id} (монитор: {mon}){mark}")
    if saved_bindings:
        print("  Сохранённые привязки:")
        for ws_id, scr_idx in saved_bindings.items():
            print(f"    воркспейс {ws_id} → экран {scr_idx}")
    print("  Введите номер воркспейса (1-10) или 0 для назад:")
    try:
        choice = input("Воркспейс: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return
    if choice == "0" or not choice:
        return
    monitor = state_file.monitor_for_screen(0)
    if not monitor:
        headless = hyprctl.find_headless_monitors()
        if headless:
            monitor = headless[0]
        else:
            print("HEADLESS не найден.")
            return
    try:
        hyprctl.workspace_rule(choice, monitor, default=True)
        settings_store.set_workspace_binding(choice, 0)
        print(f"✓ Воркспейс {choice} → {monitor} (сохранено)")
        try:
            hyprctl.focus_workspace(choice)
            print(f"  Переключились на воркспейс {choice}")
        except Exception:
            pass
    except hyprctl.HyprctlError as exc:
        print(f"Ошибка: {exc}")


def _cmd_kill() -> int:
    """Найти и остановить работающий сервер HyprScreen + очистить HEADLESS."""
    import subprocess
    import os
    import signal
    import time

    print("=== Поиск и остановка сервера HyprScreen ===")

    # 1. Ищем процессы main.py (сервер и interactive).
    killed = []
    try:
        result = subprocess.run(
            ["pgrep", "-f", "main.py"],
            capture_output=True, text=True, timeout=5,
        )
        pids = [int(p) for p in result.stdout.strip().split("\n") if p.strip()]
    except Exception:
        pids = []

    # Исключаем себя.
    my_pid = os.getpid()
    pids = [p for p in pids if p != my_pid]

    if pids:
        for pid in pids:
            try:
                os.kill(pid, signal.SIGTERM)
                print(f"  SIGTERM → pid {pid}")
                killed.append(pid)
            except ProcessLookupError:
                pass
            except PermissionError:
                print(f"  ⚠ Нет прав на pid {pid} (sudo kill {pid}?)")
        # Ждём завершения.
        time.sleep(2)
        # Проверяем кто ещё жив — добиваем.
        for pid in killed:
            try:
                os.kill(pid, 0)  # проверка жив ли
                os.kill(pid, signal.SIGKILL)
                print(f"  SIGKILL → pid {pid} (не завершился по SIGTERM)")
            except ProcessLookupError:
                pass
        print(f"  Остановлено процессов: {len(killed)}")
    else:
        print("  Работающий сервер не найден.")

    # 2. Освобождаем порт 8765 если занят.
    try:
        result = subprocess.run(
            ["lsof", "-ti:8765"],
            capture_output=True, text=True, timeout=5,
        )
        port_pids = [int(p) for p in result.stdout.strip().split("\n") if p.strip()]
        for pid in port_pids:
            if pid not in killed and pid != my_pid:
                try:
                    os.kill(pid, signal.SIGKILL)
                    print(f"  Порт 8765 освобождён (pid {pid})")
                except Exception:
                    pass
    except Exception:
        pass

    # 3. Очищаем фантомные HEADLESS.
    print("\n--- Очистка HEADLESS ---")
    try:
        removed = hyprctl.cleanup_phantom_outputs()
        if removed:
            for n in removed:
                print(f"  — {n}")
        else:
            print("  Уже чисто")
    except Exception as exc:
        print(f"  ⚠ {exc}")

    # 4. Чистим state-файл.
    state_file.clear_state()
    print("  state-файл очищен")
    print("\nГотово.")
    return 0


def main(argv: Optional[Sequence[str]] = None) -> int:
    """Точка входа. Возвращает код выхода процесса."""
    parser = _build_arg_parser()
    args = parser.parse_args(argv)
    cmd = args.command
    # Подкоманды, которым не нужен конфиг/сервер.
    if cmd == "list":
        setup_logging("WARNING")
        return _cmd_list()
    elif cmd == "reset":
        setup_logging("WARNING")
        return _cmd_reset()
    elif cmd == "diagnose":
        setup_logging("WARNING")
        hyprctl.diagnose()
        return 0
    elif cmd == "grimtest":
        setup_logging("WARNING")
        return _cmd_grimtest()
    elif cmd == "workspace":
        setup_logging("INFO")
        return _cmd_workspace(args)
    elif cmd == "interactive":
        setup_logging("WARNING")
        return _cmd_interactive()
    elif cmd == "kill":
        setup_logging("WARNING")
        return _cmd_kill()
    # По умолчанию (без подкоманды или run) — запускаем сервер.
    cfg = _load_config(args)
    setup_logging(args.log_level, log_to_file=cfg.log_to_file, log_file=cfg.log_file)
    log.info("HyprScreen %s запускается с конфигом: %s", __version__, cfg.to_dict())
    try:
        return asyncio.run(_run(cfg, create_outputs=not args.no_virtual_output))
    except KeyboardInterrupt:
        return 130
    except asyncio.CancelledError:
        return 130
    except Exception as exc:  # noqa: BLE001
        log.error("фатальная ошибка: %s", exc, exc_info=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
