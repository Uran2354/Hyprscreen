@file:Suppress("SpellCheckingInspection") // HyprScreen/keysym — не опечатки

package com.example.hyprscreen

import android.app.Application
import android.util.Log

/**
 * Точка входа Application для Android-клиента HyprScreen.
 *
 * Сейчас — просто инициализирует синглтон-доступ к [Prefs] и тегирует лог;
 * зарезервировано под будущую инициализацию (например, общий OkHttpClient).
 *
 * Подключается в манифесте через `android:name=".HyprScreenApp"` на элементе
 * `<application>` (см. SETUP.md).
 */
class HyprScreenApp : Application() {

    /** Лениво создаваемая обёртка [Prefs], привязанная к application. */
    val prefs: Prefs by lazy { Prefs(this) }

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Запуск приложения HyprScreen")
    }

    companion object {
        private const val TAG = "HyprScreen/App"
    }
}
