"""Инъекция КЛАВИАТУРЫ для HyprScreen — через wtype.

Единственный канал ввода с телефона — клавиатура приложения (тап по
видео поднимает мягкую клавиатуру): POST /key ({"keysym","modifiers"}) и
POST /text ({"text"}). Тачпада из экрана телефона НЕТ (решение
пользователя): pointer-события протоколом 3.x не предусмотрены и сюда
не попадают.

wtype — способ из 2.2.0 (тот же бэкенд текста/клавиш): виртуального
UInput-устройства не нужно, Wayland-композитор получает события напрямую.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
import threading
import time
from collections import deque

log = logging.getLogger("hyprscreen.input")

WTYPE_MODIFIERS = {
    "ctrl": "ctrl", "control": "ctrl",
    "shift": "shift",
    "alt": "alt",
    "super": "super", "meta": "super", "win": "super", "logo": "super",
}


class InputError(RuntimeError):
    """Понятная ошибка инъекции (уходит клиенту текстом ошибки)."""


class KeyboardInjector:
    """Отправка клавиш/текста в сессию Hyprland через wtype.

    rate_limit > 0 — не более N событий в секунду (защита от шторма,
    как input_rate_limit в 2.2.0).
    """

    def __init__(self, rate_limit: int = 0) -> None:
        self._wtype = shutil.which("wtype")
        self._rate_limit = max(0, int(rate_limit))
        self._lock = threading.Lock()
        self._recent: deque[float] = deque()

    @property
    def available(self) -> bool:
        return self._wtype is not None

    def missing_message(self) -> str:
        return "wtype не установлен: sudo pacman -S wtype"

    # ------------------------------------------------------------------ API
    def inject_key(self, keysym: str, modifiers: list[str] | None = None) -> None:
        if not keysym or not isinstance(keysym, str):
            raise InputError("key требует непустой keysym")
        if keysym.startswith("-"):
            # wtype разбирал бы его как опцию командной строки; настоящих
            # X11-keysyms, начинающихся с '-', не существует.
            raise InputError(f"подозрительный keysym: {keysym!r}")
        self._ensure_ready()
        mods = []
        for mod in (modifiers or []):
            flag = WTYPE_MODIFIERS.get(str(mod).lower())
            if flag is None:
                raise InputError(f"неизвестный модификатор: {mod!r}")
            mods.append(flag)
        args = [self._wtype]
        for flag in mods:
            args += ["-M", flag]
        args += ["-k", keysym]
        self._run(args)

    def inject_text(self, text: str) -> None:
        if not isinstance(text, str) or not text:
            raise InputError("text требует непустую строку")
        self._ensure_ready()
        # Текст передаётся через STDIN (wtype без аргумента читает stdin):
        # так текст, начинающийся с '-', не будет разобран как опция.
        self._run([self._wtype, "-d", "0"], stdin_text=text)

    # -------------------------------------------------------------- внутренне
    def _ensure_ready(self) -> None:
        if not self.available:
            raise InputError(self.missing_message())
        self._check_rate()

    def _check_rate(self) -> None:
        if self._rate_limit <= 0:
            return
        with self._lock:
            now = time.monotonic()
            while self._recent and now - self._recent[0] > 1.0:
                self._recent.popleft()
            if len(self._recent) >= self._rate_limit:
                raise InputError(
                    f"превышен лимит ввода ({self._rate_limit}/с)"
                )
            self._recent.append(now)

    def _run(self, argv: list[str], stdin_text: str | None = None) -> None:
        try:
            proc = subprocess.run(
                argv, check=False,
                input=stdin_text,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, timeout=10,
            )
        except FileNotFoundError as exc:
            raise InputError(f"команда не найдена: {argv[0]!r}") from exc
        except subprocess.TimeoutExpired:
            return  # wtype завис — не роняем сервер
        if proc.returncode != 0:
            detail = (proc.stdout or proc.stderr or "").strip()
            log.warning("wtype exit %d: %s", proc.returncode, detail)
            raise InputError(detail[:200] or f"wtype exit {proc.returncode}")
