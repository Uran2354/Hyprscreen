#!/usr/bin/env bash
# Запускатор HyprScreen.
#
# Без аргументов:  ./run.sh
#   → интерактивное меню (сервер в фоне + выбор обоев/воркспейса).
#
# С аргументами:  ./run.sh --screens 2 --wallpaper ~/wp.jpg
#   → прямая передача в `python main.py` (как раньше).
#
# Подкоманды:  ./run.sh run | workspace N | list | reset | diagnose | grimtest

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
cd "$SCRIPT_DIR"

PYTHON="${PYTHON:-python}"
VENV_DIR="${VENV_DIR:-$SCRIPT_DIR/.venv}"
if [[ -x "$VENV_DIR/bin/python" ]]; then
    PYTHON="$VENV_DIR/bin/python"
fi

export PYTHONPATH="$SCRIPT_DIR${PYTHONPATH:+:$PYTHONPATH}"

# Без аргументов → интерактивное меню.
if [[ $# -eq 0 ]]; then
    exec "$PYTHON" main.py interactive
else
    exec "$PYTHON" main.py "$@"
fi
