// HyprScreenTicker.qml — виджет-«пилюля» для панели quickshell.
//
// Показывает:
//   • «выкл»              — трансляция выключена
//   • 192.168.x.x:8080    — включена, телефон ещё не открыл страницу
//   • IP:8080 ●           — кто-то смотрит
//
// Управление мышью:
//   ЛКМ — вкл/выкл трансляцию
//
// Встраивание в панель вашего шелла:
//   import "./hyprscreen" as HyprScreen
//   ... ваш Row/каркас бара ...
//   HyprScreen.HyprScreenTicker {}
// =============================================================================
import QtQuick
import Quickshell
import "."

Rectangle {
    id: root

    // ---- настраиваемо ----
    property int  padX: 10
    property real fontScale: 1.0
    property color cOff:      "#9a9aa5"
    property color cIdle:     "#34d399"   // включена, никто не смотрит
    property color cConnected: "#fbbf24"  // телефон смотрит
    property color cSurface:  "#1b1b22"
    property color cBorder:   "#2c2c35"

    readonly property color accent: !svc.running ? cOff
                                  : svc.connected ? cConnected
                                  : cIdle
    readonly property string label: !svc.running ? "выкл"
                                  : svc.connected ? svc.hostPort + " ●"
                                  : svc.hostPort

    Service { id: svc }

    implicitWidth: row.implicitWidth + padX * 2
    implicitHeight: Math.round(30 * fontScale)
    radius: height / 2.4
    color: cSurface
    border.width: 1
    border.color: Qt.rgba(accent.r, accent.g, accent.b, svc.running ? 0.85 : 0.35)

    Row {
        id: row
        anchors.centerIn: parent
        spacing: 6

        Text {
            text: "📱"
            font.pixelSize: Math.round(13 * root.fontScale)
            anchors.verticalCenter: parent.verticalCenter
            opacity: svc.running ? 1 : 0.45
        }
        Text {
            text: root.label
            font.pixelSize: Math.round(12 * root.fontScale)
            font.family: "monospace"
            color: svc.running ? "#e8e8ee" : root.cOff
            anchors.verticalCenter: parent.verticalCenter
        }
    }

    MouseArea {
        id: ma
        anchors.fill: parent
        acceptedButtons: Qt.LeftButton
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: (mouse) => {
            svc.toggle();
        }
    }

    // Подсветка при наведении
    Rectangle {
        anchors.fill: parent
        radius: parent.radius
        color: Qt.rgba(1, 1, 1, ma.containsMouse ? 0.06 : 0)
        Behavior on color { ColorAnimation { duration: 120 } }
    }
}
